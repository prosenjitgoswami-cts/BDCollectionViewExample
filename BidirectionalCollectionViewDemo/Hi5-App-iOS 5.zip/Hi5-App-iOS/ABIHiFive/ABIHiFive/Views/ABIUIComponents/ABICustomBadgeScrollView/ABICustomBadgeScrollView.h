    //
    //  ABICustomBadgeScrollView.h
    //  ABIHiFive
    //
    //  Created by Prsenjit Goswami on 18/08/16.
    //  Copyright © 2016 Cognizant. All rights reserved.
    //
#import "ABISFEarnBadgesDataModel.h"
#import <UIKit/UIKit.h>
@protocol ABICustomBadgeScrollViewProtocol <NSObject>
- (void)tappedOnBadge;
@end
@interface ABICustomBadgeScrollView : UIView
@property (nonnull, strong, nonatomic) NSArray<ABISFBadgesDetailsNameWiseDataModel *> *rosterEarnBadges;
@property (nullable, weak, nonatomic) id<ABICustomBadgeScrollViewProtocol> delegate;
@end
