    //
    //  ABICustomBadgeScrollView.m
    //  ABIHiFive
    //
    //  Created by Prsenjit Goswami on 18/08/16.
    //  Copyright © 2016 Cognizant. All rights reserved.
    //
#import "ABICustomBadgeScrollView.h"
#import "ABISFBadgesDetailsNameWiseDataModel.h"
#import "ABISFRosterDataModel.h"
#import "Constants.h"
#import "CustomBadge.h"
#import "UIFont+ABIFont.h"

@interface ABICustomBadgeScrollView () {
    CGRect badgeRect;
}
@property (strong, nonatomic) UIScrollView *myScrollView;
@property (strong, nonatomic) UILabel *noBadgesLabel;
@property (strong, nonatomic) NSArray *horizontalContraints1;
@property (strong, nonatomic) NSArray *horizontalContraints2;
@end
@implementation ABICustomBadgeScrollView
    // TODO: refactor
- (instancetype)initWithCoder:(NSCoder *)aDecoder {
    self = [super initWithCoder:aDecoder];
    if (self) {
    }
    return self;
}
- (void)dealloc {
    _myScrollView = nil;
    _noBadgesLabel = nil;
    _horizontalContraints1 = nil;
    _horizontalContraints2 = nil;
}
- (void)setupUI {
    self.horizontalContraints1 = [[NSArray alloc] init];
    self.horizontalContraints2 = [[NSArray alloc] init];
    if (_myScrollView) {
        [_myScrollView removeFromSuperview];
        _myScrollView = nil;
    }
    if (_noBadgesLabel) {
        [_noBadgesLabel removeFromSuperview];
        _noBadgesLabel = nil;
    }
    NSDictionary *views = @{ @"myScrollView" : self.myScrollView, @"noBadgesLabel" : self.noBadgesLabel };
    [self addSubview:self.myScrollView];
    [self addSubview:self.noBadgesLabel];
    [self addConstraints:[NSLayoutConstraint constraintsWithVisualFormat:@"V:|[myScrollView]|" options:0 metrics:nil views:views]];
    [self addConstraints:[NSLayoutConstraint constraintsWithVisualFormat:@"V:[noBadgesLabel(20)]|" options:0 metrics:nil views:views]];
    self.horizontalContraints1 =
    [NSLayoutConstraint constraintsWithVisualFormat:@"H:|[myScrollView][noBadgesLabel(0)]|" options:0 metrics:nil views:views];
    self.horizontalContraints2 =
    [NSLayoutConstraint constraintsWithVisualFormat:@"H:|[myScrollView(50)][noBadgesLabel]|" options:0 metrics:nil views:views];
}
- (UIScrollView *)myScrollView {
    if (!_myScrollView) {
        _myScrollView = [[UIScrollView alloc] init];
        _myScrollView.showsHorizontalScrollIndicator = NO;
        _myScrollView.translatesAutoresizingMaskIntoConstraints = NO;
        _myScrollView.scrollEnabled = NO;
    }
    return _myScrollView;
}
- (UILabel *)noBadgesLabel {
    if (!_noBadgesLabel) {
        _noBadgesLabel = [[UILabel alloc] init];
        _noBadgesLabel.text = STATIC_TEXT_NO_BADGES_TEXT;
        _noBadgesLabel.textColor = [UIColor defaultTextDarkColor];
        [_noBadgesLabel setFont:[UIFont fontHelvetica57Condensed:10.0f]];
        _noBadgesLabel.translatesAutoresizingMaskIntoConstraints = NO;
    }
    return _noBadgesLabel;
}
- (void)setRosterEarnBadges:(NSArray<ABISFBadgesDetailsNameWiseDataModel *> *)rosterEarnBadges {
    _rosterEarnBadges = rosterEarnBadges;
    [self setupUI];
    [self updateUI];
}
- (void)updateUI {
    for (UIView *view in self.myScrollView.subviews) {
        [view removeFromSuperview];
    }
    CGRect rect = _myScrollView.bounds;
    rect.origin.y = 10;
    rect.origin.x = 10;
    UIImage *noMedel = [UIImage imageNamed:@"no_Medal"];
    if (self.rosterEarnBadges.count == 0) {
        [self addConstraints:self.horizontalContraints2];
        UIImageView *ribbonImgView = [[UIImageView alloc] initWithImage:noMedel];
        [self.myScrollView addSubview:ribbonImgView];
        rect.size.width = 35.0f;
        rect.size.height = 40.0f;
        ribbonImgView.frame = rect;
    } else {
        [self addConstraints:self.horizontalContraints1];
        for (ABISFEarnBadgesDataModel *earnBadgesDataModel in self.rosterEarnBadges) {
            UIImageView *ribbonImgView = [[UIImageView alloc] init];
            UITapGestureRecognizer *badgeTapGesture = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(tappedOnBadge)];
            [badgeTapGesture setCancelsTouchesInView:NO];
            [ribbonImgView addGestureRecognizer:badgeTapGesture];
            ribbonImgView.userInteractionEnabled = YES;
            [self.myScrollView addSubview:ribbonImgView];
            NSString *urlString = earnBadgesDataModel.badgesImageURLString;
            NSNumber *numberOfEarnBadges = earnBadgesDataModel.numberOfEarnBadges;
            NSInteger badgeCount = (numberOfEarnBadges && numberOfEarnBadges.integerValue) ? numberOfEarnBadges.integerValue : 0;
            NSString *badgeCountString = [NSString stringWithFormat:@"%ld", (long)badgeCount];
            __block CustomBadge *badge = [CustomBadge customBadgeWithString:(badgeCount == 0) ? STATIC_TEXT_EMPTY_STRING : badgeCountString];
            badge.hidden = YES;
            [ribbonImgView setABIBadgeImageWithURL:urlString
                                  placeholderImage:nil
                                        completion:^(UIImage *image) {
                                            if (image) {
                                                badge.hidden = (badgeCount == 0);
                                            }
                                        }];

                //
                //
                //						   setABIBadgeImageWithURL:urlString
                //                             placeholderImage:nil
                //                                   completion:^(UIImage *_Nonnull image) {
                //                                       ribbonImgView.image = image;
                //                                       if (image) {
                //                                           badge.hidden = (badgeCount == 0);
                //                                       }
                //                                   }];
            rect.origin.y = 15;
            rect.size.width = 35.0f;
            rect.size.height = 35.0f;
            ribbonImgView.frame = rect;
            badgeRect = rect;
            badgeRect.origin.x = CGRectGetMaxX(ribbonImgView.frame) - 15;
            badgeRect.origin.y = 5;
            badgeRect.size.width = badge.frame.size.width;
            badgeRect.size.height = badge.frame.size.height;
            badge.frame = badgeRect;
            badge.userInteractionEnabled = NO;
            [self.myScrollView addSubview:badge];
            rect.origin.x = CGRectGetMaxX(badgeRect) + 10.0;
        }
    }
    self.myScrollView.contentSize = CGSizeMake(CGRectGetMaxX(rect), 0);
        //    self.myScrollView.scrollEnabled = (self.rosterEarnBadges && self.rosterEarnBadges.count > 5);
}
- (void)layoutSubviews {
    [super layoutSubviews];
    CGFloat scrollViewWidth = self.bounds.size.width;
    CGFloat BadgesTotalWidth = CGRectGetMaxX(badgeRect); // badgeRect.origin.x + badgeRect.size.width; //(self.rosterEarnBadges.count * 45) - 10;
    self.myScrollView.scrollEnabled = (self.rosterEarnBadges && BadgesTotalWidth > scrollViewWidth);
}
#pragma mark - Delegate
- (void)tappedOnBadge {
    if (_delegate && [_delegate respondsToSelector:@selector(tappedOnBadge)]) {
        [_delegate tappedOnBadge];
    }
}
@end
