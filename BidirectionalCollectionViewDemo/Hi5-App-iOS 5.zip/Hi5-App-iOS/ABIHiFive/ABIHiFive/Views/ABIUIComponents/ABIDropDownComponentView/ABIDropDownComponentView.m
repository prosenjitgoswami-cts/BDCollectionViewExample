    //
    //  ABIDropDownComponentView.m
    //  ABIHiFive
    //
    //  Created by Prsenjit Goswami on 12/08/16.
    //  Copyright © 2016 Cognizant. All rights reserved.
    //
#import "ABIDropDownComponentView.h"
#import "ABISFIncentiveDataModel.h"
#import "CustomDropDownTableView.h"
@interface ABIDropDownComponentView ()
@property (strong, nonatomic) NSMutableDictionary *metrics;
@property (strong, nonatomic) UILabel *viewByLabel;
@property (strong, nonatomic) UIImageView *dropDownImgView;
@property (strong, nonatomic) CustomDropDownTableView *customDropDownTableView;
@property (assign, nonatomic) NSUInteger selectedIndex;
@property (strong, nonatomic) NSMutableArray<id> *dropDownLists;
@property (strong, nonatomic) UIButton *dropDownButton;

@end
@implementation ABIDropDownComponentView
- (instancetype)initWithCoder:(NSCoder *)aDecoder {
    self = [super initWithCoder:aDecoder];
    if (self) {
        self.selectedIndex = 0;
        [self initialSetup];
    }
    return self;
}
- (instancetype)init {
    self = [super init];
    if (self) {
        self.selectedIndex = 0;
        [self initialSetup];
    }
    return self;
}
- (void)dealloc {
    [self cleanUp];
}
- (void)cleanUp {
    [_customDropDownTableView removeFromSuperview];
    _customDropDownTableView = nil;
    [_dropDownButton removeFromSuperview];
    _dropDownButton = nil;
    [_dropDownImgView removeFromSuperview];
    _dropDownImgView = nil;
    [_viewByLabel removeFromSuperview];
    _viewByLabel = nil;
    [_dropDownLists removeAllObjects];
    _dropDownLists = nil;
}
#pragma mark - Custom Accessors Method

- (void)setSelectedIndex:(NSUInteger)selectedIndex {
    _selectedIndex = selectedIndex;
    self.customDropDownTableView.selectedIndex = _selectedIndex;
}
- (void)setDropDownTitle:(NSString *)dropDownTitle {
    _dropDownTitle = dropDownTitle;
    self.viewByLabel.text = _dropDownTitle;
}
- (void)setDropDownButtonTitle:(NSString *)dropDownButtonTitle {
    _dropDownButtonTitle = [dropDownButtonTitle nullStringTextCorrection];
    [_dropDownButton setTitle:_dropDownButtonTitle forState:UIControlStateNormal];
    [_dropDownButton setTitle:_dropDownButtonTitle forState:UIControlStateHighlighted];
}

- (UILabel *)viewByLabel {
    if (!_viewByLabel) {
        _viewByLabel = [[UILabel alloc] init];
        _viewByLabel.translatesAutoresizingMaskIntoConstraints = NO;
        _viewByLabel.textColor = [UIColor darkTextColor];
        [_viewByLabel setFont:[UIFont fontHelvetica57Condensed:12.0f]];
    }
    return _viewByLabel;
}
- (UIButton *)dropDownButton {
    if (!_dropDownButton) {
        _dropDownButton = [UIButton buttonWithType:UIButtonTypeCustom];
        _dropDownButton.backgroundColor = [UIColor whiteColorABI];
        _dropDownButton.translatesAutoresizingMaskIntoConstraints = NO;
        _dropDownButton.layer.borderColor = [UIColor lightGreyColorABI].CGColor;
        _dropDownButton.layer.borderWidth = 1.0f;
        _dropDownButton.layer.cornerRadius = 3.0f;
        _dropDownButton.contentHorizontalAlignment = UIControlContentHorizontalAlignmentLeft;
        _dropDownButton.titleEdgeInsets = UIEdgeInsetsMake(0, 10, 0, 0);
        _dropDownButton.titleLabel.font = [UIFont defaultTextFontABI];
        [_dropDownButton setTitleColor:[UIColor darkTextColor] forState:UIControlStateNormal];
        [_dropDownButton addTarget:self action:@selector(clickedDropDown:) forControlEvents:UIControlEventTouchUpInside];
    }
    return _dropDownButton;
}
- (UIImageView *)dropDownImgView {
    if (!_dropDownImgView) {
        _dropDownImgView = [[UIImageView alloc] initWithImage:[UIImage imageNamed:@"dropDownArrow"]];
        ;
        _dropDownImgView.translatesAutoresizingMaskIntoConstraints = NO;
    }
    return _dropDownImgView;
}
- (CustomDropDownTableView *)customDropDownTableView {
    if (!_customDropDownTableView) {
        _customDropDownTableView = [[CustomDropDownTableView alloc] initWithData:nil dropDownListType:self.dropDownListType];
    }
    return _customDropDownTableView;
}
- (void)setDropDownListType:(DropDownListType)dropDownListType {
    _dropDownListType = dropDownListType;
    [self.customDropDownTableView setDropDownListType:_dropDownListType];
}

#pragma mark - Private Method

- (void)initialSetup {
    [self initialUISetup];
}
- (void)initialUISetup {
    self.backgroundColor = [UIColor clearColor];
    [self createAndAddUI];
    self.dropDownTitle = DROP_DOWN_TITLE_VIEW_BY;
}
- (void)createAndAddUI {
    [self addSubview:self.viewByLabel];
    [self addSubview:self.dropDownButton];
    [self addSubview:self.dropDownImgView];
    [self addConstrains];
}
- (void)addConstrains {
    NSDictionary *views = @{ @"viewByLabel" : self.viewByLabel, @"dropDownButton" : self.dropDownButton, @"dropDownImgView" : self.dropDownImgView };
    [self addConstraints:[NSLayoutConstraint
                          constraintsWithVisualFormat:@"H:|-hPadding20-[viewByLabel(viewByLabelWidth)]-hPadding-[dropDownButton]-hPadding20-|"
                          options:0
                          metrics:self.metrics
                          views:views]];
    [self addConstraints:[NSLayoutConstraint constraintsWithVisualFormat:@"V:|[viewByLabel]|" options:0 metrics:self.metrics views:views]];
    [self addConstraints:[NSLayoutConstraint constraintsWithVisualFormat:@"V:|[dropDownButton]|" options:0 metrics:self.metrics views:views]];
    [self addConstraint:[NSLayoutConstraint constraintWithItem:self.dropDownButton
                                                     attribute:NSLayoutAttributeCenterY
                                                     relatedBy:NSLayoutRelationEqual
                                                        toItem:self
                                                     attribute:NSLayoutAttributeCenterY
                                                    multiplier:1
                                                      constant:0]];
    [self addConstraint:[NSLayoutConstraint constraintWithItem:self.viewByLabel
                                                     attribute:NSLayoutAttributeCenterY
                                                     relatedBy:NSLayoutRelationEqual
                                                        toItem:self
                                                     attribute:NSLayoutAttributeCenterY
                                                    multiplier:1
                                                      constant:0]];
    [self addConstraints:[NSLayoutConstraint constraintsWithVisualFormat:@"H:[dropDownImgView(dropDownImgViewHeight)]-hPadding30-|"
                                                                 options:0
                                                                 metrics:self.metrics
                                                                   views:views]];
    [self addConstraints:[NSLayoutConstraint constraintsWithVisualFormat:@"V:[dropDownImgView(dropDownImgViewHeight)]"
                                                                 options:0
                                                                 metrics:self.metrics
                                                                   views:views]];
    [self addConstraint:[NSLayoutConstraint constraintWithItem:self.dropDownImgView
                                                     attribute:NSLayoutAttributeCenterY
                                                     relatedBy:NSLayoutRelationEqual
                                                        toItem:self
                                                     attribute:NSLayoutAttributeCenterY
                                                    multiplier:1
                                                      constant:0]];
}
- (NSDictionary *)metrics {
    if (!_metrics) {
        _metrics = [NSMutableDictionary dictionary];
        [_metrics setObject:@(30.0) forKey:@"hPadding30"];
        [_metrics setObject:@(15.0) forKey:@"dropDownImgViewHeight"];
        [_metrics setObject:@(40.0) forKey:@"viewByLabelWidth"];
        [_metrics setObject:@(5.0) forKey:@"hPadding"];
        [_metrics setObject:@(20.0) forKey:@"hPadding20"];
    }
    return _metrics;
}
#pragma mark - IB Action
- (void)clickedDropDown:(UIButton *)sender {
    if (self.dropDownLists.count) {
        self.customDropDownTableView.dataSources = self.dropDownLists;
        self.customDropDownTableView.isBadge = self.isBadge;
        __weak typeof(self) weakSelf = self;

        [self.customDropDownTableView
         showPopOverInView:sender
         completion:^(id selectedDataModel, NSIndexPath *indexPath) {
             if ([AppDelegate isOffline] && !self.isBadge) {
                 if (weakSelf.delegate && [weakSelf.delegate respondsToSelector:@selector(dropDownComponentView:selectedItem:indexPath:)]) {
                     [weakSelf.delegate dropDownComponentView:self selectedItem:nil indexPath:nil];
                 }
             } else {
                 if (weakSelf.selectedIndex != indexPath.row) {
                     weakSelf.selectedIndex = indexPath.row;
                     weakSelf.dropDownButtonTitle = [NSString textForKey:self.customDropDownTableView.displayTextKey object:selectedDataModel];
                     if (weakSelf.delegate && [weakSelf.delegate respondsToSelector:@selector(dropDownComponentView:selectedItem:indexPath:)]) {
                         [weakSelf.delegate dropDownComponentView:self selectedItem:selectedDataModel indexPath:indexPath];
                     }
                 }
             }
         }];
    }
}

#pragma mark - Public Method

- (void)dropDownDataSource:(NSMutableArray *)dropDownDataSource selectedItem:(id)selectedItem displayTextKey:(NSString *)displayTextKey {

    if ([NSArray isValidArray:dropDownDataSource]) {

        NSUInteger selectedIndex = [dropDownDataSource indexOfObject:selectedItem];
        self.selectedIndex = selectedIndex;
        self.customDropDownTableView.displayTextKey = displayTextKey;

        NSString *displayText = [NSString textForKey:displayTextKey object:selectedItem];

        if (nil != displayText) {
            self.dropDownButtonTitle = displayText;
            self.dropDownLists = dropDownDataSource;
        }

            //		if(nil ==  displayTextKey && [selectedItem isKindOfClass:[NSString class]]) {
            //			self.dropDownLists = nil;
            //		}
    }

    selectedItem = [NSArray objectFromArray:dropDownDataSource atIndex:self.selectedIndex];

    if (self.delegate && [self.delegate respondsToSelector:@selector(dropDownComponentView:selectedItem:indexPath:)]) {
        [self.delegate dropDownComponentView:self selectedItem:selectedItem indexPath:[NSIndexPath indexPathForRow:self.selectedIndex inSection:0]];
    }
}

@end
