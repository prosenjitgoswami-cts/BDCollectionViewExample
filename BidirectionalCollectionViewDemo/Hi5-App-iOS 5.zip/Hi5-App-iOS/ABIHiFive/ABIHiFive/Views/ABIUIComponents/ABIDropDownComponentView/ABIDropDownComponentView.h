    //
    //  ABIDropDownComponentView.h
    //  ABIHiFive
    //
    //  Created by Prsenjit Goswami on 12/08/16.
    //  Copyright © 2016 Cognizant. All rights reserved.
    //
#import "ABIDropDownComponentViewDelegate.h"
#import <UIKit/UIKit.h>

@interface ABIDropDownComponentView : UIView

@property (strong, nonatomic) IBInspectable NSString *dropDownTitle;
@property (assign, nonatomic) IBInspectable DropDownListType dropDownListType;
@property (weak, nonatomic) IBInspectable id<ABIDropDownComponentViewDelegate> delegate;
@property (assign, nonatomic) BOOL isBadge;
@property (assign, nonatomic, readonly) NSUInteger selectedIndex;
@property (strong, nonatomic) NSString *dropDownButtonTitle;

- (void)dropDownDataSource:(NSMutableArray *)dropDownDataSource selectedItem:(id)selectedItem displayTextKey:(NSString *)displayTextKey;

@end
