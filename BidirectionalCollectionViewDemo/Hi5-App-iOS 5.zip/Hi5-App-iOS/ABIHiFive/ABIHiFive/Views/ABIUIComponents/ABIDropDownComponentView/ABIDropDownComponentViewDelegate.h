    //
    //  ABIDropDownComponentViewDelegate.h
    //  ABIHiFive
    //
    //  Created by Prsenjit Goswami on 18/08/16.
    //  Copyright © 2016 Cognizant. All rights reserved.
    //
#import "Constants.h"
#import <Foundation/Foundation.h>
@class ABIDropDownComponentView;
@protocol ABIDropDownComponentViewDelegate <NSObject>
- (void)dropDownComponentView:(ABIDropDownComponentView *)dropDownComponentView selectedItem:(id)selectedItem indexPath:(NSIndexPath *)indexPath;
@end
