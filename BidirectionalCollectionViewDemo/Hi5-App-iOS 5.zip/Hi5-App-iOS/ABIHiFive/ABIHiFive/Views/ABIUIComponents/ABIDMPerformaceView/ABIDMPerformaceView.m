    //
    //  ABIDMPerformaceView.m
    //  ABIHiFive
    //
    //  Created by Amit Kumar on 8/12/16.
    //  Copyright © 2016 Cognizant. All rights reserved.
    //
#import "ABIDMPerformaceView.h"
#import "ABISFMyReporteePerformanceDataModel.h"
#import "Constants.h"
@interface ABIDMPerformaceView ()
@property (strong, nonatomic) NSMutableDictionary *metrics;
@property (strong, nonatomic) UILabel *dmPerformanceLabel;
@property (strong, nonatomic) UIView *bottomSeperatorView;
@end
@implementation ABIDMPerformaceView
- (instancetype)initWithDataSource:(NSArray<ABISFMyReporteePerformanceDataModel *> *)myDMsPerformanceDataModels {
    self = [super init];
    if (self) {
        self.myDMsPerformanceDataModels = myDMsPerformanceDataModels;
    }
    return self;
}

#pragma mark - Public Method
- (void)setABISFMyReporteePerformanceDataModels:(NSArray<ABISFMyReporteePerformanceDataModel *> *)myDMsPerformanceDataModels {
    _myDMsPerformanceDataModels = myDMsPerformanceDataModels;
    [self dmPerformanceViewCreate];
}
- (UIView *)bottomSeperatorView {
    if (!_bottomSeperatorView) {
        _bottomSeperatorView = [UIView new];
        _bottomSeperatorView.backgroundColor = [UIColor lightGreyColorABI];
        _bottomSeperatorView.translatesAutoresizingMaskIntoConstraints = NO;
    }
    return _bottomSeperatorView;
}
- (UILabel *)dmPerformanceLabel {
    if (!_dmPerformanceLabel) {
        _dmPerformanceLabel = [UILabel new];
        _dmPerformanceLabel.text = @"My DMs Performance";
        _dmPerformanceLabel.translatesAutoresizingMaskIntoConstraints = NO;
        _dmPerformanceLabel.font = [UIFont fontHelvetica57Condensed:12.0];
    }
    return _dmPerformanceLabel;
}
- (void)dmPerformanceViewCreate {
    [self createHeader];
    [self createMyDMsPerformanceView:self.myDMsPerformanceDataModels];
}
- (void)createHeader {
    if (_dmPerformanceLabel) {
        [_dmPerformanceLabel removeFromSuperview];
    }
    if (_bottomSeperatorView) {
        [_bottomSeperatorView removeFromSuperview];
    }
    [self addSubview:self.dmPerformanceLabel];
    [self addSubview:self.bottomSeperatorView];
    NSDictionary *views1 = @{ @"dmPerformanceLabel" : self.dmPerformanceLabel, @"bottomSeperatorView" : self.bottomSeperatorView };
    [self addConstraints:[NSLayoutConstraint constraintsWithVisualFormat:@"H:|-[dmPerformanceLabel]-|" options:0 metrics:nil views:views1]];
    [self addConstraints:[NSLayoutConstraint constraintsWithVisualFormat:@"H:|-[bottomSeperatorView]-|" options:0 metrics:nil views:views1]];
    [self addConstraints:[NSLayoutConstraint constraintsWithVisualFormat:
                          @"V:|-[dmPerformanceLabel(dmPerformanceLabelHeight)]-[bottomSeperatorView(bottomSeperatorViewHeight)]"
                                                                 options:0
                                                                 metrics:self.metrics
                                                                   views:views1]];
}
- (void)createMyDMsPerformanceView:(NSArray<ABISFMyReporteePerformanceDataModel *> *)myDMsPerformanceDataModels {
    if (myDMsPerformanceDataModels.count < 1) {
        self.noDmKpi = [[UILabel alloc] init];
        self.noDmKpi.translatesAutoresizingMaskIntoConstraints = NO;
        self.noDmKpi.font = [UIFont fontHelvetica57Condensed:14.0];
        self.noDmKpi.text = @"No DM records available";
        self.noDmKpiView = [[UIView alloc] init];
        self.noDmKpiView.translatesAutoresizingMaskIntoConstraints = NO;
        self.noDmKpiView.backgroundColor = [UIColor whiteColor];
        [self.noDmKpiView addSubview:self.noDmKpi];
        [self addSubview:self.noDmKpiView];
        NSDictionary *views = @{ @"noDmKpiView" : self.noDmKpiView };
        [self addConstraints:[NSLayoutConstraint constraintsWithVisualFormat:@"H:|-[noDmKpiView]-|" options:0 metrics:nil views:views]];
        [self addConstraints:[NSLayoutConstraint constraintsWithVisualFormat:@"V:|-50-[noDmKpiView]-15-|" options:0 metrics:self.metrics views:views]];
        NSLayoutConstraint *c;
        c = [NSLayoutConstraint constraintWithItem:self.noDmKpi
                                         attribute:NSLayoutAttributeCenterX
                                         relatedBy:NSLayoutRelationEqual
                                            toItem:self.noDmKpiView
                                         attribute:NSLayoutAttributeCenterX
                                        multiplier:1
                                          constant:0];
        [self.noDmKpiView addConstraint:c];
        NSLayoutConstraint *d;
        d = [NSLayoutConstraint constraintWithItem:self.noDmKpi
                                         attribute:NSLayoutAttributeCenterY
                                         relatedBy:NSLayoutRelationEqual
                                            toItem:self.noDmKpiView
                                         attribute:NSLayoutAttributeCenterY
                                        multiplier:1
                                          constant:0];
        [self.noDmKpiView addConstraint:d];
    } else {
        for (int i = 0; i < myDMsPerformanceDataModels.count; i++) {
            ABISFMyReporteePerformanceDataModel *model = [NSArray objectFromArray:myDMsPerformanceDataModels atIndex:i];
            if (!model)
                continue;
            UILabel *dmUserNameLabel = [[UILabel alloc] init];
            dmUserNameLabel.translatesAutoresizingMaskIntoConstraints = NO;
            dmUserNameLabel.font = [UIFont fontHelvetica57Condensed:14.0];
            dmUserNameLabel.text = model.nameOfDM;
            UILabel *dmPerformancePointLabel = [[UILabel alloc] init];
            dmPerformancePointLabel.translatesAutoresizingMaskIntoConstraints = NO;
            dmPerformancePointLabel.font = [UIFont fontHelvetica57Condensed:14.0];
            dmPerformancePointLabel.backgroundColor = [UIColor greenColorABI];
            dmPerformancePointLabel.text = model.performancePoint;
            dmPerformancePointLabel.textAlignment = NSTextAlignmentCenter;
            [self addSubview:dmUserNameLabel];
            [self addSubview:dmPerformancePointLabel];
            dmPerformancePointLabel.backgroundColor = [UIColor colorForIncentiveProgress:model.progressStatusColor];
            UILabel *prevLabel = [dmUserNameLabel viewWithTag:99 + i];
            NSDictionary *views = @{
                                    @"dmUserNameLabel" : dmUserNameLabel,
                                    @"dmPerformancePointLabel" : dmPerformancePointLabel,
                                    @"prevLabel" : (prevLabel == nil) ? @(1) : prevLabel
                                    };
            CGFloat topSpace;
            if (i == 0) {
                topSpace = 50.0;
            } else {
                topSpace = (30 * i) + 25 * i + 50;
            }
            NSDictionary *metrics = [[NSDictionary alloc] initWithObjectsAndKeys:@(topSpace), @"topSpace", nil];
            [self addConstraints:[NSLayoutConstraint
                                  constraintsWithVisualFormat:
                                  @"H:|-[dmUserNameLabel(dmUserNameLabelWidth)]-hPadding-[dmPerformancePointLabel(dmPerformancePointLabelWidth)]"
                                  options:0
                                  metrics:self.metrics
                                  views:views]];
            [self addConstraints:[NSLayoutConstraint constraintsWithVisualFormat:@"V:|-topSpace-[dmUserNameLabel(30)]"
                                                                         options:0
                                                                         metrics:metrics
                                                                           views:views]];
            [self addConstraints:[NSLayoutConstraint constraintsWithVisualFormat:@"V:|-topSpace-[dmPerformancePointLabel(30)]"
                                                                         options:0
                                                                         metrics:metrics
                                                                           views:views]];
        }
    }
}
- (NSDictionary *)metrics {
    if (!_metrics) {
        _metrics = [NSMutableDictionary dictionary];
        [_metrics setObject:@(10.0) forKey:@"dmPerformanceLabelHeight"];
        [_metrics setObject:@(2.0) forKey:@"bottomSeperatorViewHeight"];
        [_metrics setObject:@(150.0) forKey:@"dmUserNameLabelWidth"];
        [_metrics setObject:@(90.0) forKey:@"dmPerformancePointLabelWidth"];
        [_metrics setObject:@(5.0) forKey:@"hPadding"];
    }
    return _metrics;
}
@end
