    //
    //  ABIDMPerformaceView.h
    //  ABIHiFive
    //
    //  Created by Amit Kumar on 8/12/16.
    //  Copyright © 2016 Cognizant. All rights reserved.
    //
#import <UIKit/UIKit.h>
@class ABISFMyReporteePerformanceDataModel;
@interface ABIDMPerformaceView : UIView
- (instancetype)initWithDataSource:(NSArray<ABISFMyReporteePerformanceDataModel *> *)myDMsPerformanceDataModels;
@property (strong, nonatomic) NSArray<ABISFMyReporteePerformanceDataModel *> *myDMsPerformanceDataModels;
@property (strong, nonatomic) UILabel *noDmKpi;
@property (strong, nonatomic) UIView *noDmKpiView;
@end
