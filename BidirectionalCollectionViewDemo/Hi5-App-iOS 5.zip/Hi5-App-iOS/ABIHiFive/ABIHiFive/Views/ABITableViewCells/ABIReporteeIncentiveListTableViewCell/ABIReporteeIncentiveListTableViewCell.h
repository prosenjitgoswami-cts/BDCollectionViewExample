    //
    //  ABIReporteeIncentiveListTableViewCell.h
    //  ABIHiFive
    //
    //  Created by Prsenjit Goswami on 27/06/16.
    //  Copyright © 2016 Cognizant. All rights reserved.
    //
#import "ABISFRosterDataModel.h"
@class UIButton;

@protocol ABIReporteeIncentiveListTableViewCellDelegate <NSObject>

@optional
- (void)clickedPeerRanking:(UIButton *)sender atIndex:(NSUInteger)index;
- (void)clickedKPIRanking:(UIButton *)sender atIndex:(NSUInteger)index;

@end

@class ABISFIncentiveDataModel;

@interface ABIReporteeIncentiveListTableViewCell : UITableViewCell

@property (weak, nonatomic) id<ABIReporteeIncentiveListTableViewCellDelegate> delegate;
@property (strong, nonatomic) ABISFRosterDataModel *rosterDataModel;

- (void)updateCell:(ABISFIncentiveDataModel *)incentive atIndex:(NSUInteger)index;

@end
