    //
    //  ABIReporteeIncentiveListTableViewCell.m
    //  ABIHiFive
    //
    //  Created by Prsenjit Goswami on 27/06/16.
    //  Copyright © 2016 Cognizant. All rights reserved.
    //
#import "ABIReporteeIncentiveListTableViewCell.h"
#import "ABISFDataFetcherService.h"
#import "ABISFIncentiveDataModel.h"
#import "ABISFPeerRankingDataModel.h"
#import "Constants.h"
#import "CustomProgressBarView.h"
@interface ABIReporteeIncentiveListTableViewCell ()
@property (weak, nonatomic) IBOutlet UIImageView *IncentiveLogo;
@property (weak, nonatomic) IBOutlet UILabel *IncentiveName;
@property (weak, nonatomic) IBOutlet UIImageView *RankImage;
@property (weak, nonatomic) IBOutlet UILabel *rankNumberLabel;
@property (weak, nonatomic) IBOutlet UIView *chartView;
@property (weak, nonatomic) IBOutlet UILabel *statusTitleLabel;
@property (weak, nonatomic) IBOutlet UIButton *peerRankingButton;
@property (weak, nonatomic) IBOutlet UIButton *KPIDetailsButton;
@property (weak, nonatomic) IBOutlet UIView *buttonContainerView;
@property (assign, nonatomic) NSUInteger index;
@property (strong, nonatomic) ABISFIncentiveDataModel *incentive;
@property (strong, nonatomic) CustomProgressBarView *progressBarView;
@property (strong, nonatomic) NSAttributedString *rankDecoratedString;

@end
@implementation ABIReporteeIncentiveListTableViewCell
- (void)awakeFromNib {
    [self configureUI];
}
- (void)dealloc {
    _progressBarView = nil;
    _rankDecoratedString = nil;
    _incentive = nil;
}
#pragma mark - Private Method
- (CustomProgressBarView *)progressBarView {
    if (!_progressBarView) {
        _progressBarView = [CustomProgressBarView new];
        _progressBarView.translatesAutoresizingMaskIntoConstraints = NO;
        [self.chartView addSubview:_progressBarView];
        [_progressBarView fitToParentView:self.chartView];
    }
    return _progressBarView;
}
#pragma mark - Public Method
- (void)updateCell:(ABISFIncentiveDataModel *)incentive atIndex:(NSUInteger)index {
    _index = index;
    if (!incentive)
        return;
    self.peerRankingButton.tag = _index;
    self.KPIDetailsButton.tag = _index;
    self.incentive = incentive;
    NSString *incentiveDisplayNm = incentive.incentiveCustomDisplayText;
    if (![NSString isNULLString:incentiveDisplayNm]) {
        self.IncentiveName.text = incentiveDisplayNm;
    }
    [self updateProgressBarView];

        // Calculate Count of KPIs
    if (self.incentive.attributedString) {
        _statusTitleLabel.attributedText = self.incentive.attributedString;
    }

        // Get user rank for incentive
    if ([self.rosterDataModel.managerRoleInString isEqualToString:ABI_SF_USER_ROLE_SD] &&
        [self.rosterDataModel.roleInString isEqualToString:ABI_SF_USER_ROLE_DM]) {
        [self.peerRankingButton setTitle:BUTTON_TITLE_PEER_RANKING forState:UIControlStateNormal];
    } else {
        [self.peerRankingButton setTitle:BUTTON_TITLE_PEER_RANKING forState:UIControlStateNormal];
    }
    [self getIncentiveWiseUserRank];
}
/*!
 *  Create UI with Component
 */
- (void)configureUI {
    self.IncentiveName.textColor = [UIColor defaultTextDarkColor];
    self.IncentiveLogo.image = [UIImage imageNamed:IMAGE_NAME_INCENTIVE];
    self.RankImage.image = [UIImage imageNamed:rankImage];
    self.rankNumberLabel.backgroundColor = [UIColor clearColor];
    self.rankNumberLabel.font = PROFILE_RANKANDPOINT_FONT_SIZE;
    self.rankNumberLabel.font = PROFILE_RANKANDPOINT_FONT_SIZE;
    self.RankImage.backgroundColor = [UIColor whiteColor];
    self.IncentiveName.font = PROFILE_SUMMER_INCENTIVE_FONT_SIZE;
    self.statusTitleLabel.font = PROFILE_STATUS_TITLE_FONT_SIZE;
    [[self.peerRankingButton layer] setBorderWidth:1.5f];
    self.peerRankingButton.layer.borderColor = [UIColor defaultABIBlueColor].CGColor;
    self.peerRankingButton.backgroundColor = [UIColor whiteColor];
    self.KPIDetailsButton.backgroundColor = [UIColor blueColorABI];
    self.peerRankingButton.layer.cornerRadius = 3; // this value vary as per your desire
    self.peerRankingButton.clipsToBounds = YES;
    self.KPIDetailsButton.layer.cornerRadius = 3; // this value vary as per your desire
    self.KPIDetailsButton.clipsToBounds = YES;
    self.peerRankingButton.titleLabel.font = PROFILE_PEER_KPI_BUTTON_FONT_SIZE;
    self.KPIDetailsButton.titleLabel.font = PROFILE_PEER_KPI_BUTTON_FONT_SIZE;
    [self.peerRankingButton setTitleColor:[UIColor defaultABIBlueColor] forState:UIControlStateNormal];
    [self.KPIDetailsButton setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
    self.RankImage.hidden = YES;
}
/*!
 *  Update Line Chart
 */
- (void)updateProgressBarView {
    if (!self.chartView)
        return;
    self.progressBarView.progressStatusColorName = self.incentive.progressStatusColorName;
    self.progressBarView.progressAmountRaw = self.incentive.overAllIncentiveProgressRaw;
    self.progressBarView.minRange = self.incentive.minIncentiveRange;
    self.progressBarView.maxRange = self.incentive.maxIncentiveRange;
    self.progressBarView.progressAmount = self.incentive.overAllIncentiveProgress;
    self.progressBarView.progressDisplayText = self.incentive.overAllIncentiveProgress.stringValue;

    self.progressBarView.unitName = self.incentive.progressUnit;
    self.progressBarView.descriptionTextColor = [UIColor defaultTextLightColor];
    self.progressBarView.descriptionTextFont = PROFILE_DESCRIPTION_TEXT_FONT_SIZE;
    self.progressBarView.unitTextColor = [UIColor defaultTextDarkColor];
    self.progressBarView.unitTextFont = PROFILE_UNIT_TEXT_FONT_SIZE;
    self.buttonContainerView.layer.cornerRadius = 3;
    self.buttonContainerView.clipsToBounds = YES;
    self.buttonContainerView.backgroundColor = [UIColor defaultABIBlueColor];
    NSString *statusTitle = self.incentive.statusTitle;
    if (![NSString isNULLString:statusTitle]) {
        self.progressBarView.descriptionText = statusTitle;
    }
}
/**
 *  Get User Rank For specific Incentive
 */
- (void)getIncentiveWiseUserRank {

    __weak typeof(self) weakself = self;
    weakself.RankImage.hidden = YES;

    if (_rankDecoratedString) {
        [self updateRankNumberLabel];

    } else {
        [self.incentive getUserIncentiveRankAmongSameRolePeerWithCompletionBlock:^(NSNumber *_Nonnull rank) {

            weakself.rankDecoratedString = [NSAttributedString decoratedRankStringWithRankValueNumber:rank staticRankText:STATIC_TEXT_RANK];
            [self updateRankNumberLabel];
        }];
    }
}

- (void)updateRankNumberLabel {
    [self.rankNumberLabel setAttributedText:_rankDecoratedString];
    self.RankImage.hidden = (nil == _rankDecoratedString);
}
#pragma mark - IB Action
- (IBAction)clickedPeerRanking:(UIButton *)sender atIndex:(NSUInteger)index {
    if (self.delegate && [self.delegate respondsToSelector:@selector(clickedPeerRanking:atIndex:)]) {
        [self.delegate clickedPeerRanking:sender atIndex:self.index];
    }
}
- (IBAction)clickedKPIRanking:(UIButton *)sender {
    if (self.delegate && [self.delegate respondsToSelector:@selector(clickedKPIRanking:atIndex:)]) {
        [self.delegate clickedKPIRanking:sender atIndex:self.index];
    }
}
@end
