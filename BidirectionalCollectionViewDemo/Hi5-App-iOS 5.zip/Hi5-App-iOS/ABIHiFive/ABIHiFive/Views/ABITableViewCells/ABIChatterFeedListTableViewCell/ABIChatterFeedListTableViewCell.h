    //
    //  ABIChatterFeedListTableViewCell.h
    //  AnheuserBusch
    //
    //  Created by Prsenjit Goswami on 21/07/16.
    //  Copyright © 2016 Cognizant. All rights reserved.
    //
#import "ABIChatterFeedListTableViewCellDelegate.h"
#import "ABISFChatterFeedElementDataModel.h"
#import "Constants.h"
#import <UIKit/UIKit.h>
@interface ABIChatterFeedListTableViewCell : UITableViewCell <UITextFieldDelegate>
- (instancetype)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier cellType:(CellStyle)CellStyle;
@property (strong, nonatomic) UIColor *cellBackgroundColor;
@property (strong, nonatomic) UILabel *userListLabel;
@property (weak, nonatomic) id<ABIChatterFeedListTableViewCellDelegate> delegate;
@property (strong, nonatomic) id dataModel;
@property (assign, nonatomic) CGFloat cellBackgroundCornerRadius;
@property (assign, nonatomic) NSInteger detailsLabelNumberOfLines;
@property (assign, nonatomic) CellStyle cellStyle;
@property (strong, nonatomic, readonly) ABISFChatterFeedElementDataModel *feedElementDataModel;
@property (strong, nonatomic, readonly) NSString *commentText;
@property (strong, nonatomic, readonly) NSArray *uniqueCommentUsers;
@property (strong, nonatomic) NSIndexPath *indexPath;
- (void)dismissKeyBoard;
- (void)resetCommentTextField;
@end
