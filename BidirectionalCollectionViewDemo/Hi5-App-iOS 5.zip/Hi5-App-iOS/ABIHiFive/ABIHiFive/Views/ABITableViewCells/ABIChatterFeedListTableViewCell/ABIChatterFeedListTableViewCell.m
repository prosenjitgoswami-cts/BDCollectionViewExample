    //
    //  ABIChatterFeedListTableViewCell.m
    //  AnheuserBusch
    //
    //  Created by Prsenjit Goswami on 21/07/16.
    //  Copyright © 2016 Cognizant. All rights reserved.
    //
#import "ABIChatterFeedListTableViewCell.h"
#import "ABISFChatterContentDataModel.h"
#import "ABISFChatterFeedElementDataModel.h"
#import "ABISFChatterPrivateMessageDataModel.h"
#import "ABISFChatterPrivateMessageItemsDataModel.h"
#import "ABISFRestRequestManager.h"
#import "CustomImageView.h"
#import "CustomView.h"
#import "SFRestAPI+Files.h"
#import "UIImageView+ABISalesforceImage.h"

@interface ABIChatterFeedListTableViewCell () <UITextFieldDelegate>
@property (strong, nonatomic) UIView *headerView;
@property (strong, nonatomic) UIView *cellBackgroundView;
@property (strong, nonatomic) UILabel *detailsLabel;
@property (strong, nonatomic) CustomImageView *feedImageView;
@property (strong, nonatomic) UIView *boundaryView;
@property (strong, nonatomic) UIView *commentView;
@property (strong, nonatomic) CustomView *userImageView;
@property (strong, nonatomic) UILabel *userNameLabel, *commentByUsersNameLabel;
@property (strong, nonatomic) UILabel *timeLabel;
@property (strong, nonatomic) UILabel *incentiveNameLabel;
@property (strong, nonatomic) UIImageView *currentUserImageView;
@property (strong, nonatomic) UIButton *commentButton;
@property (strong, nonatomic) UITextField *commentTextField;
@property (strong, nonatomic) CustomView *currentUserImageBorderView;
@property (strong, nonatomic) UIView *lowerBoundaryView;
@property (strong, nonatomic) NSArray *verticleContrains;
@property (strong, nonatomic) NSMutableDictionary *metrics;
@property (strong, nonatomic) NSDictionary *views;
@property (strong, nonatomic) UITapGestureRecognizer *tapGesture;
@property (strong, nonatomic) UIButton *imageLinkButton;
@property (assign, nonatomic) CellStyle cellType;
@property (strong, nonatomic) ABISFChatterPrivateMessageItemsDataModel *messageItemsDataModel;
@property (strong, nonatomic) ABISFChatterFeedElementDataModel *feedElementDataModel;
@property (strong, nonatomic) NSArray *uniqueCommentUsers;
@property (weak, nonatomic) SFRestRequest *request;
@property (strong, nonatomic) NSIndexPath *imageRequestForindexPath;
@end
@implementation ABIChatterFeedListTableViewCell

- (instancetype)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier cellType:(CellStyle)cellType {
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if (self) {
        self.cellType = cellType;
        [self configureUI];
    }
    return self;
}
- (void)dealloc {
    _headerView = nil;
    _cellBackgroundView = nil;
    _detailsLabel = nil;
    _feedImageView = nil;
    _commentByUsersNameLabel = nil;
    _boundaryView = nil;
    _commentView = nil;
        //    _userImageBorderView = nil;
    _userImageView = nil;
    _userNameLabel = nil;
    _timeLabel = nil;
    _incentiveNameLabel = nil;
    _currentUserImageView = nil;
    _commentButton = nil;
    _commentTextField = nil;
    _currentUserImageBorderView = nil;
    _feedElementDataModel = nil;
    _tapGesture = nil;
    _imageLinkButton = nil;
    _delegate = nil;
    _views = nil;
    _metrics = nil;
    _verticleContrains = nil;
    _lowerBoundaryView = nil;
    _uniqueCommentUsers = nil;
}
#pragma mark - Public Method
- (NSString *)commentText {
    return self.commentTextField.text;
}
- (void)setCellBackgroundCornerRadius:(CGFloat)cellBackgroundCornerRadius {
    _cellBackgroundCornerRadius = cellBackgroundCornerRadius;
    _cellBackgroundView.layer.cornerRadius = 5.0f;
}
- (void)setCellBackgroundColor:(UIColor *)cellBackgroundColor {
    _cellBackgroundColor = cellBackgroundColor;
    _cellBackgroundView.backgroundColor = _cellBackgroundColor;
}
- (void)setDetailsLabelNumberOfLines:(NSInteger)detailsLabelNumberOfLines {
    _detailsLabelNumberOfLines = detailsLabelNumberOfLines;
    _detailsLabel.numberOfLines = _detailsLabelNumberOfLines;
}
- (void)setDataModel:(id)dataModel {
    _dataModel = dataModel;
    if (dataModel && [dataModel isMemberOfClass:[ABISFChatterPrivateMessageItemsDataModel class]]) {
        self.messageItemsDataModel = (ABISFChatterPrivateMessageItemsDataModel *)dataModel;
        [self refreshDataWithABISFChatterPrivateMessageDataModel:self.messageItemsDataModel];
    } else if (dataModel && [dataModel isMemberOfClass:[ABISFChatterFeedElementDataModel class]]) {
        self.feedElementDataModel = (ABISFChatterFeedElementDataModel *)dataModel;
        [self refreshDataWithABISFChatterFeedElementDataModel:self.feedElementDataModel];
    }
}

- (void)refreshDataWithABISFChatterPrivateMessageDataModel:(ABISFChatterPrivateMessageItemsDataModel *)messageDataModel {
    [self refreshUIWithParentPhotoURLString:[[messageDataModel sender] photo].fullEmailPhotoUrl
                                   userName:[messageDataModel sender].name
                                refreshTime:[messageDataModel refreshTime]
                                  groupName:nil
                           shortDescription:[messageDataModel text]
                         uniqueCommentUsers:nil
                            uniqueUsersName:nil
                                  fileItems:nil];
}

- (void)refreshDataWithABISFChatterFeedElementDataModel:(ABISFChatterFeedElementDataModel *)feedElementDataModel {
    NSString *groupName = feedElementDataModel.parent.isGroupType ? feedElementDataModel.parent.name : STATIC_TEXT_EMPTY_STRING;
    [self refreshUIWithParentPhotoURLString:[[feedElementDataModel parent] photo].fullEmailPhotoUrl
                                   userName:[feedElementDataModel parent].name
                                refreshTime:[feedElementDataModel refreshTime]
                                  groupName:groupName
                           shortDescription:[feedElementDataModel feedMessage]
                         uniqueCommentUsers:[feedElementDataModel comment].uniqueCommentUsers
                            uniqueUsersName:[feedElementDataModel comment].uniqueUsersName
                                  fileItems:[feedElementDataModel file].items];
}

- (void)refreshUIWithParentPhotoURLString:(NSString *)parentPhotoURLString
                                 userName:(NSString *)userName
                              refreshTime:(NSString *)refreshTime
                                groupName:(NSString *)groupName
                         shortDescription:(NSString *)shortDescription
                       uniqueCommentUsers:(NSArray *)uniqueCommentUsers
                          uniqueUsersName:(NSString *)uniqueUsersName
                                fileItems:(NSArray *)fileItems {

        // Reset Cell
    [self resetCell];

    if ([NSArray isValidArray:fileItems] && fileItems.count) {
        ABISFChatterContentDataModel *contentDataModel = [fileItems firstObject];
        [self downloadAndUpdateFeedImage:contentDataModel];
    }

    if (![NSString isNULLString:parentPhotoURLString]) {
        [self.userImageView.innerUserImageView setABIUserImageWithURL:parentPhotoURLString];
        [self.currentUserImageBorderView.innerUserImageView setABISignedInUserProfileImage];
    }
    self.userNameLabel.text = [userName nullStringTextCorrection];
    self.timeLabel.text = [refreshTime nullStringTextCorrection];
    self.detailsLabel.text = [shortDescription nullStringTextCorrection];
    self.uniqueCommentUsers = uniqueCommentUsers;
    self.incentiveNameLabel.text = [groupName nullStringTextCorrection];
    if (uniqueUsersName.length && self.cellType == CellStyleFeedList) {
        self.commentByUsersNameLabel.text = [uniqueUsersName nullStringTextCorrection];
        _commentByUsersNameLabel.hidden = NO;
        [self.metrics setObject:@(30) forKey:@"kcommentByUsersNameLabelheight"];
    } else {
        [self.metrics setObject:@(0) forKey:@"kcommentByUsersNameLabelheight"];
        _commentByUsersNameLabel.hidden = YES;
    }
    [_metrics setObject:@([shortDescription length] ? 3.0 : 0.0) forKey:@"paddingdescTextToFeedImage"];
    [self updateVerticalConstrain];
    self.commentByUsersNameLabel.userInteractionEnabled = self.feedElementDataModel.comment.isMoreAvailable;
}

#pragma mark - Private Method
- (void)configureUI {
    [self.contentView addSubview:self.cellBackgroundView];
        // Header View
    [self.cellBackgroundView addSubview:self.headerView];
    [self.headerView addSubview:self.userImageView];
    [self.headerView addSubview:self.userNameLabel];
    [self.headerView addSubview:self.timeLabel];
    [self.headerView addSubview:self.incentiveNameLabel];
        // Message Label
    [self.cellBackgroundView addSubview:self.detailsLabel];
        // Feed image
    [self.cellBackgroundView addSubview:self.feedImageView];
        // image Link Button
    [self.cellBackgroundView addSubview:self.imageLinkButton];
        // Latest Comments User name
    [self.cellBackgroundView addSubview:self.commentByUsersNameLabel];
        // Seperator View
    [self.cellBackgroundView addSubview:self.boundaryView];
        // Comment View
    [self.cellBackgroundView addSubview:self.commentView];
        // Lower Boundary View
    [self.cellBackgroundView addSubview:self.lowerBoundaryView];
    [self.commentView addSubview:self.currentUserImageBorderView];
    [self.commentView addSubview:self.commentTextField];
    [self.commentView addSubview:self.commentButton];
    [self addConstraints];
    if (self.delegate && [self.delegate respondsToSelector:@selector(selectedCell:)]) {
        [self.delegate selectedCell:self];
    }
}
- (void)addConstraints {
    [self.contentView
     addConstraints:[NSLayoutConstraint constraintsWithVisualFormat:@"H:|[cellBackgroundView]|" options:0 metrics:self.metrics views:self.views]];
    [self.contentView
     addConstraints:[NSLayoutConstraint constraintsWithVisualFormat:@"V:|[cellBackgroundView]|" options:0 metrics:self.metrics views:self.views]];
    [self.cellBackgroundView addConstraints:[NSLayoutConstraint constraintsWithVisualFormat:@"H:|-hPadding-[headerView]-hPadding-|"
                                                                                    options:0
                                                                                    metrics:self.metrics
                                                                                      views:self.views]];
    [self.cellBackgroundView addConstraints:[NSLayoutConstraint constraintsWithVisualFormat:@"H:|-hPadding-[detailsLabel]-hPadding-|"
                                                                                    options:0
                                                                                    metrics:self.metrics
                                                                                      views:self.views]];
    [self.cellBackgroundView addConstraints:[NSLayoutConstraint constraintsWithVisualFormat:@"H:|-hPadding-[feedImageView]-hPadding-|"
                                                                                    options:0
                                                                                    metrics:self.metrics
                                                                                      views:self.views]];
    [self.cellBackgroundView addConstraints:[NSLayoutConstraint constraintsWithVisualFormat:@"H:|-hPadding-[imageLinkButton]"
                                                                                    options:0
                                                                                    metrics:self.metrics
                                                                                      views:self.views]];
    [self.cellBackgroundView addConstraints:[NSLayoutConstraint constraintsWithVisualFormat:@"H:|-hPadding-[commentByUsersNameLabel]-hPadding-|"
                                                                                    options:0
                                                                                    metrics:self.metrics
                                                                                      views:self.views]];
    [self.cellBackgroundView
     addConstraints:[NSLayoutConstraint constraintsWithVisualFormat:@"H:|[boundaryView]|" options:0 metrics:self.metrics views:self.views]];
    [self.cellBackgroundView addConstraints:[NSLayoutConstraint constraintsWithVisualFormat:@"H:|-hPadding-[commentView]-hPadding-|"
                                                                                    options:0
                                                                                    metrics:self.metrics
                                                                                      views:self.views]];
    [self.cellBackgroundView
     addConstraints:[NSLayoutConstraint constraintsWithVisualFormat:@"H:|[lowerBoundaryView]|" options:0 metrics:self.metrics views:self.views]];
        // Sub Child
    [self.headerView
     addConstraints:[NSLayoutConstraint
                     constraintsWithVisualFormat:@"H:|-hPadding-[userImageView(kUserImageViewHeight)]-10-[userNameLabel]-10-[incentiveNameLabel]|"
                     options:0
                     metrics:self.metrics
                     views:self.views]];
    [self.headerView addConstraints:[NSLayoutConstraint constraintsWithVisualFormat:@"V:|-hPadding-[userImageView(kUserImageViewHeight)]"
                                                                            options:0
                                                                            metrics:self.metrics
                                                                              views:self.views]];
    [self.headerView addConstraints:[NSLayoutConstraint constraintsWithVisualFormat:@"V:|-10-[incentiveNameLabel]-40-|"
                                                                            options:0
                                                                            metrics:self.metrics
                                                                              views:self.views]];
    [self.headerView addConstraints:[NSLayoutConstraint constraintsWithVisualFormat:@"V:|-10-[userNameLabel][timeLabel]-15-|"
                                                                            options:0
                                                                            metrics:self.metrics
                                                                              views:self.views]];
    [self.headerView addConstraint:[NSLayoutConstraint constraintWithItem:self.timeLabel
                                                                attribute:NSLayoutAttributeLeft
                                                                relatedBy:NSLayoutRelationEqual
                                                                   toItem:self.userNameLabel
                                                                attribute:NSLayoutAttributeLeft
                                                               multiplier:1
                                                                 constant:0]];
    if (self.cellType == CellStyleMessage) {
        [_currentUserImageBorderView removeConstraints:_currentUserImageBorderView.constraints];
    }
    [self.commentView
     addConstraints:[NSLayoutConstraint
                     constraintsWithVisualFormat:@"H:|-hPaddingOptional-[currentUserImageBorderView(kCurrentUserImageBorderView)]-10-["
                     @"commentTextField]-hPaddingOptional-[commentButton(kCommentButtonWidth)]-hPaddingOptional-|"
                     options:0
                     metrics:self.metrics
                     views:self.views]];
    [self.commentView addConstraints:[NSLayoutConstraint constraintsWithVisualFormat:@"V:|[currentUserImageBorderView(kCurrentUserImageBorderView)]"
                                                                             options:0
                                                                             metrics:self.metrics
                                                                               views:self.views]];
    [self.commentView addConstraints:[NSLayoutConstraint constraintsWithVisualFormat:@"V:|-hPaddingOptional-[commentTextField]-hPaddingOptional-|"
                                                                             options:0
                                                                             metrics:self.metrics
                                                                               views:self.views]];
    [self.commentView addConstraints:[NSLayoutConstraint constraintsWithVisualFormat:@"V:|-hPaddingOptional-[commentButton(kCommentButtonHeight)]"
                                                                             options:0
                                                                             metrics:self.metrics
                                                                               views:self.views]];

    [self updateVerticalConstrain];
}

- (void)resetCell {
    [self resetCommentTextField];
    [self.metrics setObject:@(0) forKey:@"kImageLinkButtonHeight"];
    [self.metrics setObject:@(0) forKey:@"kFeedImageViewHeight"];
    [_imageLinkButton setTitle:nil forState:UIControlStateNormal];
    self.feedImageView.image = nil;
}
#pragma mark

- (NSDictionary *)metrics {

    if (!_metrics) {
        _metrics = [NSMutableDictionary dictionary];
        [_metrics setObject:@(5.0) forKey:@"hPadding"];
        [_metrics setObject:@(3.0) forKey:@"hPaddingOptional"];
        [_metrics setObject:@(0.0) forKey:@"paddingdescTextToFeedImage"];
        [_metrics setObject:@(50.0) forKey:@"kUserImageViewHeight"];
        [_metrics setObject:@(36.0) forKey:@"kCurrentUserImageBorderView"];
        [_metrics setObject:@(30.0) forKey:@"kCommentButtonWidth"];
        [_metrics setObject:@(20.0) forKey:@"kCommentButtonHeight"];
        [_metrics setObject:@(60.0) forKey:@"kHeaderView"];
        [_metrics setObject:@(35) forKey:@"kCommentViewHeight"];
        [_metrics setObject:@(0) forKey:@"kFeedImageViewHeight"];
        [_metrics setObject:@(0) forKey:@"kImageLinkButtonHeight"];
        [_metrics setObject:@(0) forKey:@"kcommentByUsersNameLabelheight"];
        [_metrics setObject:@(0.0) forKey:@"kLowerBoundaryView"];
        [_metrics setObject:@(1.0) forKey:@"kUppreBoundaryView"];
        switch (self.cellType) {
            case CellStyleFeedList:
                [_metrics setObject:self.cellType == CellStyleFeedList ? @(30.0) : @(0) forKey:@"kcommentByUsersNameLabelheight"];
                [_metrics setObject:self.cellType == CellStyleFeedList ? @(0.0) : @(1.0) forKey:@"kLowerBoundaryView"];
                break;
            case CellStyleFeedListDetails:
                [_metrics setObject:self.cellType == CellStyleFeedList ? @(30.0) : @(0) forKey:@"kcommentByUsersNameLabelheight"];
                [_metrics setObject:self.cellType == CellStyleFeedList ? @(0.0) : @(1.0) forKey:@"kLowerBoundaryView"];
                [_metrics setObject:@(0) forKey:@"kcommentByUsersNameLabelheight"];
                _commentByUsersNameLabel.hidden = YES;
                break;
            case CellStyleMessage:
                [_metrics setObject:@(0) forKey:@"kCommentViewHeight"];
                [_metrics setObject:@(0) forKey:@"kCommentButtonHeight"];
                [_metrics setObject:@(0) forKey:@"kCurrentUserImageBorderView"];
                [_metrics setObject:@(0.0) forKey:@"kUppreBoundaryView"];
                [_metrics setObject:@(0.0) forKey:@"kFeedImageViewHeight"];
                [_metrics setObject:@(0.0) forKey:@"kImageLinkButtonHeight"];
                [_metrics setObject:@(0.0) forKey:@"hPaddingOptional"];
                [_metrics setObject:@(0) forKey:@"kcommentByUsersNameLabelheight"];
                _feedImageView.hidden = YES;
                _commentByUsersNameLabel.hidden = YES;
                break;
            default: break;
        }
    }
    return _metrics;
}
- (void)downloadAndUpdateFeedImage:(ABISFChatterContentDataModel *)contentDataModel {
    if (_request) {
        [_request cancel];
        _request = nil;
    }

    if (self.feedImageView)
        [self.feedImageView stopAnimating];

    NSString *title = contentDataModel.title;
    if (contentDataModel && !contentDataModel.isImageType) {
        [_imageLinkButton setTitle:title forState:UIControlStateNormal];
        [self.metrics setObject:@(20) forKey:@"kImageLinkButtonHeight"];
        [self.metrics setObject:@(0) forKey:@"kFeedImageViewHeight"];
        [self updateVerticalConstrain];

    } else if (contentDataModel) {
        __weak typeof(self) weakSelf = self;
        [weakSelf.metrics setObject:@(0) forKey:@"kImageLinkButtonHeight"];
        [weakSelf.metrics setObject:@(120) forKey:@"kFeedImageViewHeight"];

        _feedImageView.isIndicatorShown = YES;
        weakSelf.feedImageView.hidden = NO;
        self.imageRequestForindexPath = self.indexPath;
        self.request = [ABISFRestRequestManager
                        requestForFileContentsWithABISFChatterContentDataModel:contentDataModel
                        completion:^(NSString *filePath, BOOL isNewImage) {

                            if (weakSelf.imageRequestForindexPath &&
                                weakSelf.imageRequestForindexPath != weakSelf.indexPath) {
                                return;
                            }
                            self.imageRequestForindexPath = self.indexPath;

                            if (contentDataModel.isImageType && filePath) {
                                UIImage *downloadedImage = [UIImage loadImageWithFilePath:filePath];
                                weakSelf.feedImageView.hidden = NO;
                                weakSelf.feedImageView.clipsToBounds = YES;
                                if (downloadedImage) {
                                    CGRect screenRect = [[UIScreen mainScreen] bounds];
                                    CGFloat screenWidth = screenRect.size.width;
                                    NSNumber *hPaddingInNumber = [self.metrics valueForKey:@"hPadding"];
                                    NSNumber *heightOfFrameInNumber = [self.metrics valueForKey:@"kFeedImageViewHeight"];
                                    CGFloat hPadding = hPaddingInNumber ? hPaddingInNumber.floatValue : 0;
                                    CGFloat heightOfFrame = heightOfFrameInNumber ? heightOfFrameInNumber.floatValue : 0;
                                    CGFloat widthOfFrame = screenWidth - (hPadding * 2);
                                    CGSize size = CGSizeMake(widthOfFrame, heightOfFrame);
                                    if (self.cellType == CellStyleFeedListDetails) {

                                        size = [UIImageView
                                                CGSizeFillSize:CGSizeMake(downloadedImage.size.width, downloadedImage.size.height)
                                                boundingSize:size];
                                        [self.metrics setObject:@(size.height) forKey:@"kFeedImageViewHeight"];
                                        [weakSelf.feedImageView setImage:downloadedImage];

                                        weakSelf.feedImageView.contentMode = UIViewContentModeScaleAspectFill;

                                    } else if (self.cellType == CellStyleFeedList) {
                                        size = [UIImageView
                                                CGSizeFillSize:CGSizeMake(downloadedImage.size.width, downloadedImage.size.height)
                                                boundingSize:size];
                                        [self.metrics setObject:@(size.height) forKey:@"kFeedImageViewHeight"];
                                        [weakSelf.feedImageView setImage:downloadedImage];
                                        weakSelf.feedImageView.contentMode = UIViewContentModeScaleAspectFill;
                                    }
                                    if (_delegate && [_delegate respondsToSelector:@selector(needToUpdate:)] && isNewImage) {
                                        [_delegate needToUpdate:self.imageRequestForindexPath];
                                    }
                                } else {
                                    weakSelf.feedImageView.hidden = YES;
                                    [self.metrics setObject:@(0) forKey:@"kFeedImageViewHeight"];
                                }
                            } else {
                                weakSelf.feedImageView.hidden = YES;
                                [self.metrics setObject:@(0) forKey:@"kFeedImageViewHeight"];
                            }
                            [weakSelf.feedImageView stopAnimating];
                            [weakSelf updateVerticalConstrain];
                        }];
    }
}
- (void)setImageViewDimension:(CGFloat)value andType:(NSLayoutAttribute)attributeType {
    for (NSLayoutConstraint *aConstraint in self.feedImageView.constraints) {
        if (aConstraint.firstAttribute == attributeType) {
            aConstraint.constant = value;
        }
    }
    [self.feedImageView layoutIfNeeded];
    [self.contentView layoutIfNeeded];
}
- (void)updateVerticalConstrain {
    if (_verticleContrains) {
        [self.cellBackgroundView removeConstraints:_verticleContrains];
    }
    _verticleContrains = [NSLayoutConstraint
                          constraintsWithVisualFormat:@"V:|-hPaddingOptional-[headerView(kHeaderView)]-hPaddingOptional-[detailsLabel]-paddingdescTextToFeedImage-["
                          @"feedImageView(kFeedImageViewHeight)]-"
                          @"paddingdescTextToFeedImage-[imageLinkButton(kImageLinkButtonHeight)]-hPaddingOptional-[commentByUsersNameLabel("
                          @"kcommentByUsersNameLabelheight)]-hPaddingOptional-[boundaryView(kUppreBoundaryView)]-hPaddingOptional-["
                          @"commentView(kCommentViewHeight)]-hPaddingOptional-[lowerBoundaryView(kLowerBoundaryView)]-hPaddingOptional-|"
                          options:0
                          metrics:self.metrics
                          views:self.views];
    [self.cellBackgroundView addConstraints:_verticleContrains];
    [self.cellBackgroundView layoutIfNeeded];
    [self.contentView layoutIfNeeded];
    self.feedImageView.backgroundColor = [UIColor whiteColor];
}
- (void)dismissKeyBoard {
    if (self.commentTextField && [self.commentTextField isFirstResponder]) {
        [self.commentTextField resignFirstResponder];
    }
}
- (void)dismissKeyBoard:(void (^)(void))completion {
    if (self.commentTextField && [self.commentTextField isFirstResponder]) {
        [self dismissKeyBoard];
        [NSObject performInMainThreadAfterDelay:0.3
                                     completion:^{
                                         if (completion)
                                             completion();
                                     }];
    } else {
        if (completion)
            completion();
    }
}
- (void)resetCommentTextField {
    self.commentTextField.text = nil;
    [self dismissKeyBoard];
}

#pragma mark - Custom Accessors
- (UIView *)cellBackgroundView {
    if (!_cellBackgroundView) {
        _cellBackgroundView = [[UIView alloc] init];
        _cellBackgroundView.translatesAutoresizingMaskIntoConstraints = NO;
    }
    return _cellBackgroundView;
}
- (UIView *)headerView {
    if (!_headerView) {
        _headerView = [[UIView alloc] init];
        _headerView.translatesAutoresizingMaskIntoConstraints = NO;
            //_headerView.backgroundColor = [UIColor greenColor];
    }
    return _headerView;
}
- (UILabel *)detailsLabel {
    if (!_detailsLabel) {
        _detailsLabel = [[UILabel alloc] init];
        _detailsLabel.font = CHATTER_Comment_FONT_SIZE;
        _detailsLabel.textColor = [UIColor darkGreyColorABI];
        _detailsLabel.translatesAutoresizingMaskIntoConstraints = NO;
        _detailsLabel.lineBreakMode = NSLineBreakByTruncatingTail;
    }
    return _detailsLabel;
}
- (CustomImageView *)feedImageView {
    if (!_feedImageView) {
        _feedImageView = [[CustomImageView alloc] init];
        _feedImageView.contentMode = UIViewContentModeScaleAspectFit;
        _feedImageView.translatesAutoresizingMaskIntoConstraints = NO;
        _feedImageView.backgroundColor = [UIColor clearColor];
    }
    return _feedImageView;
}
- (UILabel *)commentByUsersNameLabel {
    if (!_commentByUsersNameLabel) {
        _commentByUsersNameLabel = [[UILabel alloc] init];
        _commentByUsersNameLabel.font = [UIFont fontHelvetica57Condensed:12.0f];
        _commentByUsersNameLabel.textColor = [UIColor defaultABIBlueColor];
        _commentByUsersNameLabel.translatesAutoresizingMaskIntoConstraints = NO;
        _commentByUsersNameLabel.numberOfLines = 1;
        _commentByUsersNameLabel.hidden = YES;
        if (!_tapGesture) {
            _tapGesture = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(clickedRecentCommentUserNamesButton:)];
            [_commentByUsersNameLabel addGestureRecognizer:_tapGesture];
            _commentByUsersNameLabel.userInteractionEnabled = YES;
        }
    }
    return _commentByUsersNameLabel;
}
- (UIView *)boundaryView {
    if (!_boundaryView) {
        _boundaryView = [[UIView alloc] init];
        _boundaryView.backgroundColor = [UIColor veryLightGreySeperator];
        _boundaryView.translatesAutoresizingMaskIntoConstraints = NO;
    }
    return _boundaryView;
}
- (UIView *)lowerBoundaryView {
    if (!_lowerBoundaryView) {
        _lowerBoundaryView = [[UIView alloc] init];
        _lowerBoundaryView.backgroundColor = [UIColor veryLightGreySeperator];
        _lowerBoundaryView.translatesAutoresizingMaskIntoConstraints = NO;
    }
    return _lowerBoundaryView;
}
- (UIView *)commentView {
    if (!_commentView) {
        _commentView = [[UIView alloc] init];
        _commentView.translatesAutoresizingMaskIntoConstraints = NO;
            //_commentView.backgroundColor = [UIColor cyanColor];
    }
    return _commentView;
}

- (CustomView *)userImageView {
    if (!_userImageView) {
        _userImageView = [[CustomView alloc] initWithImage:[UIImage imageABIDummyUser]
                                             andOuterImage:[UIImage imageABIOuterCircle]
                                                   andSize:CGSizeMake(52, 52)
                                    andPaddingForInnerView:4];
        _userImageView.translatesAutoresizingMaskIntoConstraints = NO;
    }
    _userImageView.clipsToBounds = YES;
    return _userImageView;
}
- (UILabel *)userNameLabel {
    if (!_userNameLabel) {
        _userNameLabel = [[UILabel alloc] init];
        _userNameLabel.font = USERNAME_FONT_SIZE;
        _userNameLabel.textColor = [UIColor darkGreyColorABI];
        _userNameLabel.translatesAutoresizingMaskIntoConstraints = NO;
    }
    return _userNameLabel;
}
- (UILabel *)timeLabel {
    if (!_timeLabel) {
        _timeLabel = [[UILabel alloc] init];
        _timeLabel.font = TIME_FONT_SIZE;
        _timeLabel.textColor = [UIColor defaultTextLightColor];
        _timeLabel.translatesAutoresizingMaskIntoConstraints = NO;
    }
    return _timeLabel;
}
- (UILabel *)incentiveNameLabel {
    if (!_incentiveNameLabel) {
        _incentiveNameLabel = [[UILabel alloc] init];
        _incentiveNameLabel.font = INCENTIVE_TYPE_FONT_SIZE;
        _incentiveNameLabel.textColor = [UIColor defaultTextLightColor];
        _incentiveNameLabel.translatesAutoresizingMaskIntoConstraints = NO;
    }
    return _incentiveNameLabel;
}
- (UIImageView *)currentUserImageView {
    if (!_currentUserImageView) {
        _currentUserImageView = [[UIImageView alloc] initWithImage:[UIImage imageABIDummyUser]];
        _currentUserImageView.translatesAutoresizingMaskIntoConstraints = NO;
    }
    return _currentUserImageView;
}
- (CustomView *)currentUserImageBorderView {
    if (!_currentUserImageBorderView) {
        _currentUserImageBorderView = [[CustomView alloc] initWithImage:[UIImage imageABIDummyUser]
                                                          andOuterImage:[UIImage imageABIOuterCircle]
                                                                andSize:CGSizeMake(36, 36)
                                                 andPaddingForInnerView:2];
        _currentUserImageBorderView.translatesAutoresizingMaskIntoConstraints = NO;
    }
        //	_currentUserImageBorderView.layer.cornerRadius = 18.0f;
    _currentUserImageBorderView.clipsToBounds = YES;
    return _currentUserImageBorderView;
}
- (UIButton *)commentButton {
    if (!_commentButton) {
        _commentButton = [[UIButton alloc] init];
        [_commentButton setBackgroundImage:[UIImage imageNamed:postIcon] forState:UIControlStateNormal];
        [_commentButton addTarget:self action:@selector(clickedPostComment:) forControlEvents:UIControlEventTouchUpInside];
        _commentButton.translatesAutoresizingMaskIntoConstraints = NO;
    }
    return _commentButton;
}
- (UITextField *)commentTextField {
    if (!_commentTextField) {
        _commentTextField = [[UITextField alloc] init];
        _commentTextField.placeholder = PLACEHOLDER_WRITE_A_COMMENT;
        _commentTextField.font = USER_Comment_FONT_SIZE;
        _commentTextField.textColor = [UIColor defaultTextLightColor];
        _commentTextField.translatesAutoresizingMaskIntoConstraints = NO;
        _commentTextField.delegate = self;
        _commentTextField.autocorrectionType = UITextAutocorrectionTypeYes;
        _commentTextField.spellCheckingType = UITextSpellCheckingTypeYes;
    }
    return _commentTextField;
}
- (UIButton *)imageLinkButton {
    if (!_imageLinkButton) {
        _imageLinkButton = [UIButton buttonWithType:UIButtonTypeCustom];
        _imageLinkButton.backgroundColor = [UIColor clearColor];
        [_imageLinkButton setImage:[UIImage imageNamed:attachment] forState:UIControlStateNormal];
        [_imageLinkButton titleLabel].font = TIME_FONT_SIZE;
        _imageLinkButton.translatesAutoresizingMaskIntoConstraints = NO;
        [_imageLinkButton setTitleColor:[UIColor blueColorABI] forState:UIControlStateNormal];
        [_imageLinkButton addTarget:self action:@selector(clicledFileLinkButton:) forControlEvents:UIControlEventTouchUpInside];
    }
    return _imageLinkButton;
}
- (NSDictionary *)views {
    if (!_views) {
        _views = @{
                   @"cellBackgroundView" : self.cellBackgroundView,
                   @"headerView" : self.headerView,
                   @"detailsLabel" : self.detailsLabel,
                   @"feedImageView" : self.feedImageView,
                   @"commentByUsersNameLabel" : self.commentByUsersNameLabel,
                   @"boundaryView" : self.boundaryView,
                   @"commentView" : self.commentView,
                   @"userImageView" : self.userImageView,
                   @"userNameLabel" : self.userNameLabel,
                   @"timeLabel" : self.timeLabel,
                   @"incentiveNameLabel" : self.incentiveNameLabel,
                   @"currentUserImageBorderView" : self.currentUserImageBorderView,
                   @"commentTextField" : self.commentTextField,
                   @"commentButton" : self.commentButton,
                   @"lowerBoundaryView" : self.lowerBoundaryView,
                   @"imageLinkButton" : self.imageLinkButton
                   };
    }
    return _views;
}
#pragma mark - IBAction
- (void)clicledFileLinkButton:(UIButton *)sender {
    NSArray *items = self.feedElementDataModel.file.items;
    if (items.count) {
        ABISFChatterContentDataModel *contentDataModel = [items firstObject];
        if (self.delegate && [self.delegate respondsToSelector:@selector(clickedFileContainLins:cell:)]) {
            [self.delegate clickedFileContainLins:contentDataModel cell:self];
        }
    }
}
- (void)clickedPostComment:(UIButton *)sender {
    sender.enabled = NO;
    [NSObject performInMainThreadAfterDelay:0.8 completion:^{ sender.enabled = YES; }];
    if (self.delegate && [self.delegate respondsToSelector:@selector(clickedPostComment:cell:)]) {
        __weak typeof(self) weakSelf = self;
        [self dismissKeyBoard:^{ [weakSelf.delegate clickedPostComment:sender cell:self]; }];
    }
}
- (void)clickedRecentCommentUserNamesButton:(UIButton *)sender {
    sender.enabled = NO;
    [NSObject performInMainThreadAfterDelay:0.8 completion:^{ sender.enabled = YES; }];

    if (self.delegate && [self.delegate respondsToSelector:@selector(clickedRecentCommentUserNamesButton:cell:)]) {
        [self.delegate clickedRecentCommentUserNamesButton:sender cell:self];
    }
}
#pragma mark - UITextFieldDelegate
- (BOOL)textFieldShouldReturn:(UITextField *)textField {
    [self dismissKeyBoard];
    return YES;
}
@end
