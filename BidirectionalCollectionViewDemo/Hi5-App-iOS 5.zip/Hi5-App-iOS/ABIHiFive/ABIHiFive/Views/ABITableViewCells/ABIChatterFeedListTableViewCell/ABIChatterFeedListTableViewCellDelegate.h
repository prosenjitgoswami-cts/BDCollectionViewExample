    //
    //  ABIChatterFeedListTableViewCellDelegate.h
    //  ABIHiFive
    //
    //  Created by Prsenjit Goswami on 23/07/16.
    //  Copyright © 2016 Cognizant. All rights reserved.
    //
#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>

@class ABISFChatterContentDataModel;
@class ABIChatterFeedListTableViewCell;
@protocol ABIChatterFeedListTableViewCellDelegate <NSObject>
- (void)clickedPostComment:(UIButton *)sender cell:(ABIChatterFeedListTableViewCell *)cell;
@optional
- (void)clickedRecentCommentUserNamesButton:(UIButton *)sender cell:(ABIChatterFeedListTableViewCell *)cell;
- (void)selectedCell:(ABIChatterFeedListTableViewCell *)cell;
- (void)clickedFileContainLins:(ABISFChatterContentDataModel *)ABISFChatterContentDataModel cell:(ABIChatterFeedListTableViewCell *)cell;
- (void)needToUpdate:(NSIndexPath *)indexPath;
@end
