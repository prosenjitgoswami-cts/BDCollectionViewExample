    //
    //  ABIBadgeDetailTableViewCell.h
    //  ABIHiFive
    //
    //  Created by Prsenjit Goswami on 16/08/16.
    //  Copyright © 2016 Cognizant. All rights reserved.
    //
#import "Constants.h"
#import <UIKit/UIKit.h>
@interface ABIBadgeDetailTableViewCell : UITableViewCell
- (nonnull instancetype)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(nullable NSString *)reuseIdentifier;
- (void)updateCellAtindexPath:(nonnull NSIndexPath *)indexPath
 withABISFEarnBadgesDataModel:(nullable ABISFEarnBadgesDataModel *)earnBadgesDataModel
       totalGroupedBadgeCount:(nullable NSNumber *)totalGroupedBadgeCount
            isSeperatorHidden:(Boolean)isSeperatorHidden;
@end
