    //
    //  ABIBadgeDetailTableViewCell.m
    //  ABIHiFive
    //
    //  Created by Prsenjit Goswami on 16/08/16.
    //  Copyright © 2016 Cognizant. All rights reserved.
    //
#import "ABIBadgeDetailTableViewCell.h"
#import "ABISFEarnBadgesDataModel.h"
#import "CustomBadge.h"
@interface ABIBadgeDetailTableViewCell ()
@property (strong, nonatomic) UIView *textView;
@property (strong, nonatomic) UIView *borderView;
@property (strong, nonatomic) UILabel *incentiveNameLabel;
@property (strong, nonatomic) UILabel *dateLabel;
@property (strong, nonatomic) UIImageView *ribbonImgView;
@property (strong, nonatomic) CustomBadge *badge;
@property (strong, nonatomic) UIView *badgeImageView;
@end
@implementation ABIBadgeDetailTableViewCell
- (void)awakeFromNib {
    [super awakeFromNib];
        // Initialization code
}
- (instancetype)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier {
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if (self) {
        [self configureUI];
    }
    return self;
}
- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];
        // Configure the view for the selected state
}
- (void)configureUI {
    [self.contentView addSubview:self.badgeImageView];
    [self.contentView addSubview:self.textView];
    [self.textView addSubview:self.incentiveNameLabel];
    [self.textView addSubview:self.dateLabel];
    [self.textView addSubview:self.borderView];
        //[self addConstraintsToView];
}
- (void)addConstraintsToView {
    NSDictionary *views = @{
                            @"badgeImageView" : self.badgeImageView,
                            @"textView" : self.textView,
                            @"incentiveNameLabel" : self.incentiveNameLabel,
                            @"dateLabel" : self.dateLabel,
                            @"borderView" : self.borderView,
                            };
    [self.contentView
     addConstraints:[NSLayoutConstraint constraintsWithVisualFormat:@"H:|-[badgeImageView(50)]-[textView]-|" options:0 metrics:nil views:views]];
    [self.contentView addConstraints:[NSLayoutConstraint constraintsWithVisualFormat:@"V:|-4-[badgeImageView(50)]" options:0 metrics:nil views:views]];

    [self.contentView addConstraints:[NSLayoutConstraint constraintsWithVisualFormat:@"V:|[textView]|" options:0 metrics:nil views:views]];
    if (self.incentiveNameLabel.text.length == 0) {
        [self.textView addConstraints:[NSLayoutConstraint constraintsWithVisualFormat:@"V:[borderView(1)]-0@999-|" options:0 metrics:nil views:views]];
        [self.dateLabel centerYToParent:self.textView];
    } else {

        [self.textView
         addConstraints:[NSLayoutConstraint constraintsWithVisualFormat:@"V:|-15@999-[incentiveNameLabel]-3-[dateLabel]->=5-[borderView(1)]-0@999-|"
                                                                options:0
                                                                metrics:nil
                                                                  views:views]];
    }
    [self.textView addConstraints:[NSLayoutConstraint constraintsWithVisualFormat:@"H:|-[incentiveNameLabel]" options:0 metrics:nil views:views]];
    [self.textView addConstraints:[NSLayoutConstraint constraintsWithVisualFormat:@"H:|-[dateLabel]" options:0 metrics:nil views:views]];
    [self.textView addConstraints:[NSLayoutConstraint constraintsWithVisualFormat:@"H:|[borderView]|" options:0 metrics:nil views:views]];
}
- (UIView *)badgeImageView {
    if (!_badgeImageView) {
        _badgeImageView = [self returnCustomBadgeImageWithTag:@""];
        _badgeImageView.translatesAutoresizingMaskIntoConstraints = NO;
    }
    return _badgeImageView;
}
- (UIView *)returnCustomBadgeImageWithTag:(NSString *)tag {
    UIView *contentView = [[UIView alloc] init];
    self.badge = [CustomBadge customBadgeWithString:@"0"];
    self.badge.hidden = NO;
    self.ribbonImgView = [[UIImageView alloc] initWithImage:nil];
    [contentView addSubview:self.ribbonImgView];
    CGRect rect;
    rect.origin.x = 0;
    rect.origin.y = 15;
    rect.size.width = 35.0f;
    rect.size.height = 35.0f;
    self.ribbonImgView.frame = rect;
    CGRect badgeRect = rect;
    badgeRect.origin.x = CGRectGetMaxX(self.ribbonImgView.frame) - 15;
    badgeRect.origin.y = 5;
    badgeRect.size.width = self.badge.frame.size.width;
    badgeRect.size.height = self.badge.frame.size.height;
    self.badge.frame = badgeRect;
    self.badge.userInteractionEnabled = NO;
    [contentView addSubview:self.badge];
    [contentView bringSubviewToFront:self.badge];
    return contentView;
}
- (UIView *)textView {
    if (!_textView) {
        _textView = [[UIView alloc] init];
    }
    _textView.translatesAutoresizingMaskIntoConstraints = NO;
    return _textView;
}
- (UIView *)borderView {
    if (!_borderView) {
        _borderView = [[UIView alloc] init];
    }
    _borderView.translatesAutoresizingMaskIntoConstraints = NO;
    _borderView.backgroundColor = [UIColor defaultPageBGColor];
    return _borderView;
}
- (UILabel *)incentiveNameLabel {
    if (!_incentiveNameLabel) {
        _incentiveNameLabel = [[UILabel alloc] init];
    }
    _incentiveNameLabel.translatesAutoresizingMaskIntoConstraints = NO;
    _incentiveNameLabel.textColor = [UIColor defaultTextDarkColor];
    _incentiveNameLabel.font = [UIFont fontHelvetica57Condensed:12.0f];
    return _incentiveNameLabel;
}
- (UILabel *)dateLabel {
    if (!_dateLabel) {
        _dateLabel = [[UILabel alloc] init];
    }
    _dateLabel.translatesAutoresizingMaskIntoConstraints = NO;
    _dateLabel.textColor = [UIColor defaultTextDarkColor];
    _dateLabel.font = [UIFont fontHelvetica57Condensed:12.0f];
    return _dateLabel;
}
- (void)updateCellAtindexPath:(NSIndexPath *)indexPath
 withABISFEarnBadgesDataModel:(ABISFEarnBadgesDataModel *)earnBadgesDataModel
       totalGroupedBadgeCount:(NSNumber *)totalGroupedBadgeCount
            isSeperatorHidden:(Boolean)isSeperatorHidden {
    if (_badgeImageView) {
        [_badgeImageView removeFromSuperview];
        _badgeImageView = nil;
    }
    if (_textView) {
        [_textView removeFromSuperview];
        _textView = nil;
    }
    if (_incentiveNameLabel) {
        [_incentiveNameLabel removeFromSuperview];
        _incentiveNameLabel = nil;
    }
    if (_dateLabel) {
        [_dateLabel removeFromSuperview];
        _dateLabel = nil;
    }
    if (_borderView) {
        [_borderView removeFromSuperview];
        _borderView = nil;
    }
    [self configureUI];
    if (isSeperatorHidden) {
        _borderView.hidden = YES;
    }
    self.badge.hidden = NO;
    UIImage *noMedel = [UIImage imageNamed:@"no_Medal"];
    if (earnBadgesDataModel.badgesDataModel.count == 0) {
        self.badge.hidden = YES;
        _dateLabel.text = STATIC_TEXT_NO_BADGES_TEXT;
        _incentiveNameLabel.text = nil;
        _ribbonImgView.image = noMedel;
    } else {
        NSArray *badgesDataModels = earnBadgesDataModel.badgesDataModel;
        if ([NSArray isValidArray:badgesDataModels] && badgesDataModels.count) {
            ABISFBadgesDataModel *badgesDataModel = [badgesDataModels firstObject];
            _dateLabel.text = badgesDataModel.incentiveDateString;
            _incentiveNameLabel.text = badgesDataModel.incentiveName;
        }
        NSString *urlString = earnBadgesDataModel.badgesImageURLString;
        NSInteger badgeCount = totalGroupedBadgeCount.integerValue ? totalGroupedBadgeCount.integerValue : 0;
        self.badge.badgeText = [NSString stringWithFormat:@"%ld", (long)badgeCount];
        self.badgeImageView.hidden = NO;
        __weak typeof(self) weakSelf = self;

        [_ribbonImgView setABIBadgeImageWithURL:urlString
                               placeholderImage:nil
                                     completion:^(UIImage *image) {
                                         weakSelf.ribbonImgView.image = image;
                                         weakSelf.badge.hidden = (badgeCount == 0);
                                     }];
            //        [_ribbonImgView imageWithURLString:urlString
            //                          placeholderImage:nil
            //                                completion:^(UIImage *_Nonnull image) {
            //                                    if (image) {
            //                                        weakSelf.ribbonImgView.image = image;
            //                                        self.badge.hidden = (badgeCount == 0);
            //                                    }
            //                                }];
    }
    [self addConstraintsToView];
    _badgeImageView.hidden = indexPath.row != 0;
    _ribbonImgView.hidden = indexPath.row != 0;
}
@end
