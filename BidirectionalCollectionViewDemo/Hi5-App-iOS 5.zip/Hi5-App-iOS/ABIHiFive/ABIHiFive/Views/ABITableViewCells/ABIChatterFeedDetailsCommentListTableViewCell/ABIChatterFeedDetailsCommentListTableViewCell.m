    //
    //  ABIChatterFeedDetailsCommentListTableViewCell.m
    //  AnheuserBusch
    //
    //  Created by Amit Kumar on 7/22/16.
    //  Copyright © 2016 Cognizant. All rights reserved.
    //
#import "ABIChatterFeedDetailsCommentListTableViewCell.h"
#import "Constants.h"
@interface ABIChatterFeedDetailsCommentListTableViewCell ()
@property (nonatomic, strong) UILabel *userName;
@property (nonatomic, strong) UILabel *timelbl;
@property (nonatomic, strong) UILabel *commentDescription;
@end
@implementation ABIChatterFeedDetailsCommentListTableViewCell
- (instancetype)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier {
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if (self) {
        [self multiUserCommentFunction];
    }
    return self;
}
#pragma Public Method
- (void)setABISFChatterCommentItemModel:(ABISFChatterCommentItemModel *)commentItemModel {
    _commentItemModel = commentItemModel;
    self.userName.text = _commentItemModel.parent.name;
    self.timelbl.text = _commentItemModel.refreshTime;
    self.commentDescription.text = _commentItemModel.message;
}
#pragma mark - Private Method
- (void)multiUserCommentFunction {
    [self.contentView addSubview:self.userName];
    [self.contentView addSubview:self.timelbl];
    [self.contentView addSubview:self.commentDescription];
    NSDictionary *views = @{ @"userName" : self.userName, @"timelbl" : self.timelbl, @"description" : self.commentDescription };
    [self.contentView addConstraints:[NSLayoutConstraint constraintsWithVisualFormat:@"V:|[userName(20)]-0-[timelbl(12)]-10-[description]-10-|"
                                                                             options:0
                                                                             metrics:nil
                                                                               views:views]];
    [self.contentView addConstraints:[NSLayoutConstraint constraintsWithVisualFormat:@"H:|-5-[userName(150)]" options:0 metrics:nil views:views]];
    [self.contentView addConstraints:[NSLayoutConstraint constraintsWithVisualFormat:@"H:|-5-[timelbl(150)]" options:0 metrics:nil views:views]];
    [self.contentView addConstraints:[NSLayoutConstraint constraintsWithVisualFormat:@"H:|-5-[description]-2-|" options:0 metrics:nil views:views]];
}
- (UILabel *)userName {
    if (!_userName) {
        _userName = [[UILabel alloc] init];
        _userName.font = USERNAME_FONT_SIZE;
        _userName.textColor = [UIColor blueColorABI];
        _userName.translatesAutoresizingMaskIntoConstraints = NO;
    }
    return _userName;
}
- (UILabel *)timelbl {
    if (!_timelbl) {
        _timelbl = [[UILabel alloc] init];
        _timelbl.font = TIME_FONT_SIZE;
        _timelbl.textColor = [UIColor defaultTextLightColor];
        _timelbl.translatesAutoresizingMaskIntoConstraints = NO;
    }
    return _timelbl;
}
- (UILabel *)commentDescription {
    if (!_commentDescription) {
        _commentDescription = [[UILabel alloc] init];
        _commentDescription.textColor = [UIColor darkGreyColorABI];
        [_commentDescription setFont:CHATTER_Comment_FONT_SIZE];
        _commentDescription.numberOfLines = 0;
        _commentDescription.translatesAutoresizingMaskIntoConstraints = NO;
    }
    return _commentDescription;
}
- (void)refreshData {
    _userName.text = self.commentItemModel.parent.name;
    _commentDescription.text = self.commentItemModel.message;
    _timelbl.text = self.commentItemModel.refreshTime;
}
@end
