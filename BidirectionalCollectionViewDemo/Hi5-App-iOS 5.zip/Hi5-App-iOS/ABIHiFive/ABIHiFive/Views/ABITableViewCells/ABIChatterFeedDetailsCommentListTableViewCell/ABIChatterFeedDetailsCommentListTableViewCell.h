    //
    //  ABIChatterFeedDetailsCommentListTableViewCell.h
    //  AnheuserBusch
    //
    //  Created by Amit Kumar on 7/22/16.
    //  Copyright © 2016 Cognizant. All rights reserved.
    //
#import "ABISFChatterCommentItemModel.h"
#import <UIKit/UIKit.h>
@interface ABIChatterFeedDetailsCommentListTableViewCell : UITableViewCell
@property (nonatomic, strong) ABISFChatterCommentItemModel *commentItemModel;
@end
