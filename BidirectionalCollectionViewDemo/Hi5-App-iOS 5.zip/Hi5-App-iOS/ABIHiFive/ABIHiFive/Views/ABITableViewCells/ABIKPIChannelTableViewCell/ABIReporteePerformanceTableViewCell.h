    //
    //  ABIReporteePerformanceTableViewCell.h
    //  ABIHiFive
    //
    //  Created by Amit Kumar on 8/18/16.
    //  Copyright © 2016 Cognizant. All rights reserved.
    //
#import <UIKit/UIKit.h>
@class ABIDMPerformaceView, ABISFMyReporteePerformanceDataModel;
@interface ABIReporteePerformanceTableViewCell : UITableViewCell
@property (nonatomic, strong) UIColor *backGroundViewColor;
@property (nonatomic, strong) UIColor *seperatorColorColor;
@property (nonatomic, strong) UIColor *titleTextColor;
@property (strong, nonatomic) NSArray<ABISFMyReporteePerformanceDataModel *> *myDMsPerformanceDataModels;
@property (nonatomic, strong) ABIDMPerformaceView *dmLabelsCreateView;
@end
