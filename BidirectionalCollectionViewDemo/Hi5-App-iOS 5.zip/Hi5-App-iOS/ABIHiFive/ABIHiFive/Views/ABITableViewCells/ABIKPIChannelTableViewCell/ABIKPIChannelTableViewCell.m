    //
    //  ABIKPIChannelTableViewCell.m
    //  ABIHiFive
    //
    //  Created by Prsenjit Goswami on 30/06/16.
    //  Copyright © 2016 Cognizant. All rights reserved.
    //
#import "ABIKPIChannelTableViewCell.h"
#import "Constants.h"
@interface ABIKPIChannelTableViewCell ()
@property (nonatomic, strong) UILabel *incentiveTitleLabel;
@property (nonatomic, strong) UIView *seperatorView;
@property (nonatomic, strong) UIView *customBackgroundView;

@end
@implementation ABIKPIChannelTableViewCell
#pragma mark - Cell Life Cycle
- (instancetype)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier {
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if (self) {
        [self createAndAddUI];
    }
    return self;
}
- (void)dealloc {
    _customBackgroundView = nil;
    _incentiveTitleLabel = nil;
    _incentiveBarChartView = nil;
    _dropDownButton = nil;
}
#pragma mark - Public Method
- (void)setKpiName:(NSString *)kpiName {
    _kpiName = kpiName;
    if (![NSString isNULLString:_kpiName])
        self.incentiveTitleLabel.text = kpiName;
    self.incentiveTitleLabel.textColor = [UIColor darkTextColor];
}
#pragma mark - Private Method
/*!
 *  Create UI
 */
- (void)createAndAddUI {
    self.backgroundView.backgroundColor = [UIColor clearColor];
    self.incentiveBarChartView.unitTextFont = [UIFont fontHelvetica57Condensed:10.0f];
    self.incentiveBarChartView.unitTextColor = [UIColor darkTextColor];
        //    self.dmLabelsCreateView = [[ABIDMPerformaceView alloc]init];
        //    self.dmLabelsCreateView.translatesAutoresizingMaskIntoConstraints = NO;
    [self.contentView addSubview:self.customBackgroundView];
    [self.customBackgroundView addSubview:self.incentiveTitleLabel];
    [self.customBackgroundView addSubview:self.dropDownButton];
    [self.customBackgroundView addSubview:self.seperatorView];
    [self.customBackgroundView addSubview:self.incentiveBarChartView];
        //    [self.customBackgroundView addSubview:self.dmLabelsCreateView];
        //    [self.customBackgroundView addSubview:self.dmPerformanceLabel];
        //    [self.customBackgroundView addSubview:self.bottomSeperatorView];
        //    [self.customBackgroundView addSubview:self.dmLabelsCreateView];
    [self addConstrainsts];
        //    [self dmPerformanceViewCreate];
}
/*!
 *  Add Component Constrains
 */
- (void)addConstrainsts {
    NSDictionary *views = @{
                            @"customBackgroundView" : self.customBackgroundView,
                            @"seperatorView" : self.seperatorView,
                            @"incentiveTitleLabel" : self.incentiveTitleLabel,
                            @"incentiveBarChartView" : self.incentiveBarChartView,
                            @"dropDownButton" : self.dropDownButton
                            };
    NSMutableDictionary *metrics = [NSLayoutConstraint defaultMetricsDictionary];
    [self.contentView
     addConstraints:[NSLayoutConstraint constraintsWithVisualFormat:[NSString stringWithFormat:@"H:|-%@-[customBackgroundView]-%@-|",
                                                                     kMetricsDefaultPadding, kMetricsDefaultPadding]
                                                            options:0
                                                            metrics:metrics
                                                              views:views]];
    [self.contentView addConstraints:[NSLayoutConstraint constraintsWithVisualFormat:@"V:|[customBackgroundView]|" options:0 metrics:nil views:views]];
    [self.customBackgroundView
     addConstraints:[NSLayoutConstraint constraintsWithVisualFormat:@"H:|-[incentiveTitleLabel]-|" options:0 metrics:nil views:views]];
    [self.customBackgroundView
     addConstraints:[NSLayoutConstraint constraintsWithVisualFormat:@"H:[dropDownButton(20)]-|" options:0 metrics:nil views:views]];
    [self.customBackgroundView
     addConstraints:[NSLayoutConstraint constraintsWithVisualFormat:@"V:|-[dropDownButton(20)]" options:0 metrics:nil views:views]];
    [self.customBackgroundView
     addConstraints:[NSLayoutConstraint constraintsWithVisualFormat:@"H:|-[seperatorView]-|" options:0 metrics:nil views:views]];
    [self.customBackgroundView
     addConstraints:[NSLayoutConstraint constraintsWithVisualFormat:@"H:|-[incentiveBarChartView]-|" options:0 metrics:nil views:views]];
        //    [self.customBackgroundView addConstraints:[NSLayoutConstraint constraintsWithVisualFormat:@"H:|-[dmPerformanceLabel]-|" options:0 metrics:nil
        //    views:views]];
        //    [self.customBackgroundView addConstraints:[NSLayoutConstraint constraintsWithVisualFormat:@"H:|-[bottomSeperatorView]-125-|" options:0
        //    metrics:nil views:views]];
        //    [self.customBackgroundView addConstraints:[NSLayoutConstraint constraintsWithVisualFormat:@"H:|-[dmLabelsCreateView]-|" options:0 metrics:nil
        //    views:views]];
    [self.customBackgroundView
     addConstraints:[NSLayoutConstraint
                     constraintsWithVisualFormat:
                     [NSString stringWithFormat:@"V:|-[incentiveTitleLabel]-[seperatorView(%@)]-%@-[incentiveBarChartView(%@)]",
                      kMetricsDefaultCellSeperatorHeight, kMetricsDefaultPadding, kMetricskDefaultBarChartHeight]
                     options:0
                     metrics:metrics
                     views:views]];
}
- (UIView *)customBackgroundView {
    if (!_customBackgroundView) {
        _customBackgroundView = [UIView new];
        _customBackgroundView.translatesAutoresizingMaskIntoConstraints = NO;
        _customBackgroundView.layer.cornerRadius = DEFAULT_CELL_CORNER_RADIUS;
    }
    return _customBackgroundView;
}
    //- (UIView *)dmLabelsCreateView {
    //
    //    if(!_dmLabelsCreateView) {
    //
    //        _dmLabelsCreateView = [UIView new];
    //        _dmLabelsCreateView.translatesAutoresizingMaskIntoConstraints =  NO;
    //    }
    //
    //    return _dmLabelsCreateView;
    //}
- (UILabel *)incentiveTitleLabel {
    if (!_incentiveTitleLabel) {
        _incentiveTitleLabel = [UILabel new];
        _incentiveTitleLabel.translatesAutoresizingMaskIntoConstraints = NO;
        _incentiveTitleLabel.font = [UIFont fontHelvetica57Condensed:12.0];
    }
    return _incentiveTitleLabel;
}
- (UIButton *)dropDownButton {
    if (!_dropDownButton) {
        _dropDownButton = [UIButton new];
        _dropDownButton.translatesAutoresizingMaskIntoConstraints = NO;
        UIImage *btnImage = [UIImage imageNamed:@"dropDownImg"];
        [_dropDownButton setImage:btnImage forState:UIControlStateNormal];
        _dropDownButton.clipsToBounds = YES;
        [_dropDownButton addTarget:self action:@selector(toggleReporteePerformanceView:) forControlEvents:(UIControlEvents)UIControlEventTouchDown];
        _dropDownButton.userInteractionEnabled = YES;
    }
    return _dropDownButton;
}

- (UIView *)incentiveBarChartView {
    if (!_incentiveBarChartView) {
        _incentiveBarChartView = [[CustomProgressBarView alloc] init];
        _incentiveBarChartView.translatesAutoresizingMaskIntoConstraints = NO;
    }
    return _incentiveBarChartView;
}
- (UIView *)seperatorView {
    if (!_seperatorView) {
        _seperatorView = [UIView new];
        _seperatorView.translatesAutoresizingMaskIntoConstraints = NO;
    }
    return _seperatorView;
}

#pragma mark - Public Method
- (void)setBackGroundViewColor:(UIColor *)backGroundViewColor {
    _backGroundViewColor = backGroundViewColor;
    if (_customBackgroundView && _backGroundViewColor)
        _customBackgroundView.backgroundColor = _backGroundViewColor;
}
- (void)setSeperatorColorColor:(UIColor *)seperatorColorColor {
    _seperatorColorColor = seperatorColorColor;
    if (_seperatorView && _seperatorColorColor)
        _seperatorView.backgroundColor = [UIColor lightGreyColorABI];
        //    _bottomSeperatorView.backgroundColor = [UIColor lightGreyColorABI];
}
- (void)setTitleTextColor:(UIColor *)titleTextColor {
    _titleTextColor = titleTextColor;
    if (_incentiveTitleLabel && _titleTextColor)
        _incentiveTitleLabel.textColor = _titleTextColor;
        //    _dmPerformanceLabel.textColor = _titleTextColor;
}
- (void)toggleReporteePerformanceView:(id)sender {
    if (self.delegate && [self.delegate respondsToSelector:@selector(toggleReporteePerformanceView:indexPath:)]) {
        [self.delegate toggleReporteePerformanceView:self indexPath:self.indexPath];
    }
}
@end
