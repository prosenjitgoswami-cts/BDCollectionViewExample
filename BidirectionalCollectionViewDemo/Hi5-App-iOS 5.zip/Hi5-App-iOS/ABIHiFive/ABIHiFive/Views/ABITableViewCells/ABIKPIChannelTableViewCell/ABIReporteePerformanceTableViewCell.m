    //
    //  ABIReporteePerformanceTableViewCell.m
    //  ABIHiFive
    //
    //  Created by Amit Kumar on 8/18/16.
    //  Copyright © 2016 Cognizant. All rights reserved.
    //
#import "ABIReporteePerformanceTableViewCell.h"
#import "ABIDMPerformaceView.h"
#import "ABISFMyReporteePerformanceDataModel.h"
#import "Constants.h"
@interface ABIReporteePerformanceTableViewCell ()
@end
@implementation ABIReporteePerformanceTableViewCell

#pragma mark -  Cell Life Cycle
- (instancetype)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier {
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if (self) {
        [self createAndAddUI];
    }
    return self;
}
- (void)dealloc {
    _dmLabelsCreateView = nil;
}

#pragma mark -  Public Method
- (void)setABISFMyReporteePerformanceDataModels:(NSMutableArray<ABISFMyReporteePerformanceDataModel *> *)myDMsPerformanceDataModels {
    _myDMsPerformanceDataModels = myDMsPerformanceDataModels;
    self.dmLabelsCreateView.myDMsPerformanceDataModels = _myDMsPerformanceDataModels;
}
- (ABIDMPerformaceView *)dmLabelsCreateView {
    if (!_dmLabelsCreateView) {
        _dmLabelsCreateView = [[ABIDMPerformaceView alloc] initWithDataSource:self.myDMsPerformanceDataModels];
        _dmLabelsCreateView.backgroundColor = [UIColor whiteColorABI];
        _dmLabelsCreateView.layer.cornerRadius = DEFAULT_CELL_CORNER_RADIUS;
        _dmLabelsCreateView.translatesAutoresizingMaskIntoConstraints = NO;
    }
    return _dmLabelsCreateView;
}
- (void)createAndAddUI {
    [self.contentView addSubview:self.dmLabelsCreateView];
    [self addConstrainsts];
}
- (void)addConstrainsts {
    self.layer.cornerRadius = DEFAULT_CELL_CORNER_RADIUS;
    NSDictionary *views = @{ @"dmLabelsCreateView" : self.dmLabelsCreateView };
    [self.contentView
     addConstraints:[NSLayoutConstraint constraintsWithVisualFormat:@"V:|-(-2)-[dmLabelsCreateView]|" options:0 metrics:nil views:views]];
    [self.contentView
     addConstraints:[NSLayoutConstraint constraintsWithVisualFormat:@"H:|-10-[dmLabelsCreateView]-10-|" options:0 metrics:nil views:views]];
}
- (void)awakeFromNib {
    [super awakeFromNib];
        // Initialization code
}
- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];
        // Configure the view for the selected state
}
@end
