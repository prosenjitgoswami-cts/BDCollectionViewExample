    //
    //  ABIKPIChannelTableViewCell.h
    //  ABIHiFive
    //
    //  Created by Prsenjit Goswami on 30/06/16.
    //  Copyright © 2016 Cognizant. All rights reserved.
    //
#import "CustomProgressBarView.h"
#import <UIKit/UIKit.h>
@class ABIKPIChannelTableViewCell;
@protocol ABIKPIChannelTableViewCellDelegate <NSObject>
- (void)toggleReporteePerformanceView:(ABIKPIChannelTableViewCell *)cell indexPath:(NSIndexPath *)indexPath;
@end
@interface ABIKPIChannelTableViewCell : UITableViewCell
@property (nonatomic, strong) UIButton *dropDownButton;
@property (nonatomic, strong) CustomProgressBarView *incentiveBarChartView;
@property (nonatomic, strong) NSString *kpiName;
@property (nonatomic, strong) UIColor *backGroundViewColor;
@property (nonatomic, strong) UIColor *seperatorColorColor;
@property (nonatomic, strong) UIColor *titleTextColor;
@property (nonatomic, strong) NSIndexPath *indexPath;
@property (weak, nonatomic) id<ABIKPIChannelTableViewCellDelegate> delegate;
@end
