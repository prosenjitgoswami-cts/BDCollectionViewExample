    //
    //  ABIChatterFeedRecentCommentUserViewControllerCell.h
    //  ABIHiFive
    //
    //  Created by Prsenjit Goswami on 27/07/16.
    //  Copyright © 2016 Cognizant. All rights reserved.
    //
#import <UIKit/UIKit.h>
@class ABISFChatterCommentItemModel;
@class CustomView;
@interface ABIChatterFeedRecentCommentUserViewControllerCell : UITableViewCell
@property (nonatomic, strong) CustomView *leftImageView;
@property (nonatomic, strong) UILabel *leftDescription;
@property (nonatomic, strong) UILabel *rightDescription;
- (id)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier;
- (void)updateCellWithABISFChatterCommentItemModel:(ABISFChatterCommentItemModel *)commentItemModel;
@end
