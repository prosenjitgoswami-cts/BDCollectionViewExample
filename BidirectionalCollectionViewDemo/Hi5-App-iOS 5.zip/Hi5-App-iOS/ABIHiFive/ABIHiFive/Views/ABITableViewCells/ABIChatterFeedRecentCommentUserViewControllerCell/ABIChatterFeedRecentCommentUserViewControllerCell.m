    //
    //  ABIChatterFeedRecentCommentUserViewControllerCell.m
    //  ABIHiFive
    //
    //  Created by Prsenjit Goswami on 27/07/16.
    //  Copyright © 2016 Cognizant. All rights reserved.
    //
#import "ABIChatterFeedRecentCommentUserViewControllerCell.h"
#import "ABISFChatterCommentItemModel.h"
#import "Constants.h"
#import "CustomView.h"
@implementation ABIChatterFeedRecentCommentUserViewControllerCell
- (id)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier {
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if (self) {
        self.leftDescription = [[UILabel alloc] init];
        self.leftDescription.numberOfLines = 2;
        self.leftDescription.lineBreakMode = NSLineBreakByWordWrapping;
        self.leftDescription.textAlignment = NSTextAlignmentCenter;
        self.leftDescription.backgroundColor = [UIColor cyanColorABI];
        self.leftDescription.textColor = [UIColor whiteColorABI];
        self.leftDescription.layer.cornerRadius = 30.0;
        self.leftDescription.clipsToBounds = YES;
        self.rightDescription = [[UILabel alloc] init];
        self.rightDescription.numberOfLines = 2;
        self.rightDescription.lineBreakMode = NSLineBreakByWordWrapping;
        self.rightDescription.font = [UIFont fontHelvetica57Condensed:12.0f];
        self.rightDescription.textColor = [UIColor blueColorABI];
        self.leftImageView.translatesAutoresizingMaskIntoConstraints = NO;
        self.leftDescription.translatesAutoresizingMaskIntoConstraints = NO;
        self.rightDescription.translatesAutoresizingMaskIntoConstraints = NO;
        [self.contentView addSubview:self.leftImageView];
        [self.contentView addSubview:self.leftDescription];
        [self.contentView addSubview:self.rightDescription];
        NSDictionary *views = [[NSDictionary alloc] initWithObjectsAndKeys:self.leftImageView, @"imageView", self.leftDescription, @"leftDescription",
                               self.rightDescription, @"rightDescription", nil];
        NSDictionary *metrics = [[NSDictionary alloc] initWithObjectsAndKeys:[NSNumber numberWithFloat:44.0], @"viewHeight", nil];
        [self.contentView addConstraints:[NSLayoutConstraint constraintsWithVisualFormat:@"H:|-10-[imageView(viewHeight)]-10-[rightDescription]-5-|"
                                                                                 options:0
                                                                                 metrics:metrics
                                                                                   views:views]];
        [self.contentView
         addConstraints:[NSLayoutConstraint constraintsWithVisualFormat:@"V:[imageView(viewHeight)]" options:0 metrics:metrics views:views]];
        [self.leftImageView centerYToParent:self.contentView];
        [self.contentView
         addConstraints:[NSLayoutConstraint constraintsWithVisualFormat:@"V:[leftDescription(viewHeight)]" options:0 metrics:metrics views:views]];
        [self.leftDescription centerYToParent:self.contentView];
        [self.contentView addConstraints:[NSLayoutConstraint constraintsWithVisualFormat:@"H:|-10-[leftDescription(viewHeight)]"
                                                                                 options:0
                                                                                 metrics:metrics
                                                                                   views:views]];
        [self.contentView addConstraintForCenterY:self.leftDescription toItem:self.contentView];
        [self.contentView
         addConstraints:[NSLayoutConstraint constraintsWithVisualFormat:@"V:|-15-[rightDescription]" options:0 metrics:metrics views:views]];

    }
    return self;
}
- (CustomView *)leftImageView {
    if (!_leftImageView) {
        _leftImageView = [[CustomView alloc] initWithImage:[UIImage imageABIDummyUser]
                                             andOuterImage:[UIImage imageABIOuterCircle]
                                                   andSize:CGSizeMake(43, 43)
                                    andPaddingForInnerView:4.5];
        _leftImageView.translatesAutoresizingMaskIntoConstraints = NO;
    }
    _leftImageView.clipsToBounds = YES;
    return _leftImageView;
}
- (void)updateCellWithABISFChatterCommentItemModel:(ABISFChatterCommentItemModel *)commentItemModel {
    self.leftDescription.hidden = TRUE;
    if (!commentItemModel || ![commentItemModel isKindOfClass:[ABISFChatterCommentItemModel class]])
        return;
    NSString *urlString = commentItemModel.parent.photo.mediumPhotoUrl;
    if (![NSString isNULLString:urlString] && urlString.length) {
        self.leftImageView.hidden = FALSE;
        [self.leftImageView.innerUserImageView setABIUserImageWithURL:[NSURL URLWithString:urlString]];
    }
    NSString *name = commentItemModel.parent.name;
    if (![NSString isNULLString:name] && name.length) {
        self.rightDescription.text = name;
    }
}
@end
