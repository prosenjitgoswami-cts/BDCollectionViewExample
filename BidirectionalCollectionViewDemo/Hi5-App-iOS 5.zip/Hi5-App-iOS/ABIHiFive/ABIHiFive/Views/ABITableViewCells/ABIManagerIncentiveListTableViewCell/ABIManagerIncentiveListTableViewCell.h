    //
    //  ABIReporteeIncentiveListTableViewCell.h
    //  ABIHiFive
    //
    //  Created by Prsenjit Goswami on 12/08/16.
    //  Copyright © 2016 Cognizant. All rights reserved.
    //
#import "ABISFRosterDataModel.h"
#import <UIKit/UIKit.h>
@protocol ABIManagerIncentiveListTableViewCellDelegate <NSObject>
@optional
- (void)clickedPeerRanking:(UIButton *)sender atIndex:(NSUInteger)index;
- (void)clickedKPIRanking:(UIButton *)sender atIndex:(NSUInteger)index;
@end
@class ABISFIncentiveDataModel;
@interface ABIManagerIncentiveListTableViewCell : UITableViewCell
@property (weak, nonatomic) id<ABIManagerIncentiveListTableViewCellDelegate> delegate;
@property (strong, nonatomic) ABISFRosterDataModel *rosterDataModel;
- (void)updateCell:(ABISFIncentiveDataModel *)incentive atIndex:(NSUInteger)index;
@end
