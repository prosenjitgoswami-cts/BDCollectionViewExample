    //
    //  ABIManagerIncentiveListTableViewCell.m
    //  ABIHiFive
    //
    //  Created by Prsenjit Goswami on 12/08/16.
    //  Copyright © 2016 Cognizant. All rights reserved.
    //
#import "ABIManagerIncentiveListTableViewCell.h"
#import "ABISFDataFetcherService.h"
#import "ABISFIncentiveDataModel.h"
#import "ABISFPeerRankingDataModel.h"
#import "Constants.h"
#import "CustomProgressBarView.h"

@interface ABIManagerIncentiveListTableViewCell ()
@property (weak, nonatomic) IBOutlet UIImageView *IncentiveLogo;
@property (weak, nonatomic) IBOutlet UILabel *IncentiveName;
@property (weak, nonatomic) IBOutlet UILabel *rankNumberLabel;
@property (weak, nonatomic) IBOutlet UIView *chartView;
@property (weak, nonatomic) IBOutlet UILabel *progressStatus;
@property (weak, nonatomic) IBOutlet UILabel *requiredPointsLabel;
@property (weak, nonatomic) IBOutlet UILabel *numberOfDms;
@property (weak, nonatomic) IBOutlet UILabel *bestDmScoreLabel;
@property (weak, nonatomic) IBOutlet UIButton *peerRankingButton;
@property (weak, nonatomic) IBOutlet UIButton *KPIDetailsButton;
@property (weak, nonatomic) IBOutlet UIImageView *RankImage;
@property (weak, nonatomic) IBOutlet UIView *buttonContainerView;
@property (assign, nonatomic) NSUInteger index;
@property (strong, nonatomic) ABISFIncentiveDataModel *incentive;
@property (strong, nonatomic) CustomProgressBarView *progressBarView;
@property (strong, nonatomic) NSAttributedString *dmScoreDecoratedString;
@property (strong, nonatomic) NSAttributedString *rankDecoratedString;
@property (strong, nonatomic) NSAttributedString *assingedDMCountDecoratedString;

@end
@implementation ABIManagerIncentiveListTableViewCell
- (void)awakeFromNib {
    [self configureUI];
}
- (void)dealloc {
    _assingedDMCountDecoratedString = nil;
    _rankDecoratedString = nil;
    _dmScoreDecoratedString = nil;
    _progressBarView = nil;
    _incentive = nil;
}
#pragma mark - Private Method
- (CustomProgressBarView *)progressBarView {
    if (!_progressBarView) {
        _progressBarView = [CustomProgressBarView new];
        _progressBarView.translatesAutoresizingMaskIntoConstraints = NO;
        [self.chartView addSubview:_progressBarView];
        [_progressBarView fitToParentView:self.chartView];
    }
    return _progressBarView;
}
- (void)updateCell:(ABISFIncentiveDataModel *)incentive atIndex:(NSUInteger)index {
    self.index = index;
    if (!incentive)
        return;
    self.incentive = incentive;
    self.requiredPointsLabel.attributedText = incentive.attributedString;
    self.progressStatus.text = incentive.statusTitle;
    self.IncentiveName.text = incentive.incentiveCustomDisplayText;
    ;
    [self updateProgressBarView];
    [self updateAssignedDMsTextWithDmnumber:[NSString stringWithFormat:@"%ld", (long)incentive.nuberOfDMs]];
    if ([self.incentive.progressStatusColorName isEqualToString:@"yellow"] || [self.incentive.progressStatusColorName isEqualToString:@"red"]) {
        [self updateBestDMsScoreTextWithScore:incentive.minDMPointsInNumber
         ? [NSString stringWithFormat:@"%ld", (long)incentive.minDMPointsInNumber.integerValue]
                                             : nil];
    } else {
        [self updateBestDMsScoreTextWithScore:incentive.maxDMPointsInNumber
         ? [NSString stringWithFormat:@"%ld", (long)incentive.maxDMPointsInNumber.integerValue]
                                             : nil];
    }
    [self getIncentiveWiseUserRank];
}
/*!
 *  Create UI with Component
 */
- (void)configureUI {
    self.IncentiveName.textColor = [UIColor defaultTextDarkColor];
    self.IncentiveLogo.image = [UIImage imageNamed:IMAGE_NAME_INCENTIVE];
    self.RankImage.image = [UIImage imageNamed:rankImage];
    self.rankNumberLabel.backgroundColor = [UIColor clearColor];
    self.rankNumberLabel.font = PROFILE_RANKANDPOINT_FONT_SIZE;
    self.rankNumberLabel.font = PROFILE_RANKANDPOINT_FONT_SIZE;
    self.RankImage.backgroundColor = [UIColor whiteColor];
    self.IncentiveName.font = PROFILE_SUMMER_INCENTIVE_FONT_SIZE;
        // self.statusTitleLabel.font = PROFILE_STATUS_TITLE_FONT_SIZE;
    [[self.peerRankingButton layer] setBorderWidth:1.5f];
    self.peerRankingButton.layer.borderColor = [UIColor defaultABIBlueColor].CGColor;
    self.peerRankingButton.backgroundColor = [UIColor whiteColor];
    self.KPIDetailsButton.backgroundColor = [UIColor blueColorABI];
    self.peerRankingButton.layer.cornerRadius = 3; // this value vary as per your desire
    self.peerRankingButton.clipsToBounds = YES;
    self.KPIDetailsButton.layer.cornerRadius = 3; // this value vary as per your desire
    self.KPIDetailsButton.clipsToBounds = YES;
    self.peerRankingButton.titleLabel.font = PROFILE_PEER_KPI_BUTTON_FONT_SIZE;
    self.KPIDetailsButton.titleLabel.font = PROFILE_PEER_KPI_BUTTON_FONT_SIZE;
    [self.peerRankingButton setTitleColor:[UIColor defaultABIBlueColor] forState:UIControlStateNormal];
    [self.KPIDetailsButton setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
    self.RankImage.hidden = YES;
    self.buttonContainerView.layer.cornerRadius = 3;
    self.buttonContainerView.clipsToBounds = YES;
    self.buttonContainerView.backgroundColor = [UIColor defaultABIBlueColor];
    self.progressStatus.font = [UIFont fontHelvetica67Condensed:12.0f];
    self.requiredPointsLabel.font = PROFILE_SUMMER_INCENTIVE_FONT_SIZE;
    self.numberOfDms.font = PROFILE_SUMMER_INCENTIVE_FONT_SIZE;
    self.bestDmScoreLabel.font = PROFILE_SUMMER_INCENTIVE_FONT_SIZE;
    self.progressStatus.textColor = [UIColor defaultTextDarkColor];
    self.requiredPointsLabel.textColor = [UIColor defaultTextDarkColor];
    self.numberOfDms.textColor = [UIColor defaultTextLightColor];
    self.bestDmScoreLabel.textColor = [UIColor defaultTextLightColor];
}
/*!
 *  Update Line Chart
 */
- (void)updateProgressBarView {
    if (!self.chartView)
        return;
    self.progressBarView.progressStatusColorName = self.incentive.progressStatusColorName;
    self.progressBarView.progressAmountRaw = self.incentive.overAllIncentiveProgressRaw;
    self.progressBarView.minRange = self.incentive.minIncentiveRange;
    self.progressBarView.maxRange = self.incentive.maxIncentiveRange;
    self.progressBarView.progressAmount = self.incentive.overAllIncentiveProgress;
    self.progressBarView.progressDisplayText = self.incentive.overAllIncentiveProgress.stringValue;
    self.progressBarView.unitName = self.incentive.progressUnit;
    self.progressBarView.unitTextColor = [UIColor defaultTextDarkColor];
    self.progressBarView.unitTextFont = PROFILE_UNIT_TEXT_FONT_SIZE;
    self.buttonContainerView.layer.cornerRadius = 3;
    self.buttonContainerView.clipsToBounds = YES;
    self.buttonContainerView.backgroundColor = [UIColor defaultABIBlueColor];
    self.progressBarView.descriptionText = @"";
}

- (void)updateAssignedDMsTextWithDmnumber:(NSString *)dmCount {

    if (!self.assingedDMCountDecoratedString) {
        self.assingedDMCountDecoratedString = [NSAttributedString decoratedAssignedDMsCountTextWithDMCount:dmCount];
    }

    self.numberOfDms.attributedText = self.assingedDMCountDecoratedString;
}

/**
 *  Update DM score Label with Score
 *
 *  @param score Incentive Point as Score
 */
- (void)updateBestDMsScoreTextWithScore:(NSString *)score {

    if (!self.dmScoreDecoratedString)
        self.dmScoreDecoratedString = [NSAttributedString decoratedDMsScoreTextWithScore:score incentive:self.incentive];

    self.bestDmScoreLabel.attributedText = self.dmScoreDecoratedString;
}

/**
 *  Update Rank Number Label
 */
- (void)updateRankNumberLabel {
    [self.rankNumberLabel setAttributedText:_rankDecoratedString];
    self.RankImage.hidden = (nil == _rankDecoratedString);
}

/**
 *  Get User Rank For specific Incentive
 */
- (void)getIncentiveWiseUserRank {

    __weak typeof(self) weakself = self;
    weakself.RankImage.hidden = YES;

    if (_rankDecoratedString) {
        [self updateRankNumberLabel];

    } else {
        [self.incentive getUserIncentiveRankAmongSameRolePeerWithCompletionBlock:^(NSNumber *_Nonnull rank) {

            weakself.rankDecoratedString = [NSAttributedString decoratedRankStringWithRankValueNumber:rank staticRankText:STATIC_TEXT_RANK];
            [self updateRankNumberLabel];
        }];
    }
}

#pragma mark - IB Action
- (IBAction)clickedPeerRanking:(UIButton *)sender atIndex:(NSUInteger)index {
    if (self.delegate && [self.delegate respondsToSelector:@selector(clickedPeerRanking:atIndex:)]) {
        [self.delegate clickedPeerRanking:sender atIndex:self.index];
    }
}
- (IBAction)clickedKPIRanking:(UIButton *)sender {
    if (self.delegate && [self.delegate respondsToSelector:@selector(clickedKPIRanking:atIndex:)]) {
        [self.delegate clickedKPIRanking:sender atIndex:self.index];
    }
}
@end
