    //
    //  ABIBadgeDetailTableViewCell.m
    //  ABIHiFive
    //
    //  Created by Amit Kumar on 8/8/16.
    //  Copyright © 2016 Cognizant. All rights reserved.
    //
#import "ABIReporteeListTableViewCell.h"
#import "ABISFRosterDataModel.h"
#import "ABIChatterNewPostViewController.h"
#import "Constants.h"
#import "CustomView.h"
#import "HelperUtilHeader.h"

@interface ABIReporteeListTableViewCell ()
@property (strong, nonatomic) UIView *headerView;
@property (strong, nonatomic) CustomView *userImageView;
@property (strong, nonatomic) UILabel *userNameLabel, *districtLabel, *incentiveNameLabel;
@property (strong, nonatomic) NSDictionary *views;
@property (assign, nonatomic) CellStyle cellType;
@end
@implementation ABIReporteeListTableViewCell
- (instancetype)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier {
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if (self) {
        [self configureUI];
    }
    return self;
}
- (void)dealloc {
    _headerView = nil;
    _userImageView = nil;
    _userNameLabel = nil;
    _districtLabel = nil;
    _chatterBtn = nil;
}
- (void)awakeFromNib {
    [super awakeFromNib];
        // Initialization code
}
- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];
        // Configure the view for the selected state
}

#pragma mark -  Private Method
- (void)updateCellUI:(ABISFRosterDataModel *)rosterDataModel {

    self.chatterBtn.enabled = YES;

    if (rosterDataModel) {
        self.chatterBtn.enabled = ![NSString isNULLString:rosterDataModel.rosterUserID];
        self.rosterDataModel = rosterDataModel;
        _districtLabel.text = rosterDataModel.regionName;
        _userNameLabel.text = [[rosterDataModel rosterNameText] nullStringTextCorrection];
        if (![NSString isNULLString:rosterDataModel.rosterNameText])
            _userNameLabel.text = [_userNameLabel.text stringByReplacingOccurrencesOfString:@"," withString:@""];
        [_incentiveNameLabel setText:[NSString displayTextForBadgsCountInMyDMsCell:self.rosterDataModel.earnedBadgeCount.integerValue]];
        [self.userImageView.innerUserImageView setABIUserImageWithURL:rosterDataModel.rosterImageURLString];
    }
}
- (void)configureUI {
        // Header View
    [self.contentView addSubview:self.headerView];
    [self.headerView addSubview:self.userImageView];
    [self.headerView addSubview:self.userNameLabel];
    [self.headerView addSubview:self.districtLabel];
    [self.headerView addSubview:self.incentiveNameLabel];
    [self.headerView addSubview:self.chatterBtn];
    self.chatterBtn.userInteractionEnabled = YES;
    [self addConstraints];
}
- (void)addConstraints {
    [self.contentView addConstraints:[NSLayoutConstraint constraintsWithVisualFormat:@"H:|[headerView]|" options:0 metrics:nil views:self.views]];
    [self.contentView addConstraints:[NSLayoutConstraint constraintsWithVisualFormat:@"V:|[headerView]|" options:0 metrics:nil views:self.views]];
    [self.headerView addConstraints:[NSLayoutConstraint constraintsWithVisualFormat:@"H:|-5-[userImageView(50)]-10-[userNameLabel]"
                                                                            options:0
                                                                            metrics:nil
                                                                              views:self.views]];
    [self.headerView addConstraints:[NSLayoutConstraint constraintsWithVisualFormat:@"H:[chatterBtn(50)]|" options:0 metrics:nil views:self.views]];
    [self.headerView addConstraints:[NSLayoutConstraint constraintsWithVisualFormat:@"V:|[chatterBtn(50)]" options:0 metrics:nil views:self.views]];
    [self.chatterBtn setImageEdgeInsets:UIEdgeInsetsMake(0, 10, 10, 0)];
    [self.headerView
     addConstraints:[NSLayoutConstraint constraintsWithVisualFormat:@"V:|-7-[userImageView(50)]" options:0 metrics:nil views:self.views]];
    [self.headerView addConstraints:[NSLayoutConstraint constraintsWithVisualFormat:@"V:|-10-[userNameLabel][districtLabel][incentiveNameLabel]"
                                                                            options:0
                                                                            metrics:nil
                                                                              views:self.views]];
    [self.headerView addConstraint:[NSLayoutConstraint constraintWithItem:self.districtLabel
                                                                attribute:NSLayoutAttributeLeft
                                                                relatedBy:NSLayoutRelationEqual
                                                                   toItem:self.userNameLabel
                                                                attribute:NSLayoutAttributeLeft
                                                               multiplier:1
                                                                 constant:0]];
    [self.headerView addConstraint:[NSLayoutConstraint constraintWithItem:self.incentiveNameLabel
                                                                attribute:NSLayoutAttributeLeft
                                                                relatedBy:NSLayoutRelationEqual
                                                                   toItem:self.districtLabel
                                                                attribute:NSLayoutAttributeLeft
                                                               multiplier:1
                                                                 constant:0]];
}
#pragma mark Views
- (NSDictionary *)views {
    if (!_views) {
        _views = @{
                   @"headerView" : self.headerView,
                   @"userImageView" : self.userImageView,
                   @"userNameLabel" : self.userNameLabel,
                   @"districtLabel" : self.districtLabel,
                   @"incentiveNameLabel" : self.incentiveNameLabel,
                   @"chatterBtn" : self.chatterBtn
                   };
    }
    return _views;
}

#pragma mark -
- (UIView *)headerView {
    if (!_headerView) {
        _headerView = [[UIView alloc] init];
        _headerView.translatesAutoresizingMaskIntoConstraints = NO;
            //_headerView.backgroundColor = [UIColor greenColor];
    }
    return _headerView;
}
- (CustomView *)userImageView {
    if (!_userImageView) {
        _userImageView = [[CustomView alloc] initWithImage:[UIImage imageABIDummyUser]
                                             andOuterImage:[UIImage imageABIOuterCircle]
                                                   andSize:CGSizeMake(50, 50)
                                    andPaddingForInnerView:4];
        _userImageView.translatesAutoresizingMaskIntoConstraints = NO;
    }
    _userImageView.clipsToBounds = YES;
    return _userImageView;
}
- (UILabel *)userNameLabel {
    if (!_userNameLabel) {
        _userNameLabel = [[UILabel alloc] init];
        _userNameLabel.font = USERNAME_FONT_SIZE;
        _userNameLabel.textColor = [UIColor darkGreyColorABI];
        _userNameLabel.translatesAutoresizingMaskIntoConstraints = NO;
    }
    return _userNameLabel;
}
- (UILabel *)districtLabel {
    if (!_districtLabel) {
        _districtLabel = [[UILabel alloc] init];
        _districtLabel.font = TIME_FONT_SIZE;
        _districtLabel.textColor = [UIColor defaultTextLightColor];
        _districtLabel.translatesAutoresizingMaskIntoConstraints = NO;
    }
    return _districtLabel;
}
- (UILabel *)incentiveNameLabel {
    if (!_incentiveNameLabel) {
        _incentiveNameLabel = [[UILabel alloc] init];
        _incentiveNameLabel.font = INCENTIVE_TYPE_FONT_SIZE;
        _incentiveNameLabel.textColor = [UIColor defaultTextLightColor];
        _incentiveNameLabel.translatesAutoresizingMaskIntoConstraints = NO;
    }
    return _incentiveNameLabel;
}
- (UIButton *)chatterBtn {
    if (!_chatterBtn) {
        _chatterBtn = [[UIButton alloc] init];
        [_chatterBtn setImage:[UIImage imageNamed:@"chatter_logo"] forState:UIControlStateNormal];
        [_chatterBtn addTarget:self action:@selector(clickedPostComment:) forControlEvents:UIControlEventTouchUpInside];
        _chatterBtn.userInteractionEnabled = YES;
        _chatterBtn.translatesAutoresizingMaskIntoConstraints = NO;
    }
    return _chatterBtn;
}

#pragma mark -  IBAction
- (void)clickedPostComment:(UIButton *)sender {
    if (self.delegate && [self.delegate respondsToSelector:@selector(clickedPostComment:cell:)]) {
        [self.delegate clickedPostComment:sender cell:self];
    }
}
@end
