    //
    //  ABIBadgeDetailTableViewCell.h
    //  ABIHiFive
    //
    //  Created by Amit Kumar on 8/8/16.
    //  Copyright © 2016 Cognizant. All rights reserved.
    //
#import "Constants.h"
#import <UIKit/UIKit.h>
@class ABIReporteeListTableViewCell;
@protocol ABIReporteeListTableViewCellDelegate <NSObject>
- (void)clickedPostComment:(UIButton *)sender cell:(ABIReporteeListTableViewCell *)cell;
@end
@interface ABIReporteeListTableViewCell : UITableViewCell
- (UILabel *)districtLabel;
- (instancetype)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier;
@property (weak, nonatomic) id<ABIReporteeListTableViewCellDelegate> delegate;
@property (weak, nonatomic) ABISFRosterDataModel *rosterDataModel;
- (void)updateCellUI:(ABISFRosterDataModel *)rosterDataModel;
@property (strong, nonatomic) UIButton *chatterBtn;
@end
