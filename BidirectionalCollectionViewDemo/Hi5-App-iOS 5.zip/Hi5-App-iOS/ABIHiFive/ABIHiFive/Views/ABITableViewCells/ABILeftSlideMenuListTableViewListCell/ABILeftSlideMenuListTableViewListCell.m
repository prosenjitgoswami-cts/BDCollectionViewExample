    //
    //  CustomMenuTableViewCell.m
    //  CustomSideMenuExample
    //
    //  Created by Prsenjit Goswami on 28/06/16.
    //  Copyright © 2016 Mobivery. All rights reserved.
    //
#import "ABILeftSlideMenuListTableViewListCell.h"
#import "ABIMenuItemDataModel.h"
#import "Constants.h"
#import "HelperUtilHeader.h"

@implementation ABILeftSlideMenuListTableViewListCell
#pragma marl - TableViewListCell Life Cycle
- (instancetype)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(nullable NSString *)reuseIdentifier {
    if (self = [super initWithStyle:style reuseIdentifier:reuseIdentifier]) {
        [self configureUI];
    }
    return self;
}
#pragma mark - Private Method
/*!
 *  Create UI with Component
 */
- (void)configureUI {
    [self.contentView addSubview:self.menuIconimageView];
    [self.contentView addSubview:self.menuTitleLabel];
    [self.contentView addSubview:self.seperatorImageView];
    [self addConstraint];
}
/*!
 * Add Constraint for UI with Component
 */
- (void)addConstraint {
    NSDictionary *views = @{
                            @"menuIconimageView" : self.menuIconimageView,
                            @"menuTitleLabel" : self.menuTitleLabel,
                            @"seperatorImageView" : self.seperatorImageView,
                            };
    [self.contentView addConstraintsWithVisualFormat:@"H:|-[menuIconimageView(15)]-[menuTitleLabel]-|" options:0 metrics:nil views:views];
    [self.contentView addConstraintsWithVisualFormat:@"H:|[seperatorImageView]|" options:0 metrics:nil views:views];
    [self.contentView addConstraintsWithVisualFormat:@"V:[seperatorImageView(1)]|" options:0 metrics:nil views:views];
    [self.contentView addConstraintsWithVisualFormat:@"V:[menuIconimageView(15)]" options:0 metrics:nil views:views];
    [self.contentView addConstraintForCenterY:self.menuIconimageView toItem:self.contentView];
    [self.contentView addConstraint:[NSLayoutConstraint verticallyCenter:self.menuTitleLabel toItem:self.menuIconimageView]];
}
- (UIImageView *)menuIconimageView {
    if (!_menuIconimageView) {
        _menuIconimageView = [UIImageView initWithImage:nil];
    }
    return _menuIconimageView;
}
- (UIImageView *)seperatorImageView {
    if (!_seperatorImageView) {
        _seperatorImageView = [UIImageView initWithImage:nil];
        _seperatorImageView.backgroundColor = [UIColor lightGreyColorABI];
    }
    return _seperatorImageView;
}
- (UILabel *)menuTitleLabel {
    if (!_menuTitleLabel) {
        _menuTitleLabel = [UILabel labelWithText:@"" textColor:nil textFont:nil textAlignment:0 numberOfLines:1 backgroundColor:nil];
    }
    return _menuTitleLabel;
}
/*!
 *  Update Cell
 *
 *  @param selected  Selected Mode
 *  @param indexPath Selected Index
 */
- (void)updateOnSelection:(BOOL)selected atIndexPath:(NSIndexPath *)indexPath {
    _menuTitleLabel.text = _menuItemModel.itemName;
    BOOL isSelected = selected; //( indexPath.row == 0 );
    _menuTitleLabel.font = MENU_LIST_FONT;
    _menuIconimageView.image =
    isSelected ? [UIImage imageNamed:_menuItemModel.selectedImageName] : [UIImage imageNamed:_menuItemModel.deselectedImageName];
    self.contentView.backgroundColor = isSelected ? SLIDE_MENU_SELECTED_CELL_BG_COLOR : SLIDE_MENU_DESELECTED_CELL_BG_COLOR;
    _menuTitleLabel.textColor = isSelected ? SLIDE_MENU_SELECTED_LABEL_TEXT_COLOR : SLIDE_MENU_DESELECTED_LABEL_TEXT_COLOR;
    if (SLIDEMENU_OPT_NOT_CHANGE_COLOR_CONDITION) // TODO:
        {
        self.contentView.backgroundColor = SLIDE_MENU_DESELECTED_CELL_BG_COLOR;
        _menuTitleLabel.textColor = SLIDE_MENU_DESELECTED_LABEL_TEXT_COLOR;
        _menuIconimageView.image = [UIImage imageNamed:_menuItemModel.deselectedImageName];
        }
    BOOL isEnabledOption = SLIDEMENU_CONDITION;
    _menuTitleLabel.alpha = isEnabledOption ? 1.0f : 0.5f;
    _menuIconimageView.alpha = isEnabledOption ? 1.0f : 0.5f;
}
@end
