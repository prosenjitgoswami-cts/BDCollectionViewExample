    //
    //  CustomMenuTableViewCell.h
    //  CustomSideMenuExample
    //
    //  Created by Prsenjit Goswami on 28/06/16.
    //  Copyright © 2016 Mobivery. All rights reserved.
    //
#import "ABIMenuItemDataModel.h"
#import <UIKit/UIKit.h>
@interface ABILeftSlideMenuListTableViewListCell : UITableViewCell
@property (strong, nonatomic) UIImageView *menuIconimageView, *seperatorImageView;
@property (strong, nonatomic) UILabel *menuTitleLabel;
@property (strong, nonatomic) ABIMenuItemDataModel *menuItemModel;
- (void)updateOnSelection:(BOOL)selected atIndexPath:(NSIndexPath *)indexPath;
@end
