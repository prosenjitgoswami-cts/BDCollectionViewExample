    //
    //  announcementDataModelTableCell.m
    //  HelloObjC
    //
    //  Created by KoliMac1 on 08/07/16.
    //  Copyright © 2016 KoliMac1. All rights reserved.
    //
#import "ABIAnnouncementsPopoverTableViewCell.h"
#import "ABISFAnnouncementDataModel.h"
#import "Constants.h"
@implementation ABIAnnouncementsPopoverTableViewCell

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];
        // Configure the view for the selected state
}
- (id)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier {
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if (self) {
        self.leftImageView = [[UIImageView alloc] init];
        self.leftImageView.layer.cornerRadius = 2.0;
        self.leftImageView.clipsToBounds = YES;
        self.leftImageView.backgroundColor = [UIColor lightGreyColorABI];
        self.leftDescription = [[UILabel alloc] init];
        self.leftDescription.numberOfLines = 2;
        self.leftDescription.lineBreakMode = NSLineBreakByWordWrapping;
        self.leftDescription.textAlignment = NSTextAlignmentCenter;
        self.leftDescription.backgroundColor = [UIColor lightBlueColorABI];
        self.leftDescription.textColor = [UIColor whiteColorABI];
        [self.leftDescription setFont:[UIFont fontHelvetica57Condensed:12.0f]];
        self.leftDescription.layer.cornerRadius = 20.0f;
        self.leftDescription.clipsToBounds = YES;
        self.rightDescription = [[UILabel alloc] init];
        self.rightDescription.numberOfLines = 2;
        self.rightDescription.lineBreakMode = NSLineBreakByWordWrapping;
        self.rightDescription.font = [UIFont fontHelvetica57Condensed:12.0f];
        self.rightDescription.textColor = [UIColor blueColorABI];
        self.leftImageView.translatesAutoresizingMaskIntoConstraints = NO;
        self.leftDescription.translatesAutoresizingMaskIntoConstraints = NO;
        self.rightDescription.translatesAutoresizingMaskIntoConstraints = NO;
        [self.contentView addSubview:self.leftImageView];
        [self.contentView addSubview:self.leftDescription];
        [self.contentView addSubview:self.rightDescription];
        NSDictionary *views = [[NSDictionary alloc] initWithObjectsAndKeys:self.leftImageView, @"imageView", self.leftDescription, @"leftDescription",
                               self.rightDescription, @"rightDescription", nil];
        NSDictionary *metrics = [[NSDictionary alloc]
                                 initWithObjectsAndKeys:[NSNumber numberWithFloat:60.0], @"viewHeight", [NSNumber numberWithFloat:40.0], @"labelHeight", nil];
        [self.contentView addConstraints:[NSLayoutConstraint constraintsWithVisualFormat:@"H:|-10-[imageView(viewHeight)]-10-[rightDescription]-5-|"
                                                                                 options:0
                                                                                 metrics:metrics
                                                                                   views:views]];
        [self.contentView
         addConstraints:[NSLayoutConstraint constraintsWithVisualFormat:@"V:[imageView(viewHeight)]" options:0 metrics:metrics views:views]];
        [self.leftImageView centerYToParent:self.contentView];
        [self.contentView
         addConstraints:[NSLayoutConstraint constraintsWithVisualFormat:@"V:[leftDescription(labelHeight)]" options:0 metrics:metrics views:views]];
        [self.contentView
         addConstraints:[NSLayoutConstraint constraintsWithVisualFormat:@"H:[leftDescription(labelHeight)]" options:0 metrics:metrics views:views]];
            // [self.contentView addConstraintForCenterY:self.leftDescription toItem:self.leftImageView];
            // [self.contentView addConstraintForCenterY:self.rightDescription toItem:self.leftImageView];
        [self.contentView
         addConstraints:[NSLayoutConstraint constraintsWithVisualFormat:@"V:|-15-[rightDescription]" options:0 metrics:metrics views:views]];
        [self.contentView
         addConstraints:[NSLayoutConstraint constraintsWithVisualFormat:@"V:|-10-[leftDescription]" options:0 metrics:metrics views:views]];
        [self.contentView
         addConstraints:[NSLayoutConstraint constraintsWithVisualFormat:@"H:|-10-[leftDescription]" options:0 metrics:metrics views:views]];
    }
    return self;
}
- (NSAttributedString *)attributText:(NSDate *)aDate {
    NSMutableAttributedString *attString = nil;
    if (aDate) {
        NSString *day = [NSString stringWithFormat:@"%@", [NSDate stringFromDateInLocal:aDate andFormatterStyle:@"dd"]];
        NSString *month = [NSString stringWithFormat:@"%@", [NSDate stringFromDateInLocal:aDate andFormatterStyle:@"MMMM"]];
        if (day.length && month.length) {
            NSString *dayMonthString = [NSString stringWithFormat:@"%@\n%@", day, month];
            attString = [[NSMutableAttributedString alloc] initWithString:dayMonthString];
            NSDictionary *attrs = @{NSForegroundColorAttributeName : [UIColor whiteColor], NSFontAttributeName : [UIFont fontHelvetica67Condensed:12.0f]};
            NSRange range = [dayMonthString rangeOfString:day];
            [attString addAttributes:attrs range:range];
            attrs = @{NSForegroundColorAttributeName : [UIColor whiteColor], NSFontAttributeName : [UIFont fontHelvetica67Condensed:7.0f]};
            range = [dayMonthString rangeOfString:month];
            [attString addAttributes:attrs range:range];
        }
    }
    return attString;
}
- (void)updateCellWithABISFAnnouncementDataModel:(ABISFAnnouncementDataModel *)announcementDataModel {
    if (!announcementDataModel)
        return;
    if (announcementDataModel.announcementImageURLString) {
        dispatch_queue_t queue = dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_HIGH, 0);
        dispatch_async(queue, ^{
            NSData *data = [NSData dataWithContentsOfURL:[NSURL URLWithString:announcementDataModel.announcementImageURLString]];
            UIImage *image = [UIImage imageWithData:data];
            dispatch_main_async_safeBlock(^{ self.leftImageView.image = image; });
        });
        self.leftImageView.hidden = FALSE;
        self.leftDescription.hidden = TRUE;
    } else {
        if (![NSString isNULLString:announcementDataModel.lastModifiedDateShortString]) {
            self.leftDescription.text = STATIC_TEXT_EMPTY_STRING;
            NSAttributedString *attributedString = [self attributText:announcementDataModel.lastModifiedDate];
            if (attributedString) {
                self.leftDescription.attributedText = attributedString;
            } else if (announcementDataModel.lastModifiedDateShortString) {
                self.leftDescription.text = announcementDataModel.lastModifiedDateShortString;
            }
        }
        self.leftImageView.hidden = TRUE;
        self.leftDescription.hidden = FALSE;
    }
    if (!announcementDataModel.announcementSubject) {
        self.rightDescription.text = [[announcementDataModel.announcementName componentsSeparatedByCharactersInSet:[NSCharacterSet newlineCharacterSet]]
                                      componentsJoinedByString:STATIC_TEXT_EMPTY_STRING];
    } else {
        self.rightDescription.text = [[announcementDataModel.announcementSubject
                                       componentsSeparatedByCharactersInSet:[NSCharacterSet newlineCharacterSet]] componentsJoinedByString:STATIC_TEXT_EMPTY_STRING];
    }
}
@end
