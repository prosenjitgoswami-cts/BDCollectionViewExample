    //
    //  AssessmentTableCell.h
    //  HelloObjC
    //
    //  Created by KoliMac1 on 08/07/16.
    //  Copyright © 2016 KoliMac1. All rights reserved.
    //
#import <UIKit/UIKit.h>
@class ABISFAnnouncementDataModel;
@interface ABIAnnouncementsPopoverTableViewCell : UITableViewCell
@property (nonatomic, strong) UIImageView *leftImageView;
@property (nonatomic, strong) UILabel *leftDescription;
@property (nonatomic, strong) UILabel *rightDescription;
- (id)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier;
- (void)updateCellWithABISFAnnouncementDataModel:(ABISFAnnouncementDataModel *)assessment;
@end
