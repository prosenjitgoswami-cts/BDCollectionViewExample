    //
    //  ABIPeerRankingDetailPageCell.h
    //  ABIHiFive
    //
    //  Created by Prsenjit Goswami on 28/06/16.
    //  Copyright © 2016 Cognizant. All rights reserved.
    //
#import <UIKit/UIKit.h>
@class ABISFPeerRankingDataModel;
@interface ABIPeerRankingDetailPageCell : UITableViewCell
@property (weak, nonatomic) IBOutlet UILabel *rankLabel;
@property (weak, nonatomic) IBOutlet UILabel *nameLabel;
@property (weak, nonatomic) IBOutlet UILabel *pointsLabel;
@property (weak, nonatomic) IBOutlet UILabel *pointsText;
@property (weak, nonatomic) IBOutlet UIImageView *verticalLine;
@property (weak, nonatomic) IBOutlet UIImageView *horizontalLine;
@property (weak, nonatomic) IBOutlet UIImageView *currentUserMarkerImageView;
- (void)updateCell:(ABISFPeerRankingDataModel *)peerRankingDataModel;
@end
