    //
    //  ABIPeerRankingDetailPageCell.m
    //  ABIHiFive
    //
    //  Created by Prsenjit Goswami on 28/06/16.
    //  Copyright © 2016 Cognizant. All rights reserved.
    //
#import "ABIPeerRankingDetailPageCell.h"
#import "ABISFPeerRankingDataModel.h"
#import "Constants.h"
@implementation ABIPeerRankingDetailPageCell
#pragma mark - Public Method
- (instancetype)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier {
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if (self) {
    }
    return self;
}
#pragma mark - Private method
/*!
 *  Set oulet Color and Font
 */
- (void)setColorAndFont {
        // PointsLabel
    self.pointsLabel.layer.cornerRadius = self.pointsLabel.frame.size.width / 2;
    self.pointsLabel.clipsToBounds = YES;
    self.pointsLabel.backgroundColor = [UIColor lightBlueColorABI];
    self.pointsLabel.textColor = [UIColor whiteColor];
    self.pointsLabel.font = [UIFont fontHelvetica67Condensed:18.0f];
        // Current user location ImageView
    self.currentUserMarkerImageView.backgroundColor = [UIColor clearColor];
    [self.currentUserMarkerImageView setImage:[UIImage imageNamed:youAreHereLeft_Image]];
        // Points Text
    self.pointsText.textColor = [UIColor lightBlueColorABI];
    self.pointsText.font = [UIFont fontHelvetica67Condensed:9.0f];
        // VerticalLine Line
    self.verticalLine.backgroundColor = [UIColor peerRankingTableSeparatorColor];
        // Horizontal Line
    self.horizontalLine.backgroundColor = [UIColor peerRankingTableSeparatorColor];
    self.rankLabel.font = [UIFont fontHelvetica67Condensed:12.0f];
    self.nameLabel.font = [UIFont fontHelvetica67Condensed:15.0f];
    self.rankLabel.textColor = [UIColor darkTextColor];
    self.nameLabel.textColor = [UIColor darkTextColor];
}
/*!
 *  Update Cell
 *
 *  @param peerRankingDataModel ABISFPeerRankingDataModel object
 */
- (void)updateCell:(ABISFPeerRankingDataModel *)peerRankingDataModel {
    if ([NSObject isNullObject:peerRankingDataModel])
        return;
    [self setColorAndFont];
    /*!
     *  Set Rank Value
     */
    NSString *rank = peerRankingDataModel.userRank;
    if (![NSString isNULLString:rank]) {
        self.rankLabel.text = [NSString stringWithFormat:@"#%ld", (long)rank.integerValue];
    }
    /*!
     *  Set user Name value
     */
    NSString *userName = [peerRankingDataModel peerRoster].rosterNameText;
    if (![NSString isNULLString:userName]) {
        self.nameLabel.text = userName;
    }
    /*!
     *  Set IncentivePoints
     */
    NSString *incentivePoints = [NSString stringWithFormat:@"%ld", (long)peerRankingDataModel.incentivePointsInNumber.integerValue];
    if (![NSString isNULLString:incentivePoints]) {
        self.pointsLabel.text = incentivePoints;
    }
    /*!
     *  Set current User Image
     */
    if (peerRankingDataModel.isCurrentUser) {
        if ([peerRankingDataModel.peerRoster.managerRoleInString isEqualToString:ABI_SF_USER_ROLE_SD] &&
            [peerRankingDataModel.peerRoster.roleInString isEqualToString:ABI_SF_USER_ROLE_DM]) {
            self.currentUserMarkerImageView.hidden = TRUE;
        } else {
            self.currentUserMarkerImageView.hidden = FALSE;
        }
    } else {
        self.currentUserMarkerImageView.hidden = TRUE;
    }
}
@end
