    //
    //  ABIChatterRecentCommentUserListTableViewCell.h
    //  AnheuserBusch
    //
    //  Created by IR Mac Mini on 25/07/16.
    //  Copyright © 2016 Cognizant. All rights reserved.
    //
#import <UIKit/UIKit.h>
@interface ABIChatterRecentCommentUserListTableViewCell : UITableViewCell
@property (nonatomic, strong) IBOutlet UILabel *nameLabel;
@property (nonatomic, strong) IBOutlet UIImageView *cellSelectionIndicator;
- (void)populateCellData:(NSString *)nameStr;
@end
