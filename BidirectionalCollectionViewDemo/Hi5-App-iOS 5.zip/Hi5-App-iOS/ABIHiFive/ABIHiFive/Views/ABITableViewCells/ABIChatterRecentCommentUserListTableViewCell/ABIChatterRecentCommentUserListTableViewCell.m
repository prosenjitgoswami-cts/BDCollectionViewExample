    //
    //  ABIChatterRecentCommentUserListTableViewCell.m
    //  AnheuserBusch
    //
    //  Created by IR Mac Mini on 25/07/16.
    //  Copyright © 2016 Cognizant. All rights reserved.
    //
#import "ABIChatterRecentCommentUserListTableViewCell.h"
@implementation ABIChatterRecentCommentUserListTableViewCell
- (void)awakeFromNib {
        // Initialization code
}
- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];
        // Configure the view for the selected state
}
- (void)populateCellData:(NSString *)nameStr {
    [self.nameLabel setText:nameStr];
}
@end
