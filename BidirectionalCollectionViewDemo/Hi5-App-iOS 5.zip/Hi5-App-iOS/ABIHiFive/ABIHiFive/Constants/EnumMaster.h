    //
    //  EnumMaster.h
    //  ABIHiFive
    //
    //  Created by Prsenjit Goswami on 25/07/16.
    //  Copyright © 2016 Cognizant. All rights reserved.
    //
#import <Foundation/Foundation.h>
typedef enum {
    BarButtonItemUnknown,
    BarButtonItemLeft,
    BarButtonItemRight,
} CustomBarButtonItem;

typedef enum {
    ChatterAllFeedElements = 0,
    ChatterMeFeedElements,
    ChatterRestAPIPathTypeCustomPath,
    RestAPIPathSearchMention,
    GetSearchMentionUser,
    GetSearchMentionAll,
    ChatterRestAPISearchPathMessage,
    ChatterRestAPIPrivateMessage,
    ChatterRestAPIPathPostFeedElement,
    ChatterRestAPIMe,
} ChatterRestAPIPathType;

typedef enum {
    ChatterFeedTypeAll = 0,
    ChatterFeedTypeMe = 1,
    ChatterFeedTypeCustomPath = 2,
    ChatterFeedTypeMessageCustomPath = 3,
    ChatterGetMessages = 4,
} ChatterFeedType;

typedef enum {
    MentionSearchTypeAll = 0,
    MentionSearchTypeUser = 1,
} MentionSearchType;

typedef enum {
    DefaultChatterFeedPageSize = 25,
    DefaultChatterCommentSize = 3,
    ChatterPageSize100 = 100,
} ChatterPageSize;

typedef enum {
    CellStyleFeedList = 0,
    CellStyleFeedListDetails = 1,
    CellStyleMessage = 3,
} CellStyle;

/*!
 SOQLCompletion Status
 */
typedef enum {
    kSOQLStatusFailed = 0,
    kSOQLStatusSucccess = 1,
    kSOQLStatusCanceled = 2,
    kSOQLStatusTimedOut = 3,
    kSOQLStatusInvalidSOQL = 4,
    kSOQLStatusCompleted = 5,
    kSOQLStatusAttachmentUploadFailed = 5,
} SOQLStatus;
/*!
 Page details
 */
typedef enum {
        //  kPageLogin = 0,
    kPageProfile = 0,
    kPageChatter,
    kPageHelp_Support,
    kLogout,
    kAnnouncement = 99,
} PageIndex;
/*!
 Enum for RankingState
 */
typedef enum {
    RankingStateLocal = 0,
    RankingStateMarket = 1,
} RankingState;
/*!
 Enum Error
 */
typedef enum {
    ErrorTypeFailed = 0,
    ErrorTypeSucccess,
    ErrorTypeNoNetworkConnection,
    ErrorTypeCanceled,
    ErrorTypeTimedOut,
    ErrorTypeInvalidSOQL,
    ErrorTypeCompleted,
    ErrorTypeAttachmentUploadFailed,
    ErrorTypeDataParsingFailed,
    ErrorTypAnyInputDataIsNull,
    ErrorTypeNoDataAvailable,
    ErrorTypeNilSOQLQurery,
} ErrorType;

typedef enum {
    RosterRoleUnknown = 0,
    RosterRoleSD,
    RosterRoleDM,
} RosterRole;

typedef enum {
    DropDownListdefault = 0,
    DropDownListYear = 1,
    DropDownListBages,
} DropDownListType;

typedef enum {
    ABIFetchOperationForRosterDetails = 0,
    ABIFetchOperationForBadgeDetails,
    ABIFetchOperationForIncentiveDetails,
    ABIFetchOperationForAllReporteeDetails,
    ABIFetchOperationForReporteesIncentiveDetails,
    ABIFetchOperationForPeerRankingIncentivePointWise,
    ABIFetchOperationForKPIDetailsForIncentive,
    ABIFetchOperationForAllReporteeKPIsWiseIncentivePerformanceDetails,
    ABIFetchOperationForAnnouncementDetails,

} ABIFetchOperationKey;

typedef enum {
    PageFlowUnknown = 0,
    PageFlowAsDM,
    PageFlowAsSD,
    PageFlowAsMyDMAsSDLogin,
} PageFlow;

typedef enum {
    MyPeerRankingList = 0,
    MyDMsPeerRankingList,
} PeerRankingType;

typedef enum {
    KPIDetailsPageFromLogInUserProfilePage = 0,
    KPIDetailsPageFromReporteeProfilePageOfLogInUser,
    KPIDetailsFromMyPeerRankingTab,
    KPIDetailsFromMyDMsPeerRankingTab,

} KPIDetailsPageType;

typedef enum { ChatterFeatureAll = 0, ChatterFeatureOnlyPrivate } ChatterFeature;

typedef enum {
    SortKeyName = 0,
} SortKey;
