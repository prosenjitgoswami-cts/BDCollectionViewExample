    //
    //  Constants.h
    //  ABIHiFive
    //
    //  Created by Prsenjit Goswami on 10/06/16.
    //  Copyright © 2016 Cognizant. All rights reserved.
    //
#import "CommonHeader.h"
#import <Foundation/Foundation.h>

#define UNIT_TEST 0

#define DEBUGGING NO
#define NSLog                                                                                                                                        \
if (DEBUGGING)                                                                                                                                     \
NSLog
#define IS_IPAD (UI_USER_INTERFACE_IDIOM() == UIUserInterfaceIdiomPad)
#define IS_IPHONE (UI_USER_INTERFACE_IDIOM() == UIUserInterfaceIdiomPhone)
#define IS_IPHONE_5_LESS (IS_IPHONE && [[UIScreen mainScreen] bounds].size.height <= 568.0)
#define IS_IPHONE_5 (IS_IPHONE && [[UIScreen mainScreen] bounds].size.height == 568.0)
#define IS_IPHONE_6 (IS_IPHONE && [[UIScreen mainScreen] bounds].size.height == 667.0)
#define IS_IPHONE_6PLUS (IS_IPHONE && [[UIScreen mainScreen] nativeScale] == 3.0f)
#define IS_IPHONE_6_PLUS (IS_IPHONE && [[UIScreen mainScreen] bounds].size.height == 736.0)
#define IS_RETINA ([[UIScreen mainScreen] scale] == 2.0)
#define dispatch_main_async_safeBlock(block)                                                                                                         \
if ([NSThread isMainThread]) {                                                                                                                     \
block();                                                                                                                                         \
} else {                                                                                                                                           \
dispatch_async(dispatch_get_main_queue(), block);                                                                                                \
}
@class ABISFBadgesDetailsNameWiseDataModel;
    // Block types
typedef void (^SOQLCompletion)(id result, NSError *error, SOQLStatus status);
typedef void (^ABIResponseBlock)(id result, NSDictionary *extraInfo);
typedef void (^ABIMutableArrayResponseBlock)(NSMutableArray *results, NSDictionary *extraInfo);
typedef void (^ABIFailedBlock)(NSError *error, NSDictionary *extraInfo);
/*!
 *  User Default key
 */
#define kOnboardingIsShown @"OnboardingIsShown"
    // StoryBoard ID
static NSString *kStoryBoardIDABIChatterFileViewerViewController = @"ABIChatterFileViewerViewController";
static NSString *kStoryBoardIDABIChatterFeedListViewController = @"ABIChatterFeedListViewController";
static NSString *kStoryBoardIDPageViewController = @"PageViewController";
static NSString *kStoryBoardIDInternalViewController = @"ABIOnBoardingInternalPageViewController";
static NSString *kStoryBoardIDMain = @"Main";
static NSString *IncentiveHintView = @"IncentiveHintView";

#define FLASH_MESSAGE_DISPLAY_TIME 1.0f
#define DEFAULT_PAGE_HEIGHT 44.0f
#define MAX_NAME_COUNT 3
#define MAX_CHARECTER_LENGHT_BEFORE_MORE_STRING 150
#define DEFAULT_CELL_CORNER_RADIUS 4.0f
#define DEFAULT_CELL_PADDING 10.0f
#define DEFAULT_CELL_SEPERATOR_HEIGHT 2.0f
#define DEFAULT_BAR_CHART_HEIGHT 20.0f

    // MARK: PAGE TITLE
#define PAGER_TITLES_CHATTER_CHANNEL_NAMES @[ @"Posts", @"Messages" ]
#define PAGER_TITLES_PEER_RANKING_AS_SD @[ @"My Peer Ranking", @"My DMs Ranking" ]
#define PAGER_TITLES_PRFILE_PAGE_AS_MANAGER_LOGIN @[ @"My Incentives", @"My DMs" ]
#define PAGE_TITLE_CHATTER @"Chatter"
#define PAGE_TITLE_NEW_CHATTER @"New Chatter"
#define PAGE_TITLE_ANNOUNCEMENTS_HEADER @"Latest Announcements"
#define PAGE_TITLE_PROFILE @"Profile"
#define PAGE_TITLE_DM_PROFILE @"DM Profile"
#define PAGE_TITLE_BADGE_DETAILS @"Badge Details"
#define PAGE_TITLE_PEER_RANKING @"Peer Ranking"
#define PAGE_TITLE_DMS_RANKING @"DMs Ranking"
#define PAGE_TITLE_MY_DMS_RANKING @"My DMs Ranking"
#define PAGE_TITLE_KPI_DETAILAS @"KPI Details"
#define PAGE_TITLE_DM_KPI_DETAILAS @"DM KPI Details"
    // MARK: Placeholder
#define PLACEHOLDER_WRITE_A_COMMENT @"Write a comment.. "

    // MARK: Dictionary
#define kMetricsDefaultPadding @"kMetricsDefaultPadding"
#define kMetricsDefaultCellSeperatorHeight @"kMetricsDefaultCellSeperatorHeight"
#define kMetricskDefaultBarChartHeight @"kMetricskDefaultBarChartHeight"
    // MARK: IMAGE NAME
#define kPLACE_HOLDER_IMAGE nil
#define PUBLIC_IMAGE @"public.image"
#define PUBLIC_MOVIE @"public.movie"
#define cancelButtonImage @"cancelButtonImage"
#define dummyProfileImage @"dummyProfileImage"
#define mainProfileCircle @"mainProfileCircle"
#define chatterPostProfile @"chatterPostProfile"
#define attachment @"attachment"
#define search_icon @"search-icon"
#define checkedBox @"checkedBox"
#define uncheckedBox @"uncheckedBox"
#define IMAGE_FORMAT @"IMG_%.0f.JPG"
#define notification_inactive @"notification_inactive"
#define notification_active @"notification_active"
#define back_IMAGE @"left_arrow"
#define menu_icon @"menu_icon"
#define profile_logo_deselected @"profile_logo_deselected"
#define postIcon @"postIcon"
#define newPostButton @"newPostButton"
#define menu_profile_image @"menu_profile_image"
#define mainProfileCircle @"mainProfileCircle"
#define SecondPlace_IMAGE @"SecondPlace"
#define FirstPlace_IMAGE @"FirstPlace"
#define ThirdPlace_IMAGE @"ThirdPlace"
#define youAreHereRight_Image @"youAreHereRight"
#define youAreHereLeft_Image @"youAreHereLeft"
#define rankImage @"rankImage"
#define IMAGE_NAME_INCENTIVE @"incentive"
#define pointer @"pointer"

    // MARK: Progress bar
#define ANNOTATION_IMAGE_VIEW_WIDTH 10.0
#define PROGRESS_BAR_HEIGHT 15.0
#define BAR_CORNER_RADIUS (PROGRESS_BAR_HEIGHT / 2)
    // MARK: File Extension
#define m4v @"m4v"
#define mp4 @"mp4"
#define mov @"mov"
#define pdf @"pdf"
#define docx @"docx"
#define txt @"txt"
#define xlsx @"xlsx"
#define xls @"xls"
    // MARK: MENTION
#define PREFIX_TAG_MENTIONS_NAME @"@["
#define POST_TAG_MENTIONS_NAME @"]"
#define PRE_TAG_MENTIONS_NAME @"["
#define COMMA_TAG_MENTIONS_NAME @","
#define AT_THE_RATE_TAG_MENTIONS_NAME @"@"
    // MARK: SLIDE MENU CONSTANT
#define MENU_LIST_FONT [UIFont systemFontOfSize:12]
#define SLIDEMENU_CONDITION YES
#define SLIDEMENU_OPT_NOT_CHANGE_COLOR_CONDITION (indexPath.row == 3 || indexPath.row == 2)
    // MARK: Font
#define SLIDE_MENU_USER_NAME_TEXT_FONT [UIFont systemFontOfSize:18]
#define SLIDE_MENU_USER_NAME_TEXT_COLOR [UIColor darkGreyColorABI]
#define SLIDE_MENU_SELECTED_LABEL_TEXT_FONT [UIFont systemFontOfSize:18]
#define SLIDE_MENU_DESELECTED_LABEL_TEXT_FONT [UIFont systemFontOfSize:18]
#define FONT_WITH_NAME @"HelveticaNeue-Bold"
    // MARK: Color
#define SLIDE_MENU_SELECTED_LABEL_TEXT_COLOR [UIColor darkGreyColorABI]
#define SLIDE_MENU_DESELECTED_LABEL_TEXT_COLOR [UIColor blueColorABI]
#define SLIDE_MENU_SELECTED_CELL_BG_COLOR [UIColor defaultPageBGColor]
#define SLIDE_MENU_DESELECTED_CELL_BG_COLOR [UIColor whiteColor]
    // MARK: HEX COLOR CODE
#define HEX_COLOR_CODE_0e71b9_BLUE @"#0e71b9" //(14,113,185)
#define HEX_COLOR_CODE_7ad2f7_SKY @"#7ad2f7"  //(122,210,247)
#define HEX_COLOR_CODE_ffffff_WHITE @"#ffffff"
#define HEX_COLOR_CODE_000000_BLACK @"#000000"
#define HEX_COLOR_CODE_2fbeef_LIGHTBLUE @"2fbeef"
#define HEX_COLOR_CODE_8dba00_GREEN @"#8dba00"     //(141,186,0)
#define HEX_COLOR_CODE_fdd519_YELLOW @"#fdd519"    //(254,150,17)
#define HEX_COLOR_CODE_fe9611_ORANGE @"#fe9611"    //(254,150,17)
#define HEX_COLOR_CODE_f25957_OFFRED @"#f25957"    //(242,89,87)
#define HEX_COLOR_CODE_333333_DARK_GREY @"#333333" //(204,204,204)
#define HEX_COLOR_CODE_cccccc_LIGHTGREY @"#cccccc" //(51,51,51)
#define HEX_COLOR_CODE_C2CDFD_MAUVE @"#C2CDFD"
#define HEX_COLOR_CODE_6c6c6c_MEDIUMGREY @"#6c6c6c"
#define HEX_COLOR_CODE_e5ebed_veryLightGrey @"#e5ebed"
#define HEX_COLOR_CODE_ececec_veryLightGreySeperator @"#ececec"
    // MARK: Profile Page Font
#define PROFILE_INCENTIVE_TABLE_HEADING_FONT_SIZE [UIFont fontHelvetica67Condensed:18.0f]
#define PROFILE_USER_NAME_FONT_SIZE [UIFont fontHelvetica57Condensed:17.0f]
#define PROFILE_INCENTIVE_NAME_FONT_SIZE [UIFont fontHelvetica57Condensed:15.0f]
#define PROFILE_SUMMER_INCENTIVE_FONT_SIZE [UIFont fontHelvetica57Condensed:12.0f]
#define PROFILE_RANK_FONT_SIZE [UIFont fontHelvetica67Condensed:7.0f]
#define PROFILE_RANKANDPOINT_FONT_SIZE [UIFont fontHelvetica67Condensed:7.0f]
#define PROFILE_PEER_KPI_BUTTON_FONT_SIZE [UIFont fontHelvetica57Condensed:12.0f]
#define PROFILE_DESCRIPTION_TEXT_FONT_SIZE [UIFont fontHelvetica67Condensed:10.0f]
#define PROFILE_STATUS_TITLE_FONT_SIZE [UIFont fontHelvetica67Condensed:8.0f]
#define PROFILE_UNIT_TEXT_FONT_SIZE [UIFont fontHelvetica67Condensed:14.0f]
    // MARK: Profile Page Colour
#define PROFILE_INCENTIVE_TABLE_HEADING_FONT_COLOUR [UIColor blackColorABI]
#define PROFILE_USER_NAME_FONT_COLOUR [UIColor blackColorABI]
#define PROFILE_INCENTIVE_NAME_FONT_COLOUR [UIColor blackColorABI]
#define PROFILE_STATUS_TITLE_FONT_COLOUR [UIColor blackColorABI]
#define PROFILE_STATUS_FONT_COLOUR [UIColor blackColorABI]
#define PROFILE_POINTS_FONT_COLOUR [UIColor blackColorABI]
#define PROFILE_UNIT_TEXT_FONT_COLOUR [UIColor blackColorABI]
#define PROFILE_DESCRIPTION_TEXT_FONT_COLOUR [UIColor blackColorABI]
    // MARK: Peer Profile View Controller
#define PEER_PROFILE_POINTS_FONT_SIZE [UIFont fontHelvetica67Condensed:18.0f]
#define PEER_PROFILE_POINTS_TEXT_FONT_SIZE [UIFont fontHelvetica67Condensed:12.0f]
#define PEER_PROFILE_PROFILE_USER_NAME_FONT_SIZE [UIFont fontHelvetica57Condensed:17.0f]
#define INCENTIVE_NAME_FONT_SIZE [UIFont defaultTextFontABI]
#define STATUS_TITLE_FONT_SIZE [UIFont defaultTextFontABI]
#define STATUS_FONT_SIZE [UIFont defaultTextFontABI]
#define POINTS_FONT_SIZE [UIFont defaultTextFontABI]
    // MARK: Announcement
#define TIMETOGOANDDAYSREMAINING_FONT_SIZE [UIFont defaultTextFontABI]
#define TEXTVIEW_FONT_SIZE [UIFont defaultTextFontABI]
#define ANNOUNCEMENT_TABLE_HEADER_TITLE_COLOR [UIColor lightGreyColorABI]
#define ANNOUNCEMENT_TABLE_HEADER_TITLE_FONT [UIFont fontHelvetica57Condensed:12.0f]
    // MARK: CHATTER ON BOARDING
#define USERNAME_FONT_SIZE [UIFont fontHelvetica57Condensed:14.0f]
#define TIME_FONT_SIZE [UIFont fontHelvetica57Condensed:12.0f]            // 10
#define INCENTIVE_TYPE_FONT_SIZE [UIFont fontHelvetica57Condensed:12.0f]  // 10
#define CHATTER_Comment_FONT_SIZE [UIFont fontHelvetica57Condensed:12.0f] // 10
#define USER_Comment_FONT_SIZE [UIFont fontHelvetica57Condensed:15.0f]
#define Private_FONT_SIZE [UIFont fontHelvetica57Condensed:12.0f]
#define COMMENT_FONT_SIZE [UIFont fontHelvetica57Condensed:14.0f]
#define POSTBTN_FONT_SIZE [UIFont fontHelvetica57Condensed:16.0f]

    // MARK: STATIC TEXT
#define STATIC_TEXT_EMPTY_STRING @""
#define STATIC_TEXT_RANK @"Rank "
#define STATIC_TEXT_OVER_ALL_RANK @"Overall Rank "
#define STATIC_TEXT_MORE_TEXT @" More..."
#define STATIC_TEXT_TODAY @"Today at"
#define STATIC_TEXT_YESTERDAY @"Yesterday at"
#define STATIC_TEXT_TWO_DAYS_AGO @"Two days ago at"
#define STATIC_TEXT_MINUS_STRING @"-"
#define STATIC_TEXT_AGO_STRING @" ago"
#define STATIC_TEXT_AFTER_STRING @"After %@"
#define STATIC_TEXT_OVER_ALL_KIP_RANKING @"Overall KPI ranking"
#define STATIC_TEXT_MY_INCENTIVES @"My Incentives"
#define STATIC_TEXT_DM_INCENTIVES @"DM Incentives"
#define STATIC_TEXT_DMS_ASSIGNED @"DMs Assigned: "
#define STATIC_TEXT_BEST_DM_SCORE @"Best DM Score: "
#define STATIC_TEXT_LEAST_DM_SCORE @"Least DM Score: "
#define STATIC_TEXT_OUT_OF_TEXT @"Out of"
#define STATIC_TEXT_YOU_HAVE_TEXT @"you have"

#define TableViewDownANIMATION @"TableViewDown"
#define STATIC_TEXT_Welcome_STRING @"Welcome %@"

#define STATIC_TEXT_POINTS @"Points"
#define STATIC_TEXT_Profiles_TEXT @"%@'s Profile"

#define STATIC_TEXT_NO_BADGES_TEXT @"No badges Yet"
#define STATIC_TEXT_NO_INCENTIVE_ASSINGED @"There is no incentives assigned"

#define STATIC_TEXT_NO_ANNOUNCEMENTS @"You have no new announcements yet"

#define SFAuthenticationManager_Logout @"SFAuthenticationManager logged out.  Resetting app."
#define Post_launch @"Post-launch: launch actions taken: %@"
#define ERROR_launch @"Error during SDK launch: %@"
#define SFUserAccountManager_CHANGE @"SFUserAccountManager changed from user %@ to %@.  Resetting app."
#define progressStatusColor_TEXT @"self.progressStatusColor =  %@"

    // MARK: Alert Title, Message,Button Title
#define ALT_MSG_NO_INTERNET_CONNECTION @"Unable to connect with the server. Check your internet connection and try again."
#define ALT_MSG_NO_ANNOUANCE @"Announcement is not available, Please try again!"
#define ALT_MSG_NO_COMMENT_TEXT @"You have not entered any text. Type your text and post the message."
#define ALT_MSG_SUCESS_COMMENT_POST @"Your comment has been successfully posted"
#define ALT_MSG_SUCESS_POST @"Your message has been successfully posted"
#define ALT_MSG_FAILED_POST @"Error while posting"
#define ALT_MSG_FAILED_TO_UPLOAD_ATTACHMENT @"Due to a technical issue the text alone is sent but not the attachment."
#define ALT_MSG_NO_SEARCH_RESULT_FOUND @"No search result found"
#define ALT_MSG_NO_POST_MGS_TEXT @"You have not entered any text. Type your text and post the message."
#define ALT_MSG_NO_SEARCH_WORD_TEXT @"Enter atleast one character"
#define ALT_MSG_MAX_RECIPIENT_IN_PRIVATE_MESSAGE @"You can able to add max 9 recipients in private message"
#define ALT_MSG_NO_RECIPIENT_IN_PRIVATE_MESSAGE @"Enter atleast one recipient"
#define ALT_MSG_WHEN_RESET_NEW_CHATTER_PAGE @"You cannot make any attachment and also you cannot send it to a group."
#define ALT_MSG_INCOMPATIBLE_FILE_TYPE @"The file type m4v, mp4, mov, txt, pdf, docx, xlsx is only compatible. Check your file type and try again."
#define ALT_MSG_NO_POST @"No recent posts"
#define ALT_MSG_NO_MSG @"No recent messages"
#define ALT_LOGOUT_MSG_TEXT @"Are you sure you want to exit the application?"
#define ALT_NO_TEXT_WHEN_POST_A_FEED @"There is no text in the message"
#define ALT_MSG_WHEN_PRIVATE_CHECKED @"You can now make an attachment & send to groups"
#define ALT_MSG_WHEN_PRIVATE_CLICKED @"Do you want to overwrite the previous attachment ?"
#define ALT_TAKE_PHOTO @"Take Photo"
#define ALT_PICK_FROM_CAMERA_ROLL @"Pick from Camera Roll"
#define ALT_NO_COMMENT @"There is no comment found."

    // MARK: ALERT BUTTON TITLE
#define ALT_BTN_TITLE_OK @"OK"
#define ALT_BTN_TITLE_CANCEL @"CANCEL"
#define ALT_BTN_TITLE_TRY_AGAIN @"TRY AGAIN"
#define ALT_BTN_TITLE_CONTINUE @"CONTINUE"
#define ALT_BTN_TITLE_NO @"NO"
#define ALT_BTN_TITLE_EXIT @"EXIT"
#define ALT_BTN_TITLE_SURE_BTN_TITLE @"SURE"
#define ALT_BTN_TITLE_SEND_ANYWAY @"SEND ANYWAY"

    // LABEL TEXT

#define STATIC_TEXT_PRIVATE @"Private"

    // BUTTON TITLE
#define BUTTON_TITLE_PEER_RANKING @"Peer Ranking"
#define BUTTON_TITLE_SEE_MORE @"See More..."

    // PLACE HOLDER
#define PLACEHOLDER_TEXT_POST_MSG_BOX @"Type your message here..."
#define PLACEHOLDER_TEXT_WRITE_A_COMMENT @"write a comment..."

    // MARK: Story Board ID
#define STORY_BOARD_ID_PEER_RANKING_PAGE_VC @"ABIPeerRankingPageViewController"
#define STORY_BOARD_ID_KPI_DETAILS_PAGE_VC @"ABIKPIDetailsPageViewController"
#define STORY_BOARD_ID_PEER_RANKING_DETAILS_VC @"PeerKIPChannelViewController"
    // MARK: Segue Identifier
#define SEGUE_ID_ONBOARDING_TO_LOGIN @"PushToLoginViewController"
#define SEGUE_ID_PROFILE_PAGE_TO_PEER_RANKING_LIST_PAGE @"PushToABIPeerRankingListViewController"
#define SEGUE_ID_PROFILE_PAGE_TO_KPI_SUB_CATEGORIES_PAGE @"PushToABIKPIDetailsPageViewController"
#define SEGUE_ID_PEER_RANKING_LIST_PAGE_TO_PEER_SUB_CATG_DETLS_PAGE @"PushToPeerKPIsPageViewController"
#define SEGUE_ID_PushToPostPage @"PushToABIChatterNewPostViewController"
#define SEGUE_ID_PushToABIChatterDetailsViewController @"PushToABIChatterDetailsViewController"
#define SEGUE_ID_PushToABIBadgeDetailsViewController @"PushToABIBadgeDetailsViewController"
#define STORY_BOARD_ID_ANNOUNCEMENT_VC @"ABIAnnouncementDetailsPageViewController"
    // MARK: Cell Identifier
#define CELL_ID_SD_PROFILE_CELL @"SD_ProfileTableViewCell"
#define CELL_ID_DM_PROFILE_CELL @"DM_ProfileTableViewCell"
#define DROP_DOWN_TITLE_VIEW_BY @"View By"
#define DROP_DOWN_TITLE_FOR_YEAR @"For Year"
#define PREVIOUS_YEAR_FROM_NOW 4
    // MARK: DROP DOWN LIST
#define DROP_DOWN_CELL_ROW_HEIGHT 40.0f
#define MAX_VIBILE_CELL 6
#define SEPERATOR_LINE_WIDTH 1
    // TableView
#define TABLEVIEW_ESTIMATED_ROW_HEIGHT 85.0f
    // MARK: TERMS AND CONDITION MAIL
#define TREMS_AND_CONDITION_URL_STRING @"http://anheuser-busch.com/index.php/privacy-policy/"
    // MARK: HELP AND SUPPPORT MAIL
#define HELP_AND_SUPPPORT_RECIPIENTS @"Salesforce@anheuser-busch.com"
    // TITLE_PRIVACY_POLICY
#define TITLE_PRIVACY_POLICY @"Privacy Policy"
    // MARK: Incentive Perfermance
#define kGREEN @"GREEN"
#define kYELLOW @"YELLOW"
#define kRED @"RED"
#define kGREEN_COLOR_START_VALUE_IN_POINT 0.69
#define kRED_COLOR_START_VALUE_IN_POINT 0.39
#define EXCEEDED_PERFORMANCE_STATUS_TEXT @"Way to Go!"
#define MEDIUM_PERFORMANCE_STATUS_TEXT @"Good Work!"
#define VERY_LOW_PERFORMANCE_STATUS_TEXT @"Need to Improve!"
