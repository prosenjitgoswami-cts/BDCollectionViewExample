    //
    //  SFConstants.h
    //  ABIHiFive
    //
    //  Created by Prsenjit Goswami on 11/08/16.
    //  Copyright © 2016 Cognizant. All rights reserved.
    //
#import <Foundation/Foundation.h>
#define kOAuthRedirectURI @"OAuthRedirectURI"
#define kRemoteAccessConsumerKey @"RemoteAccessConsumerKey"
#define kPlistName @"Info"
#define STATIC_TEXT_POINTS @"Points"
#pragma mark -

#pragma mark -  SOQL DICTIONARY KEY
    // ABI USER ROLE
#define kALL @"All"
#define kALL_Badges @"All Badges"
#define kRosterID @"RosterID"
#define kIncentiveName @"IncentiveName"
#define kIncentiveID @"IncentiveID"
#define kABISFRosterDataModel @"rosterDataModel"
#define kRosterRole @"RosterRole"
    // Roster Role
#define ABI_SF_USER_ROLE_DM @"DM"
#define ABI_SF_USER_ROLE_SD @"SD"
    // DATE FORMAT
#define DEFAULT_SF_DATE_FORMAT @"yyyy-MM-dd'T'HH:mm:ss.SSSZ"
#define ABISFBADGE_AWARD_DATE_FORMAT @"YYYY-MM-dd"
#define DISPLAY_BADGE_AWARD_DATE_FORMAT @"MMMM dd, YYYY"
#define kID @"Id"
#define kRECORD @"records"
#define kExtraDependency extraDependency
    // USER TABLE
static NSString *kComment = @"Comment Received From";

    // ROSTER TABLE
    // ----- ----- ----- ----- ----- ----- ----- Duplicate ----- ----- ----- ----- ----- ----- ----- ----- -----
#define kSOQLRoster_User__r @"Roster_User__r"
    //#define Points__c @"Points__c"
#define kIncntv_Id__r @"Incntv_Id__r"

    // ----- ----- ----- ----- ----- ----- -----  ----- ----- ----- ----- ----- ----- ----- -----

    // ----- ----- ----- ----- ----- ----- ----- NEW ----- ----- ----- ----- ----- ----- ----- ----- ----- -----
#define kSOQLDisplay__c @"Roster_Display__c"
#define kSOQLName @"Name"
#define kSOQLRoster_Hier_SD__c @"Roster_Hier_SD__c"
#define kSOQLRoster_Name__c @"Roster_Name__c"
#define kSOQLRoster_Role__c @"Roster_Role__c"
#define kSOQLRoster_User__c @"Roster_User__c"
#define kSOQLSLs_Regn_Nm__c @"SLs_Regn_Nm__c"
#define kSOQLUser_ID__r @"User_ID__r"
#define kSOQLFullPhotoUrl @"FullPhotoUrl"
#define kSOQLSmallPhotoUrl @"SmallPhotoUrl"

#define kSOQLSLS_Regn_Cd__r @"SLS_Regn_Cd__r"

    // ----- ----- ----- ----- ----- ----- ----- Annoucement ---- ----- ----- ----- ----- ----- ----- ----- ----- -----

#define kSOQLAnnouncement_NM__c @"Announcement_NM__c"
#define kSOQLAnnouncement_Body__c @"Announcement_Body__c"
#define kSOQLAnnouncement_SUBJ__c @"Announcement_SUBJ__c"
#define kSOQLAnnouncement_URL__c @"Announcement_URL__c"
#define kSOQLAnnouncement_Start__c @"Announcement_Start__c"
#define kSOQLAnnouncement_End__c @"Announcement_End__c"
#define kSOQLCreatedDate @"CreatedDate"
#define kSOQLLastModifiedDate @"LastModifiedDate"

    //-------------------------------

#define kSOQLUser__c @"User__c"
#define kSOQLRole__c @"Role__c"
#define kSOQLSignInUserRole__c @"SignInUserRole__c"
#define kSOQLSLS_Regn_Cd__c @"SLS_Regn_Cd__c"
#define kSOQLID__c @"ID__c"
#define kSOQLUser__r @"User__r"
#define kSOQLINCNTV_KPI_KPI_NM__c @"INCNTV_KPI_KPI_NM__c" //@"KPI_Nm__c"

    // ----- ----- ----- ----- ----- ----- ----- INCENTIVE ---- ----- ----- ----- ----- ----- ----- ----- -----

#define KSOQLINCNTV_ID__r @"INCNTV_ID__r"
#define KSOQLINCNTV_WEEK__c @"INCNTV_WEEK__c"
#define kSOQLINCNTV_POINTS__c @"INCNTV_POINTS__c"
#define kSOQLIncntv_Nm__c @"INCNTV_NM__c"
#define kSOQLINCNTV_Start__c @"INCNTV_Start__c"
#define kSOQLINCNTV_End__c @"INCNTV_End__c"
#define kSOQLIncntv_KPI_Id__r @"Incentive_KPI_ID__r"
#define kSOQLChannel_Nm__c @"INCNTV_KPI_Channel_NM__c" //@"Channel_Nm__c"

#define kSOQLRoster_User_ID__r @"Roster_User_ID__r"
#define kSOQLINCNTV_WEEK__c @"INCNTV_WEEK__c"

    //  KPI
#define kSOQLINCNTV_Value__c @"INCNTV_Value__c"           //@"KPI_Result__c"
#define kSOQLINCNTV_Value_Disp__c @"INCNTV_Value_Disp__c" //@"KPI_Result__c"
#define kSOQLINCNTV_Status__c @"INCNTV_Status__c"         //@"Status_Ref__c"

    // Badge
#define kSOQLBadge_Award_DT__c @"Badge_Award_DT__c"
#define kSOQLDoc_Folder_NM1__c @"Doc_Folder_NM1__c" //@"Document_Name_Folder__c"
#define kSOQLBadge_NM__c @"Badge_NM__c"             //@"Badge_Nm__c"
#define kSOQLBadge_Desc__c @"Badge_Desc__c"
    // Peer Ranking

#define kSLS_Regn_Cd__c @"SLS_Regn_Cd__c"
#define kLastModifiedDate @"LastModifiedDate"
#define kAnnouncement_TITLE @"Announcements"

    // ----- ----- ----- ----- ----- ----- ----- Badge---- ----- ----- ----- ----- ----- ----- ----- -----

#define kBadge_Nm__c @"Badge_Nm__c"
#define kBadge_Id__r @"Badge_Id__r"
#define kPriority__c @"Priority__c"
#define kIncentive_Assignments__r @"Incentive_Assignments__r"
#define kIncntv_Id__c @"Incntv_Id__c"
#define kSOQLBadge_Priority__c @"Badge_Priority__c"
/*!
 *  -------------------------------- CHATTER DICTIONARY KEY ----------------------
 */

#pragma mark -  CHATTER

#pragma mark -
#define kendURL @"/services/data"
#define RestAPIPath_PostNewFeed(actorID, messageText)                                                                                                \
[NSString stringWithFormat:@"/chatter/feed-elements?feedElementType=FeedItem&subjectId=%@&text=%@", actorID, messageText]
#define kId @"Id"
#define kElements @"elements"
#define kid @"id"
#define kBody @"body"
#define kActor @"actor"
#define kText @"text"
#define kComments @"comments"
#define kPage @"page"
#define kItems @"items"
#define kname @"name"
#define kDisplayName @"displayName"
#define kType @"type"
#define kPhotoUrl @"photoUrl"
#define kParent @"parent"
#define kUser @"user"
#define kCreatedDate @"createdDate"
#define kRelativeCreatedDate @"relativeCreatedDate"
#define kModifiedDate @"modifiedDate"
#define kFeedElement @"feedElement"
#define kUrl @"url"
    // MARK: Photos
#define kphoto @"photo"
#define kMediumPhotoUrl @"mediumPhotoUrl"
#define kFullEmailPhotoUrl @"fullEmailPhotoUrl"
#define kStandardEmailPhotoUrl @"standardEmailPhotoUrl"
#define kSmallPhotoUrl @"smallPhotoUrl"
#define kPhotoVersionId @"photoVersionId"
#define kLargePhotoUrl @"largePhotoUrl"
    // MARK:Contain
#define kFiles @"files"
#define kRenditionUrl @"renditionUrl"
#define kRenditionUrl720By480 @"renditionUrl720By480"
#define kRenditionUrl240By180 @"renditionUrl240By180"
#define kVersionId @"versionId"
#define kFileExtension @"fileExtension"
#define kDownloadUrl @"downloadUrl"
#define kTitle @"title"
#define kFileType @"fileType"
#define kMimeType @"mimeType"
#define kCapabilities @"capabilities"
#define kContent @"content"
#define HamburgerMenuList @"HamburgerMenuList"
#define plist @"plist"
#define ListMenuItem @"ListMenuItem"
#define SelectedImageName @"SelectedImageName"
#define DeselectedImageName @"DeselectedImageName"
#define OnBoarding @"OnBoarding"
#define heading1 @"heading"
#define imageName1 @"imageName"
#define pageDescription1 @"pageDescription"
    // MARK:Comment
#define kTotal @"total"
#define kNextPageUrl @"nextPageUrl"
#define kPreviousPageUrl @"previousPageUrl"
#define kCurrentPageUrl @"currentPageUrl"
#define kUpdatesUrl @"updatesUrl"
    // MARK:Mention
#define kRecordId @"recordId"
    // MARK: Feed Type
#define FEED_TYPE_COLLABRATION_GROOP @"CollaborationGroup"
    // MARK:Message
#define kMessages @"messages"
#define kRecipients @"recipients"
#define kSender @"sender"
#define kConversationId @"conversationId"
#define kConversationUrl @"conversationUrl"
#define kSentDate @"sentDate"
#define kMentionCompletions @"mentionCompletions"
