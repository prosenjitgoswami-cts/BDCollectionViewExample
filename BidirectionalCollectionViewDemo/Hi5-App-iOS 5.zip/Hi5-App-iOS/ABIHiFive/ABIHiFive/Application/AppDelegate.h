    //
    //  AppDelegate.h
    //  ABIHiFive
    //
    //  Created by Prsenjit Goswami on 10/06/16.
    //  Copyright © 2016 Cognizant. All rights reserved.
    //
#import "EnumMaster.h"
#import <CoreData/CoreData.h>
#import <UIKit/UIKit.h>

@class ABISFRosterDataModel;
@interface AppDelegate : UIResponder <UIApplicationDelegate>
@property (strong, nonatomic) UIWindow *window;
@property (readonly, strong, nonatomic) NSManagedObjectContext *managedObjectContext;
@property (readonly, strong, nonatomic) NSManagedObjectModel *managedObjectModel;
@property (readonly, strong, nonatomic) NSPersistentStoreCoordinator *persistentStoreCoordinator;
@property (strong, nonatomic) UINavigationController *navigationController;
- (void)saveContext;
- (NSURL *)applicationDocumentsDirectory;
+ (AppDelegate *)appdelegateShareInstance;
- (void)setupSlideMenuViewController;
- (void)setLoginViewControllerAsRootViewController;
+ (BOOL)isOffline;
@property (nonatomic, assign) BOOL isNewPostDone;
@property (nonatomic, strong) ABISFRosterDataModel *globalSingedInRoster;
@property (nonatomic, assign) PageFlow globalCurrentPageFlow;
+ (void)setGlobalSingedInRoster:(ABISFRosterDataModel *)singedInRoster;
+ (void)setGlobalCurrentPageFlow:(PageFlow)globalCurrentPageFlow;
+ (PageFlow)globalCurrentPageFlow;
+ (ABISFRosterDataModel *)globalSingedInABISFRosterDataModel;

@end
