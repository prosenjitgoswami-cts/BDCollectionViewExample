    //
    //  NSString+ABIPageTitleString.m
    //  ABIHiFive
    //
    //  Created by Prsenjit Goswami on 15/06/16.
    //  Copyright © 2016 Cognizant. All rights reserved.
    //

#import "ABISFChatterContentDataModel.h"
#import "Constants.h"
#import "NSString+ABIPageTitleString.h"

@implementation NSString (ABIPageTitleString)

+ (NSString *)profilePageTitle {

    NSString *titleString = STATIC_TEXT_EMPTY_STRING;
    if (([AppDelegate globalCurrentPageFlow] == PageFlowAsMyDMAsSDLogin)) {
        titleString = PAGE_TITLE_DM_PROFILE;
    } else {
        titleString = PAGE_TITLE_PROFILE;
    }
    return titleString;
}

+ (NSString *)kpiDetailsPageTitle:(ABISFRosterDataModel *)roster {
    NSString *titleString = STATIC_TEXT_EMPTY_STRING;

    NSString *currentRole = roster.roleInString;
    NSString *signedInRole = roster.managerRoleInString;

    if ([currentRole isEqualToString:ABI_SF_USER_ROLE_DM] && [signedInRole isEqualToString:ABI_SF_USER_ROLE_SD]) {
        titleString = PAGE_TITLE_DM_KPI_DETAILAS;
    } else {
        titleString = PAGE_TITLE_KPI_DETAILAS;
    }
    return titleString;
}
+ (NSString *)peerKPIsPageTitle:(ABISFRosterDataModel *)roster isCurrentUser:(BOOL)isCurrentUser {
    NSString *titleString = PAGE_TITLE_KPI_DETAILAS;

    switch (roster.rosterRole) {
        case RosterRoleSD:
            if (!isCurrentUser) {
                NSString *firstName = [roster rosterFirstName];
                titleString = [NSString stringWithFormat:@"%@'s KPI Details", firstName];
            } else {
                titleString = PAGE_TITLE_KPI_DETAILAS;
            }
            break;
        case RosterRoleDM:
            if (!isCurrentUser && [roster.managerRoleInString isEqualToString:ABI_SF_USER_ROLE_DM]) {
                NSString *firstName = [roster rosterFirstName];

                if (![NSString isNULLString:firstName]) {
                    titleString = [NSString stringWithFormat:@"%@'s KPI Details", firstName];
                }

            } else {
                if ([roster.managerRoleInString isEqualToString:ABI_SF_USER_ROLE_SD]) {
                    titleString = PAGE_TITLE_DM_KPI_DETAILAS;
                } else {
                    titleString = PAGE_TITLE_KPI_DETAILAS;
                }
            }
            break;
        default: break;
    }

    return titleString;
}
    //+ (NSString *)___peerKPIsPageTitle:(ABISFRosterDataModel *)roster isCurrentUser:(BOOL)isCurrentUser {
    //    NSString *titleString = @"KPI Details";
    //    {
    //    switch (roster.rosterRole) {
    //
    //
    //
    //        case RosterRoleSD:
    //            if (!isCurrentUser) {
    //                NSString *firstName = [roster rosterFirstName];
    //                titleString = [NSString stringWithFormat:@"%@'s KPI Details", firstName];
    //            } else {
    //                titleString = @"KPI Details";
    //            }
    //            break;
    //        case RosterRoleDM:
    //            if (!isCurrentUser && [roster.managerRoleInString isEqualToString:ABI_SF_USER_ROLE_DM]) {
    //                NSString *firstName = [roster rosterFirstName];
    //
    //                if(![NSString isNULLString:firstName]) {
    //                    titleString = [NSString stringWithFormat:@"%@'s KPI Details", firstName];
    //                }
    //
    //            } else {
    //                if ([roster.managerRoleInString isEqualToString:ABI_SF_USER_ROLE_SD]) {
    //                    titleString = @"DM KPI Details";
    //                } else {
    //                    titleString = @"KPI Details";
    //                }
    //            }
    //            break;
    //        default: break;
    //    }
    //    }
    //
    //    return titleString;
    //}

+ (NSString *)peerRankingPageTitle:(ABISFRosterDataModel *)roster pagerTabIndex:(NSInteger)pagerTabIndex {
    NSString *titleString = @"";
    if ([roster.managerRoleInString isEqualToString:ABI_SF_USER_ROLE_SD] && [roster.roleInString isEqualToString:ABI_SF_USER_ROLE_DM]) {
        titleString = PAGE_TITLE_DMS_RANKING;
    } else if ([roster.managerRoleInString isEqualToString:ABI_SF_USER_ROLE_DM] && [roster.roleInString isEqualToString:ABI_SF_USER_ROLE_DM]) {
        titleString = PAGE_TITLE_PEER_RANKING;
    } else {
        if (pagerTabIndex == 0) {
            titleString = PAGE_TITLE_PEER_RANKING;
        } else {
            titleString = PAGE_TITLE_MY_DMS_RANKING;
        }
    }
    return titleString;
}

+ (NSString *)rosterAssingedIncentiveDetailsTableHeader:(ABISFRosterDataModel *)roster {

    NSString *titleString = @"";

    if ([roster.managerRoleInString isEqualToString:ABI_SF_USER_ROLE_SD] && [roster.roleInString isEqualToString:ABI_SF_USER_ROLE_DM]) {
        titleString = STATIC_TEXT_DM_INCENTIVES;
    } else {
        titleString = STATIC_TEXT_MY_INCENTIVES;
    }

    return titleString;
}

+ (NSString *)announcementsPageTitle {
    return kAnnouncement_TITLE;
}

+ (NSString *)badgeDetailsPageTitle {
    return PAGE_TITLE_BADGE_DETAILS;
}

+ (NSString *)chatterPageTitle {
    return PAGE_TITLE_CHATTER;
}

+ (NSString *)newChatterPageTitle {

    return PAGE_TITLE_NEW_CHATTER;
}

+ (NSString *)chatterFileViewer:(ABISFChatterContentDataModel *)contentDataModel {

    return contentDataModel.title;
}
@end
