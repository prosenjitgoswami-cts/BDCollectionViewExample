    //
    //  NSDictionary+ABIExtraDependency.m
    //  ABIHiFive
    //
    //  Created by Prsenjit Goswami on 15/06/16.
    //  Copyright © 2016 Cognizant. All rights reserved.
    //

#import "NSDictionary+ABIExtraDependency.h"

@implementation NSDictionary (ABIExtraDependency)

+ (NSDictionary *)extraDDSkipFetchingKPIDetails {

    return @{ kExtraDepDictKeySkipFetchingKPIDetails : @(YES) };
}

- (BOOL)extraDependencySkipFetchingKPIDetails {

    NSNumber *skipped = self[kExtraDepDictKeySkipFetchingKPIDetails];

    return [skipped boolValue];
}

@end
