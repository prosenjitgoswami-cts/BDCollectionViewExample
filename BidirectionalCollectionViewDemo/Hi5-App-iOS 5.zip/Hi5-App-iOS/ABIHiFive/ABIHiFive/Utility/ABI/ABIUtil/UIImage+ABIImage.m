    //
    //  UIImage+ABIImage.m
    //  ABIHiFive
    //
    //  Created by Prsenjit Goswami on 15/06/16.
    //  Copyright © 2016 Cognizant. All rights reserved.
    //

#import "Constants.h"
#import "UIImage+ABIImage.h"

@implementation UIImage (ABIImage)

+ (UIImage *)imageABIOuterCircle {
    return [UIImage imageNamed:mainProfileCircle];
}

+ (UIImage *)imageABIDummyUser {
    return [UIImage imageNamed:dummyProfileImage];
}

+ (UIImage *)imageABIYorRHereRight {
    return [UIImage imageNamed:youAreHereRight_Image];
}

@end
