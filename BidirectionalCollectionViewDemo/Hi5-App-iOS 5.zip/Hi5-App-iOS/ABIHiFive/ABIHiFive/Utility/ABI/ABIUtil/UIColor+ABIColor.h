    //
    //  UIColor+ABIColorUtil.h
    //  ABIHiFive
    //
    //  Created by Prsenjit Goswami on 15/06/16.
    //  Copyright © 2016 Cognizant. All rights reserved.
    //

#import <UIKit/UIKit.h>

@interface UIColor (ABIColorUtil)

+ (UIColor *)colorWithHexString:(NSString *)hexString;
+ (UIColor *)defaultPageBGColor;
+ (UIColor *)defaultSeparatorColor;
+ (UIColor *)defaultABIBlueColor;
+ (UIColor *)defaultTextDarkColor;
+ (UIColor *)defaultTextLightColor;
+ (UIColor *)defaultMauveColorABI;
+ (UIColor *)peerRankingListTableSeperatorColor;
+ (UIColor *)veryLightGreySeperator;
+ (UIColor *)peerRankingTableSeparatorColor;
+ (UIColor *)blueColorABI;
+ (UIColor *)lightBlueColorABI;
+ (UIColor *)cyanColorABI;
+ (UIColor *)whiteColorABI;
+ (UIColor *)blackColorABI;
+ (UIColor *)greenColorABI;
+ (UIColor *)redColorABI;
+ (UIColor *)darkGreyColorABI;
+ (UIColor *)lightGreyColorABI;
+ (UIColor *)yellowColorABI;
+ (UIColor *)colorForIncentiveInPercentage:(CGFloat)multiplier;
+ (UIColor *)colorForIncentiveProgress:(NSString *)colorName;
+ (UIColor *)incentiveExceededColor;
+ (UIColor *)incentiveMinimumColor;
+ (UIColor *)incentiveVeryLessColor;

@end
