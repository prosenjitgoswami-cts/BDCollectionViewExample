    //
    //  UIViewController+ABIUtil.h
    //  ABIHiFive
    //
    //  Created by Prsenjit Goswami on 15/06/16.
    //  Copyright © 2016 Cognizant. All rights reserved.
    //

#import "EnumMaster.h"
#import <UIKit/UIKit.h>

@interface UIViewController (ABIUtil)
#pragma mark - NavigationBar
- (void)navigationBarCustomiseABI;

- (void)addNavigationItem:(nullable UIImage *)buttonImage
                addTarget:(nullable id)target
                   action:(nullable SEL)action
      customBarButtonItem:(CustomBarButtonItem)customBarButtonItem;

#pragma mark - AlertViewController

- (void)alertWithTitle:(nullable NSString *)alertTitle
               message:(nullable NSString *)message
    defaultButtonTitle:(nullable NSString *)defaultButtonTitle
   defaultButtonHander:(nullable void (^)(void))defaultButtonHander
     cancelButtonTitle:(nullable NSString *)cancelButtonTitle
    cancelButtonHander:(nullable void (^)(void))cancelButtonHander;

+ (void)alertInNoNetworkConnection:(nonnull UIViewController *)viewcontroller clickedOkButton:(void (^_Nullable)(void))clickedOkButton;

- (void)alertWithTitle:(nullable NSString *)title
               message:(nullable NSString *)message
    defaultButtonTitle:(nullable NSString *)defaultButtonTitle
       clickedOkButton:(void (^_Nullable)(void))clickedOkButton;
- (void)alertWithMessage:(nullable NSString *)message clickedOkButton:(void (^_Nullable)(void))clickedOkButton;
- (void)alertWithMessage:(nullable NSString *)message;
@end
