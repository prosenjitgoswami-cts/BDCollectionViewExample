    //
    //  UIViewController+ABIUtil.m
    //  ABIHiFive
    //
    //  Created by Prsenjit Goswami on 15/06/16.
    //  Copyright © 2016 Cognizant. All rights reserved.
    //

#import "Constants.h"
#import "CustomLoaderManager.h"
#import "ABICustomNavigationBar.h"
#import "UIAlertController+HelperUtil.h"
#import "UIViewController+ABIUtil.h"

@implementation UIViewController (ABIUtil)

#pragma mark - NavigationItem Button
- (void)navigationBarCustomiseABI {
    self.navigationController.navigationBar.titleTextAttributes = @{NSForegroundColorAttributeName : [UIColor whiteColor]};
    self.navigationController.navigationBar.barTintColor = [UIColor blueColorABI];
    self.navigationController.navigationBar.translucent = NO;
    self.navigationController.navigationBar.tintColor = [UIColor whiteColor];
    [[UINavigationBar appearance] setBackgroundImage:[[UIImage alloc] init] forBarPosition:UIBarPositionAny barMetrics:UIBarMetricsDefault];
    [[UINavigationBar appearance] setShadowImage:[[UIImage alloc] init]];
    UIBarButtonItem *navBarButtonAppearance = [UIBarButtonItem appearanceWhenContainedIn:[UINavigationBar class], nil];
    [navBarButtonAppearance setTitleTextAttributes:@{
                                                     NSFontAttributeName : [UIFont systemFontOfSize:0.1],
                                                     }
                                          forState:UIControlStateNormal];
}
- (void)navigationBarCustomiseAB {
    self.navigationController.navigationBar.titleTextAttributes = @{NSForegroundColorAttributeName : [UIColor whiteColor]};
    self.navigationController.navigationBar.barTintColor = [UIColor blueColorABI];
    self.navigationController.navigationBar.translucent = NO;
    self.navigationController.navigationBar.tintColor = [UIColor whiteColor];
    [[UINavigationBar appearance] setBackgroundImage:[[UIImage alloc] init] forBarPosition:UIBarPositionAny barMetrics:UIBarMetricsDefault];
    [[UINavigationBar appearance] setShadowImage:[[UIImage alloc] init]];
    UIBarButtonItem *navBarButtonAppearance = [UIBarButtonItem appearanceWhenContainedIn:[UINavigationBar class], nil];
    [navBarButtonAppearance setTitleTextAttributes:@{
                                                     NSFontAttributeName : [UIFont systemFontOfSize:0.1],
                                                     NSForegroundColorAttributeName : [UIColor clearColor]
                                                     }
                                          forState:UIControlStateNormal];
}

- (void)addNavigationItem:(UIImage *)buttonImage
                addTarget:(id)target
                   action:(SEL)action
      customBarButtonItem:(CustomBarButtonItem)customBarButtonItem {
    CGFloat buttonWidth = 44.0;
    CGFloat buttonHeight = 44.0;
    ABICustomNavigationBar *buttonContainer = [[ABICustomNavigationBar alloc] initWithFrame:CGRectMake(0, 0, buttonWidth, buttonHeight)];
    UIButton *barItemButton = [UIButton buttonWithType:UIButtonTypeCustom];
    barItemButton.frame = CGRectMake(0, 0, buttonWidth, buttonHeight);
    [barItemButton setImage:buttonImage forState:UIControlStateSelected];
    [barItemButton setImage:buttonImage forState:UIControlStateNormal];
    [buttonContainer addSubview:barItemButton];
    [barItemButton addTarget:target action:action forControlEvents:UIControlEventTouchUpInside];
    barItemButton.translatesAutoresizingMaskIntoConstraints = NO;
    barItemButton.imageEdgeInsets = UIEdgeInsetsMake(0, buttonWidth / 2 + 2, 5, 0);
    NSDictionary *views = @{ @"notificationButton" : barItemButton };
    NSDictionary *metrics = @{ @"buttonHeight" : @(buttonHeight), @"buttonWidth" : @(buttonWidth) };
    [buttonContainer
     addConstraints:[NSLayoutConstraint constraintsWithVisualFormat:@"H:[notificationButton(buttonWidth)]|" options:0 metrics:metrics views:views]];
    [buttonContainer
     addConstraints:[NSLayoutConstraint constraintsWithVisualFormat:@"V:[notificationButton(buttonHeight)]" options:0 metrics:metrics views:views]];
    [buttonContainer addConstraint:[NSLayoutConstraint constraintWithItem:barItemButton
                                                                attribute:NSLayoutAttributeCenterY
                                                                relatedBy:NSLayoutRelationEqual
                                                                   toItem:buttonContainer
                                                                attribute:NSLayoutAttributeCenterY
                                                               multiplier:1
                                                                 constant:0]];
    switch (customBarButtonItem) {
        case BarButtonItemRight:
            barItemButton.imageEdgeInsets = UIEdgeInsetsMake(0, buttonWidth / 2 + 2, 4, 0);
            self.navigationItem.rightBarButtonItem = [[UIBarButtonItem alloc] initWithCustomView:buttonContainer];
            break;
        case BarButtonItemLeft:
            barItemButton.imageEdgeInsets = UIEdgeInsetsMake(0, 0, 4, buttonWidth / 2 + 2);
            self.navigationItem.leftBarButtonItem = [[UIBarButtonItem alloc] initWithCustomView:buttonContainer];
            break;
        default: break;
    }
}

+ (void)alertInNoNetworkConnection:(UIViewController *)viewcontroller clickedOkButton:(void (^)(void))clickedOkButton {
    dispatch_async(dispatch_get_main_queue(), ^{
        [viewcontroller alertWithTitle:nil message:ALT_MSG_NO_INTERNET_CONNECTION clickedOkButton:clickedOkButton];
        [CustomLoaderManager hideLoader];
    });
}
- (void)alertWithMessage:(NSString *)message {
    [self alertWithTitle:nil message:message defaultButtonTitle:ALT_BTN_TITLE_OK defaultButtonHander:NULL cancelButtonTitle:nil cancelButtonHander:nil];
}
- (void)alertWithMessage:(NSString *)message clickedOkButton:(void (^)(void))clickedOkButton {
    [self alertWithTitle:nil
                 message:message
      defaultButtonTitle:ALT_BTN_TITLE_OK
     defaultButtonHander:clickedOkButton
       cancelButtonTitle:nil
      cancelButtonHander:nil];
}
- (void)alertWithTitle:(NSString *)title message:(NSString *)message clickedOkButton:(void (^)(void))clickedOkButton {
    [self alertWithTitle:title
                 message:message
      defaultButtonTitle:ALT_BTN_TITLE_OK
     defaultButtonHander:clickedOkButton
       cancelButtonTitle:nil
      cancelButtonHander:nil];
}

- (void)alertWithTitle:(nullable NSString *)alertTitle
               message:(nullable NSString *)message
    defaultButtonTitle:(nullable NSString *)defaultButtonTitle
   defaultButtonHander:(nullable void (^)(void))defaultButtonHander
     cancelButtonTitle:(nullable NSString *)cancelButtonTitle
    cancelButtonHander:(nullable void (^)(void))cancelButtonHander {
    __weak typeof(self) weakSelf = self;
    BOOL isMainTHread = [NSThread isMainThread];
    if (isMainTHread) {
        [weakSelf alertAlwaysInMainThreadWithTitle:alertTitle
                                           message:message
                                defaultButtonTitle:defaultButtonTitle
                               defaultButtonHander:defaultButtonHander
                                 cancelButtonTitle:cancelButtonTitle
                                cancelButtonHander:cancelButtonHander];
    } else {
        dispatch_async(dispatch_get_main_queue(), ^{
            [weakSelf alertAlwaysInMainThreadWithTitle:alertTitle
                                               message:message
                                    defaultButtonTitle:defaultButtonTitle
                                   defaultButtonHander:defaultButtonHander
                                     cancelButtonTitle:cancelButtonTitle
                                    cancelButtonHander:cancelButtonHander];
        });
    }
}
- (UIAlertController *)alertAlwaysInMainThreadWithTitle:(nullable NSString *)alertTitle
                                                message:(nullable NSString *)message
                                     defaultButtonTitle:(nullable NSString *)defaultButtonTitle
                                    defaultButtonHander:(nullable void (^)(void))defaultButtonHander
                                      cancelButtonTitle:(nullable NSString *)cancelButtonTitle
                                     cancelButtonHander:(nullable void (^)(void))cancelButtonHander {
    UIAlertController *alert = nil;
    if ([UIAlertController class]) {
            // use UIAlertController
        if (!message.length && !alertTitle.length)
            return nil;
        alert = [UIAlertController alertControllerWithTitle:alertTitle message:message preferredStyle:UIAlertControllerStyleAlert];
        if (defaultButtonTitle.length) {
            UIAlertAction *ok = [UIAlertAction actionWithTitle:defaultButtonTitle
                                                         style:(cancelButtonTitle.length == 0) ? UIAlertActionStyleCancel : UIAlertActionStyleDefault
                                                       handler:^(UIAlertAction *_Nonnull action) {
                                                           if (defaultButtonHander)
                                                               defaultButtonHander();
                                                       }];
            [alert addAction:ok];
        }
        if (cancelButtonTitle.length) {
            UIAlertAction *cancel = [UIAlertAction actionWithTitle:cancelButtonTitle
                                                             style:UIAlertActionStyleCancel
                                                           handler:^(UIAlertAction *_Nonnull action) {
                                                               if (cancelButtonHander)
                                                                   cancelButtonHander();
                                                           }];
            [alert addAction:cancel];
        }
        [self presentViewController:alert animated:YES completion:nil];
    }
    return alert;
}
- (void)alertWithTitle:(NSString *)title
               message:(NSString *)message
    defaultButtonTitle:(NSString *)defaultButtonTitle
       clickedOkButton:(void (^)(void))clickedOkButton {
    [self alertAlwaysInMainThreadWithTitle:nil
                                   message:message
                        defaultButtonTitle:defaultButtonTitle
                       defaultButtonHander:clickedOkButton
                         cancelButtonTitle:nil
                        cancelButtonHander:nil];
}

@end
