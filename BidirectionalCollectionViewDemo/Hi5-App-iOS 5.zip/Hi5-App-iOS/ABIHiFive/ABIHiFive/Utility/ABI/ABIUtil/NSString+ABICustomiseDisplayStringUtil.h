    //
    //  NSString+ABICustomiseDisplayString.h
    //  ABIHiFive
    //
    //  Created by Prsenjit Goswami on 15/06/16.
    //  Copyright © 2016 Cognizant. All rights reserved.
    //

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>

@class ABISFIncentiveDataModel;

@interface NSString (ABICustomiseDisplayString)
+ (NSString *)nameAndSurnameOfRoster:(NSString *)rosterName;
+ (NSString *)colorNameForIncentiveInPercentage:(CGFloat)multiplier;
+ (NSString *)incentivePerformanceStatusStringWRTPoints:(NSNumber *)point;
+ (NSMutableAttributedString *)descriptionTextName:(NSString *)colorName totalKPIs:(NSInteger)kpis subKpis:(NSInteger)subKPISNumber;
+ (NSString *)displayTextForTotalDMsCountInProfileMyDMsVC:(NSInteger)myDMsCount;
+ (NSString *)displayTextForBadgsCountInMyDMsCell:(NSInteger)badegsCount;
+ (NSString *)displayTextForTotalDMsInMyDMsCell:(NSInteger)totalDMsCount;

+ (NSMutableString *)formatedString:(NSString *)aString forCount:(NSInteger)count;
@end

@interface NSAttributedString (ABICustomiseDisplayString)
+ (NSAttributedString *)decoratedDMsScoreTextWithScore:(NSString *)score incentive:(ABISFIncentiveDataModel *)incentive;
+ (NSAttributedString *)decoratedAssignedDMsCountTextWithDMCount:(NSString *)dmCount;
+ (NSAttributedString *)decoratedRankStringWithRankValueString:(NSString *)rankValueInString staticRankText:(NSString *)staticRankText;
+ (NSAttributedString *)decoratedRankStringWithRankValueNumber:(NSNumber *)rankValueInNumber staticRankText:(NSString *)staticRankText;

@end
