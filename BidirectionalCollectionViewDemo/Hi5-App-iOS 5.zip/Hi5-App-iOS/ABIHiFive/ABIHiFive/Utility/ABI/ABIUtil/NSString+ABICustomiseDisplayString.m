    //
    //  NSString+ABICustomiseDisplayString.m
    //  ABIHiFive
    //
    //  Created by Prsenjit Goswami on 15/06/16.
    //  Copyright © 2016 Cognizant. All rights reserved.
    //

#import "ABISFIncentiveDataModel.h"
#import "Constants.h"
#import "NSString+ABICustomiseDisplayString.h"
#import "NSString+HelperUtil.h"
#import "UIColor+ABIColor.m"
#import "UIFont+ABIFont.h"

@implementation NSString (ABICustomiseDisplayString)

+ (NSMutableAttributedString *)descriptionTextName:(NSString *)colorName totalKPIs:(NSInteger)kpis subKpis:(NSInteger)subKPISNumber {

        //#define STATIC_TEXT_KPIs_TEXT @"%ld KPIs"
        //#define STATIC_TEXT_KPIs_IN_TEXT @"%ld KPIs in %@"
    UIColor *color = [UIColor colorForIncentiveProgress:colorName];
    NSString *str1 = STATIC_TEXT_OUT_OF_TEXT;
    NSString *str2 = [NSString formatedString:@"KPI" forCount:(long)kpis]; //[NSString stringWithFormat:@"%ld KPIs", (long)kpis];
    NSString *str3 = STATIC_TEXT_YOU_HAVE_TEXT;
    NSString *strTotalKPIs = [NSString formatedString:@"KPI" forCount:(long)subKPISNumber];
    NSString *str4 = [NSString stringWithFormat:@"%@ in %@", strTotalKPIs, [colorName lowercaseString]];
    NSString *statusDescription = [NSString stringWithFormat:@"%@ %@ %@ %@", str1, str2, str3, str4];
        // Create mutable string from original one
    NSMutableAttributedString *attString = [[NSMutableAttributedString alloc] initWithString:statusDescription];
    NSDictionary *attrs =
    @{NSForegroundColorAttributeName : [UIColor defaultTextLightColor], NSFontAttributeName : [UIFont fontHelvetica57Condensed:12.0f]};
    NSRange range = [statusDescription rangeOfString:str1];
    [attString addAttributes:attrs range:range];
    attrs = @{NSForegroundColorAttributeName : [UIColor blackColor], NSFontAttributeName : [UIFont fontHelvetica67Condensed:12.0f]};
    range = [statusDescription rangeOfString:str2];
    [attString addAttributes:attrs range:range];
    attrs = @{NSForegroundColorAttributeName : [UIColor defaultTextLightColor], NSFontAttributeName : [UIFont fontHelvetica57Condensed:12.0f]};
    range = [statusDescription rangeOfString:str3];
    [attString addAttributes:attrs range:range];
    attrs = @{NSForegroundColorAttributeName : color, NSFontAttributeName : [UIFont fontHelvetica67Condensed:12.0f]};
    range = [statusDescription rangeOfString:str4];
    [attString addAttributes:attrs range:range];
        // Add it to the label - notice its not text property but it's attributeText
    return attString;
}

+ (NSString *)displayTextForTotalDMsCountInProfileMyDMsVC:(NSInteger)myDMsCount {
    NSString *displayText = nil;
    { displayText = [NSString stringWithFormat:@"Total DMs: %ld", (long)myDMsCount]; }
    return displayText;
}
+ (NSString *)displayTextForBadgsCountInMyDMsCell:(NSInteger)badegsCount {
    NSString *displayText = nil;
    { displayText = [NSString stringWithFormat:@"%ld %@", (long)badegsCount, badegsCount > 1 ? @"Badges" : @"Badge"]; }
    return displayText;
}
+ (NSString *)displayTextForTotalDMsInMyDMsCell:(NSInteger)totalDMsCount {
    NSString *displayText = nil;
    { displayText = [NSString stringWithFormat:@"Total DMs: %ld", (long)totalDMsCount]; }
    return displayText;
}
@end
#pragma mark -  NSAttributedString

@implementation NSAttributedString (ABICustomiseDisplayString)

+ (NSAttributedString *)decoratedDMsScoreTextWithScore:(NSString *)score incentive:(ABISFIncentiveDataModel *)incentive {

    NSString *dmsScoreLabelText;
    /*
     As Discussed,
     - When ProgressColor of Incentive is yellow and red, It consider as 'Least DM Score:<#score>'
     - When ProgressColor of Incentive is Green, It consider as 'Best DM Score:<#score>'

     - When IncentivePoint is available in 'IncentivePoint' table. It shows as
     'Least DM Score:0 Points'
     'Least DM Score:1 Points'
     'Least DM Score:10 Points'

     'Best DM Score:0 Points'
     'Best DM Score:1 Points'
     'Best DM Score:10 Points'

     - When IncentivePoint is not available in 'IncentivePoint' table. It shows as
     'Least DM Score:--'
     'Best DM Score:--'

     */
    if ([incentive.progressStatusColorName isEqualToString:@"yellow"] || [incentive.progressStatusColorName isEqualToString:@"red"]) {
        dmsScoreLabelText = STATIC_TEXT_LEAST_DM_SCORE;
    } else {
        dmsScoreLabelText = STATIC_TEXT_BEST_DM_SCORE;
    }
    NSString *srtDmsScore = nil;
    if ([NSString isNULLString:score]) {
        score = @"--";
        srtDmsScore = [NSString stringWithFormat:@"%@%@", dmsScoreLabelText, score];
    }
        //    else if ([strScore integerValue] == 0) {
        //		srtDmsScore = [NSString stringWithFormat:@"%@--", dmsScoreLabelText];
        //	}
    else {
        score = [NSString stringWithFormat:@"%@ Points", score];

        srtDmsScore = [NSString stringWithFormat:@"%@%@", dmsScoreLabelText, score];
    }
    if ([NSString isNULLString:srtDmsScore])
        return nil;

    NSMutableAttributedString *attString = [[NSMutableAttributedString alloc] initWithString:srtDmsScore];
    NSDictionary *attrs1 =
    @{NSForegroundColorAttributeName : [UIColor defaultTextLightColor], NSFontAttributeName : [UIFont fontHelvetica67Condensed:12.0f]};
    NSDictionary *attrs2 =
    @{NSForegroundColorAttributeName : [UIColor defaultTextDarkColor], NSFontAttributeName : [UIFont fontHelvetica67Condensed:12.0f]};
    NSRange range1 = [srtDmsScore rangeOfString:dmsScoreLabelText];
    NSRange range2 = [srtDmsScore rangeOfString:score];

    if (range1.length)
        [attString addAttributes:attrs1 range:range1];
    if (range2.length)
        [attString addAttributes:attrs2 range:range2];

        //    if (![NSString isNULLString:score]) {
        //        attrs1 = @{NSForegroundColorAttributeName : [UIColor defaultTextLightColor], NSFontAttributeName : [UIFont
        //        fontHelvetica67Condensed:12.0f]};
        //        NSDictionary *attrs2 =
        //        @{NSForegroundColorAttributeName : [UIColor defaultTextDarkColor], NSFontAttributeName : [UIFont fontHelvetica67Condensed:12.0f]};
        //        range1 = [srtDmsScore rangeOfString:dmsScoreLabelText];
        //        range2 = [srtDmsScore rangeOfString:score];
        //
        //        if (range1.length)
        //            [attString addAttributes:attrs1 range:range1];
        //
        //        if (range2.length)
        //            [attString addAttributes:attrs2 range:range2];
        //    }

    return attString.length ? attString : nil;
}

+ (NSAttributedString *)decoratedAssignedDMsCountTextWithDMCount:(NSString *)dmCount {

    NSString *strDmsAssigned = STATIC_TEXT_DMS_ASSIGNED;
    NSString *strDmnumber = [NSString stringWithFormat:@"%@", dmCount];
    NSString *srtNumberOfDms = [NSString stringWithFormat:@"%@%@", strDmsAssigned, strDmsAssigned];
    if ([NSString isNULLString:srtNumberOfDms]) {
        srtNumberOfDms = [NSString stringWithFormat:@"%@", strDmsAssigned];
    } else {
        srtNumberOfDms = [NSString stringWithFormat:@"%@%@", strDmsAssigned, strDmnumber];
    }
    if ([NSString isNULLString:srtNumberOfDms])
        return nil;
    NSMutableAttributedString *attString = [[NSMutableAttributedString alloc] initWithString:srtNumberOfDms];
    NSDictionary *attrs1 =
    @{NSForegroundColorAttributeName : [UIColor defaultTextLightColor], NSFontAttributeName : [UIFont fontHelvetica67Condensed:12.0f]};
    NSDictionary *attrs2 =
    @{NSForegroundColorAttributeName : [UIColor defaultTextDarkColor], NSFontAttributeName : [UIFont fontHelvetica67Condensed:12.0f]};
    NSRange range1 = [srtNumberOfDms rangeOfString:strDmsAssigned];
    NSRange range2 = [srtNumberOfDms rangeOfString:strDmnumber];
    if (range1.length)
        [attString addAttributes:attrs1 range:range1];
    if (range2.length)
        [attString addAttributes:attrs2 range:range2];
    if (![NSString isNULLString:strDmnumber]) {
        attrs1 = @{NSForegroundColorAttributeName : [UIColor defaultTextLightColor], NSFontAttributeName : [UIFont fontHelvetica67Condensed:12.0f]};
        NSDictionary *attrs2 =
        @{NSForegroundColorAttributeName : [UIColor defaultTextDarkColor], NSFontAttributeName : [UIFont fontHelvetica67Condensed:12.0f]};
        range1 = [srtNumberOfDms rangeOfString:strDmnumber];
        if (range1.length)
            [attString addAttributes:attrs1 range:range1];
        if (range2.length)
            [attString addAttributes:attrs2 range:range2];
    }

    return attString.length ? attString : nil;
}

+ (NSAttributedString *)decoratedRankStringWithRankValueString:(NSString *)rankValueInString staticRankText:(NSString *)staticRankText {
    if ([NSString isNULLString:rankValueInString])
        return nil;
        // self.backgroundColor = [UIColor clearColor];
        // self.font = PROFILE_RANK_FONT_SIZE;
    NSString *combindString = [NSString stringWithFormat:@"%@%@", staticRankText, rankValueInString];
    NSMutableAttributedString *attString = [[NSMutableAttributedString alloc] initWithString:combindString];
    NSDictionary *attrs = @{NSForegroundColorAttributeName : [UIColor whiteColor], NSFontAttributeName : [UIFont fontHelvetica67Condensed:10.0f]};
    NSRange range = [combindString rangeOfString:staticRankText];
    if (range.length) {
        [attString addAttributes:attrs range:range];
        attrs = @{NSForegroundColorAttributeName : [UIColor whiteColor], NSFontAttributeName : [UIFont fontHelvetica67Condensed:10.0f]};
        if (![NSString isNULLString:rankValueInString]) {
            range = [combindString rangeOfString:rankValueInString];
            if (range.length) {
                [attString addAttributes:attrs range:range];
                return attString;
            }
        }
    }

    return nil;
}

+ (NSAttributedString *)decoratedRankStringWithRankValueNumber:(NSNumber *)rankValueInNumber staticRankText:(NSString *)staticRankText {
    if (!rankValueInNumber)
        return nil;
    NSString *rankValueString = [NSString stringWithFormat:@"%ld", (long)[rankValueInNumber integerValue]];
    return [self decoratedRankStringWithRankValueString:rankValueString staticRankText:staticRankText];
}
@end
