    //
    //  NSArray+ABISortedResults.m
    //  ABIHiFive
    //
    //  Created by Prsenjit Goswami on 17/06/16.
    //  Copyright © 2016 Cognizant. All rights reserved.
    //

#import "NSArray+ABISortedResults.h"
#import "NSMutableArray+HelperUtil.h"

@implementation NSArray (ABISortedResults)

@end

@implementation NSMutableArray (ABISortedResults)

- (void)abiSortedPeerCollectionResults {
        // Sort By point and Name
    if (self.count > 0) {
        [self sortForKey:@"rosterNameText" ascending:YES];
        [self sortForKey:@"incentivePointsInNumber" ascending:NO];
    }
}

- (void)abiSortedBadgesCollectionResults {
    if (self.count > 0) {
        [self sortForKey:@"priority" ascending:YES];
    }
}

- (void)abiSortedReporteePerformanceCollectionResults {
    if (self.count > 0) {
        [self sortForKey:@"nameOfDM" ascending:YES];
    }
}
- (void)abiSortedMyReporteeCollectionResults {
    if (self.count > 0) {
        [self sortForKey:@"rosterNameText" ascending:YES];
    }
}

- (void)abiSortedWeekWishIncentiveCollection {
    if (self.count > 0) {
        [self sortForKey:@"overAllIncentiveProgress" ascending:NO];
        [self sortForKey:@"incentiveWeek" ascending:NO];
    }
}

- (void)abiSortedIncentiveCollection {
    if (self.count > 0) {
        [self sortForKey:@"incentiveDisplayName" ascending:YES];
    }
}

@end
