    //
    //  NSString+ABIPageTitleString.h
    //  ABIHiFive
    //
    //  Created by Prsenjit Goswami on 15/06/16.
    //  Copyright © 2016 Cognizant. All rights reserved.
    //

#import <Foundation/Foundation.h>
@class ABISFPeerRankingDataModel, ABISFRosterDataModel, ABISFChatterContentDataModel;

@interface NSString (ABIPageTitleString)

+ (NSString *)profilePageTitle;

+ (NSString *)badgeDetailsPageTitle;

+ (NSString *)peerRankingPageTitle:(ABISFRosterDataModel *)roster pagerTabIndex:(NSInteger)pagerTabIndex;
+ (NSString *)peerKPIsPageTitle:(ABISFRosterDataModel *)roster isCurrentUser:(BOOL)isCurrentUser;

+ (NSString *)kpiDetailsPageTitle:(ABISFRosterDataModel *)roster;

+ (NSString *)announcementsPageTitle;

+ (NSString *)chatterPageTitle;

+ (NSString *)newChatterPageTitle;

+ (NSString *)chatterFileViewer:(ABISFChatterContentDataModel *)contentDataModel;

+ (NSString *)rosterAssingedIncentiveDetailsTableHeader:(ABISFRosterDataModel *)roster;
@end
