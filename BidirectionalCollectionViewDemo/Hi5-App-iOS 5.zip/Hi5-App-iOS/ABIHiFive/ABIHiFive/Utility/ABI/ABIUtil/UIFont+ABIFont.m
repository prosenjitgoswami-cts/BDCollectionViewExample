    //
    //  UIFont+ABIFont.m
    //  ABIHiFive
    //
    //  Created by Prsenjit Goswami on 15/06/16.
    //  Copyright © 2016 Cognizant. All rights reserved.
    //

#import "UIFont+ABIFont.h"

@implementation UIFont (ABIFont)
+ (UIFont *)defaultTextFontABI {
    return [UIFont fontWithName:@"HelveticaNeue-Thin" size:14.0f];
}
+ (UIFont *)fontHelvetica57Condensed:(CGFloat)size {
    return [UIFont fontWithName:@"HelveticaNeue-Condensed" size:size];
}
+ (UIFont *)fontHelvetica67Condensed:(CGFloat)size {
    return [UIFont fontWithName:@"HelveticaNeue-MediumCond" size:size];
}
@end
