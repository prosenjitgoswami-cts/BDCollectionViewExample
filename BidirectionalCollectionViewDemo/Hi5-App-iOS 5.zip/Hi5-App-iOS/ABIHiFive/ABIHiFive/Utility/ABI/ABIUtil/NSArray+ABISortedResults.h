    //
    //  NSArray+ABISortedResults.h
    //  ABIHiFive
    //
    //  Created by Prsenjit Goswami on 17/06/16.
    //  Copyright © 2016 Cognizant. All rights reserved.
    //

#import <Foundation/Foundation.h>

@interface NSArray (ABISortedResults)

@end

@interface NSMutableArray (ABISortedResults)
- (void)abiSortedPeerCollectionResults;
- (void)abiSortedBadgesCollectionResults;
- (void)abiSortedReporteePerformanceCollectionResults;
- (void)abiSortedMyReporteeCollectionResults;
- (void)abiSortedWeekWishIncentiveCollection;
- (void)abiSortedIncentiveCollection;
@end