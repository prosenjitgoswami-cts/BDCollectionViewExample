    //
    //  NSURL+ABIURL.h
    //  ABIHiFive
    //
    //  Created by Prsenjit Goswami on 17/06/16.
    //  Copyright © 2016 Cognizant. All rights reserved.
    //

#import <Foundation/Foundation.h>

@interface NSURL (ABIURL)

+ (NSString *)prepareBadgesImagesURLPathString:(NSString *)documentFolderName;
- (NSURL *)prepareABIImageURL;
+ (NSURL *)prepareSignedUserImageURL;

@end
