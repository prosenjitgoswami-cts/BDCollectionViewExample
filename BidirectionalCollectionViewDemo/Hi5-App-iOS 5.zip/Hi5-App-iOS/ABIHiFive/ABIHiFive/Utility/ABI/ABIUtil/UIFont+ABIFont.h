    //
    //  UIFont+ABIFontUtil.h
    //  ABIHiFive
    //
    //  Created by Prsenjit Goswami on 15/06/16.
    //  Copyright © 2016 Cognizant. All rights reserved.
    //

#import <UIKit/UIKit.h>

@interface UIFont (ABIFontUtil)
+ (UIFont *)defaultTextFontABI;
+ (UIFont *)fontHelvetica57Condensed:(CGFloat)size;
+ (UIFont *)fontHelvetica67Condensed:(CGFloat)size;
@end
