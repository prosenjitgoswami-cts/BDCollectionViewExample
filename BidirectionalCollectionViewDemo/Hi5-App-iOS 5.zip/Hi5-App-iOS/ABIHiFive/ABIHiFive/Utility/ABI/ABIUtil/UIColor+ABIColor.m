    //
    //  UIColor+ABIColor.m
    //  ABIHiFive
    //
    //  Created by Prsenjit Goswami on 15/06/16.
    //  Copyright © 2016 Cognizant. All rights reserved.
    //

#import "Constants.h"
#import "UIColor+ABIColor.h"

@implementation UIColor (ABIColor)
+ (UIColor *)colorWithHexString:(NSString *)hexString {
    if (hexString.length) {
        const char *cStr = [hexString cStringUsingEncoding:NSASCIIStringEncoding];
        long x = strtol(cStr + 1, NULL, 16);
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Wdeprecated-declarations"
        return [UIColor colorWithHex:x];
#pragma clang diagnostic pop
    }
    return nil;
}
    // takes 0x123456
+ (UIColor *)colorWithHex:(long)col {
    unsigned char r, g, b;
    b = col & 0xFF;
    g = (col >> 8) & 0xFF;
    r = (col >> 16) & 0xFF;
    return [UIColor colorWithRed:(float)r / 255.0f green:(float)g / 255.0f blue:(float)b / 255.0f alpha:1];
}
+ (UIColor *)defaultPageBGColor {
    return [UIColor colorWithRed:236.0f / 255.0f green:235.0 / 255.0f blue:235.0f / 255.0f alpha:1.0];
}
    // Final
+ (UIColor *)defaultSeparatorColor {
    return [UIColor colorWithRed:192.0f / 255.0f green:185.0 / 255.0f blue:169.0f / 255.0f alpha:1.0];
}
+ (UIColor *)peerRankingListTableSeperatorColor {
    return [UIColor colorWithHexString:HEX_COLOR_CODE_e5ebed_veryLightGrey];
}
+ (UIColor *)peerRankingTableSeparatorColor {
    return [UIColor colorWithRed:209.0f / 255.0f green:219.0 / 255.0f blue:223.0f / 255.0f alpha:1.0];
}
+ (UIColor *)incentiveExceededColor {
    return [UIColor colorWithHexString:HEX_COLOR_CODE_8dba00_GREEN];
}
+ (UIColor *)incentiveMinimumColor {
    return [UIColor colorWithHexString:HEX_COLOR_CODE_fdd519_YELLOW];
}
+ (UIColor *)incentiveVeryLessColor {
    return [UIColor colorWithHexString:HEX_COLOR_CODE_f25957_OFFRED];
}
+ (UIColor *)defaultABIBlueColor {
    return [UIColor blueColorABI];
}
+ (UIColor *)defaultTextDarkColor {
    return [UIColor darkGreyColorABI];
}
+ (UIColor *)defaultTextLightColor {
    return [UIColor colorWithHexString:HEX_COLOR_CODE_6c6c6c_MEDIUMGREY];
}
+ (UIColor *)defaultMauveColorABI {
    return [UIColor colorWithHexString:HEX_COLOR_CODE_C2CDFD_MAUVE];
}
+ (UIColor *)blueColorABI {
    return [UIColor colorWithHexString:HEX_COLOR_CODE_0e71b9_BLUE];
}
+ (UIColor *)cyanColorABI {
    return [UIColor colorWithHexString:HEX_COLOR_CODE_7ad2f7_SKY];
}
+ (UIColor *)whiteColorABI {
    return [UIColor colorWithHexString:HEX_COLOR_CODE_ffffff_WHITE];
}
+ (UIColor *)blackColorABI {
    return [UIColor colorWithHexString:HEX_COLOR_CODE_000000_BLACK];
}
+ (UIColor *)greenColorABI {
    return [UIColor colorWithHexString:HEX_COLOR_CODE_8dba00_GREEN];
}
+ (UIColor *)orangeColorABI {
    return [UIColor colorWithHexString:HEX_COLOR_CODE_fdd519_YELLOW];
}
+ (UIColor *)yellowColorABI {
    return [UIColor colorWithHexString:HEX_COLOR_CODE_fdd519_YELLOW];
}
+ (UIColor *)redColorABI {
    return [UIColor colorWithHexString:HEX_COLOR_CODE_f25957_OFFRED];
}
+ (UIColor *)darkGreyColorABI {
    return [UIColor colorWithHexString:HEX_COLOR_CODE_333333_DARK_GREY];
}
+ (UIColor *)lightGreyColorABI {
    return [UIColor colorWithHexString:HEX_COLOR_CODE_cccccc_LIGHTGREY];
}
+ (UIColor *)lightBlueColorABI {
    return [UIColor colorWithHexString:HEX_COLOR_CODE_2fbeef_LIGHTBLUE];
}
+ (UIColor *)veryLightGreySeperator {
    return [UIColor colorWithHexString:HEX_COLOR_CODE_ececec_veryLightGreySeperator];
}
+ (UIColor *)colorForIncentiveInPercentage:(CGFloat)multiplier {
    if (multiplier > kGREEN_COLOR_START_VALUE_IN_POINT) {
        return [UIColor incentiveExceededColor];
    } else if (multiplier > kRED_COLOR_START_VALUE_IN_POINT) {
        return [UIColor incentiveMinimumColor];
    } else {
        return [UIColor incentiveVeryLessColor];
    }
    return nil;
}
+ (UIColor *)colorForIncentiveProgress:(NSString *)colorName {
    colorName = [colorName uppercaseString];
    if ([colorName isEqualToString:kGREEN]) {
        return [UIColor incentiveExceededColor];
    } else if ([colorName isEqualToString:kYELLOW]) {
        return [UIColor incentiveMinimumColor];
    } else if ([colorName isEqualToString:kRED]) {
        return [UIColor incentiveVeryLessColor];
    } else
        return [UIColor clearColor];
}

@end
