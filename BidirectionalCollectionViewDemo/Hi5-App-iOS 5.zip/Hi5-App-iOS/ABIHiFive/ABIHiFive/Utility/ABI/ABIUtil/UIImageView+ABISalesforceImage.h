    //
    //  UIImageView+ABISalesforceImage.h
    //  ABIHiFive
    //
    //  Created by Prsenjit Goswami on 16/07/16.
    //  Copyright © 2016 Cognizant. All rights reserved.
    //

#import <UIKit/UIKit.h>

@interface UIImageView (ABISalesforceImage)

- (void)setABIImageWithURL:(id)imgeURL placeholderImage:(UIImage *)placeholderImage completion:(void (^)(UIImage *image))completion;

- (void)setABIBadgeImageWithURL:(id)imgeURL placeholderImage:(UIImage *)placeholderImage completion:(void (^)(UIImage *image))completion;

- (void)setABIUserImageWithURL:(id)imgeURL;
- (void)setABIUserImageWithURL:(id)imgeURL placeholderImage:(UIImage *)placeholderImage;
- (void)setABIUserImageWithURL:(id)imgeURL placeholderImage:(UIImage *)placeholderImage completion:(void (^)(UIImage *image))completion;
- (void)setABISignedInUserProfileImage;
- (void)setABISignedInUserProfileImageWithcompletion:(void (^)(UIImage *image))completion;

@end
