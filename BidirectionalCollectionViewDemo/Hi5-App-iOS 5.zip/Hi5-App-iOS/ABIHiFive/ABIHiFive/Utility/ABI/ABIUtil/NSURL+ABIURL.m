    //
    //  NSURL+ABIURL.m
    //  ABIHiFive
    //
    //  Created by Prsenjit Goswami on 17/06/16.
    //  Copyright © 2016 Cognizant. All rights reserved.
    //

#import "ABISFRosterDataModel+Additions.h"
#import "NSURL+ABIURL.h"
#import "SFIdentityData.h"
#import "SFUserAccountManager.h"

@implementation NSURL (ABIURL)

#pragma mark - ABI URL PREPARATION

+ (NSString *)prepareBadgesImagesURLPathString:(NSString *)documentFolderName {
    NSString *urlString = nil;
    if (documentFolderName) {
        NSString *orgId = [ABISFRosterDataModel currentRosterOrgId];
        if (![NSString isNULLString:orgId]) {
            urlString = [NSString
                         stringWithFormat:@"https://naz--DevNazHI5.cs44.content.force.com/servlet/servlet.ImageServer?id=%@&oid=%@", documentFolderName, orgId];
        }
    }
    return urlString;
}
- (NSURL *)prepareABIImageURL {

    NSURL *sfURL = [self toURL];

    NSString *builtImageUrlWithToken = [NSString
                                        stringWithFormat:@"%@?oauth_token=%@", [sfURL absoluteString], [SFUserAccountManager sharedInstance].currentUser.credentials.accessToken];
    NSURL *imageURL = [NSURL URLWithString:builtImageUrlWithToken];
    return imageURL;
}

+ (NSURL *)prepareSignedUserImageURL {
    SFIdentityData *idData = [ABISFRosterDataModel currentRosterInformation];
    NSURL *imageURL = idData.pictureUrl;
    return imageURL;
}

#pragma mark - Private Method
    //
    //- (NSURL *)prepareABIURL:(id)imgeURL {
    //
    //	NSURL *sfURL = [imgeURL toURL];
    //
    //	NSString *builtImageUrlWithToken = [NSString stringWithFormat:@"%@?oauth_token=%@", [sfURL absoluteString], [SFUserAccountManager
    //sharedInstance].currentUser.credentials.accessToken];
    //	NSURL *imageURL = [NSURL URLWithString:builtImageUrlWithToken];
    //	return imageURL;
    //}

@end
