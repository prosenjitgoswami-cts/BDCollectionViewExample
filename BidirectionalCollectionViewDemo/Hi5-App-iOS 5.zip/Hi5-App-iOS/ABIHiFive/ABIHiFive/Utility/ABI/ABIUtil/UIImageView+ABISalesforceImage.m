    //
    //  UIImageView+ABISalesforceImage.m
    //  ABIHiFive
    //
    //  Created by Prsenjit Goswami on 16/06/16.
    //  Copyright © 2016 Cognizant. All rights reserved.
    //

#import "ABIUtilHeader.h"
#import "HelperUtilHeader.h"
#import "NSString+HelperUtil.h"
#import "UIImage+HelperUtil.h"
#import "UIImageView+ABISalesforceImage.h"
#import "UIImageView+WebCache.h"

@implementation UIImageView (ABISalesforceImage)

#pragma mark - SF User Image
/**
 *  SF user image.
 *
 *  @param imgeURL          Image URl
 *  @param placeholderImage  placeholderImage is [UIImage imageABIDummyUser]
 */
- (void)setABIUserImageWithURL:(id)imgeURL {

    [self setABIUserImageWithURL:imgeURL placeholderImage:[UIImage imageABIDummyUser] completion:NULL];
}

/**
 *  SF user image.
 *
 *  @param imgeURL          Image URl
 *  @param placeholderImage placeholderImage if Nil then placeholderImage is [UIImage imageABIDummyUser]
 */
- (void)setABIUserImageWithURL:(id)imgeURL placeholderImage:(UIImage *)placeholderImage {

    [self setABIUserImageWithURL:imgeURL placeholderImage:placeholderImage completion:NULL];
}

/**
 *  SF user image.
 *
 *  @param imgeURL          Image URl
 *  @param placeholderImage placeholderImage if Nil then placeholderImage is [UIImage imageABIDummyUser]
 *  @param completion       Completion
 */
- (void)setABIUserImageWithURL:(id)imgeURL placeholderImage:(UIImage *)placeholderImage completion:(void (^)(UIImage *image))completion {

    [self setABIImageWithURL:imgeURL placeholderImage:placeholderImage ? placeholderImage : [UIImage imageABIDummyUser] completion:completion];
}

#pragma mark - Badge Details

- (void)setABIBadgeImageWithURL:(id)imgeURL placeholderImage:(UIImage *)placeholderImage completion:(void (^)(UIImage *image))completion {

    [self imageWithURL:[imgeURL toURL] placeholderImage:nil completion:completion];
}

#pragma mark - ABI Image
/**
 *  ABI image.
 *
 *  @param imgeURL          Image URl
 *  @param placeholderImage placeholderImage
 *  @param completion       Completion
 */
- (void)setABIImageWithURL:(id)imgeURL placeholderImage:(UIImage *)placeholderImage completion:(void (^)(UIImage *image))completion {

    NSURL *imageURL = [self prepareABIURL:imgeURL];

    [self imageWithURL:imageURL placeholderImage:placeholderImage completion:completion];
}

- (NSURL *)prepareABIURL:(id)imgeURL {

    NSURL *imageURL = [imgeURL toURL];
    imageURL = [imageURL prepareABIImageURL];
    return imageURL;
}

/*!
 *  Current User Profile Image
 *  PlaceholderImage is [UIImage imageABIDummyUser]
 */
- (void)setABISignedInUserProfileImage {

    [self setABISignedInUserProfileImageWithcompletion:NULL];
}
- (void)setABISignedInUserProfileImageWithcompletion:(void (^)(UIImage *image))completion {

    NSURL *imageURL = [NSURL prepareSignedUserImageURL];
    [self setABIUserImageWithURL:imageURL placeholderImage:[UIImage imageABIDummyUser] completion:NULL];
}

#pragma mark - Private Method

- (void)imageWithURL:(NSURL *)imageURL placeholderImage:(UIImage *)placeholderImage completion:(void (^)(UIImage *image))completion {

    dispatch_async(dispatch_get_main_queue(), ^{
        if (!imageURL) {
            if (placeholderImage)
                self.image = placeholderImage;
            if (completion)
                completion(nil);
        } else {
            [self sd_setImageWithPreviousCachedImageWithURL:imageURL
                                           placeholderImage:placeholderImage
                                                    options:0
                                                   progress:NULL
                                                  completed:^(UIImage *image, NSError *error, SDImageCacheType cacheType, NSURL *imageURL) {
                                                      if (completion)
                                                          completion(image);
                                                  }];
        }
    });
}

@end
