    //
    //  NSObject+ABIUtil.h
    //  ABIHiFive
    //
    //  Created by Prsenjit Goswami on 15/06/16.
    //  Copyright © 2016 Cognizant. All rights reserved.
    //

#import <Foundation/Foundation.h>

@interface NSObject (ABIUtil)

@end
@interface NSMutableArray (DropDownYear)
+ (NSArray *)yearsForEarnedBadges;
@end

@interface NSString (DropDownDisplayKey)
+ (NSString *)dropDownDisplayKeyIncentive;
@end