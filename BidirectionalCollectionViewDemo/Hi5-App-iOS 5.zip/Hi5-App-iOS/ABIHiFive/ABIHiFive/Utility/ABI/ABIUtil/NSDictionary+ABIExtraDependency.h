    //
    //  NSDictionary+ABIExtraDependencyDictionary.h
    //  ABIHiFive
    //
    //  Created by Prsenjit Goswami on 15/06/16.
    //  Copyright © 2016 Cognizant. All rights reserved.
    //

#import <Foundation/Foundation.h>
static NSString *const kExtraDepDictKeySkipFetchingKPIDetails = @"kExtraDepDictKeySkipFetchingKPIDetails";

@interface NSDictionary (ABIExtraDependencyDictionary)

+ (NSDictionary *)extraDDSkipFetchingKPIDetails;
- (BOOL)extraDependencySkipFetchingKPIDetails;

@end
