    //
    //  UIView+ABIUtil.m
    //  ABIHiFive
    //
    //  Created by Prsenjit Goswami on 15/06/16.
    //  Copyright © 2016 Cognizant. All rights reserved.
    //

#import "UIColor+ABIColor.h"
#import "UIFont+ABIFont.h"
#import "UIView+ABIUtil.h"
#import "UIView+HelperUtil.h"
@implementation UIView (ABIUtil)

+ (UIView *)noDataDisplayViewWithDescriptionText:(NSString *)descriptionText textFont:(UIFont *)textFont textColor:(UIColor *)textColor {

    UIView *containerView = [[UIView alloc] init];
    containerView.backgroundColor = [UIColor whiteColor];
    containerView.layer.cornerRadius = 5;
    containerView.layer.masksToBounds = YES;
    containerView.translatesAutoresizingMaskIntoConstraints = NO;

    UILabel *descriptionTextzLabel = [[UILabel alloc] init];
    descriptionTextzLabel.font = textFont ? textFont : [UIFont fontHelvetica57Condensed:18.0f];
    descriptionTextzLabel.text = descriptionText;
    descriptionTextzLabel.translatesAutoresizingMaskIntoConstraints = NO;
    descriptionTextzLabel.textAlignment = NSTextAlignmentCenter;
    [containerView addSubview:descriptionTextzLabel];
    descriptionTextzLabel.textColor = textColor ? textColor : [UIColor defaultTextLightColor];
    [containerView addConstraints:[NSLayoutConstraint constraintsWithVisualFormat:@"H:|-16-[descriptionTextzLabel]-16-|"
                                                                          options:0
                                                                          metrics:nil
                                                                            views:@{
                                                                                    @"descriptionTextzLabel" : descriptionTextzLabel
                                                                                    }]];
    [descriptionTextzLabel centerYToParent:containerView];
    return containerView;
}

@end
