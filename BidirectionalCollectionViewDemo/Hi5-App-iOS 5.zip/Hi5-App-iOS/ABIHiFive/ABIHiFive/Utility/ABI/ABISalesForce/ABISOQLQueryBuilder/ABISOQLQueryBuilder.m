    //
    //  ABISOQLQueryBuilder.m
    //  ABIHiFive
    //
    //  Created by Prsenjit Goswami on 21/06/16.
    //  Copyright © 2016 Cognizant. All rights reserved.
    //
#import "ABISOQLQueryBuilder.h"
#import "ABISFIncentiveDataModel.h"
#import "HelperUtilHeader.h"
#import "SalesForceConstants.h"

@implementation ABISOQLQueryBuilder

#pragma mark -  SOQL Query For to fetch Roster Information (Profile Page) Changed //done
/*!
 *   This SOQL is used to fetch the Roster information
 *
 NOTE: Used in Profile Page
 *
 *  @param rosterID        ROSTER ID
 *  @param extraDependency Pass extra information as required
 *  @param ascending       Sort Order (if 'YES' ascending)
 *  @param keys            Results sort By key
 *
 *  @return SOQL STRING
 */
    // getUserProfileQuery
+ (NSString *)soqlQueryForRosterProfileDetailsWithRosterID:(NSString *)rosterID
                                           extraDependency:(NSDictionary<NSString *, id> *)extraDependency
                                                 ascending:(BOOL)ascending
                                                sortByKeys:(NSArray<NSString *> *)keys {
    NSString *soqlQuery = nil;
    if (![NSString isNULLString:rosterID]) {

        soqlQuery = [NSString
                     stringWithFormat:@"Select Name,Roster_Hier_SD__c,Roster_Name__c, Roster_Display__c, Roster_Role__c, SLS_Regn_Cd__r.Name, "
                     "SLS_Regn_Cd__r.SLs_Regn_Nm__c, User_ID__r.Id, User_ID__r.Name, User_ID__r.SmallPhotoUrl, User_ID__r.FullPhotoUrl "
                     "From Incentive_Roster__c Where User_ID__r.Id = '%@'",
                     rosterID];
    }

    return soqlQuery;
}

#pragma mark -  SOQL Query to fetch Badge Earned (Profile Page/ Badge Details Page) //done
/**
 *    SOQL Query to fetch to Roster Badge Details For Roster

 *
 *  @param roster          Roster Details
 *  @param years           Specific years array
 *  @param extraDependency Pass extra information as required
 *  @param ascending       Sort Order (if 'YES' ascending)
 *  @param keys            Results sort By key
 *
 *  @return @return SOQL STRING
 */
+ (nullable NSString *)soqlQueryForRosterBadgeDetailsForRoster:(nonnull ABISFRosterDataModel *)roster
                                                      forYears:(nullable NSArray *)years
                                               extraDependency:(nullable NSDictionary *)extraDependency
                                                     ascending:(BOOL)ascending
                                                    sortByKeys:(nullable NSArray *)keys {
        // getUserBadgeDetailsQuery
    NSString *soqlQuery = nil;
    NSString *rosterID = roster.idName;

    if (![NSString isNULLString:rosterID]) {
        if (years && years.count) {
            soqlQuery = [NSString
                         stringWithFormat:
                         @"SELECT Id, Badge_Award_DT__c, Badge_Desc__c, Badge_NM__c, Badge_Priority__c, Doc_Folder_NM1__c, Roster_User_ID__r.Roster_Name__c "
                         @"FROM Badge_Earned__c WHERE Roster_User_ID__r.Name = '%@' AND "
                         @"CALENDAR_YEAR(Badge_Award_DT__c) IN %@ ORDER BY Badge_Award_DT__c DESC NULLS FIRST",
                         rosterID, [years description]];
        }
    }
    return soqlQuery;
}

#pragma mark -  SOQL Query to fetch Roster IncentiveDetails (Profile Page) //done
/*!
 *   This SOQL is used to fetch the Roster Incentive information
 *
 NOTE: Used in Profile Page
 *
 *  @param rosterID        ROSTER ID
 *  @param extraDependency Pass extra information as required
 *  @param ascending       Sort Order (if 'YES' ascending)
 *  @param keys            Results sort By key
 *
 *  @return SOQL STRING
 */
    // getUserIncentivesQuery
+ (NSString *)soqlQueryForRosterIncentiveDetailsWithRoster:(ABISFRosterDataModel *)roster
                                           extraDependency:(NSDictionary<NSString *, id> *)extraDependency
                                                 ascending:(BOOL)ascending
                                                sortByKeys:(NSArray<NSString *> *)keys {

    NSString *soqlQuery = nil;
    NSString *rosterID = roster.idName;

    if (![NSString isNULLString:rosterID]) {

        soqlQuery = [NSString
                     stringWithFormat:@"Select Id, INCNTV_POINTS__c, INCNTV_WEEK__c, INCNTV_ID__r.Name, INCNTV_ID__r.INCNTV_NM__c, INCNTV_ID__r.INCNTV_Start__c, "
                     @"INCNTV_ID__r.INCNTV_End__c, "
                     "Roster_User_ID__r.Name,Roster_User_ID__r.Roster_Hier_SD__c,Roster_User_ID__r.Roster_Name__c, "
                     "Roster_User_ID__r.Roster_Role__c, Roster_User_ID__r.User_ID__r.Id, "
                     "Roster_User_ID__r.User_ID__r.SmallPhotoUrl, Roster_User_ID__r.User_ID__r.FullPhotoUrl "
                     "From Incentive_Points__c "
                     "WHERE Roster_User_ID__r.Name = '%@' AND INCNTV_ID__r.INCNTV_Start__c <= TODAY AND INCNTV_ID__r.INCNTV_End__c >= TODAY "
                     "ORDER BY INCNTV_WEEK__c DESC NULLS LAST",
                     rosterID];
    }

    return soqlQuery;
}

#pragma mark -  SOQL Query to fetch All Reportees Incentive details (Profile Page)

/*!
 *   The SOQL needs to fetch all Reportee incentive details for  'Manager'. The informaion which fetched by this SOQL is shwon in profile page "Least
 DM Score / Max DM Score in 'My Incentive' tab as Manager login" (e.g.DM(as Reportee) of SD(as  Manager)).

 *   NOTE: ONLY MANAGER LOGIN THIS APPLICABLE
 *
 *  @param managerID       Manager ID
 *  @param reporteeRole    Repotee Role (not in use)
 *  @param extraDependency Pass extra information as required
 *  @param ascending       Sort Order (if 'YES' ascending)
 *  @param keys            Results sort By key
 *
 *  @return SOQL STRING
 */
+ (NSString *)soqlQueryForReporteesIncentiveDetailsForManager:(ABISFRosterDataModel *)manager
                                                 reporteeRole:(NSString *)reporteeRole
                                              extraDependency:(NSDictionary<NSString *, id> *)extraDependency
                                                    ascending:(BOOL)ascending
                                                   sortByKeys:(NSArray<NSString *> *)keys {

    NSString *soqlQuery = nil;
    NSString *managerID = manager.idName;

    if (![NSString isNULLString:managerID]) {
            // getReporteesIncentiveDetails Done

        soqlQuery = [NSString
                     stringWithFormat:
                     @"Select Id, Name, INCNTV_POINTS__c, INCNTV_WEEK__c, INCNTV_ID__r.INCNTV_NM__c, INCNTV_ID__r.INCNTV_Start__c, "
                     @"INCNTV_ID__r.INCNTV_End__c, "
                     "Roster_User_ID__r.Name, Roster_User_ID__r.Roster_Name__c, Roster_User_ID__r.Roster_Role__c, Roster_User_ID__r.User_ID__r.Id, "
                     "Roster_User_ID__r.User_ID__r.SmallPhotoUrl, Roster_User_ID__r.User_ID__r.FullPhotoUrl, Roster_User_ID__r.SLS_Regn_Cd__r.SLs_Regn_Nm__c "
                     "From Incentive_Points__c "
                     "WHERE %@ AND INCNTV_ID__r.INCNTV_Start__c <= TODAY AND INCNTV_ID__r.INCNTV_End__c >= TODAY "
                     "order by INCNTV_WEEK__c desc, INCNTV_POINTS__c  DESC NULLS LAST",
                     getHierSDWhereClause(managerID, true)];
            //    "WHERE Roster_User_ID__r.Roster_Hier_SD__c = '%@' AND INCNTV_ID__r.INCNTV_Start__c <= TODAY AND INCNTV_ID__r.INCNTV_End__c >= TODAY "
    }

    return soqlQuery;
}

#pragma mark -  SOQL Query For All Reportee Details (Profile Page as SD Login) //done

+ (NSString *)soqlQueryForAllReporteeDetailsForManagerWithRoster:(nonnull ABISFRosterDataModel *)roster
                                                    reporteeRole:(NSString *)reporteeRole
                                                 extraDependency:(NSDictionary<NSString *, id> *)extraDependency
                                                       ascending:(BOOL)ascending
                                                      sortByKeys:(NSArray<NSString *> *)keys {

        // OperationKey: ABIFetchOperationForAllReporteeDetails
    NSString *soql = nil;
    NSString *managerID = roster.idName;

    if (![NSString isNULLString:managerID]) {
            // getReporteesFor Done

        soql = [NSString
                stringWithFormat:@"Select Name, Roster_Hier_SD__c, Roster_Name__c, Roster_Role__c, Roster_Display__c, User_ID__r.Id, User_ID__r.Name, "
                "User_ID__r.SmallPhotoUrl, User_ID__r.FullPhotoUrl, SLS_Regn_Cd__r.SLs_Regn_Nm__c "
                "From Incentive_Roster__c "
                //                "Where Roster_Hier_SD__c = '%@' "
                "%@"
                "ORDER BY Roster_Display__c ASC NULLS LAST",
                getHierSDWhereClause(managerID, false)];
    }

    return soql;
}

#pragma mark -  SOQL Query to fetch KIP Detsils For Incentve (KPI Details Page) //done

+ (NSString *)soqlQueryForIncentiveKIPsDetailsForIncentive:(nonnull ABISFIncentiveDataModel *)incentive
                                                    roster:(nonnull ABISFRosterDataModel *)roster
                                           extraDependency:(nullable NSDictionary<NSString *, id> *)extraDependency
                                                 ascending:(BOOL)ascending
                                                sortByKeys:(nullable NSArray<NSString *> *)keys {

        // getKPIDetailsForIncentive
    NSString *soqlQuery = nil;
    NSString *incentiveName = incentive.incentiveName;
    NSString *incentiveWeek = incentive.incentiveWeek;
    NSString *rosterID = roster.idName;

    if (![NSString isNULLString:incentiveName] && ![NSString isNULLString:rosterID] && ![NSString isNULLString:incentiveWeek]) {
        soqlQuery = [NSString
                     stringWithFormat:
                     @"Select INCNTV_Status__c, INCNTV_Target__c, INCNTV_Value__c, INCNTV_Value_Disp__c, Incentive_KPI_ID__r.INCNTV_KPI_Channel_NM__c, "
                     "Incentive_KPI_ID__r.INCNTV_KPI_KPI_NM__c, Incentive_KPI_ID__r.INCNTV_KPI_Weight__c, INCNTV_ID__r.INCNTV_NM__c "
                     "From Incentive_Data__c "
                     "Where INCNTV_ID__r.Name = '%@' and Roster_User_ID__r.Name = '%@' and INCNTV_WEEK__r.Name='%@'",
                     incentiveName, rosterID, incentiveWeek];
    }

    return soqlQuery;
}

#pragma mark -  SOQL Query All Peer Details (Peer Ranking List Page) //done
/*!
 *  SOQL query string for for users details as same current 'Roster Role'
 *
 *  @return  SOQL query string
 */
    // getPeerIncentiveQuery
+ (NSString *)soqlQueryForAllPeerDetailsForRoster:(ABISFRosterDataModel *)roster
                                        incentive:(nonnull ABISFIncentiveDataModel *)incentive
                                  extraDependency:(NSDictionary<NSString *, id> *)extraDependency
                                        ascending:(BOOL)ascending
                                       sortByKeys:(NSArray<NSString *> *)keys {
    NSString *soqlQuery = nil;

    NSString *incentiveDisplayName = incentive.incentiveDisplayName;
    NSString *incentiveWeek = incentive.incentiveWeek;
    NSString *role = roster.roleInString;

    if (![NSString isNULLString:role] && ![NSString isNULLString:incentiveDisplayName] && ![NSString isNULLString:incentiveWeek]) {

        soqlQuery = [NSString
                     stringWithFormat:
                     @"Select Id, INCNTV_POINTS__c, INCNTV_WEEK__c, INCNTV_ID__r.Name, INCNTV_ID__r.INCNTV_NM__c, INCNTV_ID__r.INCNTV_Start__c, "
                     @"INCNTV_ID__r.INCNTV_End__c, "
                     "Roster_User_ID__r.Name, Roster_User_ID__r.Roster_Name__c, Roster_User_ID__r.Roster_Role__c, Roster_User_ID__r.User_ID__r.Id, "
                     "Roster_User_ID__r.User_ID__r.SmallPhotoUrl, Roster_User_ID__r.User_ID__r.FullPhotoUrl, Roster_User_ID__r.SLS_Regn_Cd__r.SLs_Regn_Nm__c "
                     "From Incentive_Points__c "
                     "WHERE INCNTV_ID__r.INCNTV_NM__c = '%@' AND Roster_User_ID__r.Roster_Role__c = '%@' "
                     "AND INCNTV_ID__r.INCNTV_Start__c <= TODAY AND INCNTV_ID__r.INCNTV_End__c >= TODAY AND INCNTV_WEEK__c='%@'"
                     "ORDER BY INCNTV_WEEK__c desc, INCNTV_POINTS__c desc NULLS LAST",
                     incentiveDisplayName, role, incentiveWeek];
    }

    return soqlQuery;
}

#pragma mark -  SOQL Query AnnouncementsDetails (Profile Page /Announcements Details Page) //done
/*!
 *  SOQL query string for announcementsDetails
 *
 *  @return AnnouncementsDetails query string
 */
    // getAnnouncementsQuery
+ (NSString *)soqlQueryForAnnouncementsDetailsWithExtraDependency:(NSDictionary *)extraDependency
                                                        ascending:(BOOL)ascending
                                                       sortByKeys:(NSArray *)keys {

    NSString *soqlQuery = @"Select Id, Announcement_Body__c, Announcement_SUBJ__c, Announcement_URL__c, Announcement_Start__c, "
    "Announcement_End__c, LastModifiedDate, LastReferencedDate, Announcement_NM__c "
    "From Announcement__c WHERE Announcement_End__c >= TODAY ORDER BY LastModifiedDate desc limit 3";

    return soqlQuery;
}

#pragma mark - KPIDetailsForReportees KPI Details (KPI Details Page)
/**
 *  SOQL To fetch the KIP detail of All Reportee For Manager
 *
 *  @param manager         Manager Referance
 *  @param incentive       Specific Incentive Referance
 *  @param extraDependency Pass Extra Info if required
 *  @param ascending       Soet Order
 *  @param keys            Sorted Key
 *
 *  @return SOQL
 */
+ (nullable NSString *)soqlQueryForAllReporteeKPIsWiseInccntivePerformanceDetailsForManager:(nonnull ABISFRosterDataModel *)manager
                                                                                  incentive:(nonnull ABISFIncentiveDataModel *)incentive
                                                                            extraDependency:(nullable NSDictionary<NSString *, id> *)extraDependency
                                                                                  ascending:(BOOL)ascending
                                                                                 sortByKeys:(nullable NSArray<NSString *> *)keys {

    NSString *soqlQuery = nil;

    NSString *incentiveName = incentive.incentiveName;
    NSString *incentiveWeek = incentive.incentiveWeek;
    NSString *roster_Hier_SD = manager.idName;

    if (![NSString isNULLString:roster_Hier_SD] && ![NSString isNULLString:incentiveName] && ![NSString isNULLString:incentiveWeek]) {
            // getKPIDetailsForReportees
        soqlQuery = [NSString
                     stringWithFormat:@"Select id, Name, INCNTV_Status__c, INCNTV_Target__c, INCNTV_Value__c, INCNTV_Value_Disp__c, "
                     "Incentive_KPI_ID__r.INCNTV_KPI_Channel_NM__c, Incentive_KPI_ID__r.INCNTV_KPI_KPI_NM__c, INCNTV_ID__r.INCNTV_NM__c, "
                     "Roster_User_ID__r.Roster_Name__c "
                     "From Incentive_Data__c "
                     //                     "Where INCNTV_ID__r.Name= '%@' AND Roster_User_ID__r.Roster_Hier_SD__c = '%@' and
                     //                     INCNTV_WEEK__r.Name='%@'",
                     //                     incentiveName, roster_Hier_SD, incentiveWeek];
                     "Where INCNTV_ID__r.Name= '%@' AND %@ and INCNTV_WEEK__r.Name='%@'",
                     incentiveName, getHierSDWhereClause(roster_Hier_SD, YES), incentiveWeek];
    }

    return soqlQuery;
}

NSString *getHierSDWhereClause(NSString *managerId, BOOL isParentRelationship) {

    NSString *condition = @"";

    if (isParentRelationship) {
        condition = [NSString stringWithFormat:@"Roster_User_ID__r.Roster_Hier_SD__c = '%@' AND Roster_User_ID__r.Name != '%@'", managerId, managerId];
    } else {
        condition = [NSString stringWithFormat:@"WHERE Roster_Hier_SD__c = '%@' AND Name != '%@'", managerId, managerId];
    }

    return condition;
}

@end
