    //
    //  ABISFRestRequestManager.m
    //  ABIHiFive
    //
    //  Created by Prsenjit Goswami on 12/08/16.
    //  Copyright © 2016 Cognizant. All rights reserved.
    //
#import "ABISFRestRequestManager.h"
#import "ABISFChatterContentDataModel.h"
@implementation ABISFRestRequestManager
#pragma mark - Request For SOQL Query
/*!
 *  Request For SOQL Query
 *
 *  @param query           soqlQuery String
 *  @param completionBlock SFRestRequest response
 */
+ (void)requestForSOQLQueryUpdated:(NSString *)query
                   extraDependency:(NSDictionary *)extraDependency
                       failedBlock:(ABIFailedBlock)failedBlock
                   completionBlock:(ABIResponseBlock)completionBlock {
    if ([NSString isNULLString:query]) {
        if (failedBlock)
            failedBlock([NSError errorNilSOQLQurery], nil);
        return;
    }
    SFRestRequest *request = [[SFRestAPI sharedInstance] requestForQuery:query];
    [ABISFRestRequestManager sendRequest:request
                             failedBlock:^(NSError *error, NSDictionary *extraInfo) {
                                 if (failedBlock)
                                     failedBlock(error, nil);
                             }
                            successBlock:^(id result, NSDictionary *extraInfo) {
                                if (completionBlock)
                                    completionBlock(result, nil);
                            }];
}

#pragma mark - REST REQUEST
#pragma mark -
+ (SFRestRequest *)requestWithMethod:(SFRestMethod)method
                                path:(NSString *)path
                         queryParams:(NSDictionary *)queryParams
                         failedBlock:(ABIFailedBlock)failedBlock
                        successBlock:(ABIResponseBlock)successBlock {
    if (!path.length) {
        dispatch_main_async_safeBlock(^{
            if (failedBlock)
                failedBlock(nil, nil);
        });
        return nil;
    }
    SFRestRequest *request = [SFRestRequest requestWithMethod:method path:path queryParams:queryParams];
    [ABISFRestRequestManager sendRequest:request failedBlock:failedBlock successBlock:successBlock];
    return request;
}
+ (void)sendRequest:(SFRestRequest *)request failedBlock:(ABIFailedBlock)failedBlock successBlock:(ABIResponseBlock)successBlock {
    [[SFRestAPI sharedInstance] sendRESTRequest:request
                                      failBlock:^(NSError *_Nullable e) {
                                          dispatch_main_async_safeBlock(^{
                                              if (failedBlock)
                                                  failedBlock(e, nil);
                                          });
                                      }
                                  completeBlock:^(NSDictionary *_Nullable dict) {
                                          // Return In main block
                                      dispatch_main_async_safeBlock(^{
                                          if (successBlock) {
                                              successBlock(dict, nil);
                                          }
                                      });
                                  }];
}
#pragma mark - REST REQUEST FOR FILE UPLOAD
+ (SFRestRequest *)requestForFileContentsWithABISFChatterContentDataModel:(ABISFChatterContentDataModel *)contentDataModel
                                                               completion:(void (^)(NSString *filePath, BOOL isNewFile))completion {
        //---------------  ---------------------------
    /*!
     *  Return Block
     *
     *  @param filePath    Path of Saved file
     *
     */
    void (^callBackInMainThread)(NSString *filePath, BOOL isNewImage) = ^(NSString *filePath, BOOL isNewImage) {
        if (completion)
            completion(filePath, isNewImage);
    };
        //------------------------------------------------------------
    SFRestRequest *restRequest = nil;
    NSString *sfdcId = contentDataModel.ID;
    NSString *version = contentDataModel.versionId;
    NSString *fileExtension = contentDataModel.fileExtension;
    NSString *fileName = [NSString stringWithFormat:@"%@-%@.%@", sfdcId, version, fileExtension];
    NSString *fileFullPath = [NSFileManager getFilePathIfExistsAtDocumentsDirectory:fileName];

    if (![NSString isNULLString:sfdcId] && ![NSString isNULLString:version] && ![NSString isNULLString:fileExtension] &&
        ![NSString isNULLString:fileFullPath]) {
        if (callBackInMainThread)
            callBackInMainThread(fileFullPath, NO);
    } else {
        restRequest = [[SFRestAPI sharedInstance] requestForFileContents:sfdcId version:nil];
        [ABISFRestRequestManager sendRequest:restRequest
                                 failedBlock:^(NSError *error, NSDictionary *extraInfo) {
                                     if (callBackInMainThread)
                                         callBackInMainThread(nil, NO);
                                 }
                                successBlock:^(id response, NSDictionary *extraInfo) {
                                    [NSData saveFileContainData:response
                                                       fileName:fileName
                                                     completion:^(NSString *_Nullable filePath) {
                                                         if (callBackInMainThread)
                                                             callBackInMainThread(filePath, YES);
                                                     }];
                                }];
    }
    return restRequest;
}
@end
