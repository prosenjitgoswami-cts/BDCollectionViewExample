    //
    //  ABISFRestRequestManager.h
    //  ABIHiFive
    //
    //  Created by Prsenjit Goswami on 12/08/16.
    //  Copyright © 2016 Cognizant. All rights reserved.
    //
#import "ABISFDataModelBinder.h"
#import "ABISOQLQueryBuilder.h"
#import "Constants.h"
#import "SFRestAPI+Blocks.h"
#import "SFRestAPI+Files.h"
#import "SFRestAPI.h"
#import "SFRestRequest.h"
#import <Foundation/Foundation.h>
@class ABISFChatterContentDataModel;
@interface ABISFRestRequestManager : NSObject
+ (void)requestForSOQLQueryUpdated:(NSString *)query
                   extraDependency:(NSDictionary *)extraDependency
                       failedBlock:(ABIFailedBlock)failedBlock
                   completionBlock:(ABIResponseBlock)completionBlock;
+ (SFRestRequest *)requestWithMethod:(SFRestMethod)method
                                path:(NSString *)path
                         queryParams:(NSDictionary *)queryParams
                         failedBlock:(ABIFailedBlock)failedBlock
                        successBlock:(ABIResponseBlock)successBlock;
+ (void)sendRequest:(SFRestRequest *)request failedBlock:(ABIFailedBlock)failedBlock successBlock:(ABIResponseBlock)successBlock;
#pragma mark - REST REQUEST FOR FILE UPLOAD
+ (SFRestRequest *)requestForFileContentsWithABISFChatterContentDataModel:(ABISFChatterContentDataModel *)contentDataModel
                                                               completion:(void (^)(NSString *filePath, BOOL isNewFile))completion;
@end
