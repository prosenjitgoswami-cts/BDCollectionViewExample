    //
    //  ABISFLogInManager.h
    //  ABIHiFive
    //
    //  Created by Prsenjit Goswami on 10/08/16.
    //  Copyright © 2016 Cognizant. All rights reserved.
    //
#import <Foundation/Foundation.h>
@interface ABISFLogInManager : NSObject
+ (ABISFLogInManager *)shareInstance;
- (void)initialishedSalesForce;
@end
