    //
    //  ABISFRestJSONParamsBuilder.m
    //  ABIHiFive
    //
    //  Created by Prsenjit Goswami on 08/08/16.
    //  Copyright © 2016 Cognizant. All rights reserved.
    //
#import "ABISFRestJSONParamsBuilder.h"
#import "ABISFChatterMentionDataModel.h"
#import "Constants.h"
@implementation ABISFRestJSONParamsBuilder

+ (NSDictionary *)queryParamsForPrivateMessageWithPostBody:(NSString *)postMessage recipientIds:(NSArray *)recipientIds {
    if ([NSString isNULLString:postMessage] || ![NSArray isValidArray:recipientIds])
        return nil;
    NSMutableDictionary *jsonBody = [NSMutableDictionary dictionary];
    [jsonBody setObject:postMessage forKey:@"body"];
    if (recipientIds.count)
        [jsonBody setObject:recipientIds forKey:@"recipients"];
    NSString *jsonString = [jsonBody jsonStringWithPrettyPrint:YES];
    NSDictionary *jsonObj =
    [NSJSONSerialization JSONObjectWithData:[jsonString dataUsingEncoding:NSUTF8StringEncoding] options:NSJSONReadingMutableContainers error:nil];
    return jsonObj;
}
#pragma mark - Feed Segment
+ (NSDictionary *)queryParamsForFeedWithMessageSegment:(NSArray *)messageSegments attachments:(NSArray *)attachments {
    NSMutableDictionary *jsonBody = [NSMutableDictionary dictionary];
    [jsonBody setObject:@"FeedItem" forKey:@"feedElementType"];
    [jsonBody setObject:@"me" forKey:@"subjectId"];
    if (attachments) {
        NSMutableDictionary *capabilitiesDict = [NSMutableDictionary dictionary];
        NSMutableDictionary *files = [NSMutableDictionary dictionary];
        [files setObject:attachments forKey:@"items"];
        [capabilitiesDict setObject:files forKey:@"files"];
        [jsonBody setObject:capabilitiesDict forKey:@"capabilities"];
    }
    if (messageSegments.count) {
        NSMutableDictionary *body = [NSMutableDictionary dictionary];
        [body setObject:messageSegments forKey:@"messageSegments"];
        [jsonBody setObject:body forKey:kBody];
    }
    NSString *jsonString = [jsonBody jsonStringWithPrettyPrint:YES];
    NSDictionary *jsonObj =
    [NSJSONSerialization JSONObjectWithData:[jsonString dataUsingEncoding:NSUTF8StringEncoding] options:NSJSONReadingMutableContainers error:nil];
    return jsonObj;
}
+ (NSArray *)getMessageSegments:(NSString *)aString selectedMentionedDetails:(NSArray *)selectedMentionedDetails {
    if ([NSString isNULLString:aString])
        return nil;
    NSMutableArray *mains = [NSMutableArray new];
    NSMutableArray *JsonBodyArray = [NSMutableArray new];
    if (!selectedMentionedDetails.count) {
        if (aString.length) {
            NSDictionary *textDict = [ABISFRestJSONParamsBuilder getTextDictionary:aString];
            if (textDict)
                [JsonBodyArray addObject:textDict];
            [mains addObject:aString];
        }
    } else {
        NSMutableArray *substrings = [NSMutableArray new];
        NSScanner *scanner = [NSScanner scannerWithString:aString];
        [scanner scanUpToString:@"@[" intoString:nil]; // Scan all characters before #
        NSInteger lengthOFString = aString.length;
        while (![scanner isAtEnd]) {
            NSString *substring = nil;
            [scanner scanString:@"@[" intoString:nil]; // Scan the # character
            if ([scanner scanUpToString:@"]" intoString:&substring]) {
                    //  [substrings addObject:substring];
                NSRange range = [substring rangeOfString:@"@[" options:NSBackwardsSearch];
                if ((range.location != NSNotFound && range.length && range.location > 0)) {
                        //                NSString *leftPart = [[substring substringToIndex:1] substringFromIndex:range.location];
                    NSString *leftPart = [substring substringWithRange:NSMakeRange(range.location, (substring.length - range.location))];
                    if (leftPart && ![substrings containsObject:leftPart]) {
                        leftPart = [leftPart stringByReplacingOccurrencesOfString:@"[" withString:@""];
                        leftPart = [leftPart stringByReplacingOccurrencesOfString:@"]" withString:@""];
                        leftPart = [leftPart stringByReplacingOccurrencesOfString:@"@" withString:@""];
                        [substrings addObject:leftPart];
                    }
                } else {
                    if (![substrings containsObject:substring])
                        [substrings addObject:substring];
                }
            }
            [scanner scanUpToString:@"@[" intoString:nil]; // Scan all characters before next #
        }
        NSString *tempString = aString;
        NSInteger lastLocation = 0;
        int index = 0;
        if (substrings.count) {
            for (NSString *mention in substrings) {
                NSRange range = [tempString rangeOfString:mention];
                if (!(range.location == NSNotFound)) {
                    if (range.location > lastLocation && range.location - 2 >= lastLocation) {
                        NSString *leftPart = [[tempString substringToIndex:range.location - 2] substringFromIndex:lastLocation];
                        if (![NSString isNULLString:leftPart]) {
                            NSDictionary *textDict = [ABISFRestJSONParamsBuilder getTextDictionary:leftPart];
                            if (textDict)
                                [JsonBodyArray addObject:textDict];
                        }
                    }
                    NSDictionary *mentiondict = [ABISFRestJSONParamsBuilder getMentionedDictionary:mention selectedMentionedDetails:selectedMentionedDetails];
                    if (mentiondict)
                        [JsonBodyArray addObject:mentiondict];
                    lastLocation = range.location + range.length + 1;
                    if (index == substrings.count - 1) {
                        if (lastLocation < lengthOFString - 1) {
                            NSRange rangeForRight = NSMakeRange(lastLocation, tempString.length - (lastLocation));
                            NSString *rightPart = [tempString substringWithRange:rangeForRight];
                            if (![NSString isNULLString:rightPart]) {
                                NSDictionary *textDict = [ABISFRestJSONParamsBuilder getTextDictionary:rightPart];
                                if (textDict)
                                    [JsonBodyArray addObject:textDict];
                            }
                        }
                    }
                    index += 1;
                }
            }
        } else if (aString.length) {
            NSDictionary *textDict = [ABISFRestJSONParamsBuilder getTextDictionary:aString];
            if (textDict)
                [JsonBodyArray addObject:textDict];
            [mains addObject:aString];
        }
    }
    return JsonBodyArray;
}
+ (NSDictionary *)getMentionedDictionary:(NSString *)name selectedMentionedDetails:(NSArray *)selectedMentionedDetails {
    if ([NSString isNULLString:name])
        return nil;
    name = [name stringByReplacingOccurrencesOfString:@"@" withString:@""];
    name = [name stringByReplacingOccurrencesOfString:@"[" withString:@""];
    name = [name stringByReplacingOccurrencesOfString:@"]" withString:@""];
    NSPredicate *predicate = [NSPredicate predicateWithFormat:@"self.name == %@", name];
    NSArray *results = [selectedMentionedDetails filteredArrayUsingPredicate:predicate];
    if (results.count) {
        ABISFChatterMentionDataModel *mentionDataModel = results[0];
        if (mentionDataModel) {
            NSString *ID = mentionDataModel.recordId;
            return @{ @"type" : @"Mention", @"id" : ID };
        }
    }
    return nil;
}
+ (NSDictionary *)getTextDictionary:(NSString *)text {
    if ([NSString isNULLString:text])
        return nil;
    return @{ @"type" : @"Text", @"text" : text };
}
@end
