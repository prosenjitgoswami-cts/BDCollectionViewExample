    //
    //  ABISFChatterPathBuilder.m
    //  ABIHiFive
    //
    //  Created by Prsenjit Goswami on 22/07/16.
    //  Copyright © 2016 Cognizant. All rights reserved.
    //
#import "ABISFChatterPathBuilder.h"
#import "SFRestAPI.h"
@implementation ABISFChatterPathBuilder

#pragma mark -  Public Method

#pragma mark -  Search Mentioned
+ (NSString *)chatterRestAPIPathALLMentionWithSearchWord:(NSString *)searchWord mentionSearchType:(MentionSearchType)mentionSearchType {
    NSString *restAPIPath = [ABISFChatterPathBuilder chatterRestAPIPath:RestAPIPathSearchMention];
    NSString *typeString = (mentionSearchType == MentionSearchTypeAll) ? @"All" : @"User";
    restAPIPath = [ABISFChatterPathBuilder chatterRestAPIPathWithBasePath:restAPIPath
                                                                queryWord:searchWord
                                                        restAPITypeString:typeString
                                                         pageSizeInNumber:@(ChatterPageSize100)];
    return restAPIPath;
}

#pragma mark -  Post Comment on A Feed
+ (NSString *)chatterRestAPIPathForComment:(NSString *)feedID commentText:(NSString *)commentText {
    NSString *basePath = [ABISFChatterPathBuilder chatterRestAPIPath:ChatterRestAPIPathPostFeedElement];
    NSString *path = [NSString stringWithFormat:@"%@/%@/capabilities/comments/items?text=%@", basePath, feedID, commentText];
    return path;
}

#pragma mark -  Private Method
+ (NSString *)chatterRestAPIPath:(ChatterRestAPIPathType)chatterRestAPIPathType {
    NSMutableString *sfChatterServicePath = [NSMutableString stringWithString:[ABISFChatterPathBuilder sfChatterServicePath]];
    switch (chatterRestAPIPathType) {
        case ChatterAllFeedElements:
            [sfChatterServicePath appendString:[NSString stringWithFormat:@"/feeds/news/me/feed-elements?recentCommentCount=%d&density=FewerUpdates",
                                                DefaultChatterCommentSize]];
            break;
        case ChatterMeFeedElements:
            [sfChatterServicePath
             appendString:[NSString stringWithFormat:@"/feeds/user-profile/me/feed-elements?recentCommentCount=%d&density=FewerUpdates",
                           DefaultChatterCommentSize]];
            break;
        case ChatterRestAPIPrivateMessage: [sfChatterServicePath appendString:@"/users/me/messages"]; break;
        case RestAPIPathSearchMention: [sfChatterServicePath appendString:@"/mentions/completions"]; break;
        case ChatterRestAPIPathPostFeedElement: [sfChatterServicePath appendString:@"/feed-elements"]; break;
        case ChatterRestAPISearchPathMessage: [sfChatterServicePath appendString:@"/users/me/messages"]; break;
        case ChatterRestAPIMe: [sfChatterServicePath appendString:@"/users/me"]; break;
        default: break;
    }
    return sfChatterServicePath;
}
+ (NSString *)apiVersion {
    return [[SFRestAPI sharedInstance] apiVersion];
}
+ (NSString *)sfChatterServicePath {
    NSString *sfServicePath = [NSString stringWithFormat:@"/services/data/%@/chatter", [ABISFChatterPathBuilder apiVersion]];
    return sfServicePath;
}
+ (NSString *)chatterRestAPIPathWithBasePath:(NSString *)basePath
                                   queryWord:(NSString *)queryWord
                           restAPITypeString:(NSString *)restAPITypeString
                            pageSizeInNumber:(NSNumber *)pageSizeInNumber {
    if ([NSString isNULLString:basePath])
        return nil;
    NSMutableString *restAPIPath = [NSMutableString string];
    [restAPIPath appendString:basePath];
    if (![NSString isNULLString:queryWord]) {
        [restAPIPath appendString:@"?q="];
        [restAPIPath appendString:queryWord];
    }
    if (![NSString isNULLString:restAPITypeString]) {
        [restAPIPath appendString:@"&type="];
        [restAPIPath appendString:[NSString stringWithFormat:@"%@", restAPITypeString]];
    }
    if (pageSizeInNumber.integerValue) {
        [restAPIPath appendString:@"&pageSize="];
        [restAPIPath appendString:[NSString stringWithFormat:@"%ld", (long)[pageSizeInNumber integerValue]]];
    }
    return restAPIPath;
}
@end
