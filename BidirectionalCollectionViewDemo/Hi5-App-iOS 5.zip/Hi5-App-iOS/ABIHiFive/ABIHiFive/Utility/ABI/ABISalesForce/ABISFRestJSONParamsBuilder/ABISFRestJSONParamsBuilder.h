    //
    //  ABISFRestJSONParamsBuilder.h
    //  ABIHiFive
    //
    //  Created by Prsenjit Goswami on 08/08/16.
    //  Copyright © 2016 Cognizant. All rights reserved.
    //
#import <Foundation/Foundation.h>
@interface ABISFRestJSONParamsBuilder : NSObject
+ (NSDictionary *)queryParamsForPrivateMessageWithPostBody:(NSString *)postMessage recipientIds:(NSArray *)recipientIds;
+ (NSDictionary *)queryParamsForFeedWithMessageSegment:(NSArray *)messageSegments attachments:(NSArray *)attachments;
+ (NSArray *)getMessageSegments:(NSString *)aString selectedMentionedDetails:(NSArray *)selectedMentionedDetails;
@end
