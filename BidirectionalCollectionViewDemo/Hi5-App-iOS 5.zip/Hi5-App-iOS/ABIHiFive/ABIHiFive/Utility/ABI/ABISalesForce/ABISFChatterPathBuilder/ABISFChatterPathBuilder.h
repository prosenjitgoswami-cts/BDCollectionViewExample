    //
    //  ABISFChatterPathBuilder.h
    //  ABIHiFive
    //
    //  Created by Prsenjit Goswami on 22/07/16.
    //  Copyright © 2016 Cognizant. All rights reserved.
    //
#import "Constants.h"
#import <Foundation/Foundation.h>
@interface ABISFChatterPathBuilder : NSObject
+ (NSString *)chatterRestAPIPath:(ChatterRestAPIPathType)chatterRestAPIPathType;

#pragma mark -  Search Mentioned
+ (NSString *)chatterRestAPIPathALLMentionWithSearchWord:(NSString *)searchWord mentionSearchType:(MentionSearchType)mentionSearchType;

#pragma mark -  Post Comment on A Feed
+ (NSString *)chatterRestAPIPathForComment:(NSString *)feedID commentText:(NSString *)commentText;
@end
