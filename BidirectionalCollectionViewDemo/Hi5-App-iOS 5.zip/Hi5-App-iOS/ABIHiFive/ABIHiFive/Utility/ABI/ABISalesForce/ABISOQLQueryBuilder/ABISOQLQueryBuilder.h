    //
    //  ABISOQLQueryBuilder.h
    //  ABIHiFive
    //
    //  Created by Prsenjit Goswami on 21/06/16.
    //  Copyright © 2016 Cognizant. All rights reserved.
    //
#import <Foundation/Foundation.h>
@class ABISFIncentiveDataModel, ABISFRosterDataModel;

@interface ABISOQLQueryBuilder : NSObject

+ (nullable NSString *)soqlQueryForRosterProfileDetailsWithRosterID:(nonnull NSString *)rosterID
                                                    extraDependency:(nullable NSDictionary *)extraDependency
                                                          ascending:(BOOL)ascending
                                                         sortByKeys:(nullable NSArray *)keys;

+ (nullable NSString *)soqlQueryForRosterIncentiveDetailsWithRoster:(nonnull ABISFRosterDataModel *)roster
                                                    extraDependency:(nullable NSDictionary *)extraDependency
                                                          ascending:(BOOL)ascending
                                                         sortByKeys:(nullable NSArray *)keys;

+ (nullable NSString *)soqlQueryForReporteesIncentiveDetailsForManager:(nonnull ABISFRosterDataModel *)rosterID
                                                          reporteeRole:(nullable NSString *)reporteeRole
                                                       extraDependency:(nullable NSDictionary *)extraDependency
                                                             ascending:(BOOL)ascending
                                                            sortByKeys:(nullable NSArray *)keys;

+ (nullable NSString *)soqlQueryForRosterBadgeDetailsForRoster:(nonnull ABISFRosterDataModel *)roster
                                                      forYears:(nullable NSArray *)years
                                               extraDependency:(nullable NSDictionary *)extraDependency
                                                     ascending:(BOOL)ascending
                                                    sortByKeys:(nullable NSArray *)keys;

+ (nullable NSString *)soqlQueryForIncentiveKIPsDetailsForIncentive:(nonnull ABISFIncentiveDataModel *)incentive
                                                             roster:(nonnull ABISFRosterDataModel *)roster
                                                    extraDependency:(nullable NSDictionary *)extraDependency
                                                          ascending:(BOOL)ascending
                                                         sortByKeys:(nullable NSArray *)keys;

+ (nullable NSString *)soqlQueryForAllPeerDetailsForRoster:(nonnull ABISFRosterDataModel *)roster
                                                 incentive:(nonnull ABISFIncentiveDataModel *)incentive
                                           extraDependency:(nullable NSDictionary *)extraDependency
                                                 ascending:(BOOL)ascending
                                                sortByKeys:(nullable NSArray *)keys;

+ (nullable NSString *)soqlQueryForAnnouncementsDetailsWithExtraDependency:(nullable NSDictionary *)extraDependency
                                                                 ascending:(BOOL)ascending
                                                                sortByKeys:(nullable NSArray *)keys;

+ (nullable NSString *)soqlQueryForAllReporteeDetailsForManagerWithRoster:(nonnull ABISFRosterDataModel *)roster
                                                             reporteeRole:(nullable NSString *)reporteeRole
                                                          extraDependency:(nullable NSDictionary *)extraDependency
                                                                ascending:(BOOL)ascending
                                                               sortByKeys:(nullable NSArray *)keys;

#pragma mark - Reportee KPI Details

+ (nullable NSString *)soqlQueryForAllReporteeKPIsWiseInccntivePerformanceDetailsForManager:(nonnull ABISFRosterDataModel *)manager
                                                                                  incentive:(nonnull ABISFIncentiveDataModel *)incentive
                                                                            extraDependency:(nullable NSDictionary<NSString *, id> *)extraDependency
                                                                                  ascending:(BOOL)ascending
                                                                                 sortByKeys:(nullable NSArray<NSString *> *)keys;
@end
