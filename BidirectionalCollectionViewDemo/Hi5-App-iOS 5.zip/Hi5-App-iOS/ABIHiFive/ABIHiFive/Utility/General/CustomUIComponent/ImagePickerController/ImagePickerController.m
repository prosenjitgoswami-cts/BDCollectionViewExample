    //
    //  ImagePickerController.m
    //  ABIHiFive
    //
    //  Created by Prsenjit Goswami on 04/08/16.
    //  Copyright © 2016 Cognizant. All rights reserved.
    //
#import "ImagePickerController.h"
#import "Constants.h"
#import <AssetsLibrary/AssetsLibrary.h>
#import <AssetsLibrary/AssetsLibrary.h>
#import <MobileCoreServices/MobileCoreServices.h> // needed for video types
@interface ImagePickerController () <UINavigationControllerDelegate, UIImagePickerControllerDelegate>
@property (nonatomic, assign, readwrite) ImagePickerType imagePickerType;
@property (nonatomic, copy) ImagePickerABIResponseBlock successBlock;
@property (nonatomic, copy) ImagePickeCancelBlock cancelBlock;
@end
@implementation ImagePickerController
/*
 *  kUTTypeAudiovisualContent
 *
 *    audio and/or video content
 *
 *    UTI: public.audiovisual-content
 *    conforms to: public.data, public.content
 *
 *
 *  kUTTypeMovie
 *
 *    A media format which may contain both video and audio
 *    Corresponds to what users would label a "movie"
 *
 *    UTI: public.movie
 *    conforms to: public.audiovisual-content
 *
 *
 *  kUTTypeVideo
 *
 *    pure video (no audio)
 *
 *    UTI: public.video
 *    conforms to: public.movie
 *
 *
 *  kUTTypeAudio
 *
 *    pure audio (no video)
 *
 *    UTI: public.audio
 *    conforms to: public.audiovisual-content
 *
 *
 *  kUTTypeQuickTimeMovie
 *
 *    QuickTime movie
 *
 *    UTI: com.apple.quicktime-movie
 *    conforms to: public.movie
 *
 *
 *  kUTTypeMPEG
 *
 *    MPEG-1 or MPEG-2 movie
 *
 *    UTI: public.mpeg
 *    conforms to: public.movie
 *
 *
 *  kUTTypeMPEG2Video
 *
 *    MPEG-2 video
 *
 *    UTI: public.mpeg-2-video
 *    conforms to: public.video
 *
 *
 *  kUTTypeMPEG2TransportStream
 *
 *    MPEG-2 Transport Stream movie format
 *
 *    UTI: public.mpeg-2-transport-stream
 *    conforms to: public.movie
 *
 *
 *  kUTTypeMP3
 *
 *    MP3 audio
 *
 *    UTI: public.mp3
 *    conforms to: public.audio
 *
 *
 *  kUTTypeMPEG4
 *
 *    MPEG-4 movie
 *
 *    UTI: public.mpeg-4
 *    conforms to: public.movie
 *
 *
 *  kUTTypeMPEG4Audio
 *
 *    MPEG-4 audio layer
 *
 *    UTI: public.mpeg-4-audio
 *    conforms to: public.mpeg-4, public.audio
 *
 *
 *  kUTTypeAppleProtectedMPEG4Audio
 *
 *    Apple protected MPEG4 format
 *    (.m4p, iTunes music store format)
 *
 *    UTI: com.apple.protected-mpeg-4-audio
 *    conforms to: public.audio
 *
 *
 *  kUTTypeAppleProtectedMPEG4Video
 *
 *    Apple protected MPEG-4 movie
 *
 *    UTI: com.apple.protected-mpeg-4-video
 *    conforms to: com.apple.m4v-video
 *
 *
 *  kUTTypeAVIMovie
 *
 *    Audio Video Interleaved (AVI) movie format
 *
 *    UTI: public.avi
 *    conforms to: public.movie
 *
 *
 *  kUTTypeAudioInterchangeFileFormat
 *
 *    AIFF audio format
 *
 *    UTI: public.aiff-audio
 *    conforms to: public.aifc-audio
 *
 *
 *  kUTTypeWaveformAudio
 *
 *    Waveform audio format (.wav)
 *
 *    UTI: com.microsoft.waveform-audio
 *    conforms to: public.audio
 *
 *
 *  kUTTypeMIDIAudio
 *
 *    MIDI audio format
 *
 *    UTI: public.midi-audio
 *    conforms to: public.audio
 *
 *
 */
- (nonnull instancetype)initWithType:(ImagePickerType)imagePickerType
                         cancelBlock:(_Nullable ImagePickeCancelBlock)cancelBlock
                        successBlock:(_Nullable ImagePickerABIResponseBlock)successBlock {
    self = [super init];
    if (self) {
        self.isPhotosOpen = YES;
        if (successBlock)
            self.successBlock = successBlock;
        if (cancelBlock)
            self.cancelBlock = cancelBlock;
        self.imagePickerType = imagePickerType;
    }
    return self;
}
- (void)viewWillAppear:(BOOL)animated {
    [super viewWillAppear:animated];
    [self navigationBarCustomiseABI];
    UIBarButtonItem *navBarButtonAppearance = [UIBarButtonItem appearanceWhenContainedIn:[UINavigationBar class], nil];
    [navBarButtonAppearance setTitleTextAttributes:@{
                                                     NSFontAttributeName : [UIFont systemFontOfSize:17 weight:UIFontWeightSemibold],
                                                     }
                                          forState:UIControlStateNormal];
}
- (void)viewWillDisappear:(BOOL)animated {
    [super viewWillDisappear:animated];
    [self navigationBarCustomiseABI];
}
- (void)setImagePickerType:(ImagePickerType)imagePickerType {
    _imagePickerType = imagePickerType;
    switch (self.imagePickerType) {
        case ImagePickerTypeCamera: [self openCameraWithABIResponseBlock:self.successBlock cancelBlock:self.cancelBlock]; break;
        case ImagePickerTypePhotoGallery: [self presentVideoPickerControllerWithABIResponseBlock:self.successBlock cancelBlock:self.cancelBlock]; break;
        default: break;
    }
}
#pragma mark - UIImagePickerController Delegate
- (void)openCameraWithABIResponseBlock:(ImagePickerABIResponseBlock)successBlock cancelBlock:(ImagePickeCancelBlock)cancelBlock {
    self.isPhotosOpen = YES;
    if ([UIImagePickerController isSourceTypeAvailable:UIImagePickerControllerSourceTypeCamera]) {
        self.delegate = self;
        self.sourceType = UIImagePickerControllerSourceTypeCamera;
        self.cameraCaptureMode = UIImagePickerControllerCameraCaptureModePhoto;
        self.allowsEditing = YES;
    } else {
        NSLog(@"Camera not available");
    }
}
- (void)presentVideoPickerControllerWithABIResponseBlock:(ImagePickerABIResponseBlock)successBlock cancelBlock:(ImagePickeCancelBlock)cancelBlock {
    self.delegate = self;
    self.modalPresentationStyle = UIModalPresentationCurrentContext;
    self.mediaTypes = [UIImagePickerController availableMediaTypesForSourceType:UIImagePickerControllerSourceTypePhotoLibrary];
    self.videoQuality = UIImagePickerControllerQualityTypeLow;
}
- (void)imagePickerController:(UIImagePickerController *)picker didFinishPickingMediaWithInfo:(NSDictionary<NSString *, id> *)info {
    __block NSData *pictureOrVideoData = nil;
    __block NSString *assetNaame = nil;
        // ================================ Return ================================
    __weak typeof(self) weakSelf = self;
    void (^returnBlockInMainThread)(NSData *_Nullable data, NSString *_Nullable assetName, NSError *_Nullable error, BOOL isFromSeccess,
                                    NSDictionary *info) =
    ^(NSData *_Nullable data, NSString *_Nullable assetName, NSError *_Nullable error, BOOL isFromSeccess, NSDictionary *info) {
            // In main thread
        dispatch_main_async_safeBlock(^{
            if (isFromSeccess) {
                if (weakSelf.successBlock)
                    weakSelf.successBlock(data, assetName, nil, info);
            }
        });
    };
        // ================ Pick Image or Video from Library =========================================
    if (picker.sourceType == UIImagePickerControllerSourceTypeCamera) {
        assetNaame = [NSString stringWithFormat:IMAGE_FORMAT, [NSDate timeIntervalSinceReferenceDate]];
        UIImage *newImage = [info valueForKey:UIImagePickerControllerOriginalImage];
        if ([info objectForKey:UIImagePickerControllerEditedImage])
            newImage = [info objectForKey:UIImagePickerControllerEditedImage];
        else
            newImage = [info valueForKey:UIImagePickerControllerOriginalImage];
        if ([newImage isKindOfClass:[UIImage class]]) {
            pictureOrVideoData = UIImageJPEGRepresentation(newImage, .5);
        }
        if (returnBlockInMainThread) {
            if (pictureOrVideoData && assetNaame.length)
                returnBlockInMainThread(pictureOrVideoData, assetNaame, nil, YES, info);
            else
                returnBlockInMainThread(nil, nil, nil, YES, info);
        }
    } else {
        ALAssetsLibrary *assetLibrary = [[ALAssetsLibrary alloc] init];
        NSURL *assetsURL = [info objectForKey:UIImagePickerControllerReferenceURL];
        if (assetsURL) {
            [assetLibrary assetForURL:assetsURL
                          resultBlock:^(ALAsset *asset) {
                              ALAssetRepresentation *rep = [asset defaultRepresentation];
                              if ([info[UIImagePickerControllerMediaType] isEqualToString:PUBLIC_IMAGE]) {
                                  UIImage *copyOfOriginalImage = [UIImage imageWithCGImage:[[asset defaultRepresentation] fullResolutionImage]];
                                  pictureOrVideoData = UIImageJPEGRepresentation(copyOfOriginalImage, 0.2);
                              } else if ([info[UIImagePickerControllerMediaType] isEqualToString:PUBLIC_MOVIE]) {
                                  Byte *buffer = (Byte *)malloc((NSUInteger)rep.size);
                                  NSUInteger buffered = [rep getBytes:buffer fromOffset:0.0 length:(NSUInteger)rep.size error:nil];
                                  pictureOrVideoData = [NSData dataWithBytesNoCopy:buffer length:buffered freeWhenDone:YES];
                              }
                              assetNaame = rep.filename;
                              if (returnBlockInMainThread) {
                                  if (pictureOrVideoData && assetNaame.length)
                                      returnBlockInMainThread(pictureOrVideoData, assetNaame, nil, YES, info);
                                  else
                                      returnBlockInMainThread(nil, nil, nil, YES, info);
                              }
                              pictureOrVideoData = nil;
                              assetNaame = nil;
                              rep = nil;
                          }
                         failureBlock:^(NSError *err) {
                             if (returnBlockInMainThread)
                                 returnBlockInMainThread(nil, nil, nil, NO, info);
                         }];
        }
    }
}
- (void)imagePickerControllerDidCancel:(UIImagePickerController *)picker {
    self.isPhotosOpen = NO;
    if (self.cancelBlock)
        self.cancelBlock(picker);
}
@end
