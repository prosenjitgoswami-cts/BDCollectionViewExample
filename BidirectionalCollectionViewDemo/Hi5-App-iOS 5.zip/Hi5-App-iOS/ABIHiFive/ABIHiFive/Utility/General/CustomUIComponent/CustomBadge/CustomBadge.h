
    //
    //  CustomBadge.h
    //  ABIHiFive
    //
    //  Created by Prsenjit Goswami on 01/08/16.
    //  Copyright © 2016 Cognizant. All rights reserved.
    //
#import <QuartzCore/QuartzCore.h>
#import <UIKit/UIKit.h>
@interface CustomBadge : UIView
@property (nonatomic, strong) NSString *badgeText;
@property (nonatomic) CGFloat badgeCornerRoundness;
@property (nonatomic) CGFloat badgeScaleFactor;
+ (CustomBadge *)customBadgeWithString:(NSString *)badgeString;
- (void)autoBadgeSizeWithString:(NSString *)badgeString;
@end
