    //
    //  ABIDropDownComponentView.m
    //  popOverlay
    //
    //  Created by Prsenjit Goswami on 18/08/16.
    //  Copyright © 2016 KolkataMobility Mac Mini 11. All rights reserved.
    //
#import "CustomDropDownTableView.h"
#import "Constants.h"
#import "DropDownTableViewCell.h"
@interface CustomDropDownTableView () <UITableViewDelegate, UITableViewDataSource>
@property (strong, nonatomic) UITableView *tblCheckList;
@property (copy, nonatomic) SelectedCallBack selectedCallBack;
@end
@implementation CustomDropDownTableView
- (instancetype)initWithData:(NSMutableArray *)dataSource dropDownListType:(DropDownListType)dropDownListType {
    self = [super init];
    if (self) {
        self.dataSources = dataSource;
        self.dropDownListType = dropDownListType;
    }
    return self;
}
- (void)dealloc {
    _selectedCallBack = nil;
    _tblCheckList.delegate = nil;
    _tblCheckList.dataSource = nil;
    [_tblCheckList removeFromSuperview];
    _tblCheckList = nil;
    [_dataSources removeAllObjects];
    _dataSources = nil;
}
#pragma mark - Accessors
- (UITableView *)tblCheckList {
    if (!_tblCheckList) {
        _tblCheckList = [[UITableView alloc] initWithFrame:CGRectZero style:UITableViewStylePlain];
        _tblCheckList.dataSource = self;
        _tblCheckList.delegate = self;
        _tblCheckList.userInteractionEnabled = YES;
        _tblCheckList.separatorStyle = UITableViewCellSeparatorStyleNone;
        _tblCheckList.translatesAutoresizingMaskIntoConstraints = NO;
        _tblCheckList.layer.borderColor = [[UIColor veryLightGreySeperator] CGColor];
        _tblCheckList.layer.borderWidth = SEPERATOR_LINE_WIDTH;
        _tblCheckList.backgroundColor = [UIColor whiteColor];
        self.tblCheckList.bounces = NO; // (self.dataSources.count > 6)
    }
    return _tblCheckList;
}

- (DropDownListDataModel *)selectedDropDownListDataModel {
    return [self.dataSources objectAtIndex:self.selectedIndex];
}
#pragma mark - Public Method
- (void)showPopOverInView:(UIView *)view completion:(SelectedCallBack)selectedCallBack {
    if (!_tblCheckList) {
        [self addSubview:self.tblCheckList];
        [self addConstraintsForSelfView:view];
        self.selectedCallBack = [selectedCallBack copy];
    } else {
        self.hidden = NO;
        [self.tblCheckList reloadData];
    }
}
#pragma mark - Private Method
- (void)addConstraintsForSelfView:(UIView *)view {
    self.hidden = NO;
    UIView *keyWinDowView = [UIApplication sharedApplication].keyWindow;
    keyWinDowView.backgroundColor = [UIColor clearColor];
    self.translatesAutoresizingMaskIntoConstraints = NO;
    [keyWinDowView addSubview:self];
    CGRect rect = [view convertRect:view.frame toView:keyWinDowView];
    CGFloat height = MAX(0, DROP_DOWN_CELL_ROW_HEIGHT * self.dataSources.count);
    height = MIN(DROP_DOWN_CELL_ROW_HEIGHT * MAX_VIBILE_CELL, height);
    NSDictionary *views = @{ @"selfView" : self, @"tblCheckList" : self.tblCheckList };
    NSDictionary *metrics = @{
                              @"originX" : @((rect.origin.x - 65) + 1),
                              @"originY" : @(CGRectGetMaxY(rect)),
                              @"width" : @(rect.size.width - 2),
                              @"height" : @(height),
                              };
    [keyWinDowView addConstraints:[NSLayoutConstraint constraintsWithVisualFormat:@"H:|[selfView]|" options:0 metrics:metrics views:views]];
    [keyWinDowView addConstraints:[NSLayoutConstraint constraintsWithVisualFormat:@"V:|[selfView]|" options:0 metrics:metrics views:views]];
    [self addConstraints:[NSLayoutConstraint constraintsWithVisualFormat:@"H:|-originX-[tblCheckList(width)]" options:0 metrics:metrics views:views]];
    [self addConstraints:[NSLayoutConstraint constraintsWithVisualFormat:@"V:|-originY-[tblCheckList(height)]" options:0 metrics:metrics views:views]];
}
    //- (void)resetCheckBox {
    //    DropDownListDataModel *dropDownListDataModel = [self.dataSources objectAtIndex:self.selectedIndex];
    //    if (dropDownListDataModel) {
    //        dropDownListDataModel.isSelected = !dropDownListDataModel.isSelected;
    //        [self.dataSources replaceObjectAtIndex:self.selectedIndex withObject:dropDownListDataModel];
    //    }
    //}
#pragma mark - TableView DataSource
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    return self.dataSources.count;
}
- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath {
    return DROP_DOWN_CELL_ROW_HEIGHT;
}
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    static NSString *CellIdentifier = @"Cell";
    DropDownTableViewCell *cell = (DropDownTableViewCell *)[tableView dequeueReusableCellWithIdentifier:CellIdentifier];
    if (cell == nil) {
        cell = [[DropDownTableViewCell alloc] initWithStyle:UITableViewCellStyleDefault
                                            reuseIdentifier:CellIdentifier
                                           dropDownListType:self.dropDownListType
                                             displayTextKey:self.displayTextKey];
    }
    cell.dropDownListType = self.dropDownListType;
    cell.displayTextKey = self.displayTextKey;

    id dataModel = [NSArray objectFromArray:self.dataSources atIndex:indexPath.row];
    [cell updateCell:dataModel selected:![self.dataSources indexOutOfBound:self.selectedIndex] && indexPath && (indexPath.row == self.selectedIndex)];
    return cell;
}
#pragma mark - TableView Delegate
- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {

    if ([AppDelegate isOffline] && !self.isBadge) {
        if (self.selectedCallBack)
            self.selectedCallBack([self selectedDropDownListDataModel], indexPath);
    } else {
            // [self resetCheckBox];
        self.selectedIndex = indexPath.row;
        if (self.selectedCallBack)
            self.selectedCallBack([self selectedDropDownListDataModel], indexPath);
    }
    self.hidden = YES;
}
#pragma mark - View Touch Event
- (void)touchesBegan:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event {
    self.hidden = YES;
}
@end
