    //
    //  DropDownListDataModel.m
    //  popOverlay
    //
    //  Created by KolkataMobility Mac Mini 11 on 16/08/16.
    //  Copyright © 2016 KolkataMobility Mac Mini 11. All rights reserved.
    //
#import "DropDownListDataModel.h"
@implementation DropDownListDataModel
+ (DropDownListDataModel *)inatialished:(BOOL)isSelected title:(NSString *)title index:(NSInteger)index {
    DropDownListDataModel *dropDownListDataModel = [DropDownListDataModel new];
    dropDownListDataModel.isSelected = isSelected;
    dropDownListDataModel.title = title;
    dropDownListDataModel.index = index;
    return dropDownListDataModel;
}
@end
