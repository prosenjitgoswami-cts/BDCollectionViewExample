    //
    //  CustomView.h
    //  SamplePopoveriPhone
    //
    //  Created by IR Mac Mini on 28/07/16.
    //  Copyright © 2016 IR Mac Mini. All rights reserved.
    //
#import <UIKit/UIKit.h>
@interface CustomView : UIView
@property (nonatomic, strong) UIImageView *innerUserImageView;
- (id)initWithImage:(UIImage *)image andOuterImage:(UIImage *)_outerimage andSize:(CGSize)_viewSize andPaddingForInnerView:(CGFloat)_padding;
@property (nonatomic, strong) UIImage *image;
@property (nonatomic, strong) UIImage *outerImage;
- (void)updateParentConstraint:(CGFloat)top andLeft:(CGFloat)left;
- (void)populateUI;
@end
