
#import <UIKit/UIKit.h>
@protocol CustomTabPagerDataSource;
@protocol CustomTabPagerDelegate;
@interface CustomTabPagerViewController : UIViewController
@property (weak, nonatomic, nullable) id<CustomTabPagerDataSource> dataSource;
@property (weak, nonatomic, nullable) id<CustomTabPagerDelegate> delegate;
+ (nonnull CustomTabPagerViewController *)initialisedTabPageViewController:(nonnull id)target;
- (void)hide;
- (void)show;
- (void)reloadData;
- (NSInteger)selectedIndex;
- (void)selectTabbarIndex:(NSInteger)index;
- (void)selectTabbarIndex:(NSInteger)index animation:(BOOL)animation;
- (nullable id)selectViewControllerIndex:(NSInteger)index;
- (void)repositionTab:(NSInteger)index;
@end
@protocol CustomTabPagerDataSource <NSObject>
@required
- (NSInteger)numberOfViewControllers;
- (nullable UIViewController *)viewControllerForIndex:(NSInteger)index;
@optional
- (nonnull UIView *)hintView;
- (nonnull UIColor *)backgroundColor;
- (nonnull UIImage *)backgroundImage;
- (nullable UIView *)viewForTabAtIndex:(NSInteger)index;
- (nullable NSString *)titleForTabAtIndex:(NSInteger)index;
- (CGFloat)tabHeight;
- (nonnull UIColor *)tabColor;
- (nonnull UIColor *)tabBackgroundColor;
- (nonnull UIFont *)titleFont;
- (nonnull UIColor *)titleColor;
- (nonnull UIColor *)deselectedTitleColor;
@end
@protocol CustomTabPagerDelegate <NSObject>
@optional
- (void)tabPager:(nullable CustomTabPagerViewController *)tabPager willTransitionToTabAtIndex:(NSInteger)index;
- (void)tabPager:(nullable CustomTabPagerViewController *)tabPager didTransitionToTabAtIndex:(NSInteger)index;
- (void)clickedMenuButton:(nonnull UIButton *)sender;
@end
@interface CustomTabPagerView : UIView
- (void)initialisedTabPageViewController:(nullable id)target;
- (void)reloadData;
- (void)repositionTab:(NSInteger)index;
@property (nonatomic, strong, nonnull, readonly) CustomTabPagerViewController *tabPageViewController;
@end
