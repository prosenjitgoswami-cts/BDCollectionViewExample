    //
    //  CustomLoaderManager.h
    //  ABIHiFive
    //
    //  Created by Prsenjit Goswami on 28/07/16.
    //  Copyright © 2016 Cognizant. All rights reserved.
    //

#import <Foundation/Foundation.h>
@class ProgressHUD;
@interface CustomLoaderManager : NSObject

+ (ProgressHUD *)showLoader;
+ (void)hideLoader;
+ (void)hideLoaderOnDelay:(NSTimeInterval)delay completion:(void (^)(void))completion;
+ (ProgressHUD *)showFlashWithMessage:(NSString *)message;
@end
