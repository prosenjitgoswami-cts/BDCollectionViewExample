
    //
    //  CustomBadge.m
    //  ABIHiFive
    //
    //  Created by Prsenjit Goswami on 01/08/16.
    //  Copyright © 2016 Cognizant. All rights reserved.
    //
#import "CustomBadge.h"
@interface CustomBadge ()
@property (nonatomic) UIFont *badgeFont;
@end
@implementation CustomBadge
@synthesize badgeCornerRoundness;
@synthesize badgeScaleFactor;
- (id)initWithString:(NSString *)badgeString {
    self = [super initWithFrame:CGRectMake(0, 0, 25, 25)];
    if (self != nil) {
        self.contentScaleFactor = [[UIScreen mainScreen] scale];
        self.backgroundColor = [UIColor clearColor];
        self.badgeText = badgeString;
        self.badgeCornerRoundness = 0.4;
        self.badgeScaleFactor = 1.0;
        [self autoBadgeSizeWithString:badgeString];
    }
    return self;
}
- (void)setBadgeText:(NSString *)badgeText {
    _badgeText = badgeText;
    [self autoBadgeSizeWithString:_badgeText];
}
- (void)autoBadgeSizeWithString:(NSString *)badgeString {
    CGSize retValue;
    CGFloat rectWidth, rectHeight;
    NSDictionary *fontAttr = @{ NSFontAttributeName : [UIFont fontWithName:@"HelveticaNeue-Medium" size:10.0f] };
    CGSize stringSize = [badgeString sizeWithAttributes:fontAttr];
    CGFloat flexSpace;
    if ([badgeString length] >= 2) {
        flexSpace = [badgeString length];
        rectWidth = 25 + (stringSize.width + flexSpace);
        rectHeight = 25;
        retValue = CGSizeMake(rectWidth * badgeScaleFactor, rectHeight * badgeScaleFactor);
    } else {
        retValue = CGSizeMake(25 * badgeScaleFactor, 25 * badgeScaleFactor);
    }
    self.frame = CGRectMake(self.frame.origin.x, self.frame.origin.y, retValue.width, retValue.height);
    _badgeText = badgeString;
    [self setNeedsDisplay];
}
+ (CustomBadge *)customBadgeWithString:(NSString *)badgeString {
    return [[self alloc] initWithString:badgeString];
}
    // Draws the Badge with Quartz
- (void)drawRoundedRectWithContext:(CGContextRef)context withRect:(CGRect)rect {
    CGContextSaveGState(context);
    CGFloat radius = CGRectGetMaxY(rect) * self.badgeCornerRoundness;
    CGFloat puffer = CGRectGetMaxY(rect) * 0.10;
    CGFloat maxX = CGRectGetMaxX(rect) - puffer;
    CGFloat maxY = CGRectGetMaxY(rect) - puffer;
    CGFloat minX = CGRectGetMinX(rect) + puffer;
    CGFloat minY = CGRectGetMinY(rect) + puffer;
    CGContextBeginPath(context);
    CGContextSetFillColorWithColor(context, [[UIColor redColor] CGColor]);
    CGContextAddArc(context, maxX - radius, minY + radius, radius, M_PI + (M_PI / 2), 0, 0);
    CGContextAddArc(context, maxX - radius, maxY - radius, radius, 0, M_PI / 2, 0);
    CGContextAddArc(context, minX + radius, maxY - radius, radius, M_PI / 2, M_PI, 0);
    CGContextAddArc(context, minX + radius, minY + radius, radius, M_PI, M_PI + M_PI / 2, 0);
    CGContextFillPath(context);
    CGContextRestoreGState(context);
}
- (void)drawRect:(CGRect)rect {
    CGContextRef context = UIGraphicsGetCurrentContext();
    [self drawRoundedRectWithContext:context withRect:rect];
    if ([self.badgeText length] > 0) {
        UIFont *textFont = [UIFont fontWithName:@"HelveticaNeue-Medium" size:12.0f];
        NSDictionary *fontAttr = @{NSFontAttributeName : textFont, NSForegroundColorAttributeName : [UIColor whiteColor]};
        CGSize textSize = [self.badgeText sizeWithAttributes:fontAttr];
        CGPoint textPoint = CGPointMake((rect.size.width / 2 - textSize.width / 2), (rect.size.height / 2 - textSize.height / 2) - 1);
        [self.badgeText drawAtPoint:textPoint withAttributes:fontAttr];
    }
}
@end
