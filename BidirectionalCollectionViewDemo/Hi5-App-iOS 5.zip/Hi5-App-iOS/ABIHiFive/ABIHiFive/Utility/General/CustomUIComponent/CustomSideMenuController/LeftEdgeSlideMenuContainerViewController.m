    //
    //  LeftEdgeSlideMenuContainerViewController.m
    //  ABIHiFive
    //
    //  Created by Prsenjit Goswami on 10/06/16.
    //  Copyright © 2016 Cognizant. All rights reserved.
    //
#import "LeftEdgeSlideMenuContainerViewController.h"
#import "ABISFDataFetcherService.h"
#import "ABIAnnouncementDetailsPageViewController.h"
#import "ABIChatterPageViewController.h"
#import "Constants.h"
#import "LoginViewController.h"
#import "ABILeftSlideMenuListViewController.h"
#import "ABIOnBoardingViewController.h"
#import "ABIProfilePageViewController.h"
#import "SFAuthenticationManager.h"
#import <MessageUI/MessageUI.h>
#import <QuartzCore/QuartzCore.h>
typedef NS_ENUM(NSInteger, CustomSideMenuAction) { CustomSideMenuOpen, CustomSideMenuClose };
typedef struct {
    CustomSideMenuAction menuAction;
    BOOL shouldBounce;
    CGFloat velocity;
    NSUInteger lastSelectedIndex;
} CustomSideMenuPanResultInfo;
@interface LeftEdgeSlideMenuContainerViewController () <UIGestureRecognizerDelegate, ABILeftSlideMenuListViewControllerDelegate,
MFMailComposeViewControllerDelegate>
@property (strong, nonatomic) UIViewController *menuViewController;
@property (strong, nonatomic) UIViewController *contentViewController;
@property (strong, nonatomic) UIView *contentContainerView;
@property (strong, nonatomic) UIView *menuContainerView;
@property (strong, nonatomic) UIView *opacityView;
@property (strong, nonatomic) UIPanGestureRecognizer *panGesture;
@property (strong, nonatomic) UITapGestureRecognizer *tapGesture;
@end
@implementation LeftEdgeSlideMenuContainerViewController
- (id)initWithCoder:(NSCoder *)aDecoder {
    self = [super initWithCoder:aDecoder];
    if (self) {
        _options = [[LeftEdgeSlideMenuOptions alloc] init];
    }
    return self;
}
- (id)initWithMenuViewController:(UIViewController *)menuViewController contentViewController:(UIViewController *)contentViewController {
    return [self initWithMenuViewController:menuViewController
                      contentViewController:contentViewController
                                    options:[[LeftEdgeSlideMenuOptions alloc] init]];
}
    // ABILeftSlideMenuListViewController
- (id)initWithMenuViewController:(UIViewController *)menuViewController
           contentViewController:(UIViewController *)contentViewController
                         options:(LeftEdgeSlideMenuOptions *)options {
    self = [super init];
    if (self) {
        _options = options;
        _menuViewController = menuViewController;
        _contentViewController = contentViewController;
    }
    return self;
}
- (void)viewDidLoad {
    [super viewDidLoad];
        // Do any additional setup after loading the view.
    self.lastSelectedIndex = -1;
    [self setUpMenuViewController:_menuViewController];
    [self setUpContentViewController:_contentViewController];
    [self addGestures];
}
- (void)viewWillAppear:(BOOL)animated {
    [super viewWillAppear:animated];
}
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
        // Dispose of any resources that can be recreated.
}
- (BOOL)shouldAutorotate {
    if (self.contentViewController) {
        return [self.contentViewController shouldAutorotate];
    } else {
        return [super shouldAutorotate];
    }
}
- (UIInterfaceOrientationMask)supportedInterfaceOrientations {
    if (self.contentViewController) {
        return [self.contentViewController supportedInterfaceOrientations];
    } else {
        return [super supportedInterfaceOrientations];
    }
}
#pragma mark – Setters
- (void)setMenuFrame:(CGRect)menuFrame {
    menuFrame.origin.x = 0;
    if (menuFrame.size.height < 0) {
        menuFrame.size.height = self.view.bounds.size.height - menuFrame.origin.y;
    }
    if (menuFrame.size.width < 0) {
        menuFrame.size.width = self.view.bounds.size.width;
    }
    _menuFrame = menuFrame;
    if (_menuContainerView) {
        menuFrame.origin.x = -menuFrame.size.width;
        _menuContainerView.frame = menuFrame;
    }
}
- (void)setMenuViewController:(UIViewController *)menuViewController {
    [self removeViewController:_menuViewController];
    _menuViewController = menuViewController;
    [self setUpMenuViewController:_menuViewController];
}
- (void)setContentViewController:(UIViewController *)contentViewController {
    [self removeViewController:_contentViewController];
    _contentViewController = contentViewController;
    [self setUpContentViewController:_contentViewController];
}

#pragma mark -  Accessors
- (UIView *)contentContainerView {
    if (!_contentContainerView) {
        _contentContainerView = [[UIView alloc] initWithFrame:self.view.bounds];
        _contentContainerView.backgroundColor = [UIColor clearColor];
        _contentContainerView.autoresizingMask = UIViewAutoresizingFlexibleHeight | UIViewAutoresizingFlexibleWidth;
        [self.view insertSubview:_contentContainerView atIndex:0];
    }
    return _contentContainerView;
}
- (UIView *)menuContainerView {
    if (!_menuContainerView) {
        if (CGRectEqualToRect(CGRectZero, self.menuFrame)) {
            self.menuFrame = CGRectMake(0, 0, self.view.bounds.size.width - 60.0, self.view.bounds.size.height);
        }
        CGRect frame = self.menuFrame;
        frame.origin.x = [self closedOriginX];
        _menuContainerView = [[UIView alloc] initWithFrame:frame];
        _menuContainerView.backgroundColor = [UIColor clearColor];
        _menuContainerView.autoresizingMask = UIViewAutoresizingFlexibleHeight;
        [self.view insertSubview:_menuContainerView atIndex:2];
    }
    return _menuContainerView;
}
#pragma mark – Public methods
- (void)closeMenu {
    [self closeMenuWithVelocity:0.0f];
}
- (void)openMenu {
    [self openMenuWithVelocity:0.0f];
    if ([_menuViewController isKindOfClass:[ABILeftSlideMenuListViewController class]]) {
        ABILeftSlideMenuListViewController *vc = (ABILeftSlideMenuListViewController *)_menuViewController;
        vc.delegate = self;
        [vc reloadMenuList];
    }
}
- (void)toggleMenu {
    [self isMenuOpen] ? [self closeMenu] : [self openMenu];
}
- (void)disable {
    self.panGesture.enabled = NO;
}
- (void)enable {
    self.panGesture.enabled = YES;
}
- (void)changeContentViewController:(UIViewController *)contentViewController closeMenu:(BOOL)closeMenu {
    self.contentViewController = contentViewController;
    closeMenu ? [self closeMenu] : nil;
}
- (void)changeMenuViewController:(UIViewController *)menuViewController closeMenu:(BOOL)closeMenu {
    self.menuViewController = menuViewController;
    closeMenu ? [self closeMenu] : nil;
}
#pragma mark – Private methods
- (void)removeViewController:(UIViewController *)menuViewController {
    if (menuViewController) {
        [menuViewController willMoveToParentViewController:nil];
        [menuViewController.view removeFromSuperview];
        [menuViewController removeFromParentViewController];
    }
}
- (void)setUpMenuViewController:(UIViewController *)menuViewController {
    if (menuViewController) {
        [self addChildViewController:menuViewController];
        menuViewController.view.frame = self.menuContainerView.bounds;
        [self.menuContainerView addSubview:menuViewController.view];
        [menuViewController didMoveToParentViewController:self];
    }
}
- (void)setUpContentViewController:(UIViewController *)contentViewController {
    if (contentViewController) {
        [self addChildViewController:contentViewController];
        contentViewController.view.frame = self.contentContainerView.bounds;
        [self.contentContainerView addSubview:contentViewController.view];
        [contentViewController didMoveToParentViewController:self];
    }
}
- (UIView *)opacityView {
    if (!_opacityView) {
        _opacityView = [[UIView alloc] initWithFrame:self.view.bounds];
        _opacityView.backgroundColor = [UIColor blackColor];
        _opacityView.autoresizingMask = UIViewAutoresizingFlexibleHeight | UIViewAutoresizingFlexibleWidth;
        _opacityView.layer.opacity = 0.0;
        [self.view insertSubview:_opacityView atIndex:1];
    }
    return _opacityView;
}
- (void)addGestures {
    if (!_panGesture) {
        _panGesture = [[UIPanGestureRecognizer alloc] initWithTarget:self action:@selector(handlePanGesture:)];
        [_panGesture setDelegate:self];
        [self.view addGestureRecognizer:_panGesture];
    }
    self.view.backgroundColor = [UIColor clearColor];
    if (!_tapGesture) {
        _tapGesture = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(toggleMenu)];
        [_tapGesture setDelegate:self];
        [self.view addGestureRecognizer:_tapGesture];
    }
}
- (void)handlePanGesture:(UIPanGestureRecognizer *)panGesture {
    static CGRect menuFrameAtStartOfPan;
    static CGPoint startPointOfPan;
    static BOOL menuWasOpenAtStartOfPan;
    static BOOL menuWasHiddenAtStartOfPan;
    switch (panGesture.state) {
        case UIGestureRecognizerStateBegan:
            menuFrameAtStartOfPan = self.menuContainerView.frame;
            startPointOfPan = [panGesture locationInView:self.view];
            menuWasOpenAtStartOfPan = [self isMenuOpen];
            menuWasHiddenAtStartOfPan = [self isMenuHidden];
            [self.menuViewController beginAppearanceTransition:menuWasHiddenAtStartOfPan animated:YES];
            [self addShadowToMenuView];
            break;
        case UIGestureRecognizerStateChanged: {
            CGPoint translation = [panGesture translationInView:panGesture.view];
            self.menuContainerView.frame = [self applyTranslation:translation toFrame:menuFrameAtStartOfPan];
            [self applyOpacity];
            [self applyContentViewScale];
            break;
        }
        case UIGestureRecognizerStateEnded: {
            [self.menuViewController beginAppearanceTransition:!menuWasHiddenAtStartOfPan animated:YES];
            CGPoint velocity = [panGesture velocityInView:panGesture.view];
            CustomSideMenuPanResultInfo panInfo = [self panResultInfoForVelocity:velocity];
            if (panInfo.menuAction == CustomSideMenuOpen) {
                [self openMenuWithVelocity:panInfo.velocity];
            } else {
                [self closeMenuWithVelocity:panInfo.velocity];
            }
            break;
        }
        default: break;
    }
}
- (CustomSideMenuPanResultInfo)panResultInfoForVelocity:(CGPoint)velocity {
    static CGFloat thresholdVelocity = 450.0f;
    CGFloat pointOfNoReturn = floorf([self closedOriginX] / 2.0f);
    CGFloat menuOrigin = self.menuContainerView.frame.origin.x;
    CustomSideMenuPanResultInfo panInfo = {CustomSideMenuClose, NO, 0.0f};
    panInfo.menuAction = menuOrigin <= pointOfNoReturn ? CustomSideMenuClose : CustomSideMenuOpen;
    if (velocity.x >= thresholdVelocity) {
        panInfo.menuAction = CustomSideMenuOpen;
        panInfo.velocity = velocity.x;
    } else if (velocity.x <= (-1.0f * thresholdVelocity)) {
        panInfo.menuAction = CustomSideMenuClose;
        panInfo.velocity = velocity.x;
    }
    return panInfo;
}
- (BOOL)isMenuOpen {
    return self.menuContainerView.frame.origin.x == 0.0f;
}
- (BOOL)isMenuHidden {
    return self.menuContainerView.frame.origin.x <= [self closedOriginX];
}
- (CGFloat)closedOriginX {
    return -self.menuFrame.size.width;
}
- (CGRect)applyTranslation:(CGPoint)translation toFrame:(CGRect)frame {
    CGFloat newOrigin = frame.origin.x;
    newOrigin += translation.x;
    CGFloat minOrigin = [self closedOriginX];
    CGFloat maxOrigin = 0.0f;
    CGRect newFrame = frame;
    if (newOrigin < minOrigin) {
        newOrigin = minOrigin;
    } else if (newOrigin > maxOrigin) {
        newOrigin = maxOrigin;
    }
    newFrame.origin.x = newOrigin;
    return newFrame;
}
- (CGFloat)getOpenedMenuRatio {
    CGFloat currentPosition = self.menuContainerView.frame.origin.x - [self closedOriginX];
    return currentPosition / self.menuFrame.size.width;
}
- (void)applyOpacity {
    CGFloat openedMenuRatio = [self getOpenedMenuRatio];
    CGFloat opacity = self.options.contentViewOpacity * openedMenuRatio;
    self.opacityView.layer.opacity = opacity;
}
- (void)applyContentViewScale {
    CGFloat openedMenuRatio = [self getOpenedMenuRatio];
    CGFloat scale = 1.0 - ((1.0 - self.options.contentViewScale) * openedMenuRatio);
    [self.contentContainerView setTransform:CGAffineTransformMakeScale(scale, scale)];
}
- (void)openMenuWithVelocity:(CGFloat)velocity {
    CGFloat menuXOrigin = self.menuContainerView.frame.origin.x;
    CGFloat finalXOrigin = 0.0f;
    CGRect frame = self.menuContainerView.frame;
    frame.origin.x = finalXOrigin;
    NSTimeInterval duration;
    if (velocity == 0.0f) {
        duration = self.options.animationDuration;
    } else {
        duration = fabs(menuXOrigin - finalXOrigin) / velocity;
        duration = fmax(0.1, fmin(1.0f, duration));
    }
    [self addShadowToMenuView];
    [UIView animateWithDuration:duration
                          delay:0.0f
                        options:UIViewAnimationOptionCurveEaseInOut
                     animations:^{
                         self.menuContainerView.frame = frame;
                         self.opacityView.layer.opacity = self.options.contentViewOpacity;
                         [self.contentContainerView setTransform:CGAffineTransformMakeScale(self.options.contentViewScale, self.options.contentViewScale)];
                     }
                     completion:^(BOOL finished) { [self disableContentInteraction]; }];
}
- (void)closeMenuWithVelocity:(CGFloat)velocity {
    CGFloat menuXOrigin = self.menuContainerView.frame.origin.x;
    CGFloat finalXOrigin = [self closedOriginX];
    CGRect frame = self.menuContainerView.frame;
    frame.origin.x = finalXOrigin;
    NSTimeInterval duration;
    if (velocity == 0.0f) {
        duration = self.options.animationDuration;
    } else {
        duration = fabs(menuXOrigin - finalXOrigin) / velocity;
        duration = fmax(0.1, fmin(1.0f, duration));
    }
    [UIView animateWithDuration:duration
                          delay:0.0f
                        options:UIViewAnimationOptionCurveEaseInOut
                     animations:^{
                         self.menuContainerView.frame = frame;
                         self.opacityView.layer.opacity = 0.0f;
                         [self.contentContainerView setTransform:CGAffineTransformMakeScale(1.0, 1.0)];
                     }
                     completion:^(BOOL finished) {
                         [self removeMenuShadow];
                         [self enableContentInteraction];
                     }];
}
- (BOOL)slideMenuForGestureRecognizer:(UIGestureRecognizer *)gesture withTouchPoint:(CGPoint)point {
    BOOL slide = [self isMenuOpen];
    slide |= self.options.panFromBezel && [self isPointContainedWithinBezelRect:point];
    slide |= self.options.panFromNavBar && [self isPointContainedWithinNavigationRect:point];
    return slide;
}
- (BOOL)isPointContainedWithinNavigationRect:(CGPoint)point {
    CGRect navigationBarRect = CGRectNull;
    if ([self.contentViewController isKindOfClass:[UINavigationController class]]) {
        UINavigationBar *navBar = [(UINavigationController *)self.contentViewController navigationBar];
        navigationBarRect = [self.contentViewController.view convertRect:navBar.frame toView:self.view];
        navigationBarRect = CGRectIntersection(navigationBarRect, self.view.bounds);
    }
    return CGRectContainsPoint(navigationBarRect, point);
}
- (BOOL)isPointContainedWithinBezelRect:(CGPoint)point {
    CGRect leftBezelRect;
    CGRect tempRect;
    CGFloat bezelWidth = self.options.bezelWidth;
    CGRectDivide(self.view.bounds, &leftBezelRect, &tempRect, bezelWidth, CGRectMinXEdge);
    return CGRectContainsPoint(leftBezelRect, point);
}
- (BOOL)isPointContainedWithinMenuRect:(CGPoint)point {
    return CGRectContainsPoint(self.menuContainerView.frame, point);
}
- (void)addShadowToMenuView {
    self.menuContainerView.layer.masksToBounds = NO;
    self.menuContainerView.layer.shadowOffset = self.options.shadowOffset;
    self.menuContainerView.layer.shadowOpacity = self.options.shadowOpacity;
    self.menuContainerView.layer.shadowRadius = self.options.shadowRadius;
    self.menuContainerView.layer.shadowPath = [[UIBezierPath bezierPathWithRect:self.menuContainerView.bounds] CGPath];
}
- (void)removeMenuShadow {
    self.menuContainerView.layer.masksToBounds = YES;
    self.contentContainerView.layer.opacity = 1.0;
}
- (void)removeContentOpacity {
    self.opacityView.layer.opacity = 0.0;
}
- (void)addContentOpacity {
    self.opacityView.layer.opacity = self.options.contentViewOpacity;
}
- (void)disableContentInteraction {
    [self.contentContainerView setUserInteractionEnabled:NO];
}
- (void)enableContentInteraction {
    [self.contentContainerView setUserInteractionEnabled:YES];
}
#pragma mark – UIGestureRecognizerDelegate
- (BOOL)gestureRecognizer:(UIGestureRecognizer *)gestureRecognizer shouldReceiveTouch:(UITouch *)touch {
    CGPoint point = [touch locationInView:self.view];
    if (gestureRecognizer == _panGesture) {
        return [self slideMenuForGestureRecognizer:gestureRecognizer withTouchPoint:point];
    } else if (gestureRecognizer == _tapGesture) {
        return [self isMenuOpen] && ![self isPointContainedWithinMenuRect:point];
    }
    return YES;
}

#pragma mark -  IBACTION
- (void)didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
        //    if(self.lastSelectedIndex == indexPath.row) {
        //        [self closeMenu];
        //        return;
        //    }
    switch (indexPath.row) {
        case kPageProfile: {
            ABIProfilePageViewController *contentVC;
            UIStoryboard *mystoryboard = [UIStoryboard storyboardWithName:@"Main" bundle:nil];
            contentVC = [mystoryboard instantiateViewControllerWithIdentifier:@"ABIProfilePageViewController"];
            [AppDelegate setGlobalCurrentPageFlow:PageFlowUnknown];
            ABIProfilePageViewController *profilePageViewController = (ABIProfilePageViewController *)contentVC;
            [self loadController:contentVC];
            self.lastSelectedIndex = indexPath.row;
            ABISFRosterDataModel *signedInABISFRosterDataModel = [ABISFRosterDataModel signedInABISFRosterDataModel];
            PageFlow pageflow = [ABISFRosterDataModel pageFlow:signedInABISFRosterDataModel.roleInString];
            [profilePageViewController profileForRosterWithUserID:signedInABISFRosterDataModel.rosterUserID andPageFlow:pageflow];
        } break;
        case kPageChatter: {
            UIStoryboard *mystoryboard = [UIStoryboard storyboardWithName:@"Main" bundle:nil];
            ABIChatterPageViewController *contentVC = [mystoryboard instantiateViewControllerWithIdentifier:@"ABIChatterPageViewController"];
            contentVC.rosterDataModel = [ABISFRosterDataModel signedInABISFRosterDataModel];
            [self loadController:contentVC];
            self.lastSelectedIndex = indexPath.row;
        } break;
        case kPageHelp_Support: {
            [self openHelpAndSupportMailComposer];
        } break;
        case kLogout: {
            [self alertWithTitle:@"Logout"
                         message:ALT_LOGOUT_MSG_TEXT
              defaultButtonTitle:ALT_BTN_TITLE_EXIT
             defaultButtonHander:^{ [self logoutAction]; }
               cancelButtonTitle:ALT_BTN_TITLE_CANCEL
              cancelButtonHander:^{
                  if ([self isMenuOpen])
                      [self closeMenu];
              }];
        } break;
        default: break;
    }
    [self closeMenu];
}
- (void)logoutAction {
    if ([AppDelegate isOffline]) {
        [self alertWithMessage:ALT_MSG_NO_INTERNET_CONNECTION clickedOkButton:^{ [self closeMenu]; }];
    } else {
        [ABISFRosterDataModel cleanUserInformation];
            // Functons off in ios on 01/09/2016
            //[NSUserDefaults removeUserDefault:kOnboardingIsShown];
        [[SFAuthenticationManager sharedManager] logout];
        NSArray *viewControllers = [AppDelegate appdelegateShareInstance].navigationController.viewControllers;
        if (viewControllers.count) {
            UIViewController *topViewController = viewControllers[0];
            [self removeViewController:topViewController];
            [self closeMenu];
        }
        [[AppDelegate appdelegateShareInstance] setLoginViewControllerAsRootViewController];
    }
}
- (void)loadController:(UIViewController *)controller {
    [AppDelegate appdelegateShareInstance].navigationController = [[UINavigationController alloc] initWithRootViewController:controller];
    [[self sideMenuController] changeContentViewController:[AppDelegate appdelegateShareInstance].navigationController closeMenu:NO];
}
- (void)openHelpAndSupportMailComposer {
    MFMailComposeViewController *comp = [[MFMailComposeViewController alloc] init];
    [comp setMailComposeDelegate:self];
    if ([MFMailComposeViewController canSendMail]) {
        [comp setToRecipients:[NSArray arrayWithObjects:HELP_AND_SUPPPORT_RECIPIENTS, nil]];
        [comp setModalTransitionStyle:UIModalTransitionStyleCrossDissolve];
        [self presentViewController:comp animated:YES completion:nil];
    }
}
- (void)mailComposeController:(MFMailComposeViewController *)controller didFinishWithResult:(MFMailComposeResult)result error:(NSError *)error {
    if (error) {
        [controller dismissViewControllerAnimated:YES completion:nil];
    } else {
        [controller dismissViewControllerAnimated:YES completion:nil];
    }
}
@end
@implementation UIViewController (CustomSideMenuController)
- (LeftEdgeSlideMenuContainerViewController *)sideMenuController {
    UIViewController *initialController = self;
    UIViewController *viewController = self;
        //   UIViewController *vc = presentedVC
    while (viewController) {
        if ([viewController isKindOfClass:[LeftEdgeSlideMenuContainerViewController class]])
            return (LeftEdgeSlideMenuContainerViewController *)viewController;
        viewController = viewController.parentViewController;
    }
    if ([initialController.presentingViewController isKindOfClass:[LeftEdgeSlideMenuContainerViewController class]] && !viewController) {
        return (LeftEdgeSlideMenuContainerViewController *)initialController.presentingViewController;
    }
    return nil;
}

@end
