    //
    //  DropDownTableViewCell.h
    //  popOverlay
    //
    //  Created by KolkataMobility Mac Mini 11 on 16/08/16.
    //  Copyright © 2016 KolkataMobility Mac Mini 11. All rights reserved.
    //
#import "Constants.h"
#import <UIKit/UIKit.h>
@class DropDownListDataModel;
@interface DropDownTableViewCell : UITableViewCell
@property (strong, nonatomic) NSString *titleLabelText;
@property (assign, nonatomic) DropDownListType dropDownListType;
@property (assign, nonatomic) UIColor *textColor;
@property (assign, nonatomic) UIFont *textFont;
@property (assign, nonatomic) UIImage *checkMarkImage;
@property (strong, nonatomic) NSString *displayTextKey;
- (id)initWithStyle:(UITableViewCellStyle)style
    reuseIdentifier:(NSString *)reuseIdentifier
   dropDownListType:(DropDownListType)dropDownListType
     displayTextKey:(NSString *)displayTextKey;
- (void)updateCell:(id)cellModel selected:(BOOL)selected;

@end
