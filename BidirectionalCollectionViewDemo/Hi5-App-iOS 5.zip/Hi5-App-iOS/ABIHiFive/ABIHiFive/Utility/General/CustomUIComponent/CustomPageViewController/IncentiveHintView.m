    //
    //  IncentiveHintView.m
    //  ABIHiFive
    //
    //  Created by Prsenjit Goswami on 08/07/16.
    //  Copyright © 2016 Cognizant. All rights reserved.
    //
#import "IncentiveHintView.h"
#import "UIColor+ABIColor.h"
#import "UIFont+ABIFont.h"

@implementation IncentiveHintView
- (void)awakeFromNib {
    _exceededIndicatorImageVIew.backgroundColor = [UIColor incentiveExceededColor];
    _miniumIndicatorImageVIew.backgroundColor = [UIColor incentiveMinimumColor];
    _veryLowIndicatorImageVIew.backgroundColor = [UIColor incentiveVeryLessColor];
    _exceededIndicatorLabel.textColor = [UIColor darkTextColor];
    _minimumIndicatorLabel.textColor = [UIColor darkTextColor];
    _veryLessIndicatorLabel.textColor = [UIColor darkTextColor];
    _exceededIndicatorLabel.font = [UIFont fontHelvetica57Condensed:12.0f];
    _minimumIndicatorLabel.font = [UIFont fontHelvetica57Condensed:12.0f];
    _veryLessIndicatorLabel.font = [UIFont fontHelvetica57Condensed:12.0f];
}
@end
