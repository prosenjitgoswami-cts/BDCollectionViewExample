    //
    //  ImagePickerController.h
    //  ABIHiFive
    //
    //  Created by Prsenjit Goswami on 04/08/16.
    //  Copyright © 2016 Cognizant. All rights reserved.
    //
#import <AssetsLibrary/AssetsLibrary.h>
#import <Foundation/Foundation.h>
#import <MobileCoreServices/MobileCoreServices.h> // needed for video types
#import <UIKit/UIKit.h>
typedef enum {
    ImagePickerTypeCamera = 0,
    ImagePickerTypePhotoGallery = 1,
} ImagePickerType;
typedef void (^ImagePickerABIResponseBlock)(NSData *_Nullable data, NSString *_Nullable assetName, NSError *_Nullable error,
                                            NSDictionary *_Nullable info);
typedef void (^ImagePickeCancelBlock)(UIImagePickerController *_Nullable picker);
@interface ImagePickerController : UIImagePickerController
- (nonnull instancetype)initWithType:(ImagePickerType)imagePickerType
                         cancelBlock:(nullable ImagePickeCancelBlock)cancelBlock
                        successBlock:(nullable ImagePickerABIResponseBlock)successBlock;
@property (nonatomic, assign, readonly) ImagePickerType imagePickerType;
@property (nonatomic, assign) BOOL isPhotosOpen;
@end
