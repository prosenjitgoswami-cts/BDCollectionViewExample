
    //
    //  CustomProgressBarView.m
    //  ABIHiFive
    //
    //  Created by Prsenjit Goswami on 29/06/16.
    //  Copyright © 2016 Cognizant. All rights reserved.
    //
#import "CustomProgressBarView.h"
#import "Constants.h"
@interface CustomProgressBarView ()
@property (strong, nonatomic) UIView *barBackgroundView;
@property (strong, nonatomic) UIView *progressBarView;
@property (strong, nonatomic) UILabel *descriptionTextLabel;
@property (strong, nonatomic) UILabel *unitTextLabel;
@property (strong, nonatomic) UIImageView *endMarkerImageView;
@property (strong, nonatomic) NSLayoutConstraint *progressBarViewWidthConstraint;
@property (strong, nonatomic) NSLayoutConstraint *unitTextLabelWidthConstraint;
@property (strong, nonatomic) NSLayoutConstraint *endMarkerImageViewButtomconstraint;
@property (strong, nonatomic) UIColor *barBackGroundColor;
@property (assign, nonatomic) float multiplier;
@property (assign, nonatomic) NSInteger barType;
@end
@implementation CustomProgressBarView {
    NSArray *unitLabelConstaraintArr;
}
- (instancetype)init {
    self = [super init];
    if (self) {
        [self createAndAddUI];
    }
    return self;
}
- (void)dealloc {
    _barBackgroundView = nil;
    _progressBarView = nil;
    _unitTextLabel = nil;
    _endMarkerImageView = nil;
}
#pragma mark - Private Method
- (UIImageView *)endMarkerImageView {
    if (!_endMarkerImageView) {
        _endMarkerImageView = [UIImageView new];
        _endMarkerImageView.image = [UIImage imageNamed:pointer];
        _endMarkerImageView.backgroundColor = [UIColor clearColor];
        _endMarkerImageView.translatesAutoresizingMaskIntoConstraints = NO;
    }
    return _endMarkerImageView;
}
- (UIView *)barBackgroundView {
    if (!_barBackgroundView) {
        _barBackgroundView = [UIView new];
        _barBackgroundView.layer.cornerRadius = BAR_CORNER_RADIUS;
        _barBackgroundView.clipsToBounds = YES;
        _barBackgroundView.translatesAutoresizingMaskIntoConstraints = NO;
    }
    return _barBackgroundView;
}
- (UIView *)progressBarView {
    if (!_progressBarView) {
        _progressBarView = [UIView new];
        _progressBarView.clipsToBounds = YES;
        _progressBarView.translatesAutoresizingMaskIntoConstraints = NO;
    }
    return _progressBarView;
}
- (UILabel *)descriptionTextLabel {
    if (!_descriptionTextLabel) {
        _descriptionTextLabel = [UILabel new];
        _descriptionTextLabel.textAlignment = NSTextAlignmentRight;
        _descriptionTextLabel.translatesAutoresizingMaskIntoConstraints = NO;
    }
    return _descriptionTextLabel;
}
- (UILabel *)unitTextLabel {
    if (!_unitTextLabel) {
        _unitTextLabel = [UILabel new];
        _unitTextLabel.textColor = [UIColor defaultTextDarkColor];
        _unitTextLabel.textAlignment = NSTextAlignmentRight;
        _unitTextLabel.translatesAutoresizingMaskIntoConstraints = NO;
    }
    return _unitTextLabel;
}
/*!
 *  Create UI
 */
- (void)createAndAddUI {
    [self addSubview:self.unitTextLabel];
    [self addSubview:self.descriptionTextLabel];
    [self addSubview:self.endMarkerImageView];
    [self addSubview:self.barBackgroundView];
    [self.barBackgroundView addSubview:self.progressBarView];
    [self addConstrains];
    self.barBackGroundColor = [UIColor lightGreyColorABI];
}
/*!
 *  Add Component Constrains
 */
- (void)addConstrains {
    NSDictionary *dict = @{
                           @"unitTextLabel" : self.unitTextLabel,
                           @"descriptionTextLabel" : self.descriptionTextLabel,
                           @"endMarkerImageView" : self.endMarkerImageView,
                           @"barBackgroundView" : self.barBackgroundView,
                           @"progressBarView" : self.progressBarView,
                           };
    NSDictionary *metrics = @{ @"endMarkerImageViewWidth" : @(ANNOTATION_IMAGE_VIEW_WIDTH), @"progressBarHeight" : @(PROGRESS_BAR_HEIGHT) };
    unitLabelConstaraintArr = [NSLayoutConstraint constraintsWithVisualFormat:@"H:|[unitTextLabel]-4-[endMarkerImageView(endMarkerImageViewWidth)]"
                                                                      options:0
                                                                      metrics:metrics
                                                                        views:dict];
        //[self addConstraints:unitLabelConstaraintArr];
        //[self addConstraints:[NSLayoutConstraint constraintsWithVisualFormat:@"H:|[unitTextLabel]-4-[endMarkerImageView(endMarkerImageViewWidth)]"
        // options:0 metrics:metrics views:dict]];
        //[self addConstraintForSameWidth:self.descriptionTextLabel toItem:self.unitTextLabel];
        //[self addConstraintForCenterX:self.descriptionTextLabel toItem:self.unitTextLabel];
    [self addConstraints:[NSLayoutConstraint constraintsWithVisualFormat:@"H:|[barBackgroundView]|" options:0 metrics:metrics views:dict]];
    [self addConstraints:[NSLayoutConstraint
                          constraintsWithVisualFormat:@"V:|[descriptionTextLabel][unitTextLabel]-5-[barBackgroundView(progressBarHeight)]"
                          options:0
                          metrics:metrics
                          views:dict]];
    [self addConstraints:[NSLayoutConstraint constraintsWithVisualFormat:@"H:|[progressBarView]" options:0 metrics:metrics views:dict]];
    [self.barBackgroundView addConstraints:[NSLayoutConstraint constraintsWithVisualFormat:@"V:|[progressBarView]|" options:0 metrics:nil views:dict]];
    _progressBarViewWidthConstraint = [NSLayoutConstraint width:self.progressBarView toItem:self.barBackgroundView multiplier:0 constant:0];
    [self.barBackgroundView addConstraint:_progressBarViewWidthConstraint];
        //	[self addConstraint:NSLayoutAttributeWidth item:self.descriptionTextLabel toItem:self.progressBarView withMultiplier:1
        // andConstant:-(4+ANNOTATION_IMAGE_VIEW_WIDTH/2)];
        //	[self addConstraintForSameButtom:self.endMarkerImageView toItem:self.unitTextLabel];
    [self addConstraints:[NSLayoutConstraint constraintsWithVisualFormat:@"V:[endMarkerImageView(15)]" options:0 metrics:nil views:dict]];
}
- (void)updateProgressBarViewWidthConstraint:(float)multiplier {
    if (_progressBarViewWidthConstraint)
        [self.barBackgroundView removeConstraint:_progressBarViewWidthConstraint];
    if (_unitTextLabelWidthConstraint) {
        [self removeConstraint:_unitTextLabelWidthConstraint];
    }
    if (_endMarkerImageViewButtomconstraint) {
        [self removeConstraint:_endMarkerImageViewButtomconstraint];
    }
    _progressBarViewWidthConstraint = [NSLayoutConstraint width:self.progressBarView toItem:self.barBackgroundView multiplier:multiplier constant:0];
    [self.barBackgroundView addConstraint:_progressBarViewWidthConstraint];
    _endMarkerImageViewButtomconstraint = [NSLayoutConstraint constraintWithItem:self.endMarkerImageView
                                                                       attribute:NSLayoutAttributeBottom
                                                                       relatedBy:NSLayoutRelationEqual
                                                                          toItem:self.barBackgroundView
                                                                       attribute:NSLayoutAttributeTop
                                                                      multiplier:1
                                                                        constant:_multiplier < 1 ? 0 : 2];
    [self addConstraint:_endMarkerImageViewButtomconstraint];
    [self layoutIfNeeded];
    NSDictionary *dict = @{
                           @"unitTextLabel" : self.unitTextLabel,
                           @"descriptionTextLabel" : self.descriptionTextLabel,
                           @"endMarkerImageView" : self.endMarkerImageView,
                           @"barBackgroundView" : self.barBackgroundView,
                           @"progressBarView" : self.progressBarView
                           };
    NSDictionary *metrics = @{
                              @"endMarkerImageViewWidth" : @(ANNOTATION_IMAGE_VIEW_WIDTH),
                              @"endMarkerPadding" : @(-ANNOTATION_IMAGE_VIEW_WIDTH / 2),
                              @"progressBarHeight" : @(PROGRESS_BAR_HEIGHT)
                              };

        // Text In Left side of Marker
    if ([self.progressAmount intValue] <= 25) {
        [self addConstraints:[NSLayoutConstraint
                              constraintsWithVisualFormat:
                              @"H:|[progressBarView]-(endMarkerPadding)-[endMarkerImageView(endMarkerImageViewWidth)]-4-[unitTextLabel]"
                              options:0
                              metrics:metrics
                              views:dict]];
        [self.unitTextLabel setTextAlignment:NSTextAlignmentLeft];
        [self.descriptionTextLabel setTextAlignment:NSTextAlignmentLeft];
    } else {
            // Text In Right side of Marker

        [self addConstraints:[NSLayoutConstraint constraintsWithVisualFormat:@"H:|[unitTextLabel]-4-[endMarkerImageView(endMarkerImageViewWidth)]"
                                                                     options:0
                                                                     metrics:metrics
                                                                       views:dict]];
        [self addConstraint:NSLayoutAttributeWidth
                       item:self.descriptionTextLabel
                     toItem:self.progressBarView
             withMultiplier:1
                andConstant:_multiplier < 1 ? -(4 + ANNOTATION_IMAGE_VIEW_WIDTH / 2) : -(7 + ANNOTATION_IMAGE_VIEW_WIDTH / 2)];
        [self.unitTextLabel setTextAlignment:NSTextAlignmentRight];
        [self.descriptionTextLabel setTextAlignment:NSTextAlignmentRight];
    }
    [self addConstraintForSameWidth:self.descriptionTextLabel toItem:self.unitTextLabel];
    [self addConstraintForCenterX:self.descriptionTextLabel toItem:self.unitTextLabel];
    [self setNeedsUpdateConstraints];
}
- (void)setUnitName:(NSString *)unitName {
    _unitName = unitName;

    NSString *unitNameTemp = nil;

    if (self.unitName && [self.unitName isEqualToString:@"%"]) {
        unitNameTemp = [NSString stringWithFormat:@"%@", self.progressDisplayText];
    } else {
        if (self.progressAmountRaw.doubleValue < 0.0) {
            unitNameTemp = [NSString stringWithFormat:@"%@ %@", self.progressDisplayText, _unitName.length ? _unitName : STATIC_TEXT_EMPTY_STRING];
        } else {
            if (self.progressAmountRaw.doubleValue < 1.0) {
                unitNameTemp = [NSString stringWithFormat:@"%@ %@", self.progressDisplayText, _unitName.length ? _unitName : STATIC_TEXT_EMPTY_STRING];
            } else {
                unitNameTemp = [NSString stringWithFormat:@"%@ %@", self.progressDisplayText, _unitName.length ? _unitName : STATIC_TEXT_EMPTY_STRING];
            }
        }
    }
    _unitTextLabel.text = unitNameTemp;
}
- (void)___setUnitName:(NSString *)unitName {
    _unitName = unitName;
    NSString *unitNameTemp = nil;
    if (self.unitName && [self.unitName isEqualToString:@"%"]) {
        unitNameTemp =
        [NSString stringWithFormat:@"%.2f %@", self.progressAmountRaw.doubleValue, self.unitName.length ? self.unitName : STATIC_TEXT_EMPTY_STRING];
    } else {
        if (self.progressAmountRaw.doubleValue < 0.0) {
            unitNameTemp =
            [NSString stringWithFormat:@"%.2f %@", self.progressAmountRaw.doubleValue, _unitName.length ? _unitName : STATIC_TEXT_EMPTY_STRING];
        } else {
            if (self.progressAmountRaw.doubleValue < 1.0) {
                unitNameTemp =
                [NSString stringWithFormat:@"%.2f %@", self.progressAmountRaw.doubleValue, _unitName.length ? _unitName : STATIC_TEXT_EMPTY_STRING];
            } else {
                unitNameTemp =
                [NSString stringWithFormat:@"%.0f %@", self.progressAmountRaw.doubleValue, _unitName.length ? _unitName : STATIC_TEXT_EMPTY_STRING];
            }
        }
    }
    _unitTextLabel.text = unitNameTemp;
}

#pragma mark - Public Method
- (void)setProgressAmount:(NSNumber *)progressAmount {
    _progressAmount = progressAmount;
    _progressAmountRaw = progressAmount;
    if (!_progressBarViewWidthConstraint || !self.maxRange || !self.minRange)
        return;
    _multiplier = (_progressAmount.doubleValue) / (self.maxRange.doubleValue - self.minRange.doubleValue);
    NSLog(@"%f", _multiplier);
    _multiplier = MAX(0, _multiplier);
    _multiplier = MIN(1, _multiplier);
    [self updateProgressBarViewWidthConstraint:_multiplier];
}
- (void)setProgressStatusColorName:(NSString *)progressStatusColorName {
    _progressStatusColorName = progressStatusColorName;
    self.progressBarView.backgroundColor = [UIColor colorForIncentiveProgress:_progressStatusColorName];
}
- (void)setBarBackGroundColor:(UIColor *)barBackGroundColor {
    _barBackGroundColor = barBackGroundColor;
    self.barBackgroundView.backgroundColor = _barBackGroundColor;
}
- (void)setUnitTextFont:(UIFont *)unitTextFont {
    _unitTextFont = unitTextFont;
    if (_unitTextLabel) {
        _unitTextLabel.font = _unitTextFont;
    }
}
- (void)setUnitTextColor:(UIColor *)unitTextColor {
    _unitTextColor = unitTextColor;
    if (_unitTextLabel) {
        _unitTextLabel.textColor = _unitTextColor;
    }
}
- (void)setDescriptionText:(NSString *)descriptionText {
    _descriptionText = descriptionText;
    if (_descriptionTextLabel) {
        _descriptionTextLabel.text = _descriptionText;
    }
}
- (void)setDescriptionTextFont:(UIFont *)descriptionTextFont {
    _descriptionTextFont = descriptionTextFont;
    if (_descriptionTextLabel) {
        _descriptionTextLabel.font = descriptionTextFont;
    }
}
- (void)setDescriptionTextColor:(UIColor *)descriptionTextColor {
    _descriptionTextColor = descriptionTextColor;
    if (_descriptionTextLabel) {
        _descriptionTextLabel.textColor = _descriptionTextColor;
    }
}
    // Test
@end
