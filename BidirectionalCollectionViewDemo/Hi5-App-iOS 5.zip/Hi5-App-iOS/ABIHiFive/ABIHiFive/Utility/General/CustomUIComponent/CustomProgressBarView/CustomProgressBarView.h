    //
    //  CustomProgressBarView.h
    //  ABIHiFive
    //
    //  Created by Prsenjit Goswami on 29/06/16.
    //  Copyright © 2016 Cognizant. All rights reserved.
    //
#import <UIKit/UIKit.h>
@interface CustomProgressBarView : UIView
@property (strong, nonatomic) NSNumber *minRange;
@property (strong, nonatomic) NSNumber *maxRange;
@property (strong, nonatomic) NSNumber *progressAmount;
@property (strong, nonatomic) NSNumber *progressAmountRaw;
@property (strong, nonatomic) NSString *unitName;
@property (strong, nonatomic) NSString *progressDisplayText;
@property (strong, nonatomic) NSString *descriptionText;
@property (strong, nonatomic) UIColor *unitTextColor;
@property (strong, nonatomic) UIColor *descriptionTextColor;
@property (strong, nonatomic) UIFont *descriptionTextFont;
@property (strong, nonatomic) UIFont *unitTextFont;
@property (readonly, assign, nonatomic) float multiplier;
@property (nonatomic, strong) NSString *progressStatusColorName;
@end
