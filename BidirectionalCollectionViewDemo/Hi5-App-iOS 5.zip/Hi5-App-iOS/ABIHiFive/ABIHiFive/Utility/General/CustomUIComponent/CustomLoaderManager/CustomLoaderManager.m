    //
    //  CustomLoaderManager.m
    //  ABIHiFive
    //
    //  Created by Prsenjit Goswami on 28/07/16.
    //  Copyright © 2016 Cognizant. All rights reserved.
    //

#import "CustomLoaderManager.h"
#import "Constants.h"
#import "HelperUtilHeader.h"
#import "ProgressHUD.h"

@implementation CustomLoaderManager

static CustomLoaderManager *sharedInstance = nil;
static ProgressHUD *hud = nil;
static UIWindow *window = nil;
- (CustomLoaderManager *)sharedInstance {

    if (!sharedInstance) {
        sharedInstance = [[CustomLoaderManager alloc] init];
        window = [UIApplication sharedApplication].keyWindow;
    }
    return sharedInstance;
}

/*!
 *  Show Loader
 */
+ (ProgressHUD *)showLoader {
    dispatch_main_async_safeBlock(^{
        if (!hud) {
            window = [UIApplication sharedApplication].keyWindow;
            hud = [ProgressHUD showHUDAddedTo:window animated:YES];
            hud.removeFromSuperViewOnHide = YES;
            [CustomLoaderManager defaultFeature];
        }
        [hud show:YES];
    });

    return hud;
}
/*!
 *  Hide Loader
 */
+ (void)hideLoader {

    dispatch_main_async_safeBlock(^{

        if (hud) {
            [hud hide:YES];
        }
        [ProgressHUD allHUDsForView:window];

        hud = nil;
    });
}
+ (void)hideLoaderOnDelay:(NSTimeInterval)delay completion:(void (^)(void))completion {
    [NSObject performInMainThreadAfterDelay:delay
                                 completion:^{
                                     [CustomLoaderManager hideLoader];
                                     if (completion)
                                         completion();
                                 }];
}

+ (ProgressHUD *)showFlashWithMessage:(NSString *)message {

    [CustomLoaderManager hideLoader];
    if (!hud) {
        hud = [ProgressHUD flashWithMessage:message onView:window forInterVal:FLASH_MESSAGE_DISPLAY_TIME];
        [CustomLoaderManager defaultFeature];
    }

    return hud;
}
#pragma mark - Private Method
+ (void)defaultFeature {

    if (hud) {

        [hud setMinShowTime:0.3];
    }
}

@end
