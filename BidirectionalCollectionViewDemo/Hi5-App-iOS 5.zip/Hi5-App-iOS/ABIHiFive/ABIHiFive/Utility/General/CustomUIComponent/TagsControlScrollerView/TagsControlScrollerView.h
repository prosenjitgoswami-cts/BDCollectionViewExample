    //
    //  TagsControlScrollerView.h
    //  ABIHiFive
    //
    //  Created by Prsenjit Goswami on 01/08/16.
    //  Copyright © 2016 Cognizant. All rights reserved.
    //
#import <UIKit/UIKit.h>
@class TagsControlScrollerView;
@protocol TagsControlScrollerViewDelegate <NSObject>
@optional
- (void)tagsControl:(TagsControlScrollerView *)tagsControl tappedAtIndex:(NSInteger)index;
- (void)deleteItems:(NSInteger)index;
@end
typedef NS_ENUM(NSUInteger, TagsControlScrollerViewMode) {
    TagsControlScrollerViewModeEdit,
    TagsControlScrollerViewModeList,
};
@interface TagsControlScrollerView : UIScrollView
@property (nonatomic, strong) NSMutableArray *tags;
@property (nonatomic, strong) NSMutableArray *tagsInObject;
@property (nonatomic, strong) UIColor *tagsBackgroundColor;
@property (nonatomic, strong) UIColor *tagsTextColor;
@property (nonatomic, strong) UIColor *tagsDeleteButtonColor;
@property (nonatomic, strong) NSString *tagPlaceholder;
@property (nonatomic) TagsControlScrollerViewMode mode;
@property (assign, nonatomic) id<TagsControlScrollerViewDelegate> tapDelegate;
- (id)initWithFrame:(CGRect)frame andTags:(NSArray *)tags withTagsControlMode:(TagsControlScrollerViewMode)mode;
- (void)addTag:(NSString *)tag;
- (void)reloadTagSubviews;
@end