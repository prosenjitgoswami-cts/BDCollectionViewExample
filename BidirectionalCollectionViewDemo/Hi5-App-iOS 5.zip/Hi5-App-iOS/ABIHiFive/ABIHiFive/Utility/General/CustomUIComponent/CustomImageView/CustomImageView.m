    //
    //  CustomImageView.m
    //  ABIHiFive
    //
    //  Created by Prsenjit Goswami on 01/08/16.
    //  Copyright © 2016 Cognizant. All rights reserved.
    //
#import "CustomImageView.h"
#import "Constants.h"
@interface CustomImageView ()
@property (strong, nonatomic) UIActivityIndicatorView *activityIndicatorView;
@end
@implementation CustomImageView

#pragma mark -  Private method
- (void)createAndAddUI {
    if (_activityIndicatorView) {
        [_activityIndicatorView removeFromSuperview];
        _activityIndicatorView = nil;
    }
    [self addSubview:self.activityIndicatorView];
    [self addConstraint:[NSLayoutConstraint constraintWithItem:self.activityIndicatorView
                                                     attribute:NSLayoutAttributeCenterX
                                                     relatedBy:NSLayoutRelationEqual
                                                        toItem:self
                                                     attribute:NSLayoutAttributeCenterX
                                                    multiplier:1
                                                      constant:0]];
    [self addConstraint:[NSLayoutConstraint constraintWithItem:self.activityIndicatorView
                                                     attribute:NSLayoutAttributeCenterY
                                                     relatedBy:NSLayoutRelationEqual
                                                        toItem:self
                                                     attribute:NSLayoutAttributeCenterY
                                                    multiplier:1
                                                      constant:0]];
}
- (UIActivityIndicatorView *)activityIndicatorView {
    if (!_activityIndicatorView) {
        _activityIndicatorView = [[UIActivityIndicatorView alloc] initWithActivityIndicatorStyle:UIActivityIndicatorViewStyleGray];
        _activityIndicatorView.translatesAutoresizingMaskIntoConstraints = NO;
    }
    _activityIndicatorView.hidden = YES;
    return _activityIndicatorView;
}
- (void)setIsIndicatorShown:(BOOL)isIndicatorShown {
    _isIndicatorShown = isIndicatorShown;
    [self createAndAddUI];
    [self startAnimating];
}
- (void)startAnimating {
    _activityIndicatorView.hidden = NO;
    if (_activityIndicatorView)
        [_activityIndicatorView startAnimating];
}
- (void)stopAnimating {
    if (_activityIndicatorView)
        [_activityIndicatorView stopAnimating];
    _activityIndicatorView.hidden = YES;
}
- (void)dealloc {
    if (_activityIndicatorView)
        [_activityIndicatorView removeFromSuperview];
    _activityIndicatorView = nil;
}
@end
