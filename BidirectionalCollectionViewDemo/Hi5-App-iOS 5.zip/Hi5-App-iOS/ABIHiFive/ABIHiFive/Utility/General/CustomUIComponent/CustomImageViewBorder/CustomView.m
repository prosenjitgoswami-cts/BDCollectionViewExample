    //
    //  CustomView.m
    //  SamplePopoveriPhone
    //
    //  Created by IR Mac Mini on 28/07/16.
    //  Copyright © 2016 IR Mac Mini. All rights reserved.
    //
#import "CustomView.h"
@implementation CustomView {
    UIImageView *outerImageView, *innerImageView;
        // UIImage *outerImage;
    CGSize viewSize;
    CGFloat padding;
}
- (id)initWithImage:(UIImage *)image andOuterImage:(UIImage *)_outerimage andSize:(CGSize)_viewSize andPaddingForInnerView:(CGFloat)_padding;
{
    self = [super init];
    if (self) {
        viewSize = _viewSize;
        padding = _padding;
        self.image = image;
        self.outerImage = _outerimage;
        self.translatesAutoresizingMaskIntoConstraints = NO;
        [self configureUI];
        [self populateUI];
        [self updateParentConstraint:padding andLeft:padding];
        CGFloat cornerRadius = (_viewSize.width - (_padding * 2)) / 2;
        innerImageView.layer.cornerRadius = cornerRadius;
    }
    return self;
}
- (void)configureUI {

    if (!innerImageView) {
        innerImageView = [UIImageView new];
        innerImageView.translatesAutoresizingMaskIntoConstraints = NO;
        [self addSubview:innerImageView];
        innerImageView.clipsToBounds = YES;
        self.innerUserImageView = innerImageView;
    }
    if (!outerImageView) {
        outerImageView = [UIImageView new];
        outerImageView.translatesAutoresizingMaskIntoConstraints = NO;
        [self addSubview:outerImageView];
    }
}
- (void)updateParentConstraint:(CGFloat)top andLeft:(CGFloat)left {
    NSDictionary *metrics = @{
                              @"height" : @(viewSize.height),
                              @"width" : @(viewSize.width),
                              @"innerWidth" : @(viewSize.width - (padding * 2)),
                              @"innerHeight" : @(viewSize.height - (padding * 2)),
                              @"padding" : @(padding),
                              @"left" : @(left),
                              @"top" : @(top)
                              };
    NSDictionary *views = NSDictionaryOfVariableBindings(self, innerImageView, outerImageView);
    [self addConstraints:[NSLayoutConstraint constraintsWithVisualFormat:@"H:|[outerImageView]|" options:0 metrics:metrics views:views]];

    [self addConstraints:[NSLayoutConstraint constraintsWithVisualFormat:@"V:|[outerImageView]|" options:0 metrics:metrics views:views]];

    [self addConstraints:[NSLayoutConstraint constraintsWithVisualFormat:@"H:[innerImageView(innerWidth)]" options:0 metrics:metrics views:views]];
    [self addConstraints:[NSLayoutConstraint constraintsWithVisualFormat:@"V:[innerImageView(innerWidth)]" options:0 metrics:metrics views:views]];
    [self addConstraint:[NSLayoutConstraint constraintWithItem:innerImageView
                                                     attribute:NSLayoutAttributeCenterX
                                                     relatedBy:NSLayoutRelationEqual
                                                        toItem:self
                                                     attribute:NSLayoutAttributeCenterX
                                                    multiplier:1
                                                      constant:0]];

    [self addConstraint:[NSLayoutConstraint constraintWithItem:innerImageView
                                                     attribute:NSLayoutAttributeCenterY
                                                     relatedBy:NSLayoutRelationEqual
                                                        toItem:self
                                                     attribute:NSLayoutAttributeCenterY
                                                    multiplier:1
                                                      constant:0]];
}

- (void)populateUI {
    [outerImageView setImage:self.outerImage];
    [innerImageView setImage:self.image];
    innerImageView.clipsToBounds = YES;
}
- (void)setImage:(UIImage *)image {
    _image = image;
    [innerImageView setImage:self.image];
}
- (void)layoutSubviews {
    innerImageView.layer.cornerRadius = (viewSize.width - (padding * 2)) / 2;
}
@end
