    //
    //  IncentiveHintView.h
    //  ABIHiFive
    //
    //  Created by Prsenjit Goswami on 08/07/16.
    //  Copyright © 2016 Cognizant. All rights reserved.
    //
#import <UIKit/UIKit.h>
@interface IncentiveHintView : UIView
@property (weak, nonatomic) IBOutlet UIImageView *exceededIndicatorImageVIew;
@property (weak, nonatomic) IBOutlet UIImageView *miniumIndicatorImageVIew;
@property (weak, nonatomic) IBOutlet UIImageView *veryLowIndicatorImageVIew;
@property (weak, nonatomic) IBOutlet UILabel *exceededIndicatorLabel;
@property (weak, nonatomic) IBOutlet UILabel *minimumIndicatorLabel;
@property (weak, nonatomic) IBOutlet UILabel *veryLessIndicatorLabel;
@end
