    //
    //  DropDownTableViewCell.m
    //  popOverlay
    //
    //  Created by KolkataMobility Mac Mini 11 on 16/08/16.
    //  Copyright © 2016 KolkataMobility Mac Mini 11. All rights reserved.
    //
#import "DropDownTableViewCell.h"
@interface DropDownTableViewCell ()
@property (strong, nonatomic) UILabel *lblHeader;
@property (strong, nonatomic) UIButton *btnCheck;
@property (strong, nonatomic) UIView *seperatorLine;
@end
@implementation DropDownTableViewCell
- (id)initWithStyle:(UITableViewCellStyle)style
    reuseIdentifier:(NSString *)reuseIdentifier
   dropDownListType:(DropDownListType)dropDownListType
     displayTextKey:(NSString *)displayTextKey {
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if (self) {
        self.separatorInset = UIEdgeInsetsZero;
        self.layoutMargins = UIEdgeInsetsZero;
        self.selectionStyle = UITableViewCellSelectionStyleNone;
        self.dropDownListType = dropDownListType;
        self.displayTextKey = displayTextKey;
        [self designCheckCustomCell];
    }
    return self;
}

#pragma mark -  Public Method
- (void)setTitleLabelText:(NSString *)titleLabelText {
    _titleLabelText = titleLabelText;
    _lblHeader.textAlignment = NSTextAlignmentLeft;
    self.lblHeader.text = titleLabelText;
}
- (void)isSelected:(BOOL)isSelected {
    _btnCheck.hidden = !isSelected;
}

- (void)updateCell:(id)cellModel selected:(BOOL)selected {
    if (cellModel) {
        self.titleLabelText = [NSString textForKey:self.displayTextKey object:cellModel];
        [self isSelected:selected];
    }
}
- (void)setCheckMarkImage:(UIImage *)checkMarkImage {
    _checkMarkImage = checkMarkImage;
    [_btnCheck setImage:_checkMarkImage forState:UIControlStateNormal];
    [self layoutIfNeeded];
}
- (void)setTextColor:(UIColor *)textColor {
    _textColor = textColor;
    _lblHeader.textColor = _textColor;
    [self layoutIfNeeded];
}
- (void)setTextFont:(UIFont *)textFont {
    _textFont = textFont;
    _lblHeader.font = _textFont;
    [self layoutIfNeeded];
}

#pragma mark -  Private Method
- (UIView *)seperatorLine {
    if (!_seperatorLine) {
        _seperatorLine = [UIView new];
        _seperatorLine.backgroundColor = [UIColor veryLightGreySeperator];
        _seperatorLine.translatesAutoresizingMaskIntoConstraints = NO;
    }
    return _seperatorLine;
}
- (void)designCheckCustomCell {
    _btnCheck = [UIButton buttonWithType:UIButtonTypeCustom];
    [_btnCheck setImage:[UIImage imageNamed:@"tickMark"] forState:UIControlStateNormal];
    _btnCheck.translatesAutoresizingMaskIntoConstraints = NO;
    _btnCheck.hidden = YES;
    _lblHeader = [self createLabel:CGRectMake(55, 0, 100, 40) withTitle:nil withFont:nil withTag:3];
    _lblHeader.textColor = [UIColor blackColor];
    _lblHeader.translatesAutoresizingMaskIntoConstraints = NO;
    _lblHeader.font = [UIFont defaultTextFontABI];
    _lblHeader.textColor = [UIColor darkTextColor];
    [self.contentView addSubview:_lblHeader];
    [self.contentView addSubview:_btnCheck];
    [self.contentView addSubview:self.seperatorLine];
    NSDictionary *views = @{ @"btnCheck" : _btnCheck, @"lblHeader" : _lblHeader, @"seperatorLine" : self.seperatorLine };
    [self.contentView
     addConstraints:[NSLayoutConstraint constraintsWithVisualFormat:@"H:|-15-[btnCheck(20)]-[lblHeader]|" options:0 metrics:nil views:views]];
    [self.contentView addConstraints:[NSLayoutConstraint constraintsWithVisualFormat:@"V:[btnCheck(20)]" options:0 metrics:nil views:views]];
    [self.contentView addConstraints:[NSLayoutConstraint constraintsWithVisualFormat:@"V:[seperatorLine(1)]|" options:0 metrics:nil views:views]];
        //	if(self.dropDownListType == DropDownListYear) {
        //
        //		[self.contentView addConstraint:[NSLayoutConstraint constraintWithItem:self.seperatorLine attribute:NSLayoutAttributeWidth
        // relatedBy:NSLayoutRelationEqual toItem:self.contentView attribute:NSLayoutAttributeWidth multiplier:0.7 constant:0]];
        //
        //			// Horizontally Centre _btnCheck and _lblHeader
        //
        //		[self.contentView addConstraint:[NSLayoutConstraint constraintWithItem:self.seperatorLine attribute:NSLayoutAttributeCenterX
        // relatedBy:NSLayoutRelationEqual toItem:_lblHeader attribute:NSLayoutAttributeCenterX multiplier:1 constant:0]];
        //	} else{
    {
    [self.contentView addConstraints:[NSLayoutConstraint constraintsWithVisualFormat:@"H:|-4-[seperatorLine]-4-|" options:0 metrics:nil views:views]];
    }
        // Vartically Centre _btnCheck and contain view
    [self.contentView addConstraint:[NSLayoutConstraint constraintWithItem:_btnCheck
                                                                 attribute:NSLayoutAttributeCenterY
                                                                 relatedBy:NSLayoutRelationEqual
                                                                    toItem:self.contentView
                                                                 attribute:NSLayoutAttributeCenterY
                                                                multiplier:1
                                                                  constant:0]];
        // Vartically Centre _btnCheck and _lblHeader
    [self.contentView addConstraint:[NSLayoutConstraint constraintWithItem:_lblHeader
                                                                 attribute:NSLayoutAttributeCenterY
                                                                 relatedBy:NSLayoutRelationEqual
                                                                    toItem:_btnCheck
                                                                 attribute:NSLayoutAttributeCenterY
                                                                multiplier:1
                                                                  constant:0]];
}
- (UILabel *)createLabel:(CGRect)rect withTitle:(NSString *)strTitle withFont:(UIFont *)font withTag:(NSInteger)tag {
    UILabel *lblCustom = [[UILabel alloc] initWithFrame:rect];
    lblCustom.backgroundColor = [UIColor clearColor];
    lblCustom.textAlignment = NSTextAlignmentLeft;
    lblCustom.font = font;
    lblCustom.textColor = [UIColor defaultTextLightColor];
    lblCustom.tag = tag;
    lblCustom.text = strTitle;
    return lblCustom;
}
@end
