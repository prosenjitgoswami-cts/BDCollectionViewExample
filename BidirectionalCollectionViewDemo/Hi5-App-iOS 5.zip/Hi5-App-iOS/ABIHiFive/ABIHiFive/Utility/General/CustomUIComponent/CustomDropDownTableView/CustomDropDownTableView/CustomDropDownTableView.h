    //
    //  ABIDropDownComponentView.h
    //  popOverlay
    //
    //  Created by Prsenjit Goswami on 18/08/16.
    //  Copyright © 2016 KolkataMobility Mac Mini 11. All rights reserved.
    //
#import "Constants.h"
#import <UIKit/UIKit.h>
@class DropDownListDataModel;
typedef void (^SelectedCallBack)(id selectedDataModel, NSIndexPath *indexPath);
@interface CustomDropDownTableView : UIView
@property (strong, nonatomic) NSMutableArray *dataSources;
@property (assign, nonatomic) DropDownListType dropDownListType;
@property (assign, nonatomic) NSInteger selectedIndex;
@property (strong, nonatomic) NSString *displayTextKey;
@property (assign, nonatomic) BOOL isBadge;

- (instancetype)initWithData:(NSMutableArray *)dataSource dropDownListType:(DropDownListType)dropDownListType;
- (void)showPopOverInView:(UIView *)view completion:(SelectedCallBack)selectedCallBack;
@end
