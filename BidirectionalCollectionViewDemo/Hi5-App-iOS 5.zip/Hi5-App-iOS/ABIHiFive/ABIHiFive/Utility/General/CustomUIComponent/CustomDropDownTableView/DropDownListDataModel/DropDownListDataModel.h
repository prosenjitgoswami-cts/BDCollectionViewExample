    //
    //  DropDownListDataModel.h
    //  popOverlay
    //
    //  Created by KolkataMobility Mac Mini 11 on 16/08/16.
    //  Copyright © 2016 KolkataMobility Mac Mini 11. All rights reserved.
    //
#import <Foundation/Foundation.h>
@interface DropDownListDataModel : NSObject
@property (strong, nonatomic) NSString *title;
@property (assign, nonatomic) BOOL isSelected;
@property (assign, nonatomic) NSInteger index;
@property (strong, nonatomic) NSString *ID;
@property (strong, nonatomic) NSNumber *priority;
+ (DropDownListDataModel *)inatialished:(BOOL)isSelected title:(NSString *)title index:(NSInteger)index;
@end
