
#import <UIKit/UIKit.h>
@protocol CustomTabScrollDelegate;
@interface CustomTabScrollView : UIScrollView
@property (weak, nonatomic) id<CustomTabScrollDelegate> tabScrollDelegate;
- (instancetype)initWithFrame:(CGRect)frame
                     tabViews:(NSArray *)tabViews
                 tabBarHeight:(CGFloat)height
                     tabColor:(UIColor *)color
              backgroundColor:(UIColor *)backgroundColor
             selectedTabIndex:(NSInteger)index;
- (instancetype)initWithFrame:(CGRect)frame
                     tabViews:(NSArray *)tabViews
                 tabBarHeight:(CGFloat)height
                     tabColor:(UIColor *)color
              backgroundColor:(UIColor *)backgroundColor;
- (void)animateToTabAtIndex:(NSInteger)index;
- (void)animateToTabAtIndex:(NSInteger)index animated:(BOOL)animated;
@end
@protocol CustomTabScrollDelegate <NSObject>
- (void)tabScrollView:(CustomTabScrollView *)tabScrollView didSelectTabAtIndex:(NSInteger)index;
@end
