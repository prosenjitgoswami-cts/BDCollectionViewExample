
#import "CustomTabPagerViewController.h"
#import "Constants.h"
#import "CustomTabScrollView.h"
#pragma mark - CustomTabPagerView
#pragma mark -
@interface CustomTabPagerView () {
}
@property (nonatomic, strong, readwrite) CustomTabPagerViewController *tabPageViewController;
@property (nonatomic, weak) id delegate;
@end
@implementation CustomTabPagerView
- (void)dealloc {
    _tabPageViewController.delegate = nil;
    _tabPageViewController.dataSource = nil;
    _tabPageViewController = nil;
}
#pragma mark - Public Method
- (void)repositionTab:(NSInteger)index {
    [_tabPageViewController repositionTab:index];
}
- (void)initialisedTabPageViewController:(id)target {
    self.delegate = target;
    [self addSubview:self.tabPageViewController.view];
    [self addConstrains];
}
- (void)addConstrains {
    NSDictionary *views = @{ @"tabPageViewController" : self.tabPageViewController.view };
    [self addConstraints:[NSLayoutConstraint constraintsWithVisualFormat:@"H:|[tabPageViewController]|" options:0 metrics:nil views:views]];
    [self addConstraints:[NSLayoutConstraint constraintsWithVisualFormat:@"V:|[tabPageViewController]|" options:0 metrics:nil views:views]];
}
- (CustomTabPagerViewController *)tabPageViewController {
    if (!_tabPageViewController) {
        _tabPageViewController = [CustomTabPagerViewController initialisedTabPageViewController:self.delegate];
    }
    return _tabPageViewController;
}
- (void)reloadData {
    [self.tabPageViewController reloadData];
}
@end
#pragma mark - CustomTabPagerViewController
#pragma mark -
@interface CustomTabPagerViewController () <CustomTabScrollDelegate, UIPageViewControllerDataSource, UIPageViewControllerDelegate>
@property (strong, nonatomic) UIPageViewController *pageViewController;
@property (strong, nonatomic) UIView *hintView;
@property (strong, nonatomic) UIImageView *backGroundImageView;
@property (strong, nonatomic) CustomTabScrollView *header;
@property (assign, nonatomic) NSInteger selectedIndex;
@property (strong, nonatomic) NSMutableArray *viewControllers;
@property (strong, nonatomic) NSMutableArray *tabTitles;
@property (strong, nonatomic) UIColor *headerColor;
@property (strong, nonatomic) UIColor *tabBackgroundColor;
@property (assign, nonatomic) CGFloat headerHeight;
@property (strong, nonatomic) NSMutableArray *tabViews;
@property (strong, nonatomic) NSArray *headerHeightConstrants;
@end
@implementation CustomTabPagerViewController
+ (CustomTabPagerViewController *)initialisedTabPageViewController:(id)target {
    CustomTabPagerViewController *tabPageViewController = [[CustomTabPagerViewController alloc] init];
    tabPageViewController.view.translatesAutoresizingMaskIntoConstraints = NO;
    [tabPageViewController setDataSource:target];
    [tabPageViewController setDelegate:target];
    return tabPageViewController;
}
- (void)allUIHidden:(BOOL)isHidden {
    if (_hintView)
        _hintView.hidden = isHidden;
    if (_header)
        _header.hidden = isHidden;
    if (_backGroundImageView)
        _backGroundImageView.hidden = isHidden;
    if (_backGroundImageView)
        _backGroundImageView.hidden = isHidden;
    if (_pageViewController)
        _pageViewController.view.hidden = isHidden;
}
- (void)show {
    [self allUIHidden:NO];
}
- (void)hide {
    [self allUIHidden:YES];
}
- (void)viewDidLoad {
    [super viewDidLoad];
    [self configureUI];
}
- (void)viewDidAppear:(BOOL)animated {
    [super viewDidAppear:animated];
}
- (void)willAnimateRotationToInterfaceOrientation:(UIInterfaceOrientation)toInterfaceOrientation duration:(NSTimeInterval)duration {
    [self reloadTabs];
}
- (void)dealloc {
    _pageViewController = nil;
    _hintView = nil;
    _backGroundImageView = nil;
    [_viewControllers removeAllObjects];
    _viewControllers = nil;
    [_tabTitles removeAllObjects];
    _tabTitles = nil;
    _headerColor = nil;
    _tabBackgroundColor = nil;
    _header = nil;
}
#pragma mark - Page View Data Source
- (UIViewController *)pageViewController:(UIPageViewController *)pageViewController
      viewControllerBeforeViewController:(UIViewController *)viewController {

    if ([NSArray isNullArray:self.viewControllers])
        return nil;

    NSInteger pageIndex = [self.viewControllers indexOfObject:viewController];

    if ([self.viewControllers indexOutOfBound:pageIndex])
        return nil;

    UIViewController *vc = [NSArray objectFromArray:self.viewControllers atIndex:(pageIndex - 1)];
    return pageIndex > 0 ? vc : nil;
}
- (UIViewController *)pageViewController:(UIPageViewController *)pageViewController
       viewControllerAfterViewController:(UIViewController *)viewController {

    if ([NSArray isNullArray:self.viewControllers])
        return nil;

    NSInteger pageIndex = [self.viewControllers indexOfObject:viewController];
    if ([self.viewControllers indexOutOfBound:pageIndex])
        return nil;

    UIViewController *vc = [NSArray objectFromArray:self.viewControllers atIndex:(pageIndex + 1)];
    return pageIndex < [self.viewControllers count] - 1 ? vc : nil;
}
#pragma mark - Page View Delegate
/*- (void)pageViewController:(UIPageViewController *)pageViewController willTransitionToViewControllers:(NSArray *)pendingViewControllers {

 if([NSArray isNullArray:self.viewControllers]) return;

 NSInteger index = [self.viewControllers indexOfObject:pendingViewControllers[0]];

 if([self.viewControllers indexOutOfBound:index]) return;

 [_header animateToTabAtIndex:index];
 if ([self.delegate respondsToSelector:@selector(tabPager:willTransitionToTabAtIndex:)]) {
 [self.delegate tabPager:self willTransitionToTabAtIndex:index];
 }
 }*/
- (void)pageViewController:(UIPageViewController *)pageViewController
        didFinishAnimating:(BOOL)finished
   previousViewControllers:(NSArray *)previousViewControllers
       transitionCompleted:(BOOL)completed {

    if ([NSArray isNullArray:self.viewControllers] || [NSArray isNullArray:self.pageViewController.viewControllers])
        return;

    NSInteger index = [self.viewControllers indexOfObject:[self.pageViewController viewControllers][0]];

    if ([self.viewControllers indexOutOfBound:index])
        return;

    if (index != self.selectedIndex) {
        [self setSelectedIndex:index];
        [self updateTextColorOnSelection];

        [self.header animateToTabAtIndex:[self selectedIndex]];

        if ([self.delegate respondsToSelector:@selector(tabPager:willTransitionToTabAtIndex:)]) {
            [self.delegate tabPager:self willTransitionToTabAtIndex:index];
        }
        if ([self.delegate respondsToSelector:@selector(tabPager:didTransitionToTabAtIndex:)]) {
            [self.delegate tabPager:self didTransitionToTabAtIndex:[self selectedIndex]];
        }
    }
}
- (void)updateTextColorOnSelection {
    if ([NSArray isNullArray:self.tabViews])
        return;

    UIColor *_deselectedTitleColor = [UIColor cyanColorABI];
    UIColor *_selectedTitleColor = [UIColor whiteColor];
    if (_dataSource && [_dataSource respondsToSelector:@selector(deselectedTitleColor)]) {
        _deselectedTitleColor = [_dataSource deselectedTitleColor];
    }
    if ([_dataSource respondsToSelector:@selector(titleColor)]) {
        _selectedTitleColor = [_dataSource titleColor];
    }
    for (int i = 0; i < self.tabViews.count; i++) {
        id _lbl = self.tabViews[i];
        if ([_lbl isKindOfClass:[UILabel class]]) {
            UILabel *lbl = (UILabel *)_lbl;
            lbl.textColor = _deselectedTitleColor;
        }
    }
    if (_deselectedTitleColor) {
        for (int i = 0; i < self.tabViews.count; i++) {
            id _lbl = self.tabViews[i];
            if ([_lbl isKindOfClass:[UILabel class]]) {
                UILabel *lbl = (UILabel *)_lbl;
                lbl.textColor = ([self selectedIndex] == i) ? _selectedTitleColor : _deselectedTitleColor;
            }
        }
    }
}
#pragma mark - Tab Scroll View Delegate
- (void)tabScrollView:(CustomTabScrollView *)tabScrollView didSelectTabAtIndex:(NSInteger)index {

    if ([NSArray isNullArray:self.viewControllers])
        return;
    if ([self.viewControllers indexOutOfBound:index])
        return;

    if (index != [self selectedIndex] && self.viewControllers.count > index) {

        if ([self.delegate respondsToSelector:@selector(tabPager:willTransitionToTabAtIndex:)]) {
            [self.delegate tabPager:self willTransitionToTabAtIndex:index];
        }
        __weak typeof(self) weakSelf = self;

        UIViewController *selectedVC = [NSArray objectFromArray:self.viewControllers atIndex:index];

        if (selectedVC) {

            [self.pageViewController setViewControllers:@[ selectedVC ]
                                              direction:(index > [weakSelf selectedIndex]) ? UIPageViewControllerNavigationDirectionForward
                                                       : UIPageViewControllerNavigationDirectionReverse
                                               animated:YES
                                             completion:^(BOOL finished) {
                                                 [weakSelf setSelectedIndex:index];
                                                 [weakSelf updateTextColorOnSelection];
                                                 if ([weakSelf.delegate respondsToSelector:@selector(tabPager:didTransitionToTabAtIndex:)]) {
                                                     [weakSelf.delegate tabPager:weakSelf didTransitionToTabAtIndex:[weakSelf selectedIndex]];
                                                 }
                                             }];
        }
    }
}
- (void)reloadData {
    self.viewControllers = [NSMutableArray array];
    self.tabTitles = [NSMutableArray array];

    if (self.hintView) {
        [_hintView removeFromSuperview];
        _hintView = nil;
    }

    for (int i = 0; i < [_dataSource numberOfViewControllers]; i++) {
        UIViewController *viewController;
        if ((viewController = [_dataSource viewControllerForIndex:i]) != nil) {
            [self.viewControllers addObject:viewController];
        }

        if ([_dataSource respondsToSelector:@selector(titleForTabAtIndex:)]) {
            NSString *title = nil;
            ;
            if ((title = [_dataSource titleForTabAtIndex:i]) != nil) {
                [self.tabTitles addObject:title];
            }
        }
    }

    if (self.viewControllers && self.viewControllers.count) {
        self.pageViewController.dataSource = self;
        self.pageViewController.delegate = self;
        _pageViewController.view.userInteractionEnabled = YES;

        if (self.viewControllers.count == 1) {
            for (UIScrollView *view in self.pageViewController.view.subviews) {
                if ([view isKindOfClass:[UIScrollView class]]) {
                    view.scrollEnabled = NO;
                }
            }
        }

        [self reloadTabs];
    } else {
        self.pageViewController.dataSource = nil;
        self.pageViewController.delegate = nil;
        _pageViewController.view.userInteractionEnabled = NO;
        if (_header) {
            [_header removeFromSuperview];
            _header = nil;
        }
        return;
    }
    CGRect frame = [self.view bounds];
    if (self.header)
        frame.origin.y = (self.header.frame.origin.y + self.header.frame.size.height);
    NSMutableDictionary *metrics = [NSMutableDictionary dictionary];
    [metrics setObject:@([self headerHeight]) forKey:@"headerHeight"];
    [metrics setObject:@(0) forKey:@"hintViewHeight"];
    NSMutableDictionary *views = [NSMutableDictionary dictionary];
    if (self.hintView) {
        [self.view addSubview:self.hintView];
    }
    frame.size.height = self.view.bounds.size.height - frame.origin.y;
    self.pageViewController.view.frame = frame;

    if (self.viewControllers && self.viewControllers.count) {
        [self.pageViewController setViewControllers:@[ [self.viewControllers firstObject] ]
                                          direction:UIPageViewControllerNavigationDirectionReverse
                                           animated:NO
                                         completion:nil];
        [self setSelectedIndex:0];
    }
    {

    if (self.pageViewController && self.header) {
        [views setObject:_header forKey:@"header"];
        [views setObject:self.pageViewController.view forKey:@"pageViewControllerView"];
        self.pageViewController.view.translatesAutoresizingMaskIntoConstraints = NO;
        self.header.translatesAutoresizingMaskIntoConstraints = NO;
        [self.view addConstraints:[NSLayoutConstraint constraintsWithVisualFormat:@"H:|[header]|" options:0 metrics:metrics views:views]];
        [self.view
         addConstraints:[NSLayoutConstraint constraintsWithVisualFormat:@"H:|[pageViewControllerView]|" options:0 metrics:metrics views:views]];
        if (!self.hintView) {
            if (self.headerHeightConstrants) {
                [self.view removeConstraints:self.headerHeightConstrants];
                self.headerHeightConstrants = nil;
            }
            self.headerHeightConstrants = [NSLayoutConstraint constraintsWithVisualFormat:@"V:|[header(headerHeight)][pageViewControllerView]|"
                                                                                  options:0
                                                                                  metrics:metrics
                                                                                    views:views];
            [self.view addConstraints:self.headerHeightConstrants];
        }
    }
    if (self.pageViewController && self.header && self.hintView) {
        self.hintView.translatesAutoresizingMaskIntoConstraints = NO;
        [metrics setObject:@(44) forKey:@"hintViewHeight"];
        [views setObject:self.hintView forKey:@"hintView"];
        [self.view addConstraints:[NSLayoutConstraint constraintsWithVisualFormat:@"H:|[hintView]|" options:0 metrics:metrics views:views]];
        if (self.headerHeightConstrants) {
            [self.view removeConstraints:self.headerHeightConstrants];
            self.headerHeightConstrants = nil;
        }
        self.headerHeightConstrants =
        [NSLayoutConstraint constraintsWithVisualFormat:@"V:|[header(headerHeight)][hintView(hintViewHeight)]-1-[pageViewControllerView]|"
                                                options:0
                                                metrics:metrics
                                                  views:views];
        [self.view addConstraints:self.headerHeightConstrants];
    }
    }
}
- (CGFloat)headerHeight {
    CGFloat height = 44.0f;
    if ([_dataSource respondsToSelector:@selector(tabHeight)]) {
        height = [_dataSource tabHeight];
    }
    return height;
}
- (void)reloadTabs {
    if (_dataSource && [_dataSource respondsToSelector:@selector(backgroundImage)]) {
        UIImage *backgroundImage = [_dataSource backgroundImage];
        if (backgroundImage) {
            _backGroundImageView.hidden = NO;
            _backGroundImageView.image = backgroundImage;
        }
    } else if (_dataSource && [_dataSource respondsToSelector:@selector(backgroundColor)]) {
        _backGroundImageView.backgroundColor = [_dataSource backgroundColor];
    }
    if ([_dataSource numberOfViewControllers] == 0)
        return;
    if ([_dataSource respondsToSelector:@selector(tabColor)]) {
        [self setHeaderColor:[_dataSource tabColor]];
    } else {
        [self setHeaderColor:[UIColor blueColor]];
    }
    if ([_dataSource respondsToSelector:@selector(tabBackgroundColor)]) {
        [self setTabBackgroundColor:[_dataSource tabBackgroundColor]];
    } else {
        [self setTabBackgroundColor:[UIColor clearColor]];
    }
    NSMutableArray *tabViews = [NSMutableArray array];
    if ([_dataSource respondsToSelector:@selector(viewForTabAtIndex:)]) {
        for (int i = 0; i < [self.viewControllers count]; i++) {
            UIView *view;
            if ((view = [_dataSource viewForTabAtIndex:i]) != nil) {
                [tabViews addObject:view];
            }
        }
    } else {
        UIFont *font = [UIFont systemFontOfSize:14.0f];
        if ([_dataSource respondsToSelector:@selector(titleFont)]) {
            font = [_dataSource titleFont];
        }
        UIColor *color = [UIColor blackColor];
        if ([_dataSource respondsToSelector:@selector(titleColor)]) {
            color = [_dataSource titleColor];
        }
        for (NSString *title in self.tabTitles) {
            UILabel *label = [UILabel new];
            [label setText:title];
            [label setFont:font];
            label.textAlignment = NSTextAlignmentCenter;
            [label setTextColor:color];
            [label sizeToFit];
            CGRect frame = [label frame];
            frame.size.width = MAX(frame.size.width + 20, 85);
            [label setFrame:frame];
            label.translatesAutoresizingMaskIntoConstraints = NO;
            [tabViews addObject:label];
        }
    }
    self.tabViews = tabViews;
    int selectedIndex = 0;
    UIColor *_deselectedTitleColor = [UIColor cyanColorABI];
    UIColor *_selectedTitleColor = [UIColor whiteColor];
    for (int i = 0; i < self.tabViews.count; i++) {
        id _lbl = self.tabViews[i];
        if ([_lbl isKindOfClass:[UILabel class]]) {
            UILabel *lbl = (UILabel *)_lbl;
            lbl.textColor = (selectedIndex != i) ? _deselectedTitleColor : _selectedTitleColor;
        }
    }
    [self removeScrollHeader];
    CGRect frame = self.view.frame;
    frame.origin.y = 0; //[self headerHeight];
    frame.size.height = [self headerHeight];
    if ([self headerHeight] > 0 && tabViews && tabViews.count) {
        self.header = [[CustomTabScrollView alloc] initWithFrame:frame
                                                        tabViews:tabViews
                                                    tabBarHeight:[self headerHeight]
                                                        tabColor:[self headerColor]
                                                 backgroundColor:[self tabBackgroundColor]
                                                selectedTabIndex:self.selectedIndex];
        self.header.autoresizingMask = UIViewAutoresizingFlexibleWidth;
        [_header setTabScrollDelegate:self];
        self.header.translatesAutoresizingMaskIntoConstraints = YES;
        [self.view addSubview:_header];
    }
}
#pragma mark - Public Methods
- (void)repositionTab:(NSInteger)index {
    if (_header) {
        [_header animateToTabAtIndex:index animated:NO];
    }
}
- (nullable id)selectViewControllerIndex:(NSInteger)index {
    if (index < self.viewControllers.count)
        return self.viewControllers[index];
    else
        return nil;
}
- (void)selectTabbarIndex:(NSInteger)index {
    [self selectTabbarIndex:index animation:NO];
}
- (void)selectTabbarIndex:(NSInteger)index animation:(BOOL)animation {
    if (self.viewControllers.count > index) {
        [self.pageViewController setViewControllers:@[ self.viewControllers[index] ]
                                          direction:UIPageViewControllerNavigationDirectionReverse
                                           animated:animation
                                         completion:nil];
        [_header animateToTabAtIndex:index animated:animation];
        [self setSelectedIndex:index];
    }
}
#pragma mark - Private Methos
/*!
 *  Create UI with Component
 */
- (void)configureUI {
    self.hintView.backgroundColor = [UIColor defaultPageBGColor];
    self.view.backgroundColor = [UIColor defaultPageBGColor];
    [self createBackgroundImage];
    [self setEdgesForExtendedLayout:UIRectEdgeNone];
    self.pageViewController = [[UIPageViewController alloc] initWithTransitionStyle:UIPageViewControllerTransitionStyleScroll
                                                              navigationOrientation:UIPageViewControllerNavigationOrientationHorizontal
                                                                            options:nil];
    for (UIView *view in [[self.pageViewController view] subviews]) {
        if ([view isKindOfClass:[UIScrollView class]]) {
            [(UIScrollView *)view setCanCancelContentTouches:YES];
            [(UIScrollView *)view setDelaysContentTouches:NO];
        }
    }
    [self.pageViewController setDataSource:self];
    [self.pageViewController setDelegate:self];
    [self addChildViewController:self.pageViewController];
    [self.view addSubview:self.pageViewController.view];
    [self.pageViewController didMoveToParentViewController:self];
}
- (void)addHintView {
    CGRect frame = [self.view bounds];
    frame.origin.y = [self headerHeight];
    if (self.hintView) {
        [self.view addSubview:self.hintView];
        frame.size.height = 30;
        self.hintView.frame = frame;
        frame.origin.y += 25;
        [self updateViewConstraints];
    }
    frame.size.height = self.view.bounds.size.height - frame.origin.y;
    [[[self pageViewController] view] setFrame:frame];
}
- (void)createBackgroundImage {
    if (!_backGroundImageView) {
        _backGroundImageView = [UIImageView new];
        _backGroundImageView.backgroundColor = [UIColor clearColor];
        [_backGroundImageView setTranslatesAutoresizingMaskIntoConstraints:NO];
        [self.view addSubview:_backGroundImageView];
        [self.view addConstraints:[NSLayoutConstraint constraintsWithVisualFormat:@"H:|[backGroundImageView]|"
                                                                          options:0
                                                                          metrics:nil
                                                                            views:@{
                                                                                    @"backGroundImageView" : _backGroundImageView
                                                                                    }]];
        [self.view addConstraints:[NSLayoutConstraint constraintsWithVisualFormat:@"V:|-20-[backGroundImageView]|"
                                                                          options:0
                                                                          metrics:nil
                                                                            views:@{
                                                                                    @"backGroundImageView" : _backGroundImageView
                                                                                    }]];
        _backGroundImageView.hidden = NO;
    }
}
- (UIView *)hintView {
    if (!_hintView) {
        if (_dataSource && [_dataSource respondsToSelector:@selector(hintView)]) {
            _hintView = [_dataSource hintView];
        }
    }
    return _hintView;
}
- (void)removeScrollHeader {
    if (_header) {
        [_header removeFromSuperview];
        _header = nil;
    }
}
@end
