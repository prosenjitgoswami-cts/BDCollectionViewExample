    //
    //  UIImageView+HelperUtil.m
    //  ABIHiFive
    //
    //  Created by Prsenjit Goswami on 10/06/16.
    //  Copyright © 2016 Cognizant. All rights reserved.
    //

#import "UIImageView+HelperUtil.h"

@implementation UIImageView (HelperUtil)

+ (CGSize)CGSizeFillSize:(CGSize)aspectRatio boundingSize:(CGSize)minimumSize {
    CGSize aspectFillSize = CGSizeMake(minimumSize.width, minimumSize.height);
    float mW = minimumSize.width / aspectRatio.width;
    float mH = minimumSize.height / aspectRatio.height;
    if (mH > mW)
        aspectFillSize.width = mH * aspectRatio.width;
    else if (mW > mH)
        aspectFillSize.height = mW * aspectRatio.height;
    return aspectFillSize;
}
+ (CGSize)CGSizeAspectFit:(CGSize)aspectRatio boundingSize:(CGSize)boundingSize {
    CGSize aspectFitSize = CGSizeMake(boundingSize.width, boundingSize.height);
    float mW = boundingSize.width / aspectRatio.width;
    float mH = boundingSize.height / aspectRatio.height;
    if (mH < mW)
        aspectFitSize.width = mH * aspectRatio.width;
    else if (mW < mH)
        aspectFitSize.height = mW * aspectRatio.height;
    return aspectFitSize;
}
+ (UIImageView *)initWithImage:(UIImage *)image {
    UIImageView *imageView = [UIImageView new];
    imageView.translatesAutoresizingMaskIntoConstraints = NO;
    if (image)
        imageView.image = image;
    return imageView;
}

@end
