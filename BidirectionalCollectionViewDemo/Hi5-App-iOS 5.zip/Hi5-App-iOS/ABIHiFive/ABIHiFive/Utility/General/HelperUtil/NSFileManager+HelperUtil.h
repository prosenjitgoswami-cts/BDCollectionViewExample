    //
    //  NSFileManager+HelperUtil.h
    //  ABIHiFive
    //
    //  Created by Prsenjit Goswami on 10/06/16.
    //  Copyright © 2016 Cognizant. All rights reserved.
    //

#import <Foundation/Foundation.h>

@interface NSFileManager (HelperUtil)
+ (nullable NSString *)documentsDirectoryPathWithFileName:(nonnull NSString *)fileName;
+ (nullable NSString *)getFilePathIfExistsAtDocumentsDirectory:(nonnull NSString *)fileName;
@end
