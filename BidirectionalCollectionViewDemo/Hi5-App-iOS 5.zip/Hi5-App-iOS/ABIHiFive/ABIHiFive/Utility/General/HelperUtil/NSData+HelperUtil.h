    //
    //  NSData+HelperUtil.h
    //  ABIHiFive
    //
    //  Created by Prsenjit Goswami on 10/06/16.
    //  Copyright © 2016 Cognizant. All rights reserved.
    //

#import <Foundation/Foundation.h>

@interface NSData (HelperUtil)

+ (BOOL)saveFileContainData:(nonnull NSData *)fileData
                   fileName:(nonnull NSString *)fileName
                 completion:(void (^_Nullable)(NSString *_Nullable filePath))completion;
+ (nonnull NSString *)mimeTypeForData:(nullable NSData *)data;
@end
