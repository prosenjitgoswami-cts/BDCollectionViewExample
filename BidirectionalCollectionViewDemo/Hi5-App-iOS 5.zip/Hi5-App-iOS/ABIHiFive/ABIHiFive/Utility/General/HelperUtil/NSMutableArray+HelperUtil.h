    //
    //  NSMutableArray+HelperUtil.h
    //  ABIHiFive
    //
    //  Created by Prsenjit Goswami on 10/06/16.
    //  Copyright © 2016 Cognizant. All rights reserved.
    //

#import <Foundation/Foundation.h>

@interface NSMutableArray (HelperUtil)
- (void)sortForKey:(nonnull NSString *)key ascending:(BOOL)ascending;
+ (nonnull NSMutableArray *)previousYearFromNow:(NSInteger)previousyearNumber;
@end
