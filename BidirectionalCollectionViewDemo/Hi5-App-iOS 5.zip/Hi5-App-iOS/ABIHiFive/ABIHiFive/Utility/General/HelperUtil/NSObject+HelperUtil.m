    //
    //  NSObject+HelperUtil.m
    //  ABIHiFive
    //
    //  Created by Prsenjit Goswami on 10/06/16.
    //  Copyright © 2016 Cognizant. All rights reserved.
    //

#import "NSObject+HelperUtil.m"
#import "NSString+HelperUtil.h"

#pragma mark -  NSObject Helper
@implementation NSObject (HelperUtil)
/*!
 *  Perform event in main thread after delay
 *
 *  @param delayInterval Delay Interval
 *  @param completion    Completion block
 */
+ (void)performInMainThreadAfterDelay:(NSTimeInterval)delayInterval completion:(void (^)(void))completion {
    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(delayInterval * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
        if (completion)
            completion();
    });
}
/**
 *  Check the Object nullablity
 *
 *  @param object Checkin Object
 *
 *  @return 'YES' if Null object
 */
+ (BOOL)isNullObject:(id)object {
    if ([object isKindOfClass:[NSNull class]])
        return YES;
    return (object == nil);
}
/**
 *  Get Object from Dictionary for Key

 *
 *  @param object (Expected) Dictionary Object
 *  @param key    'Key'
 *
 *  @return Get expected 'Object' for 'Key'
 */
+ (id)objectForKeySafe:(id)object key:(NSString *)key {
    id returnValue = nil;
    if (![NSObject isNullObject:object] && ![NSString isNULLString:key]) {
        if ([object isKindOfClass:[NSDictionary class]]) {
            NSDictionary *objectAsDict = (NSDictionary *)object;
                //   -         if ([[objectAsDict allKeys] containsObject:key])
            returnValue = [objectAsDict objectForKey:key];
            if ([NSObject isNullObject:returnValue]) {
                returnValue = nil;
            }
        }
    }
    return returnValue;
}
/**
 *  Get value from Dictionary for Key

 *
 *  @param object (Expected) Dictionary Object
 *  @param key    'Key'
 *
 *  @return Get expected 'value' for 'key'
 */
+ (id)valueForKeySafe:(id)object key:(NSString *)key {
    id returnValue = nil;
    if (![NSObject isNullObject:object] && ![NSString isNULLString:key]) {
        if ([object isKindOfClass:[NSDictionary class]]) {
            NSDictionary *objectAsDict = (NSDictionary *)object;
            if ([[objectAsDict allKeys] containsObject:key])
                returnValue = [objectAsDict valueForKey:key];
        }
    }
    return returnValue;
}

- (NSURL *)toURL {
    if (!self) {
        return nil;
    }

    NSURL *sfURL = nil;
    if ([self isKindOfClass:[NSURL class]]) {
        sfURL = (NSURL *)self;

    } else if ([self isKindOfClass:[NSString class]]) {
        NSString *imgeURLString = (NSString *)self;
        if (![NSString isNULLString:imgeURLString]) {
            sfURL = [NSURL URLWithString:imgeURLString];
        }
    }

    if (!sfURL) {
        return nil;
    }
    return sfURL;
}
@end
