    //
    //  UIImageView+HelperUtil.h
    //  ABIHiFive
    //
    //  Created by Prsenjit Goswami on 10/06/16.
    //  Copyright © 2016 Cognizant. All rights reserved.
    //

#import <UIKit/UIKit.h>

@interface UIImageView (HelperUtil)

+ (CGSize)CGSizeFillSize:(CGSize)aspectRatio boundingSize:(CGSize)minimumSize;
+ (CGSize)CGSizeAspectFit:(CGSize)aspectRatio boundingSize:(CGSize)boundingSize;
+ (nullable UIImageView *)initWithImage:(nullable UIImage *)image;
@end
