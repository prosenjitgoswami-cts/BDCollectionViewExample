    //
    //  NSData+HelperUtil.m
    //  ABIHiFive
    //
    //  Created by Prsenjit Goswami on 10/06/16.
    //  Copyright © 2016 Cognizant. All rights reserved.
    //

#import "NSData+HelperUtil.h"
#import "NSFileManager+HelperUtil.h"

@implementation NSData (HelperUtil)

+ (NSString *)mimeTypeForData:(NSData *)data {
    uint8_t c;
    [data getBytes:&c length:1];
    switch (c) {
        case 0xFF: return @"image/jpeg"; break;
        case 0x89: return @"image/png"; break;
        case 0x47: return @"image/gif"; break;
        case 0x49:
        case 0x4D: return @"image/tiff"; break;
        case 0x25: return @"application/pdf"; break;
        case 0xD0: return @"application/vnd"; break;
        case 0x46: return @"text/plain"; break;
        default: return @"application/octet-stream";
    }
    return nil;
}
+ (BOOL)saveFileContainData:(nonnull NSData *)fileData
                   fileName:(nonnull NSString *)fileName
                 completion:(void (^_Nullable)(NSString *_Nullable filePath))completion {
    BOOL isSaved = NO;
    NSString *path = @"";
    if (fileData != nil) {
        path = [NSFileManager documentsDirectoryPathWithFileName:fileName];
        isSaved = [fileData writeToFile:path atomically:YES];
    }
    if (completion)
        completion(isSaved ? path : nil);
    return isSaved;
}

@end
