    //
    //  NSArray+HelperUtil.m
    //  ABIHiFive
    //
    //  Created by Prsenjit Goswami on 10/06/16.
    //  Copyright © 2016 Cognizant. All rights reserved.
    //

#import "NSArray+HelperUtil.h"
#import "NSString+HelperUtil.h"

@implementation NSArray (HelperUtil)

+ (nullable id)objectFromArray:(nullable NSArray *)anArray atIndex:(NSUInteger)index {
    if (![anArray isKindOfClass:[NSNull class]] && anArray && anArray.count > index) {
        return anArray[index];
    }
    return nil;
}
+ (BOOL)isValidArray:(id)object {
    BOOL isValidArray = (![object isKindOfClass:[NSNull class]] && [object isKindOfClass:[NSArray class]]);
    NSArray *arr = nil;
    if (isValidArray) {
        arr = (NSArray *)object;
        isValidArray = isValidArray && arr.count;
    }
    return isValidArray;
}

- (BOOL)isEmptyArray {

    return !([NSArray isValidArray:self] && self.count);
}

+ (BOOL)isNullArray:(id)object {

    return ![NSArray isValidArray:object];
}

- (NSArray *)sortArrayForKey:(NSString *)key ascending:(BOOL)ascending {

    NSArray *sortedResults = self;

    if (!sortedResults.count && ![NSString isNULLString:key] && [key isMemberOfClass:[NSString class]])
        return nil;

    id obj = [sortedResults firstObject];
    SEL selector = NSSelectorFromString(key);
    if (obj) {
        BOOL isPropertyAvailable = [obj respondsToSelector:selector];

        if (isPropertyAvailable) {
            NSSortDescriptor *sortDescriptor = [[NSSortDescriptor alloc] initWithKey:key ascending:ascending];
            sortedResults = [self sortedArrayUsingDescriptors:@[ sortDescriptor ]];
        }
    }

        //    NSArray *sortedResults = self;
        //    if (sortedResults.count && ![NSString isNULLString:key]) {
        //        NSSortDescriptor *sortDescriptor = [[NSSortDescriptor alloc] initWithKey:key ascending:ascending];
        //        sortedResults = [self sortedArrayUsingDescriptors:@[ sortDescriptor ]];
        //    }
    return sortedResults;
}

- (BOOL)indexOutOfBound:(NSUInteger)index {

    return (index >= self.count);
}

@end
