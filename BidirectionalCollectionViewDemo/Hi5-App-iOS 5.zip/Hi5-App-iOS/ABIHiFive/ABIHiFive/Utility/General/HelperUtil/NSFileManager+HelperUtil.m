    //
    //  NSFileManager+HelperUtil.m
    //  ABIHiFive
    //
    //  Created by Prsenjit Goswami on 10/06/16.
    //  Copyright © 2016 Cognizant. All rights reserved.
    //

#import "NSFileManager+HelperUtil.h"

@implementation NSFileManager (HelperUtil)

+ (NSString *)documentsDirectoryPathWithFileName:(NSString *)fileName {
    fileName = [fileName lastPathComponent];
    NSArray *paths = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES);
    NSString *documentsDirectory = [paths objectAtIndex:0];
    NSString *path = [documentsDirectory stringByAppendingPathComponent:fileName];
    return path;
}
+ (NSString *)getFilePathIfExistsAtDocumentsDirectory:(NSString *)fileName {
    NSString *filePath = [NSFileManager documentsDirectoryPathWithFileName:fileName];
    if (![[NSFileManager defaultManager] fileExistsAtPath:filePath]) {
        return nil;
    } else {
        return filePath;
    }
    return nil;
}

@end
