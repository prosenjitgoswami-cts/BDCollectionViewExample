    //
    //  UIViewController+HelperUtil.m
    //  ABIHiFive
    //
    //  Created by Prsenjit Goswami on 10/06/16.
    //  Copyright © 2016 Cognizant. All rights reserved.
    //

#import "UIViewController+HelperUtil.h"
#import <objc/runtime.h>

@implementation UIViewController (HelperUtil)
- (NSUInteger)pageIndex {
    id pageIndexObject = objc_getAssociatedObject(self, @selector(pageIndex));
    return [pageIndexObject integerValue];
}
- (void)setPageIndex:(NSUInteger)pageIndex {
    objc_setAssociatedObject(self, @selector(pageIndex), @(pageIndex), OBJC_ASSOCIATION_ASSIGN);
}
- (NSString *)pageTitle {
    id pageTitleObject = objc_getAssociatedObject(self, @selector(pageTitle));
    return pageTitleObject;
}
- (void)setPageTitle:(NSString *)pageTitle {
    objc_setAssociatedObject(self, @selector(pageTitle), pageTitle, OBJC_ASSOCIATION_RETAIN_NONATOMIC);
}
+ (instancetype)instantiateViewControllerWithIdentifier:(NSString *)identifier {
    UIViewController *profileViewController = nil;
    if (identifier.length) {
        UIStoryboard *mystoryboard = [UIStoryboard storyboardWithName:@"Main" bundle:nil];
        if (mystoryboard)
            profileViewController = [mystoryboard instantiateViewControllerWithIdentifier:identifier];
    }
    return profileViewController;
}

#pragma mark - Alert ViewController

- (void)alertWithTitle:(nullable NSString *)alertTitle
               message:(nullable NSString *)message
    defaultButtonTitle:(nullable NSString *)defaultButtonTitle
   defaultButtonHander:(nullable void (^)(void))defaultButtonHander
     cancelButtonTitle:(nullable NSString *)cancelButtonTitle
    cancelButtonHander:(nullable void (^)(void))cancelButtonHander {
    __weak typeof(self) weakSelf = self;
    BOOL isMainTHread = [NSThread isMainThread];
    if (isMainTHread) {
        [weakSelf alertAlwaysInMainThreadWithTitle:alertTitle
                                           message:message
                                defaultButtonTitle:defaultButtonTitle
                               defaultButtonHander:defaultButtonHander
                                 cancelButtonTitle:cancelButtonTitle
                                cancelButtonHander:cancelButtonHander];
    } else {
        dispatch_async(dispatch_get_main_queue(), ^{
            [weakSelf alertAlwaysInMainThreadWithTitle:alertTitle
                                               message:message
                                    defaultButtonTitle:defaultButtonTitle
                                   defaultButtonHander:defaultButtonHander
                                     cancelButtonTitle:cancelButtonTitle
                                    cancelButtonHander:cancelButtonHander];
        });
    }
}
- (UIAlertController *)alertAlwaysInMainThreadWithTitle:(nullable NSString *)alertTitle
                                                message:(nullable NSString *)message
                                     defaultButtonTitle:(nullable NSString *)defaultButtonTitle
                                    defaultButtonHander:(nullable void (^)(void))defaultButtonHander
                                      cancelButtonTitle:(nullable NSString *)cancelButtonTitle
                                     cancelButtonHander:(nullable void (^)(void))cancelButtonHander {
    UIAlertController *alert = nil;
    if ([UIAlertController class]) {
            // use UIAlertController
        if (!message.length && !alertTitle.length)
            return nil;
        alert = [UIAlertController alertControllerWithTitle:alertTitle message:message preferredStyle:UIAlertControllerStyleAlert];
        if (defaultButtonTitle.length) {
            UIAlertAction *ok = [UIAlertAction actionWithTitle:defaultButtonTitle
                                                         style:(cancelButtonTitle.length == 0) ? UIAlertActionStyleCancel : UIAlertActionStyleDefault
                                                       handler:^(UIAlertAction *_Nonnull action) {
                                                           if (defaultButtonHander)
                                                               defaultButtonHander();
                                                       }];
            [alert addAction:ok];
        }
        if (cancelButtonTitle.length) {
            UIAlertAction *cancel = [UIAlertAction actionWithTitle:cancelButtonTitle
                                                             style:UIAlertActionStyleCancel
                                                           handler:^(UIAlertAction *_Nonnull action) {
                                                               if (cancelButtonHander)
                                                                   cancelButtonHander();
                                                           }];
            [alert addAction:cancel];
        }
        [self presentViewController:alert animated:YES completion:nil];
    }
    return alert;
}
- (void)alertWithTitle:(NSString *)title
               message:(NSString *)message
    defaultButtonTitle:(NSString *)defaultButtonTitle
       clickedOkButton:(void (^)(void))clickedOkButton {
    [self alertAlwaysInMainThreadWithTitle:nil
                                   message:message
                        defaultButtonTitle:defaultButtonTitle
                       defaultButtonHander:clickedOkButton
                         cancelButtonTitle:nil
                        cancelButtonHander:nil];
}

@end
