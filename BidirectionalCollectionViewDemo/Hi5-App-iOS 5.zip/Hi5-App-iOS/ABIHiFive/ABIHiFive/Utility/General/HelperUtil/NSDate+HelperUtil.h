    //
    //  NSDate+HelperUtil.h
    //  ABIHiFive
    //
    //  Created by Prsenjit Goswami on 10/06/16.
    //  Copyright © 2016 Cognizant. All rights reserved.
    //

#import <Foundation/Foundation.h>

@interface NSDate (HelperUtil)

- (NSInteger)year;
+ (NSInteger)currentYear;
- (nullable NSString *)formatterDateStringForAnnoucenent;
+ (nullable NSString *)dispalyTimeAsLocalTZFormatWithUTCDate:(nullable NSDate *)utcDate;
+ (nullable NSDate *)dateFromString:(nullable NSString *)dateString andFormatterStyle:(nonnull NSString *)formatter;
+ (nullable NSString *)stringFromDateInLocal:(nullable NSDate *)date andFormatterStyle:(nonnull NSString *)formatter;
+ (nullable NSString *)abiGeneralTimeDispalyFormat:(nonnull NSString *)timeString;
- (nonnull NSDate *)toLocalTime;
- (nonnull NSDate *)toUTCTime;

@end
