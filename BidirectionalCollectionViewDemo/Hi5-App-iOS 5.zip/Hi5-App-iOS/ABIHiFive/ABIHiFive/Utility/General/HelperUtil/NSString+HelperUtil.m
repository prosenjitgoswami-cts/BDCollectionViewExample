    //
    //  NSString+HelperUtil.m
    //  ABIHiFive
    //
    //  Created by Prsenjit Goswami on 10/06/16.
    //  Copyright © 2016 Cognizant. All rights reserved.
    //

#import "Constants.h"
#import "NSString+HelperUtil.h"
#import <UIKit/UIKit.h>

@implementation NSString (HelperUtil)

/*!
 *  Check null string
 *
 *  @param aString Input string
 *
 */

+ (BOOL)isNULLString:(nullable id)_aString {
    if ([_aString isKindOfClass:[NSNull class]])
        return YES;
    if (_aString && [_aString isKindOfClass:[NSString class]]) {
        NSString *aString = (NSString *)_aString;
        if ([aString isEqualToString:@"<null>"] || [aString isEqualToString:@"<NULL>"] || [aString isEqualToString:@"(null)"] ||
            [aString isEqualToString:@"(NULL)"])
            return YES;
        else {
            NSArray *words = [_aString componentsSeparatedByCharactersInSet:[NSCharacterSet whitespaceAndNewlineCharacterSet]];
            NSString *nospacestring = [words componentsJoinedByString:@""];
            words = nil;
            return !(nospacestring && nospacestring.length);
        }
    }
    return YES;
}

+ (NSString *)removeWhiteSpace:(NSString *)name {
    name = [name stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceCharacterSet]];
    return name;
}
- (NSString *)nullStringTextCorrection {
    NSString *result = self;
    return ![NSString isNULLString:result] ? result : @"";
}
- (void)saveStringInFile:(NSString *)name {
    NSArray *paths = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES);
    NSString *documentsDirectory = [paths objectAtIndex:0]; // Get documents directory
    NSError *error;
    BOOL succeed = [self writeToFile:[documentsDirectory stringByAppendingPathComponent:[NSString stringWithFormat:@"%@.txt", name]]
                          atomically:YES
                            encoding:NSUTF8StringEncoding
                               error:&error];
    if (!succeed) {
            // Handle error here
    }
}

- (nonnull NSString *)toBase64String {
    NSData *plainData = [self dataUsingEncoding:NSUTF8StringEncoding];
    NSString *base64String = nil;
    if ([plainData respondsToSelector:@selector(base64EncodedStringWithOptions:)]) {
        base64String = [plainData base64EncodedStringWithOptions:kNilOptions]; // iOS 7+
    }
    return base64String;
}
- (nonnull NSString *)toString {
    NSString *planeString = self;
    NSData *decodedData = [[NSData alloc] initWithBase64EncodedString:planeString options:0];
    NSString *plainString = nil;
    if (decodedData) {
        plainString = [[NSString alloc] initWithData:decodedData encoding:NSUTF8StringEncoding];
    }
    return plainString;
}
+ (NSMutableDictionary *)readInfoPlist {
    NSString *path = [[NSBundle mainBundle] pathForResource:kPlistName ofType:@"plist"];
    NSMutableDictionary *dictplist = [[NSMutableDictionary alloc] initWithContentsOfFile:path];
    return dictplist;
}
+ (nonnull NSString *)valueForInfoPlistForKey:(nonnull NSString *)key {
    NSString *value = nil;
    NSMutableDictionary *dictplist = [NSString readInfoPlist];
    if ([NSDictionary isValidDictionary:dictplist]) {
        value = dictplist[key];
            //        if(![NSString isNULLString:value]) {
            //            value = [value toString];
            //        }
    }
    return value;
}

+ (NSString *)textForKey:(NSString *)key object:(id)object {

    if ([object isKindOfClass:[NSString class]]) {
        return object;

    } else if (![NSString isNULLString:key]) {
        SEL displayTextSelector = NSSelectorFromString(key);

        if ([object respondsToSelector:displayTextSelector]) {
            id text = [object performSelector:displayTextSelector];
            if ([text isKindOfClass:[NSString class]]) {
                return (NSString *)text;
            }
        }
    }
    return nil;
}

+ (NSMutableString *)formatedString:(NSString *)aString forCount:(NSInteger)count {

    if ([NSString isNULLString:aString])
        return nil;
    NSMutableString *mutableString = [NSMutableString stringWithString:[NSString stringWithFormat:@"%lu %@", (unsigned long)count, aString]];
    if (count > 1) {
        [mutableString appendString:@"s"];
    }
    return mutableString;
}
- (NSString *)URLEncodeUsingEncoding:(NSStringEncoding)encoding {
    return (__bridge_transfer NSString *)CFURLCreateStringByAddingPercentEscapes(
                                                                                 NULL, (__bridge CFStringRef)self, NULL, (CFStringRef) @"!*'\"();:@&=+$,/?%#[]% ", CFStringConvertNSStringEncodingToEncoding(encoding));
}

- (NSString *)URLDecode {
    NSString *aString = [self URLDecodeUsingEncoding:NSUTF8StringEncoding];
    return aString;
}

- (NSString *)URLDecodeUsingEncoding:(NSStringEncoding)encoding {
    return (__bridge_transfer NSString *)CFURLCreateStringByReplacingPercentEscapesUsingEncoding(NULL, (__bridge CFStringRef)self, CFSTR(""),
                                                                                                 CFStringConvertNSStringEncodingToEncoding(encoding));
}
- (NSString *)toDefaultEncode {

    NSString *aString = [self URLEncodeUsingEncoding:NSUTF8StringEncoding];
    return aString;
}
@end
