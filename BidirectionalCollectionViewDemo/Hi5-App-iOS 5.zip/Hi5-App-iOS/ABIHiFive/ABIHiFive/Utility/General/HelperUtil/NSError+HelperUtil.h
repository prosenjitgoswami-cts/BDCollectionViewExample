    //
    //  NSError+HelperUtil.h
    //  ABIHiFive
    //
    //  Created by Prsenjit Goswami on 10/06/16.
    //  Copyright © 2016 Cognizant. All rights reserved.
    //

#import "EnumMaster.h"
#import <Foundation/Foundation.h>

@interface NSError (HelperUtil)
+ (nonnull NSError *)errorAnyNullInput;
+ (nonnull NSError *)dataParsingFailed;
+ (nonnull NSError *)errorForType:(ErrorType)type;
+ (nonnull NSError *)errorNoDataAvailable;
+ (nonnull NSError *)errorNilSOQLQurery;
+ (nonnull NSError *)errorNoNetworkConnection;
@end