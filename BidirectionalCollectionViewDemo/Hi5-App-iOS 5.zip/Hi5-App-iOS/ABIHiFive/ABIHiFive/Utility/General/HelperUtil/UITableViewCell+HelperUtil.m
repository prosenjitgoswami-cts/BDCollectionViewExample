    //
    //  UITableViewCell+HelperUtil.m
    //  ABIHiFive
    //
    //  Created by Prsenjit Goswami on 10/06/16.
    //  Copyright © 2016 Cognizant. All rights reserved.
    //

#import "UITableViewCell+HelperUtil.h"

@implementation UITableViewCell (HelperUtil)

- (void)defaultABICellBackground {
    UIView *view = [[UIView alloc] initWithFrame:[self superview].bounds];
    view.backgroundColor = [UIColor whiteColor];
    view.layer.cornerRadius = 5.0f;
    self.backgroundView = view;
    self.backgroundColor = [UIColor clearColor];
    self.selectionStyle = UITableViewCellSelectionStyleNone;
}

@end
