    //
    //  NSString+HelperUtil.h
    //  ABIHiFive
    //
    //  Created by Prsenjit Goswami on 10/06/16.
    //  Copyright © 2016 Cognizant. All rights reserved.
    //

#import <Foundation/Foundation.h>

@interface NSString (HelperUtil)

+ (BOOL)isNULLString:(id)_aString;
+ (NSString *)removeWhiteSpace:(NSString *)name;
- (NSString *)nullStringTextCorrection;
- (void)saveStringInFile:(NSString *)name;
- (NSString *)toBase64String;
- (NSString *)toString;
+ (NSMutableDictionary *)readInfoPlist;
+ (NSString *)valueForInfoPlistForKey:(NSString *)key;
+ (NSString *)textForKey:(NSString *)key object:(id)object;
+ (NSMutableString *)formatedString:(NSString *)aString forCount:(NSInteger)count;
- (NSString *)toDefaultEncode;
@end
