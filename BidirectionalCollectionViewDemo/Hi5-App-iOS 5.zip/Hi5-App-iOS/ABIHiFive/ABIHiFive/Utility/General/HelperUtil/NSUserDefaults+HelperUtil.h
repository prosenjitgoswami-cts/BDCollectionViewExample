    //
    //  NSUserDefaults+HelperUtil.h
    //  ABIHiFive
    //
    //  Created by Prsenjit Goswami on 10/06/16.
    //  Copyright © 2016 Cognizant. All rights reserved.
    //

#import <Foundation/Foundation.h>

@interface NSUserDefaults (HelperwUtil)
+ (void)saveObject:(id)object forKey:(NSString *)key;
+ (id)readUserDefault:(NSString *)key;
+ (void)removeUserDefault:(NSString *)key;
@end
