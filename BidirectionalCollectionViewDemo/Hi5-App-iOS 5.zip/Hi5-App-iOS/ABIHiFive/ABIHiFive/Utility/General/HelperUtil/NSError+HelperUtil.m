    //
    //  NSError+HelperUtil.m
    //  ABIHiFive
    //
    //  Created by Prsenjit Goswami on 10/06/16.
    //  Copyright © 2016 Cognizant. All rights reserved.
    //

#import "NSError+HelperUtil.h"

#pragma mark -  NSError

@implementation NSError (HelperUtit)

/**
 *
 *  @return NSError refrence
 */
+ (NSError *)errorAnyNullInput {
    return [NSError errorForType:ErrorTypAnyInputDataIsNull];
}
/**
 *  Response Data is available but unable to Perse Respons
 *
 *  @return NSError refrence
 */
+ (NSError *)dataParsingFailed {
    return [NSError errorForType:ErrorTypeDataParsingFailed];
}
/**
 *  Response Data is nil
 *
 *  @return NSError refrence
 */
+ (NSError *)errorNoDataAvailable {
    return [NSError errorForType:ErrorTypeNoDataAvailable];
}
/**
 *  Error when No Network Connection
 *
 *  @return NSError refrence
 */
+ (NSError *)errorNoNetworkConnection {
    return [NSError errorForType:ErrorTypeNoNetworkConnection];
}
/**
 *  Error when No NIL SOQLQurery
 *
 *  @return NSError refrence
 */
+ (NSError *)errorNilSOQLQurery {
    return [NSError errorForType:ErrorTypeNilSOQLQurery];
}
+ (NSError *)errorForType:(ErrorType)type {
    static NSString *domain = @"com.abi.error";
    NSInteger code = type;
    NSDictionary *userInfo = nil;
    switch (type) {
        case ErrorTypeDataParsingFailed: userInfo = @{ @"description" : @"Unable data to parse" }; break;
        default: break;
    }
    NSError *err = [NSError errorWithDomain:domain code:code userInfo:userInfo];
    return err;
}
@end
