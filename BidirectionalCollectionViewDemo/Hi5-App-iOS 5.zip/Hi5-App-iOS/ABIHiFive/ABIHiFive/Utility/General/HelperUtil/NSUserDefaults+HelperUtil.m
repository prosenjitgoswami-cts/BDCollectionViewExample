    //
    //  NSUserDefaults+HelperUtil.m
    //  ABIHiFive
    //
    //  Created by Prsenjit Goswami on 10/06/16.
    //  Copyright © 2016 Cognizant. All rights reserved.
    //

#import "NSString+HelperUtil.h"
#import "NSUserDefaults+HelperUtil.h"

@implementation NSUserDefaults (HelperwUtil)

+ (void)saveObject:(id)object forKey:(NSString *)key {
    if ([NSString isNULLString:key])
        return;
    [[NSUserDefaults standardUserDefaults] setObject:object forKey:key];
    [[NSUserDefaults standardUserDefaults] synchronize];
}
+ (id)readUserDefault:(NSString *)key {
    if ([NSString isNULLString:key])
        return nil;
    return [[NSUserDefaults standardUserDefaults] objectForKey:key];
}
+ (void)removeUserDefault:(NSString *)key {
    if ([NSString isNULLString:key])
        return;
    [[NSUserDefaults standardUserDefaults] removeObjectForKey:key];
    [[NSUserDefaults standardUserDefaults] synchronize];
}

@end
