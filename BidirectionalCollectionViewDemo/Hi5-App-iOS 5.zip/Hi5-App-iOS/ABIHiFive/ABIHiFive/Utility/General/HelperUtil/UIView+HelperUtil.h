    //
    //  UIView+HelperUtil.h
    //  ABIHiFive
    //
    //  Created by Prsenjit Goswami on 10/06/16.
    //  Copyright © 2016 Cognizant. All rights reserved.
    //

#import <UIKit/UIKit.h>

@interface UIView (HelperUtil)
+ (nullable instancetype)loadViewFromNIB;
+ (nullable instancetype)loadViewFromNIB:(nonnull NSString *)nibName;

- (void)addContraintsWithParentView:(nonnull UIView *)toItem insets:(UIEdgeInsets)insets;
- (void)fitToParentView:(nonnull UIView *)toItem;
- (void)widthMultiplyBy:(CGFloat)multiplier toParent:(nullable id)toParent;
- (void)heightMultiplyBy:(CGFloat)multiplier toParent:(nullable id)toParent;
- (void)centerXToParent:(nullable id)toParent;
- (void)centerYToParent:(nullable id)toParent;
- (void)addConstraintForCenterX:(nullable id)item toItem:(nullable id)toItem;
- (void)addConstraintForCenterY:(nullable id)item toItem:(nullable id)toItem;
- (void)addConstraintsWithVisualFormat:(nonnull NSString *)format
                               options:(NSLayoutFormatOptions)opts
                               metrics:(nullable NSDictionary<NSString *, id> *)metrics
                                 views:(nonnull NSDictionary<NSString *, id> *)views;
- (void)addConstraintForSameButtom:(nonnull id)item toItem:(nonnull id)toItem;
- (void)addConstraintForSameHeight:(nonnull id)item toItem:(nonnull id)toItem;
- (void)addConstraintForSameWidth:(nonnull id)item toItem:(nonnull id)toItem;
- (void)addConstraintForSameRight:(nonnull id)item toItem:(nonnull id)toItem;
- (void)addConstraintForRight:(nonnull id)item toItem:(nonnull id)toItem withMultiplier:(CGFloat)multiplier andConstant:(CGFloat)c;
- (void)addConstraint:(NSLayoutAttribute)attribute
                 item:(nonnull id)item
               toItem:(nonnull id)toItem
       withMultiplier:(CGFloat)multiplier
          andConstant:(CGFloat)c;

@end
