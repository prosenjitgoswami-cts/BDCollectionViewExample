    //
    //  UILabel+HelperUtil.h
    //  ABIHiFive
    //
    //  Created by Prsenjit Goswami on 10/06/16.
    //  Copyright © 2016 Cognizant. All rights reserved.
    //

#import <UIKit/UIKit.h>

@interface UILabel (HelperUtil)

+ (nonnull UILabel *)labelWithText:(nonnull NSString *)text
                         textColor:(nullable UIColor *)textColor
                          textFont:(nullable UIFont *)textFont
                     textAlignment:(NSTextAlignment)textAlignment
                     numberOfLines:(NSInteger)numberOfLines
                   backgroundColor:(nullable UIColor *)backgroundColor;

@end
