    //
    //  UITextField+HelperUtil.m
    //  ABIHiFive
    //
    //  Created by Prsenjit Goswami on 10/06/16.
    //  Copyright © 2016 Cognizant. All rights reserved.
    //

#import "UITextField+HelperUtil.h"

@implementation UITextField (HelperUtil)

- (nonnull UIToolbar *)inputAccessoryViewWithAction:(SEL)action target:(id)target barButtonSystemItem:(UIBarButtonSystemItem)barButtonSystemItem {
    UIToolbar *keyboardToolbar = [[UIToolbar alloc] initWithFrame:CGRectMake(0, 0, self.bounds.size.width, 44)];
    keyboardToolbar.barStyle = UIBarStyleDefault;
    UIBarButtonItem *btnDone = [[UIBarButtonItem alloc] initWithBarButtonSystemItem:barButtonSystemItem target:target action:action];
    UIBarButtonItem *fixedSpace = [[UIBarButtonItem alloc] initWithBarButtonSystemItem:UIBarButtonSystemItemFlexibleSpace target:self action:nil];
    UIBarButtonItem *fixedSpacew = [[UIBarButtonItem alloc] initWithBarButtonSystemItem:UIBarButtonSystemItemFlexibleSpace target:self action:nil];
    NSArray *items = [NSArray arrayWithObjects:fixedSpace, fixedSpacew, btnDone, nil];
    [keyboardToolbar setItems:items animated:YES];
    self.inputAccessoryView = keyboardToolbar;
    return keyboardToolbar;
}

@end
