    //
    //  UIAlertController+HelperUtil.m
    //  ABIHiFive
    //
    //  Created by Prsenjit Goswami on 15/06/16.
    //  Copyright © 2016 Cognizant. All rights reserved.
    //

#import "UIAlertController+HelperUtil.h"

@implementation UIAlertController (HelperUtil)

- (void)alertWithTitle:(nullable NSString *)alertTitle
               message:(nullable NSString *)message
    defaultButtonTitle:(nullable NSString *)defaultButtonTitle
   defaultButtonHander:(nullable void (^)(void))defaultButtonHander
     cancelButtonTitle:(nullable NSString *)cancelButtonTitle
    cancelButtonHander:(nullable void (^)(void))cancelButtonHander {
    __weak typeof(self) weakSelf = self;
    BOOL isMainTHread = [NSThread isMainThread];
    if (isMainTHread) {
        [weakSelf alertAlwaysInMainThreadWithTitle:alertTitle
                                           message:message
                                defaultButtonTitle:defaultButtonTitle
                               defaultButtonHander:defaultButtonHander
                                 cancelButtonTitle:cancelButtonTitle
                                cancelButtonHander:cancelButtonHander];
    } else {
        dispatch_async(dispatch_get_main_queue(), ^{
            [weakSelf alertAlwaysInMainThreadWithTitle:alertTitle
                                               message:message
                                    defaultButtonTitle:defaultButtonTitle
                                   defaultButtonHander:defaultButtonHander
                                     cancelButtonTitle:cancelButtonTitle
                                    cancelButtonHander:cancelButtonHander];
        });
    }
}
- (UIAlertController *)alertAlwaysInMainThreadWithTitle:(nullable NSString *)alertTitle
                                                message:(nullable NSString *)message
                                     defaultButtonTitle:(nullable NSString *)defaultButtonTitle
                                    defaultButtonHander:(nullable void (^)(void))defaultButtonHander
                                      cancelButtonTitle:(nullable NSString *)cancelButtonTitle
                                     cancelButtonHander:(nullable void (^)(void))cancelButtonHander {
    UIAlertController *alert = nil;
    if ([UIAlertController class]) {
            // use UIAlertController
        if (!message.length && !alertTitle.length)
            return nil;
        alert = [UIAlertController alertControllerWithTitle:alertTitle message:message preferredStyle:UIAlertControllerStyleAlert];
        if (defaultButtonTitle.length) {
            UIAlertAction *ok = [UIAlertAction actionWithTitle:defaultButtonTitle
                                                         style:(cancelButtonTitle.length == 0) ? UIAlertActionStyleCancel : UIAlertActionStyleDefault
                                                       handler:^(UIAlertAction *_Nonnull action) {
                                                           if (defaultButtonHander)
                                                               defaultButtonHander();
                                                       }];
            [alert addAction:ok];
        }
        if (cancelButtonTitle.length) {
            UIAlertAction *cancel = [UIAlertAction actionWithTitle:cancelButtonTitle
                                                             style:UIAlertActionStyleCancel
                                                           handler:^(UIAlertAction *_Nonnull action) {
                                                               if (cancelButtonHander)
                                                                   cancelButtonHander();
                                                           }];
            [alert addAction:cancel];
        }
        [self presentViewController:alert animated:YES completion:nil];
    }
    return alert;
}
- (void)alertWithTitle:(NSString *)title
               message:(NSString *)message
    defaultButtonTitle:(NSString *)defaultButtonTitle
       clickedOkButton:(void (^)(void))clickedOkButton {
    [self alertAlwaysInMainThreadWithTitle:nil
                                   message:message
                        defaultButtonTitle:defaultButtonTitle
                       defaultButtonHander:clickedOkButton
                         cancelButtonTitle:nil
                        cancelButtonHander:nil];
}

@end
