    //
    //  NSDate+HelperUtil.m
    //  ABIHiFive
    //
    //  Created by Prsenjit Goswami on 10/06/16.
    //  Copyright © 2016 Cognizant. All rights reserved.
    //

#import "Constants.h"
#import "NSDate+HelperUtil.h"
#import "NSString+HelperUtil.h"

@implementation NSDate (HelperUtil)

static NSCalendar *implicitCalendar = nil;
static NSDateFormatter *implicitDateFormatter = nil;
+ (void)load {
    [NSDate setImplicitCalendar];
    [NSDate setImplicitDateFormatter];
}
+ (void)setImplicitCalendar {
    if (!implicitCalendar) {
        implicitCalendar = [[NSCalendar alloc] initWithCalendarIdentifier:NSCalendarIdentifierGregorian];
    }
}
+ (void)setImplicitDateFormatter {
    if (!implicitDateFormatter) {
        implicitDateFormatter = [[NSDateFormatter alloc] init];
        NSLocale *posix = [[NSLocale alloc] initWithLocaleIdentifier:@"en_US_POSIX"];
        [implicitDateFormatter setLocale:posix];
    }
}
/**
 *  Retrieves a default NSCalendar instance, based on the value of defaultCalendarSetting
 *
 *  @return NSCalendar The current implicit calendar
 */
+ (NSCalendar *)implicitCalendar {
    return implicitCalendar;
}
+ (NSDateFormatter *)implicitDateFormatter {
    return implicitDateFormatter;
}
/**
 *  Returns a date representing the receivers date shifted later by the provided number of days.
 *
 *  @param years NSInteger - Number of days to add
 *
 *  @return NSDate - Date modified by the number of desired days
 */
- (NSDate *)dateByAddingDays:(NSInteger)days {
    NSCalendar *calendar = [[self class] implicitCalendar];
    NSDateComponents *components = [[NSDateComponents alloc] init];
    [components setDay:days];
    return [calendar dateByAddingComponents:components toDate:self options:0];
}
/**
 *  Returns a date representing the receivers date shifted earlier by the provided number of days.
 *
 *  @param years NSInteger - Number of days to subtract
 *
 *  @return NSDate - Date modified by the number of desired days
 */
- (NSDate *)dateBySubtractingDays:(NSInteger)days {
    NSCalendar *calendar = [[self class] implicitCalendar];
    NSDateComponents *components = [[NSDateComponents alloc] init];
    [components setDay:-1 * days];
    return [calendar dateByAddingComponents:components toDate:self options:0];
}
/**
 *  Returns an NSInteger representing the amount of time in days between the receiver and the provided date.
 *  If the receiver is earlier than the provided date, the returned value will be negative.
 *
 *  @param date     NSDate - The provided date for comparison
 *  @param calendar NSCalendar - The calendar to be used in the calculation
 *
 *  @return NSInteger - The double representation of the days between receiver and provided date
 */
- (NSInteger)daysFrom:(NSDate *)date calendar:(NSCalendar *)calendar {
    if (!calendar) {
        calendar = [[self class] implicitCalendar];
    }
    NSDate *earliest = [self earlierDate:date];
    NSDate *latest = (earliest == self) ? date : self;
    NSInteger multiplier = (earliest == self) ? -1 : 1;
    NSDateComponents *components = [calendar components:NSCalendarUnitDay fromDate:earliest toDate:latest options:0];
    return multiplier * components.day;
}
- (NSInteger)yearsFrom:(NSDate *)date calendar:(NSCalendar *)calendar {
    if (!calendar) {
        calendar = [[self class] implicitCalendar];
    }
    NSDate *earliest = [self earlierDate:date];
    NSDate *latest = (earliest == self) ? date : self;
    NSInteger multiplier = (earliest == self) ? -1 : 1;
    NSDateComponents *components = [calendar components:NSCalendarUnitYear fromDate:earliest toDate:latest options:0];
    return multiplier * components.year;
}
- (BOOL)isToday {
    NSCalendar *cal = [NSCalendar currentCalendar];
    NSDateComponents *components =
    [cal components:(NSCalendarUnitEra | NSCalendarUnitYear | NSCalendarUnitMonth | NSCalendarUnitDay) fromDate:[NSDate date]];
    NSDate *today = [cal dateFromComponents:components];
    components = [cal components:(NSCalendarUnitEra | NSCalendarUnitYear | NSCalendarUnitMonth | NSCalendarUnitDay) fromDate:self];
    NSDate *otherDate = [cal dateFromComponents:components];
    return [today isEqualToDate:otherDate];
}
- (BOOL)isTomorrow {
    NSCalendar *cal = [NSCalendar currentCalendar];
    NSDateComponents *components =
    [cal components:(NSCalendarUnitEra | NSCalendarUnitYear | NSCalendarUnitMonth | NSCalendarUnitDay) fromDate:[[NSDate date] dateByAddingDays:1]];
    NSDate *tomorrow = [cal dateFromComponents:components];
    components = [cal components:(NSCalendarUnitEra | NSCalendarUnitYear | NSCalendarUnitMonth | NSCalendarUnitDay) fromDate:self];
    NSDate *otherDate = [cal dateFromComponents:components];
    return [tomorrow isEqualToDate:otherDate];
}
- (BOOL)isYesterday {
    NSCalendar *cal = [NSCalendar currentCalendar];
    NSDateComponents *components = [cal components:(NSCalendarUnitEra | NSCalendarUnitYear | NSCalendarUnitMonth | NSCalendarUnitDay)
                                          fromDate:[[NSDate date] dateBySubtractingDays:1]];
    NSDate *tomorrow = [cal dateFromComponents:components];
    components = [cal components:(NSCalendarUnitEra | NSCalendarUnitYear | NSCalendarUnitMonth | NSCalendarUnitDay) fromDate:self];
    NSDate *otherDate = [cal dateFromComponents:components];
    return [tomorrow isEqualToDate:otherDate];
}
/**
 *  Returns an NSInteger representing the amount of time in days between the receiver and the provided date.
 *  If the receiver is earlier than the provided date, the returned value will be negative.
 *  Uses the default Gregorian calendar
 *
 *  @param date NSDate - The provided date for comparison
 *
 *  @return NSInteger - The double representation of the days between receiver and provided date
 */
- (NSInteger)daysFrom:(NSDate *)date {
    return [self daysFrom:date calendar:nil];
}
/**
 *  Returns whether two dates fall on the same day.
 *
 *  @param date NSDate - Date to compare with sender
 *  @return BOOL - YES if both paramter dates fall on the same day, NO otherwise
 */
- (BOOL)isSameDay:(NSDate *)date {
    return [NSDate isSameDay:self asDate:date];
}
/**
 *  Returns whether two dates fall on the same day.
 *
 *  @param date NSDate - First date to compare
 *  @param compareDate NSDate - Second date to compare
 *  @return BOOL - YES if both paramter dates fall on the same day, NO otherwise
 */
+ (BOOL)isSameDay:(NSDate *)date asDate:(NSDate *)compareDate {
    NSCalendar *cal = [NSCalendar currentCalendar];
    NSDateComponents *components = [cal components:(NSCalendarUnitEra | NSCalendarUnitYear | NSCalendarUnitMonth | NSCalendarUnitDay) fromDate:date];
    NSDate *dateOne = [cal dateFromComponents:components];
    components = [cal components:(NSCalendarUnitEra | NSCalendarUnitYear | NSCalendarUnitMonth | NSCalendarUnitDay) fromDate:compareDate];
    NSDate *dateTwo = [cal dateFromComponents:components];
    return [dateOne isEqualToDate:dateTwo];
}
- (NSInteger)year {
    NSCalendar *cal = [NSCalendar currentCalendar];
    NSDateComponents *components = [cal components:(NSCalendarUnitEra | NSCalendarUnitYear | NSCalendarUnitMonth | NSCalendarUnitDay) fromDate:self];
    return components.year;
}
+ (NSInteger)currentYear {
    return [[NSDate date] year];
}
- (NSDate *)toLocalTime {
    NSTimeZone *tz = [NSTimeZone defaultTimeZone];
    NSInteger seconds = [tz secondsFromGMTForDate:self];
    return [NSDate dateWithTimeInterval:seconds sinceDate:self];
}
- (NSDate *)toUTCTime {
    NSTimeZone *tz = [NSTimeZone defaultTimeZone];
    NSInteger seconds = -[tz secondsFromGMTForDate:self];
    return [NSDate dateWithTimeInterval:seconds sinceDate:self];
}
- (NSString *)formatterDateStringForAnnoucenent {

        //	NSTimeInterval timeZoneSeconds = [[NSTimeZone localTimeZone] secondsFromGMT];
        // NSDate *dateInLocalTimezone = [self dateByAddingTimeInterval:timeZoneSeconds];
    NSString *formattedText = [NSDate setDifferenceInDates:[NSDate date] toDate:self];
    return formattedText;
}
+ (NSDate *)dateFromString:(NSString *)dateString andFormatterStyle:(NSString *)formatter {
    NSDate *date = nil;
    if (![NSString isNULLString:dateString]) {
        NSDateFormatter *dateFormatter = [NSDate implicitDateFormatter];
        [dateFormatter setDateFormat:formatter];
        NSLocale *posix = [[NSLocale alloc] initWithLocaleIdentifier:@"en_US_POSIX"];
        [dateFormatter setLocale:posix];
        date = [dateFormatter dateFromString:dateString];
        dateFormatter = nil;
    }
    return date;
}
+ (NSString *)stringFromDateInLocal:(NSDate *)date andFormatterStyle:(NSString *)formatter {
    NSString *dateString = nil;
    if (date) {
        NSDateFormatter *dateFormatter = [[NSDateFormatter alloc] init];
        [dateFormatter setDateFormat:formatter];
        dateString = [dateFormatter stringFromDate:date];
        dateFormatter = nil;
    }
    return dateString;
}

+ (NSString *)setDifferenceInDates:(NSDate *)fromDate toDate:(NSDate *)toDate {

    NSTimeInterval distanceBetweenDates = [fromDate timeIntervalSinceDate:toDate];
    double secondsInAnHour = 3600;
    NSInteger hoursBetweenDates = distanceBetweenDates / secondsInAnHour;
    NSInteger minutes = (distanceBetweenDates / 60);
    NSMutableString *differnceString = [NSMutableString stringWithString:@""];

    if (distanceBetweenDates < 0) {
    } else if (hoursBetweenDates >= 24) {
        NSUInteger dayNum = hoursBetweenDates / 24;

        differnceString = [NSString formatedString:@"day" forCount:(unsigned long)dayNum];
        [differnceString appendString:STATIC_TEXT_AGO_STRING];

    } else if (hoursBetweenDates > 0) {

        differnceString = [NSString formatedString:@"hour" forCount:(unsigned long)hoursBetweenDates];
        [differnceString appendString:STATIC_TEXT_AGO_STRING];

    } else if (minutes > 0) {

        differnceString = [NSString formatedString:@"minute" forCount:(unsigned long)minutes];
        [differnceString appendString:STATIC_TEXT_AGO_STRING];

    } else {

        [differnceString setString:@"Now"];
    }
    return differnceString;
}

+ (NSString *)dispalyTimeAsLocalTZFormatWithUTCDate:(NSDate *)utcDate {
    if (!utcDate)
        return nil;
    NSDate *sfDateInLocalTz = utcDate;
    NSDate *nowInLocalTz = [NSDate date];
    NSCalendar *currentCalendar = [NSCalendar currentCalendar];
    currentCalendar.timeZone = [NSTimeZone systemTimeZone];
    currentCalendar.locale = [NSLocale currentLocale];
    NSInteger dcsfDateInLocalTz = [currentCalendar ordinalityOfUnit:NSCalendarUnitDay inUnit:NSCalendarUnitYear forDate:sfDateInLocalTz];
    NSInteger dcnowInLocalTz = [currentCalendar ordinalityOfUnit:NSCalendarUnitDay inUnit:NSCalendarUnitYear forDate:nowInLocalTz];
    NSMutableString *sendTimeString = [NSMutableString string];
        //	NSInteger dayDifferent = [nowInLocalTz daysFrom:sfDateInLocalTz];
        //
        //    NSInteger dayOfYear_SFDateInLocalTz = [sfDateInLocalTz dayOfYear];
        //    NSInteger dayOfYear_NowInLocalTz= [nowInLocalTz dayOfYear];
    NSInteger dayDifferent = dcnowInLocalTz - dcsfDateInLocalTz;
    if (dayDifferent == 2) {
        [sendTimeString appendString:STATIC_TEXT_TWO_DAYS_AGO];
        [sendTimeString appendString:@" "];
        [sendTimeString appendString:[NSDate stringFromDateInLocal:utcDate andFormatterStyle:@"hh:mm a"]];
    } else if ([utcDate isToday]) {
        [sendTimeString appendString:STATIC_TEXT_TODAY];
        [sendTimeString appendString:@" "];
        [sendTimeString appendString:[NSDate stringFromDateInLocal:utcDate andFormatterStyle:@"hh:mm a"]];
    } else if ([utcDate isYesterday]) {
        [sendTimeString appendString:STATIC_TEXT_YESTERDAY];
        [sendTimeString appendString:@" "];
        [sendTimeString appendString:[NSDate stringFromDateInLocal:utcDate andFormatterStyle:@"hh:mm a"]];
    } else {
        [sendTimeString appendString:[NSDate stringFromDateInLocal:utcDate andFormatterStyle:@"MMMM dd, YYYY 'at' hh:mm a"]];
    }
    return sendTimeString;
}
+ (NSString *)abiGeneralTimeDispalyFormat:(NSString *)timeString {
    if ([NSString isNULLString:timeString])
        return nil;
    NSDate *date = [NSDate dateFromString:timeString andFormatterStyle:DEFAULT_SF_DATE_FORMAT];
    NSString *sendTimeString = [NSDate dispalyTimeAsLocalTZFormatWithUTCDate:date];

    return sendTimeString;
}

@end
