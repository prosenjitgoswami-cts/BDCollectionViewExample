    //
    //  UIView+HelperUtil.m
    //  ABIHiFive
    //
    //  Created by Prsenjit Goswami on 10/06/16.
    //  Copyright © 2016 Cognizant. All rights reserved.
    //

#import "UIView+HelperUtil.h"

@implementation UIView (HelperUtil)

/*!
 *  Load view from nib
 *
 */
+ (instancetype)loadViewFromNIB {
    NSArray *nibs = [[NSBundle mainBundle] loadNibNamed:NSStringFromClass([self class]) owner:self options:nil];
    return (nibs && nibs.count) ? [nibs firstObject] : nil;
}
+ (instancetype)loadViewFromNIB:(NSString *)nibName {
    NSArray *nibs = [[NSBundle mainBundle] loadNibNamed:nibName owner:self options:nil];
    return (nibs && nibs.count) ? [nibs firstObject] : nil;
}
- (void)addConstraintForSameHeight:(id)item toItem:(id)toItem {
    if (!item || !toItem)
        return;
    [self addConstraint:[NSLayoutConstraint constraintWithItem:item
                                                     attribute:NSLayoutAttributeHeight
                                                     relatedBy:NSLayoutRelationEqual
                                                        toItem:toItem
                                                     attribute:NSLayoutAttributeHeight
                                                    multiplier:1
                                                      constant:0]];
}
- (void)addConstraintForSameWidth:(id)item toItem:(id)toItem {
    if (!item || !toItem)
        return;
    [self addConstraint:[NSLayoutConstraint constraintWithItem:item
                                                     attribute:NSLayoutAttributeWidth
                                                     relatedBy:NSLayoutRelationEqual
                                                        toItem:toItem
                                                     attribute:NSLayoutAttributeWidth
                                                    multiplier:1
                                                      constant:0]];
}
- (void)addConstraintForSameButtom:(id)item toItem:(id)toItem {
    if (!item || !toItem)
        return;
    [self addConstraint:[NSLayoutConstraint constraintWithItem:item
                                                     attribute:NSLayoutAttributeBottom
                                                     relatedBy:NSLayoutRelationEqual
                                                        toItem:toItem
                                                     attribute:NSLayoutAttributeBottom
                                                    multiplier:1
                                                      constant:0]];
}
- (void)addConstraintForSameRight:(id)item toItem:(id)toItem {
    if (!item || !toItem)
        return;
    [self addConstraint:[NSLayoutConstraint constraintWithItem:item
                                                     attribute:NSLayoutAttributeRight
                                                     relatedBy:NSLayoutRelationEqual
                                                        toItem:toItem
                                                     attribute:NSLayoutAttributeRight
                                                    multiplier:1
                                                      constant:0]];
}
- (void)addConstraintForRight:(id)item toItem:(id)toItem withMultiplier:(CGFloat)multiplier andConstant:(CGFloat)c {
    if (!item || !toItem)
        return;
    [self addConstraint:[NSLayoutConstraint constraintWithItem:item
                                                     attribute:NSLayoutAttributeRight
                                                     relatedBy:NSLayoutRelationEqual
                                                        toItem:toItem
                                                     attribute:NSLayoutAttributeRight
                                                    multiplier:multiplier
                                                      constant:c]];
}
- (void)addConstraint:(NSLayoutAttribute)attribute item:(id)item toItem:(id)toItem withMultiplier:(CGFloat)multiplier andConstant:(CGFloat)c {
    if (!item || !toItem)
        return;
    [self addConstraint:[NSLayoutConstraint constraintWithItem:item
                                                     attribute:attribute
                                                     relatedBy:NSLayoutRelationEqual
                                                        toItem:toItem
                                                     attribute:attribute
                                                    multiplier:multiplier
                                                      constant:c]];
}
- (void)addConstraintForCenterX:(id)item toItem:(id)toItem {
    if (!item || !toItem)
        return;
    [self addConstraint:[NSLayoutConstraint constraintWithItem:item
                                                     attribute:NSLayoutAttributeCenterX
                                                     relatedBy:NSLayoutRelationEqual
                                                        toItem:toItem
                                                     attribute:NSLayoutAttributeCenterX
                                                    multiplier:1
                                                      constant:0]];
}
- (void)addConstraintForCenterY:(id)item toItem:(id)toItem {
    if (!item || !toItem)
        return;
    [self addConstraint:[NSLayoutConstraint constraintWithItem:item
                                                     attribute:NSLayoutAttributeCenterY
                                                     relatedBy:NSLayoutRelationEqual
                                                        toItem:toItem
                                                     attribute:NSLayoutAttributeCenterY
                                                    multiplier:1
                                                      constant:0]];
}
- (void)addConstraintsWithVisualFormat:(NSString *)format
                               options:(NSLayoutFormatOptions)opts
                               metrics:(nullable NSDictionary<NSString *, id> *)metrics
                                 views:(NSDictionary<NSString *, id> *)views {
    if (views == nil || format.length == 0)
        return;
    [self addConstraints:[NSLayoutConstraint constraintsWithVisualFormat:format options:opts metrics:metrics views:views]];
}

- (void)addContraintsWithParentView:(UIView *)toItem insets:(UIEdgeInsets)insets {
    if (!toItem)
        return;
        // top, left, bottom, right;
    NSDictionary *metrics = @{
                              @"top" : @(insets.top),
                              @"left" : @(insets.left),
                              @"bottom" : @(insets.bottom),
                              @"right" : @(insets.right),
                              };

    [toItem addConstraints:[NSLayoutConstraint constraintsWithVisualFormat:@"H:|-left-[selfView]-right-|"
                                                                   options:0
                                                                   metrics:metrics
                                                                     views:@{
                                                                             @"selfView" : self
                                                                             }]];
    [toItem addConstraints:[NSLayoutConstraint constraintsWithVisualFormat:@"V:|-top-[selfView]-bottom-|"
                                                                   options:0
                                                                   metrics:metrics
                                                                     views:@{
                                                                             @"selfView" : self
                                                                             }]];
}

- (void)fitToParentView:(UIView *)toItem {
    if (!toItem)
        return;
    [toItem addConstraints:[NSLayoutConstraint constraintsWithVisualFormat:@"H:|[selfView]|" options:0 metrics:nil views:@{ @"selfView" : self }]];
    [toItem addConstraints:[NSLayoutConstraint constraintsWithVisualFormat:@"V:|[selfView]|" options:0 metrics:nil views:@{ @"selfView" : self }]];
}
- (void)widthMultiplyBy:(CGFloat)multiplier toParent:(id)toParent {
    if (!toParent || multiplier < 0)
        return;
    [toParent addConstraint:[NSLayoutConstraint constraintWithItem:self
                                                         attribute:NSLayoutAttributeWidth
                                                         relatedBy:NSLayoutRelationEqual
                                                            toItem:toParent
                                                         attribute:NSLayoutAttributeWidth
                                                        multiplier:multiplier
                                                          constant:0]];
}
- (void)heightMultiplyBy:(CGFloat)multiplier toParent:(id)toParent {
    if (!toParent || multiplier < 0)
        return;
    [toParent addConstraint:[NSLayoutConstraint constraintWithItem:self
                                                         attribute:NSLayoutAttributeHeight
                                                         relatedBy:NSLayoutRelationEqual
                                                            toItem:toParent
                                                         attribute:NSLayoutAttributeHeight
                                                        multiplier:multiplier
                                                          constant:0]];
}
- (void)centerXToParent:(id)toParent {
    if (!toParent)
        return;
    [toParent addConstraint:[NSLayoutConstraint constraintWithItem:self
                                                         attribute:NSLayoutAttributeCenterX
                                                         relatedBy:NSLayoutRelationEqual
                                                            toItem:toParent
                                                         attribute:NSLayoutAttributeCenterX
                                                        multiplier:1
                                                          constant:0]];
}
- (void)centerYToParent:(id)toParent {
    if (!toParent)
        return;
    [toParent addConstraint:[NSLayoutConstraint constraintWithItem:self
                                                         attribute:NSLayoutAttributeCenterY
                                                         relatedBy:NSLayoutRelationEqual
                                                            toItem:toParent
                                                         attribute:NSLayoutAttributeCenterY
                                                        multiplier:1
                                                          constant:0]];
}

@end
