    //
    //  NSObject+HelperUtil.h
    //  ABIHiFive
    //
    //  Created by Prsenjit Goswami on 10/06/16.
    //  Copyright © 2016 Cognizant. All rights reserved.
    //
#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>

#pragma mark - NSObject
@interface NSObject (HelperUtil)
+ (void)performInMainThreadAfterDelay:(NSTimeInterval)delayInterval completion:(void (^_Nonnull)(void))completion;
+ (BOOL)isNullObject:(nonnull id)object;
+ (nullable id)objectForKeySafe:(nullable id)object key:(nullable NSString *)key;
+ (nullable id)valueForKeySafe:(nonnull id)object key:(nonnull NSString *)key;
- (NSURL *)toURL;
@end
