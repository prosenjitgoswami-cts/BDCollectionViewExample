    //
    //  NSDictionary+HelperUtil.m
    //  ABIHiFive
    //
    //  Created by Prsenjit Goswami on 10/06/16.
    //  Copyright © 2016 Cognizant. All rights reserved.
    //

#import "NSDictionary+HelperUtil.h"
#import "NSString+HelperUtil.h"

@implementation NSDictionary (HelperUtil)

+ (BOOL)isValidDictionary:(NSDictionary *)dictionary {
    BOOL isValidDictionary = ![dictionary isKindOfClass:[NSNull class]] && [dictionary isKindOfClass:[NSDictionary class]];
    if (isValidDictionary)
        isValidDictionary = isValidDictionary && (dictionary && dictionary.count);
    return isValidDictionary;
}
- (id)valueForKeySafe:(NSString *)key {
    if ([NSString isNULLString:key])
        return nil;
    id object = nil;
    if ([NSDictionary isValidDictionary:self] && [[self allKeys] containsObject:key]) {
        object = self[key];
    }
    return object;
}
- (NSString *)jsonStringWithPrettyPrint:(BOOL)prettyPrint {
    NSError *error;
    NSData *jsonData =
    [NSJSONSerialization dataWithJSONObject:self options:(NSJSONWritingOptions)(prettyPrint ? NSJSONWritingPrettyPrinted : 0) error:&error];
    if (!jsonData) {
        NSLog(@"bv_jsonStringWithPrettyPrint: error: %@", error.localizedDescription);
        return @"{}";
    } else {
        return [[NSString alloc] initWithData:jsonData encoding:NSUTF8StringEncoding];
    }
}

@end
