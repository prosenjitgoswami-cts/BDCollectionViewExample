    //
    //  UILabel+HelperUtil.m
    //  ABIHiFive
    //
    //  Created by Prsenjit Goswami on 10/06/16.
    //  Copyright © 2016 Cognizant. All rights reserved.
    //

#import "UILabel+HelperUtil.h"

@implementation UILabel (HelperUtil)

+ (nonnull UILabel *)labelWithText:(nonnull NSString *)text
                         textColor:(nullable UIColor *)textColor
                          textFont:(nullable UIFont *)textFont
                     textAlignment:(NSTextAlignment)textAlignment
                     numberOfLines:(NSInteger)numberOfLines
                   backgroundColor:(nullable UIColor *)backgroundColor {
    UILabel *label = [UILabel new];
    if (text.length)
        label.text = text;
    label.textAlignment = textAlignment;
    if (backgroundColor)
        label.backgroundColor = backgroundColor;
    label.numberOfLines = numberOfLines != 1 ? numberOfLines : 1;
    label.lineBreakMode = NSLineBreakByWordWrapping;
    if (textFont)
        label.font = textFont;
    if (textColor)
        label.textColor = textColor;
    label.translatesAutoresizingMaskIntoConstraints = NO;
        //	if(label.translatesAutoresizingMaskIntoConstraints)
        //        label.autoresizingMask =  UIViewAutoresizingFlexibleWidth;
    return label;
}

@end
