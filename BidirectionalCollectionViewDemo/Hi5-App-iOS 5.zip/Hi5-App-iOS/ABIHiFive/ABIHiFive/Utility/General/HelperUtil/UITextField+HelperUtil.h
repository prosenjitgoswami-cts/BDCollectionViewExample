    //
    //  UITextField+HelperUtil.h
    //  ABIHiFive
    //
    //  Created by Prsenjit Goswami on 10/06/16.
    //  Copyright © 2016 Cognizant. All rights reserved.
    //

#import "EnumMaster.h"
#import <UIKit/UIKit.h>

@interface UITextField (HelperUtil)

- (UIToolbar *)inputAccessoryViewWithAction:(SEL)action target:(id)target barButtonSystemItem:(UIBarButtonSystemItem)barButtonSystemItem;
@end
