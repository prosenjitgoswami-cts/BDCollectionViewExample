    //
    //  NSLayoutConstraint+HelperUtil.h
    //  ABIHiFive
    //
    //  Created by Prsenjit Goswami on 10/06/16.
    //  Copyright © 2016 Cognizant. All rights reserved.
    //

#import <UIKit/UIKit.h>

@interface NSLayoutConstraint (HelperUtil)

+ (nonnull NSMutableDictionary *)defaultMetricsDictionary;
+ (void)fitToWithItem:(nullable id)anItem toItem:(nullable id)toItem;
+ (nullable NSLayoutConstraint *)sameWidth:(nullable id)anItem toItem:(nullable id)toItem;
+ (nullable NSLayoutConstraint *)sameHeight:(nullable id)anItem toItem:(nullable id)toItem;
+ (nullable NSLayoutConstraint *)verticallyCenter:(nullable id)anItem toItem:(nullable id)toItem;
+ (nullable NSLayoutConstraint *)horizontallyCenter:(nullable id)anItem toItem:(nullable id)toItem;
+ (nullable NSLayoutConstraint *)height:(nullable id)anItem toItem:(nullable id)toItem multiplier:(CGFloat)multiplier constant:(CGFloat)c;
+ (nullable NSLayoutConstraint *)width:(nullable id)anItem toItem:(nullable id)toItem multiplier:(CGFloat)multiplier constant:(CGFloat)c;

@end
