    //
    //  NSMutableArray+HelperUtil.m
    //  ABIHiFive
    //
    //  Created by Prsenjit Goswami on 10/06/16.
    //  Copyright © 2016 Cognizant. All rights reserved.
    //

#import "NSDate+HelperUtil.h"
#import "NSMutableArray+HelperUtil.h"
#import "NSString+HelperUtil.h"

@implementation NSMutableArray (HelperUtil)

- (void)sortForKey:(NSString *)key ascending:(BOOL)ascending {

    if (!self.count && ![NSString isNULLString:key] && [key isMemberOfClass:[NSString class]])
        return;

    id obj = [self firstObject];
    SEL selector = NSSelectorFromString(key);
    if (obj) {
        BOOL isPropertyAvailable = [obj respondsToSelector:selector];
        if (isPropertyAvailable) {
            NSSortDescriptor *sortDescriptor = [[NSSortDescriptor alloc] initWithKey:key ascending:ascending];
            [self sortUsingDescriptors:@[ sortDescriptor ]];
        }
    }
}

+ (NSMutableArray *)previousYearFromNow:(NSInteger)previousyearNumber {
    NSInteger year = [NSDate currentYear];
    NSMutableArray *years = [NSMutableArray array];
    for (int i = 0; i <= previousyearNumber; ++i) {
        [years addObject:@(year - i)];
    }
    return years;
}

@end
