    //
    //  NSArray+HelperUtil.h
    //  ABIHiFive
    //
    //  Created by Prsenjit Goswami on 10/06/16.
    //  Copyright © 2016 Cognizant. All rights reserved.
    //

#import <Foundation/Foundation.h>

@interface NSArray (HelperUtil)

+ (nullable id)objectFromArray:(nullable NSArray *)anArray atIndex:(NSUInteger)index;
+ (BOOL)isValidArray:(nullable NSArray *)object;
+ (BOOL)isNullArray:(nullable NSArray *)object;
- (nullable NSArray *)sortArrayForKey:(nullable NSString *)key ascending:(BOOL)ascending;
    //+ (nullable id)filterByKey:(nonnull NSString *)key filterWithValue:(nonnull NSString *)filterWithValue fromCollection:(nonnull NSArray *)collection;
- (BOOL)indexOutOfBound:(NSUInteger)index;
- (BOOL)isEmptyArray;
@end
