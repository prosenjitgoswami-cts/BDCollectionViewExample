    //
    //  UITextView+HelperUtil.h
    //  ABIHiFive
    //
    //  Created by Prsenjit Goswami on 10/06/16.
    //  Copyright © 2016 Cognizant. All rights reserved.
    //

#import "EnumMaster.h"
#import <UIKit/UIKit.h>

@interface UITextView (HelperUtil)

- (nonnull UIToolbar *)inputAccessoryViewWithAction:(nullable SEL)action
                                             target:(nullable id)target
                                barButtonSystemItem:(UIBarButtonSystemItem)barButtonSystemItem;
@end
