    //
    //  ABISFChatterDataModelBinder.h
    //  ABIHiFive
    //
    //  Created by Prsenjit Goswami on 22/07/16.
    //  Copyright © 2016 Cognizant. All rights reserved.
    //
#import "Constants.h"
#import <Foundation/Foundation.h>
@class ABISFChatterPrivateMessageDataModel;
@class ABISFChatterCommentByDistinctUserDataModel;
@class ABISFChatterContentDataModel;
@class ABISFChatterParentDataModel;
@class ABISFChatterMentionDataModel;
@interface ABISFChatterDataModelBinder : NSObject

#pragma mark -  Comment Item
+ (void)bindResponseDataForFeedDetails:(id)respose feedInfo:(void (^)(id feedInfoObject))feedInfo completion:(void (^)(NSArray *results))completion;
+ (void)bindResponseDataForFeedDetailsAfterPostAComment:(id)respose
                                               feedInfo:(void (^)(id feedInfoObject))feedInfo
                                             completion:(void (^)(NSArray *results))completion;

#pragma mark -  Comment Item
+ (void)bindResponseDataForCommentItems:(NSArray *)items
                           parentFeedID:(NSString *)parentFeedID
              isUniqueCommentUsersSerch:(BOOL)isUniqueCommentUsersSerch
                             completion:(void (^)(BOOL isMoreAvailable, NSString *uniqueUsersName, NSArray *uniqueCommentUsers,
                                                  NSArray *comments))completion;

#pragma mark -  Messages
+ (void)bindResponseDataForMessage:(id)respose feedInfo:(void (^)(id feedInfoObject))feedInfo completion:(SOQLCompletion)completion;
+ (ABISFChatterPrivateMessageDataModel *)bindResponseDataForMessage:(id)respose;
+ (ABISFChatterCommentByDistinctUserDataModel *)bindResponseDataForCommentItems:(NSArray *)items
                                                                   parentFeedID:(NSString *)parentFeedID
                                                      isUniqueCommentUsersSerch:(BOOL)isUniqueCommentUsersSerch;

#pragma mark -  Search Results
+ (NSMutableArray<ABISFChatterMentionDataModel *> *)bindResponseDataForSearchMentions:(NSArray *)searchResults;

#pragma mark -  UploadFile
+ (ABISFChatterContentDataModel *)bindResponseDataForUploadFile:(NSDictionary *)response;
+ (NSMutableArray<ABISFChatterParentDataModel *> *)bindResponseDataForChatterUser:(id)respose;
@end
