    //
    //  ABISFChatterDataModelBinder.m
    //  ABIHiFive
    //
    //  Created by Prsenjit Goswami on 22/07/16.
    //  Copyright © 2016 Cognizant. All rights reserved.
    //
#import "ABISFChatterDataModelBinder.h"
#import "ABISFChatterCommentByDistinctUserDataModel.h"
#import "ABISFChatterCommentItemModel.h"
#import "ABISFChatterContentDataModel.h"
#import "ABISFChatterDataFetcherServices.h"
#import "ABISFChatterFeedElementDataModel.h"
#import "ABISFChatterMentionDataModel.h"
#import "ABISFChatterPrivateMessageDataModel.h"
@implementation ABISFChatterDataModelBinder
+ (void)bindFeedDetailsResponseData:(id)respose feedInfo:(void (^)(id feedInfoObject))feedInfo completion:(void (^)(NSArray *results))completion {
    if ([NSDictionary isValidDictionary:respose]) {
        NSDictionary *resultDict = (NSDictionary *)respose;
        id nextPageUrl = [NSDictionary valueForKeySafe:resultDict key:kNextPageUrl]; // resultDict[@"nextPageUrl"];
        __block NSMutableArray *resultFeeds = [NSMutableArray array];
        NSArray *elements = [NSDictionary valueForKeySafe:resultDict key:kElements];
        NSInteger index = 0;
        [ABISFChatterDataModelBinder bindABISFChatterFeedElementDataModel:elements
                                                                    index:index
                                                              resultFeeds:resultFeeds
                                                               completion:^(NSArray *results) {
                                                                   if (completion)
                                                                       completion(results);
                                                                   if (feedInfo)
                                                                       feedInfo([NSObject isNullObject:nextPageUrl] ? nil : nextPageUrl);
                                                               }];
        elements = nil;
    } else {
        completion(nil);
        if (feedInfo)
            feedInfo(nil);
    }
}
+ (void)bindABISFChatterFeedElementDataModel:(NSArray *)elements
                                       index:(NSUInteger)index
                                 resultFeeds:(NSMutableArray *)resultFeeds
                                  completion:(void (^)(NSArray *results))completion {
    __block NSInteger _index = index;
    /*!
     *  Continue the iteration
     */
    if (_index < elements.count) {
        __block NSDictionary *dict = [NSArray objectFromArray:elements atIndex:_index];
        if ([NSDictionary isValidDictionary:dict]) {
            [ABISFChatterFeedElementDataModel prepareABISFChatterFeedElementDataModel:dict
                                                                      completionBlock:^(ABISFChatterFeedElementDataModel *model) {
                                                                          if (model)
                                                                              [resultFeeds addObject:model];
                                                                          _index += 1;
                                                                          [ABISFChatterDataModelBinder bindABISFChatterFeedElementDataModel:elements
                                                                                                                                      index:_index
                                                                                                                                resultFeeds:resultFeeds
                                                                                                                                 completion:completion];
                                                                      }];
        }
    } else {
        /*!
         *  Complete the iteration
         */
        if (completion)
            completion(resultFeeds);
    }
}
+ (void)bindResponseDataForFeedDetails:(id)respose feedInfo:(void (^)(id feedInfoObject))feedInfo completion:(void (^)(NSArray *results))completion {
    [ABISFChatterDataModelBinder bindFeedDetailsResponseData:respose feedInfo:feedInfo completion:completion];
}
+ (void)bindResponseDataForFeedDetailsAfterPostAComment:(id)respose
                                               feedInfo:(void (^)(id feedInfoObject))feedInfo
                                             completion:(void (^)(NSArray *results))completion {
    if (respose) {
        NSMutableDictionary *elementDictionary = [NSMutableDictionary dictionary];
        [elementDictionary setObject:@[ respose ] forKey:kElements];
        [ABISFChatterDataModelBinder bindFeedDetailsResponseData:elementDictionary feedInfo:feedInfo completion:completion];
    } else {
        if (completion)
            completion(nil);
        if (feedInfo)
            feedInfo(nil);
    }
}
+ (ABISFChatterCommentByDistinctUserDataModel *)bindResponseDataForCommentItems:(NSArray *)items
                                                                   parentFeedID:(NSString *)parentFeedID
                                                      isUniqueCommentUsersSerch:(BOOL)isUniqueCommentUsersSerch {
    if (![NSArray isValidArray:items]) {
        return nil;
    }
    NSMutableString *commentByDistinctUsersNameString = [NSMutableString string];
    NSMutableArray *commentByDistinctUsers = [NSMutableArray array];
    NSMutableArray *tempArray = [NSMutableArray array];
    NSInteger i = 1;
    NSMutableArray *allcomments = [NSMutableArray new];
    for (id commentItem in items) {
        ABISFChatterCommentItemModel *commentItemModel = [[ABISFChatterCommentItemModel alloc] initWithParentFeedID:parentFeedID commentItem:commentItem];
        [allcomments addObject:commentItemModel];
    }
    allcomments = [[allcomments sortArrayForKey:kCreatedDate ascending:NO] mutableCopy];
    for (ABISFChatterCommentItemModel *commentItemModel in allcomments) {
        if (isUniqueCommentUsersSerch) {
            NSString *stringName = commentItemModel.parent.name;
            if (![NSString isNULLString:stringName]) {
                if (![tempArray containsObject:stringName]) {
                    if (commentByDistinctUsersNameString.length < MAX_CHARECTER_LENGHT_BEFORE_MORE_STRING && i <= MAX_NAME_COUNT) {
                        if (commentByDistinctUsersNameString.length) {
                            [commentByDistinctUsersNameString appendString:@", "];
                        }
                        [commentByDistinctUsersNameString appendString:stringName];
                    }
                    [commentByDistinctUsers addObject:commentItemModel];
                    [tempArray addObject:stringName];
                    i += 1;
                }
            }
        }
    }
    BOOL _isMoreAvailable = NO;
    if (isUniqueCommentUsersSerch && commentByDistinctUsersNameString.length && tempArray.count > MAX_NAME_COUNT &&
        commentByDistinctUsersNameString.length < MAX_CHARECTER_LENGHT_BEFORE_MORE_STRING) {
        _isMoreAvailable = YES;
        [commentByDistinctUsersNameString appendString:STATIC_TEXT_MORE_TEXT];
    } else if (isUniqueCommentUsersSerch && commentByDistinctUsersNameString.length &&
               commentByDistinctUsersNameString.length > MAX_CHARECTER_LENGHT_BEFORE_MORE_STRING) {
        _isMoreAvailable = YES;
        [commentByDistinctUsersNameString appendString:STATIC_TEXT_MORE_TEXT];
    }
    if (tempArray.count) {
        [tempArray removeAllObjects];
    }
    tempArray = nil;
    return [ABISFChatterCommentByDistinctUserDataModel initWithCommentByDistinctUsersName:commentByDistinctUsersNameString
                                                                   commentByDistinctUsers:commentByDistinctUsers
                                                                          isMoreAvailable:_isMoreAvailable
                                                                           allCommentItem:allcomments];
}
+ (void)bindResponseDataForCommentItems:(NSArray *)items
                           parentFeedID:(NSString *)parentFeedID
              isUniqueCommentUsersSerch:(BOOL)isUniqueCommentUsersSerch
                             completion:(void (^)(BOOL isMoreAvailable, NSString *uniqueUsersName, NSArray *uniqueCommentUsers,
                                                  NSArray *comments))completion {
    NSMutableString *userName = [NSMutableString string];
    NSMutableArray *uniqueUsers = nil;
    NSMutableArray *_unqueArrayOfName = nil;
    NSInteger i = 1;
    if (![NSArray isValidArray:items]) {
        if (completion)
            completion(NO, userName, uniqueUsers, nil);
        return;
    }
    NSMutableArray *allcomments = [NSMutableArray new];
    uniqueUsers = [NSMutableArray array];
    _unqueArrayOfName = [NSMutableArray array];
    userName = [NSMutableString string];
    for (id commentItem in items) {
        ABISFChatterCommentItemModel *commentItemModel = [[ABISFChatterCommentItemModel alloc] initWithParentFeedID:parentFeedID commentItem:commentItem];
        [allcomments addObject:commentItemModel];
    }
    allcomments = [[allcomments sortArrayForKey:kCreatedDate ascending:NO] mutableCopy];
    for (ABISFChatterCommentItemModel *commentItemModel in allcomments) {
        if (isUniqueCommentUsersSerch) {
            NSString *stringName = commentItemModel.parent.name;
            if (![NSString isNULLString:stringName]) {
                if (![_unqueArrayOfName containsObject:stringName]) {
                    if (userName.length < MAX_CHARECTER_LENGHT_BEFORE_MORE_STRING && i <= MAX_NAME_COUNT) {
                        if (userName.length) {
                            [userName appendString:@", "];
                        }
                        [userName appendString:stringName];
                    }
                    [uniqueUsers addObject:commentItemModel];
                    [_unqueArrayOfName addObject:stringName];
                    i += 1;
                }
            }
        }
    }
    BOOL _isMoreAvailable = NO;
    if (isUniqueCommentUsersSerch && userName.length && _unqueArrayOfName.count > MAX_NAME_COUNT &&
        userName.length < MAX_CHARECTER_LENGHT_BEFORE_MORE_STRING) {
        _isMoreAvailable = YES;
        [userName appendString:STATIC_TEXT_MORE_TEXT];
    } else if (isUniqueCommentUsersSerch && userName.length && userName.length > MAX_CHARECTER_LENGHT_BEFORE_MORE_STRING) {
        _isMoreAvailable = YES;
        [userName appendString:STATIC_TEXT_MORE_TEXT];
    }
        // Remove
    if (_unqueArrayOfName.count)
        [_unqueArrayOfName removeAllObjects];
    _unqueArrayOfName = nil;
    if (completion)
        completion(_isMoreAvailable, userName, uniqueUsers, allcomments);
}
+ (void)bindResponseDataForMessage:(id)respose feedInfo:(void (^)(id feedInfoObject))feedInfo completion:(SOQLCompletion)completion {
    NSString *nextPageUrl = nil;
    NSMutableArray *resultMessages = nil; //[NSMutableArray array];
    if (respose) {
        if ([NSDictionary isValidDictionary:respose]) {
            ABISFChatterPrivateMessageDataModel *messageDataModel = [[ABISFChatterPrivateMessageDataModel alloc] initWithMessageResponse:respose];
            resultMessages = messageDataModel.messages;
            nextPageUrl = messageDataModel.nextPageUrl;
        }
    }
    if (completion)
        completion(resultMessages.count ? resultMessages : nil, nil, resultMessages.count ? kSOQLStatusSucccess : kSOQLStatusFailed);
    if (feedInfo)
        feedInfo([NSObject isNullObject:nextPageUrl] ? nil : nextPageUrl);
}
+ (NSMutableArray<ABISFChatterParentDataModel *> *)bindResponseDataForChatterUser:(id)respose {
    NSMutableArray *bindedModelCollection = nil;
    if ([NSDictionary isValidDictionary:respose]) {
        bindedModelCollection = [NSMutableArray array];
        ABISFChatterParentDataModel *parent = [[ABISFChatterParentDataModel alloc] initWithParentDictionary:respose];
        [bindedModelCollection addObject:parent];
    }
    return bindedModelCollection;
}
#pragma mark - Bind Search Results Response
+ (NSMutableArray *)bindResponseDataForSearchMentions:(NSArray *)searchResults {
    NSMutableArray *results = [NSMutableArray array];
    for (NSDictionary *mentionDict in searchResults) {
        ABISFChatterMentionDataModel *mentionDataModel = [[ABISFChatterMentionDataModel alloc] initWithMentionCompletions:mentionDict];
        [results addObject:mentionDataModel];
    }
    return results;
}
#pragma mark - Bind Message Response
+ (ABISFChatterPrivateMessageDataModel *)bindResponseDataForMessage:(id)respose {
    ABISFChatterPrivateMessageDataModel *messageDataModel = nil;
    if (respose) {
        if (respose && [respose isKindOfClass:[NSDictionary class]]) {
            messageDataModel = [[ABISFChatterPrivateMessageDataModel alloc] initWithMessageResponse:respose];
        }
    }
    return messageDataModel;
}
#pragma mark - Bind UploadFile Response
+ (ABISFChatterContentDataModel *)bindResponseDataForUploadFile:(NSDictionary *)response {
    ABISFChatterContentDataModel *contentDataModel = nil;
    if (response) {
        NSDictionary *_responseDict = (NSDictionary *)response;
        if (_responseDict) {
            ABISFChatterContentDataModel *tempObj = [[ABISFChatterContentDataModel alloc] initWithContentdictionary:_responseDict];
            if (tempObj.ID)
                contentDataModel = tempObj;
        }
    }
    return contentDataModel;
}
@end
