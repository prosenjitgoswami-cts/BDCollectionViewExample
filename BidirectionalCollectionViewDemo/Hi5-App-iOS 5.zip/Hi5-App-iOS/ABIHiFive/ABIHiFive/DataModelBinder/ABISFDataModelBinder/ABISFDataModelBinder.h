    //
    //  ABISFDataModelBinder.h
    //  ABIHiFive
    //
    //  Created by Prsenjit Goswami on 21/06/16.
    //  Copyright © 2016 Cognizant. All rights reserved.
    //
#import "Constants.h"
#import <Foundation/Foundation.h>
@class ABISFAnnouncementDataModel;
@class ABISFKPIsDetailsDataModel, ABISFMyReporteeDataModel;
@interface ABISFDataModelBinder : NSObject
+ (NSMutableArray<NSMutableArray<ABISFKPIsDetailsDataModel *> *> *)bindResponseDataForKPIsDetails:(id)result
                                                                                         rosterID:(NSString *)_rosterID
                                                                                      incentiveID:(NSString *)incentiveID
                                                                                  extraDependency:(NSDictionary *)extraDependency
                                                                                        ascending:(BOOL)ascending
                                                                                       sortByKeys:(NSArray<NSString *> *)sortByKeys;
+ (void)bindResponse:(id)response
 serviceOperationKey:(ABIFetchOperationKey)serviceOperationKey
     extraDependency:(NSDictionary<NSString *, id> *)extraDependency
           ascending:(BOOL)ascending
          sortByKeys:(NSArray<NSString *> *)sortByKeys
         failedBlock:(ABIFailedBlock)failedBlock
     completionBlock:(ABIMutableArrayResponseBlock)completionBlock;
@end
