    //
    //  ABISFDataModelBinder.m
    //  ABIHiFive
    //
    //  Created by Prsenjit Goswami on 21/06/16.
    //  Copyright © 2016 Cognizant. All rights reserved.
    //
#import "ABISFDataModelBinder.h"
#import "ABISFAnnouncementDataModel.h"
#import "ABISFDataFetcherService.h"
#import "ABISFEarnBadgesDataModel.h"
#import "ABISFIncentiveDataModel.h"
#import "ABISFKPIsDetailsDataModel.h"
#import "ABISFMyReporteeDataModel.h"
#import "ABISFPeerRankingDataModel.h"
#import "ABISFRosterDataModel.h"
#import "AppDelegate.h"
#import "Constants.h"

@implementation ABISFDataModelBinder

#pragma mark -  Public Method
/*!
 *  Bind Record with Model
 *
 *  @param record              Response record
 *  @param serviceOperationKey Service Operation key
 *  @param extraDependency           Pass extra information (if needed)
 *  @param failedBlock         Failed Response
 *  @param completionBlock     Completion Response Collections of Corrosponding Data Model.
 */
+ (void)bindResponse:(id)response
 serviceOperationKey:(ABIFetchOperationKey)serviceOperationKey
     extraDependency:(NSDictionary<NSString *, id> *)extraDependency
           ascending:(BOOL)ascending
          sortByKeys:(nullable NSArray<NSString *> *)sortByKeys
         failedBlock:(ABIFailedBlock)failedBlock
     completionBlock:(ABIMutableArrayResponseBlock)completionBlock {
    dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0), ^{
        NSMutableArray *results = [ABISFDataModelBinder bindResponseInOtherThread:response
                                                              serviceOperationKey:serviceOperationKey
                                                                  extraDependency:extraDependency
                                                                        ascending:ascending
                                                                       sortByKeys:sortByKeys];
            // Return In Main Thread
        dispatch_async(dispatch_get_main_queue(), ^{
            if (!response) {
                if (failedBlock) {
                    failedBlock([NSError errorNoDataAvailable], nil);
                }
            } else {
                    // FIXME: I need check the array count
                if (completionBlock) {

                    completionBlock(results, nil);
                }
            }
        });
    });
}

#pragma mark -  Private Method
+ (NSMutableArray *)bindResponseInOtherThread:(id)response
                          serviceOperationKey:(ABIFetchOperationKey)serviceOperationKey
                              extraDependency:(NSDictionary *)extraDependency
                                    ascending:(BOOL)ascending
                                   sortByKeys:(nullable NSArray<NSString *> *)sortByKeys {
    NSMutableArray *results = nil;
    switch (serviceOperationKey) {
        case ABIFetchOperationForRosterDetails: {
            results =
            [ABISFDataModelBinder bindResponseDataForRosterDetail:response extraDependency:extraDependency ascending:ascending sortByKeys:sortByKeys];
        } break;

        case ABIFetchOperationForBadgeDetails: {
            if (extraDependency.count) {
                NSString *rosterID = extraDependency[kRosterID];
                results = [ABISFDataModelBinder bindResponseDataForAllRosterBadgesDetails:response
                                                                                 rosterID:rosterID
                                                                          extraDependency:extraDependency
                                                                                ascending:ascending
                                                                               sortByKeys:sortByKeys];
            }
            break;
        }
        case ABIFetchOperationForReporteesIncentiveDetails: {
            results = [ABISFDataModelBinder bindResponseDataForDMsIncentiveDetailsOfASD:response
                                                                        extraDependency:extraDependency
                                                                              ascending:ascending
                                                                             sortByKeys:sortByKeys];
        } break;
        case ABIFetchOperationForAnnouncementDetails: {
            results =
            [ABISFDataModelBinder bindResponseDataForAnnouncements:response extraDependency:extraDependency ascending:ascending sortByKeys:sortByKeys];
        } break;
        case ABIFetchOperationForAllReporteeDetails: {
            results =
            [ABISFDataModelBinder bindResponseDataForMyDMs:response extraDependency:extraDependency ascending:(BOOL)ascending sortByKeys:sortByKeys];
        } break;
        case ABIFetchOperationForPeerRankingIncentivePointWise: {

                // This rosterDataModel is user to check the the check the current Roster Postion among all Peer results. There is a 'You are here' annotaion
                // bubble is shown among the all peer.
            ABISFRosterDataModel *rosterDataModel = extraDependency[kABISFRosterDataModel];
            results = [ABISFDataModelBinder bindResponseDataForPeerRankingDetsils:response
                                                                           roster:rosterDataModel
                                                                  extraDependency:extraDependency
                                                                        ascending:(BOOL)ascending
                                                                       sortByKeys:sortByKeys];
        } break;
        case ABIFetchOperationForIncentiveDetails: {
            results = [ABISFDataModelBinder bindResponseDataForIncentiveDetails:response
                                                                extraDependency:extraDependency
                                                                      ascending:ascending
                                                                     sortByKeys:sortByKeys];
        } break;
        case ABIFetchOperationForAllReporteeKPIsWiseIncentivePerformanceDetails: {
            results = [ABISFDataModelBinder bindResponseDataForKPIsDetails:response
                                                                  rosterID:nil
                                                               incentiveID:nil
                                                           extraDependency:nil
                                                                 ascending:ascending
                                                                sortByKeys:nil];
        } break;
        case ABIFetchOperationForKPIDetailsForIncentive: {
            NSString *incentiveID = extraDependency[kIncentiveID];
            results = [ABISFDataModelBinder bindResponseDataForKPIsDetails:response
                                                                  rosterID:nil
                                                               incentiveID:incentiveID
                                                           extraDependency:extraDependency
                                                                 ascending:ascending
                                                                sortByKeys:nil];
        } break;
        default: break;
    }
    return results;
}

#pragma mark -  Roster Detail
/*!
 *  Perse the response data and Bind to model (ABISFRosterDataModel)
 *
 *  @param record     response data
 *  @param completion Callback with Collection of ABISFRosterDataModel, error, status
 */
+ (NSMutableArray<ABISFRosterDataModel *> *)bindResponseDataForRosterDetail:(id)record
                                                            extraDependency:(NSDictionary *)extraDependency
                                                                  ascending:(BOOL)ascending
                                                                 sortByKeys:(nullable NSArray<NSString *> *)sortByKeys {
    NSDictionary *rosterDict = [ABISFDataModelBinder recordDictionary:record];
    if (!rosterDict)
        return nil;
    NSMutableArray *results = [NSMutableArray array];
    ABISFRosterDataModel *roster = [[ABISFRosterDataModel alloc] initWithResponse:rosterDict];
    [results addObject:roster];

    if ([roster isLogedInRoster])
        [AppDelegate setGlobalSingedInRoster:roster];
    return results;
}
#pragma mark Incentive Information
/*!
 *  Perse the response data and Bind to model (ABISFIncentiveDataModel)
 *
 *  @param record     Response data
 *  @param completion Callback with Collection of ABISFIncentiveDataModel, error, status
 */

+ (NSMutableArray<ABISFIncentiveDataModel *> *)bindResponseDataForIncentiveDetails:(id)response
                                                                   extraDependency:(NSDictionary *)extraDependency
                                                                         ascending:(BOOL)ascending
                                                                        sortByKeys:(nullable NSArray<NSString *> *)sortByKeys {
    NSArray *records = [ABISFDataModelBinder responseRecords:response];
    if (!records.count)
        return nil;

    NSMutableDictionary *groupedIncentiveDetails = [NSMutableDictionary dictionary];

    for (NSDictionary *obj in records) {
        ABISFIncentiveDataModel *dataModel = [[ABISFIncentiveDataModel alloc] initWithIncentiveResponse:obj];
        NSString *incentiveID = dataModel.incentiveName;

        if (![NSString isNULLString:incentiveID] && dataModel) {

            NSMutableArray *entries = [NSMutableArray array];
            NSMutableArray *previousCollections = nil;

            if ([[groupedIncentiveDetails allKeys] containsObject:incentiveID]) {
                previousCollections = [groupedIncentiveDetails objectForKey:incentiveID];
            }

            if (previousCollections.count) {
                [entries addObjectsFromArray:previousCollections];
            }

            [entries addObject:dataModel];

            if (entries.count)
                [groupedIncentiveDetails setObject:entries forKey:incentiveID];
        }
    }

    NSMutableArray<ABISFIncentiveDataModel *> *bindedModelCollection = [[NSMutableArray alloc] init];

    for (NSString *incentiveID in groupedIncentiveDetails.allKeys) {

        NSMutableArray *incentives = [groupedIncentiveDetails objectForKey:incentiveID];

        if (incentives.count) {
            [incentives abiSortedWeekWishIncentiveCollection];
            ABISFIncentiveDataModel *latestIncentive = [incentives firstObject];
            if (latestIncentive)
                [bindedModelCollection addObject:latestIncentive];
        }
    }
    [bindedModelCollection abiSortedIncentiveCollection];
        //	if(bindedModelCollection)
        //		[bindedModelCollection sortFor Key:@"incentiveD isplayName" ascending:YES];
    return bindedModelCollection;
}

+ (NSMutableArray<ABISFIncentiveDataModel *> *)bindResponseDataForDMsIncentiveDetailsOfASD:(id)response
                                                                           extraDependency:(NSDictionary *)extraDependency
                                                                                 ascending:(BOOL)ascending
                                                                                sortByKeys:(nullable NSArray<NSString *> *)sortByKeys {
    NSArray *records = [ABISFDataModelBinder responseRecords:response];
    NSMutableArray<ABISFIncentiveDataModel *> *bindedModelCollection = [[NSMutableArray alloc] init];
    for (NSDictionary *obj in records) {

        ABISFIncentiveDataModel *incentive = [[ABISFIncentiveDataModel alloc] initWithIncentiveResponse:obj];
        [bindedModelCollection addObject:incentive];
    }
    return bindedModelCollection;
}
#pragma mark Badges

+ (NSMutableArray<ABISFEarnBadgesDataModel *> *)bindResponseDataForAllRosterBadgesDetails:(id)result
                                                                                 rosterID:(NSString *)rosterID
                                                                          extraDependency:(NSDictionary *)extraDependency
                                                                                ascending:(BOOL)ascending
                                                                               sortByKeys:(nullable NSArray<NSString *> *)sortByKeys {
    NSMutableArray<ABISFEarnBadgesDataModel *> *bindedModelCollection = [[NSMutableArray alloc] init];
    NSArray *records = [ABISFDataModelBinder responseRecords:result];
    for (NSDictionary *earnBadge in records) {
        ABISFEarnBadgesDataModel *earnBadgesDataModel = [[ABISFEarnBadgesDataModel alloc] initWithEarnBadgesResponse:earnBadge rosterID:rosterID];
        [bindedModelCollection addObject:earnBadgesDataModel];
    }
    [ABISFEarnBadgesDataModel sortByPriority:bindedModelCollection];
    return bindedModelCollection;
}

#pragma mark KPIsResponse
/*!
 *  Perse the response data and Bind to model (ABISFKPIsDetailsDataModel)
 *
 *  @param record     Response data
 *  @param completion Callback with Collection of ABISFKPIsDetailsDataModel, error, status
 */
+ (NSArray<NSMutableArray<ABISFKPIsDetailsDataModel *> *> *)bindResponseDataForKPIsDetails:(nonnull id)result
                                                                                  rosterID:(nullable NSString *)_rosterID
                                                                               incentiveID:(nonnull NSString *)_incentiveID
                                                                           extraDependency:(nullable NSDictionary *)extraDependency
                                                                                 ascending:(BOOL)ascending
                                                                                sortByKeys:(nullable NSArray<NSString *> *)sortByKeys {
    NSMutableArray *bindedModelKPICollection = nil;
    if ([NSDictionary isValidDictionary:result]) {
        NSArray *records = nil;
        NSDictionary *responseDataDict = result;
        id recordData = responseDataDict[kRECORD];
        if ([NSArray isValidArray:recordData]) {
            records = (NSArray *)recordData;
        }
        NSMutableDictionary *distChannelDist = [NSMutableDictionary dictionary];
        for (NSDictionary *obj in records) {
            NSDictionary *dic_Incntv_KPI_Id__r = [NSDictionary objectForKeySafe:obj key:kSOQLIncntv_KPI_Id__r]; // kIncntv_KPI_Id__r];
            if ([NSDictionary isValidDictionary:dic_Incntv_KPI_Id__r]) {
                NSString *dictionatyKey = dic_Incntv_KPI_Id__r[kSOQLChannel_Nm__c];
                if (![distChannelDist objectForKey:dictionatyKey]) {
                    [distChannelDist setObject:dictionatyKey forKey:dictionatyKey];
                }
            }
        }
        NSArray *sortedChannelNames = nil;
        if ([NSDictionary isValidDictionary:distChannelDist] && distChannelDist.count) {
            sortedChannelNames = [ABISFKPIsDetailsDataModel sortChannelName:distChannelDist isAscending:YES];
        }
        bindedModelKPICollection = [NSMutableArray array];
        NSMutableDictionary *channelDict = [NSMutableDictionary dictionary];
        for (NSString *channelName in sortedChannelNames) {
            NSMutableArray *subChannels = [NSMutableArray array];
            for (NSDictionary *obj in records) {

                NSDictionary *Incntv_KPI_Id__r_Dict = [NSDictionary objectForKeySafe:obj key:kSOQLIncntv_KPI_Id__r];

                if ([NSDictionary isValidDictionary:Incntv_KPI_Id__r_Dict]) {
                    NSString *dictionatyKey = Incntv_KPI_Id__r_Dict[kSOQLChannel_Nm__c];
                    if (![NSString isNULLString:dictionatyKey] && [dictionatyKey isEqualToString:channelName]) {
                        ABISFKPIsDetailsDataModel *kpisDetailsDataModel = [ABISFKPIsDetailsDataModel new];
                        kpisDetailsDataModel.channelName = dictionatyKey;
                        kpisDetailsDataModel.kpiID = [NSDictionary objectForKeySafe:obj key:kID];
                        kpisDetailsDataModel.kpiName = [NSDictionary objectForKeySafe:Incntv_KPI_Id__r_Dict key:kSOQLINCNTV_KPI_KPI_NM__c];
                            // Roster Information
                        NSDictionary *dictRoster_User__r = [NSDictionary objectForKeySafe:obj key:kSOQLRoster_User_ID__r];
                        if (dictRoster_User__r.count)
                            kpisDetailsDataModel.roster = [[ABISFRosterDataModel alloc] initWithResponse:dictRoster_User__r];
                        NSString *strProgressColorForKPI = [NSDictionary objectForKeySafe:obj key:kSOQLINCNTV_Status__c];
                        kpisDetailsDataModel.progressStatusColor = [strProgressColorForKPI lowercaseString];

                        NSNumber *incentiveValue = [NSDictionary objectForKeySafe:obj key:kSOQLINCNTV_Value__c];
                        NSString *incentiveValueDisplay = [NSDictionary objectForKeySafe:obj key:kSOQLINCNTV_Value_Disp__c];
                        kpisDetailsDataModel.incentiveValueText = incentiveValueDisplay;
                        kpisDetailsDataModel.incentiveValue = incentiveValue;
                        kpisDetailsDataModel.minRange = @(0);
                        kpisDetailsDataModel.maxRange = @(100);
                        kpisDetailsDataModel.progress = @(0);

                        NSString *_kpiResult = [incentiveValueDisplay stringByReplacingOccurrencesOfString:@"" withString:@"%%"];
                        _kpiResult = [incentiveValueDisplay stringByReplacingOccurrencesOfString:@"" withString:@"("];
                        _kpiResult = [incentiveValueDisplay stringByReplacingOccurrencesOfString:@"" withString:@")"];

                        if ([incentiveValueDisplay containsString:@"%"]) {
                            kpisDetailsDataModel.progressUnit = @"%";

                            double _kpiResultInDouble = [_kpiResult doubleValue];
                            kpisDetailsDataModel.progress = @(_kpiResultInDouble);
                                //    kpisDetailsDataModel.progressText = @(_kpiResultInDouble);

                            if (![NSString isNULLString:strProgressColorForKPI]) {
                                strProgressColorForKPI = [strProgressColorForKPI uppercaseString];
                                if ([strProgressColorForKPI isEqualToString:kGREEN]) {
                                    kpisDetailsDataModel.progress = @(95);
                                } else if ([strProgressColorForKPI isEqualToString:kYELLOW]) {
                                    kpisDetailsDataModel.progress = @(65);
                                } else if ([strProgressColorForKPI isEqualToString:kRED]) {
                                    kpisDetailsDataModel.progress = @(35);
                                }
                            }
                        } else {

                            kpisDetailsDataModel.progressUnit = @"";
                                //                            double _kpiResultInDouble = [_kpiResult doubleValue];
                                // kpisDetailsDataModel.progressText = @(_kpiResultInDouble);

                            if (![NSString isNULLString:strProgressColorForKPI]) {
                                strProgressColorForKPI = [strProgressColorForKPI uppercaseString];
                                if ([strProgressColorForKPI isEqualToString:kGREEN]) {
                                    kpisDetailsDataModel.progress = @(95);
                                } else if ([strProgressColorForKPI isEqualToString:kYELLOW]) {
                                    kpisDetailsDataModel.progress = @(65);
                                } else if ([strProgressColorForKPI isEqualToString:kRED]) {
                                    kpisDetailsDataModel.progress = @(35);
                                }
                            }
                        }
                        if (kpisDetailsDataModel) {
                            [subChannels addObject:kpisDetailsDataModel];
                        }
                    }
                }
            }
            if (subChannels && subChannels.count) {

                [channelDict setObject:subChannels forKey:channelName];
            }
        }
        [bindedModelKPICollection addObject:channelDict];
        sortedChannelNames = nil;
    }
    return bindedModelKPICollection;
}
#pragma mark Peer Ranking
/*!
 *  Perse the response data and Bind to model (ABISFPeerRankingDataModel)
 *
 *  @param record     Response data
 *  @param completion Callback with Collection of ABISFPeerRankingDataModel, error, status
 */
+ (NSMutableArray<ABISFPeerRankingDataModel *> *)bindResponseDataForPeerRankingDetsils:(id)response
                                                                                roster:(ABISFRosterDataModel *)roster
                                                                       extraDependency:(NSDictionary *)extraDependency
                                                                             ascending:(BOOL)ascending
                                                                            sortByKeys:(nullable NSArray<NSString *> *)sortByKeys {
    NSArray *records = [ABISFDataModelBinder responseRecords:response];
    if (![NSArray isValidArray:records]) {
        return nil;
    }
    NSMutableArray *bindedModelCollection = [[NSMutableArray alloc] init];
    for (id obj in records) {
        if ([NSDictionary isValidDictionary:obj]) {
            ABISFPeerRankingDataModel *peerRankingDataModel =
            [[ABISFPeerRankingDataModel alloc] initWithPeerRankingResponse:obj
                                                           singnedInRoster:roster]; // FIXME: URGENT Check idName Can applicable or not?
            [bindedModelCollection addObject:peerRankingDataModel];
        }
    }

    [bindedModelCollection abiSortedPeerCollectionResults];

    return bindedModelCollection;
}
#pragma mark Announcements
/*!
 *  Perse the response data and Bind to model (ABISFAnnouncementDataModel)
 *
 *  @param record     Response data
 *  @param completion Callback with Collection of ABISFAnnouncementDataModel, error, status
 */
+ (NSMutableArray<ABISFAnnouncementDataModel *> *)bindResponseDataForAnnouncements:(id)records
                                                                   extraDependency:(NSDictionary *)extraDependency
                                                                         ascending:(BOOL)ascending
                                                                        sortByKeys:(nullable NSArray<NSString *> *)sortByKeys {
    NSArray *validRecords = [ABISFDataModelBinder responseRecords:records];
    if (![NSArray isValidArray:validRecords])
        return nil;
    NSMutableArray *bindedModelCollection = [[NSMutableArray alloc] init];
    for (id obj in validRecords) {
        if ([NSDictionary isValidDictionary:obj]) {
            NSDictionary *announcementsResponse = (NSDictionary *)obj;

            ABISFAnnouncementDataModel *announcementDataModel = [[ABISFAnnouncementDataModel alloc] initWithResponse:announcementsResponse];
            [bindedModelCollection addObject:announcementDataModel];
        }
    }
    return bindedModelCollection;
}

#pragma mark - Bind My DMs Data
+ (NSMutableArray<ABISFRosterDataModel *> *)bindResponseDataForMyDMs:(id)record
                                                     extraDependency:(NSDictionary *)extraDependency
                                                           ascending:(BOOL)ascending
                                                          sortByKeys:(nullable NSArray<NSString *> *)sortByKeys {
    NSArray *dms = [ABISFDataModelBinder responseRecords:record];
    if (!dms.count)
        return nil;
    NSMutableArray *bindedModelCollection = [[NSMutableArray alloc] init];
    for (NSDictionary *dict in dms) {
        if (![NSDictionary isValidDictionary:dict])
            continue;
        ABISFRosterDataModel *dataModel = [[ABISFRosterDataModel alloc] initWithResponse:dict];
        [bindedModelCollection addObject:dataModel];
    }
        //	if(bindedModelCollection.count)
        //		[bindedModelCollection sort ForKey:@"rosterNameText" ascending:YES];//TODO: MOVE TO COMMON FILE

    [bindedModelCollection abiSortedMyReporteeCollectionResults];
    return bindedModelCollection;
}

#pragma mark - Private Method

+ (NSArray<NSDictionary *> *)responseRecords:(id)record {
    BOOL isValidResponse = NO;
    isValidResponse = [NSDictionary isValidDictionary:record];
    if (!isValidResponse)
        return nil;
    NSDictionary *recordDictionaryObject = (NSDictionary *)record;
    id recordsArrayObject = recordDictionaryObject[kRECORD];
    isValidResponse = [NSArray isValidArray:recordsArrayObject];
    if (!isValidResponse)
        return nil;
    NSArray *records = (NSArray *)recordsArrayObject;
    isValidResponse = records && records.count > 0;
    if (!isValidResponse)
        return nil;
    return records;
}

+ (NSDictionary *)recordDictionary:(id)record {
    BOOL isValidResponse = NO;
    NSArray *records = [ABISFDataModelBinder responseRecords:record];
    id responseDictObject = [records firstObject];
    isValidResponse = [NSDictionary isValidDictionary:responseDictObject];
    if (!isValidResponse)
        return nil;

    NSDictionary *responseDict = (NSDictionary *)responseDictObject;
    return responseDict;
}

@end
