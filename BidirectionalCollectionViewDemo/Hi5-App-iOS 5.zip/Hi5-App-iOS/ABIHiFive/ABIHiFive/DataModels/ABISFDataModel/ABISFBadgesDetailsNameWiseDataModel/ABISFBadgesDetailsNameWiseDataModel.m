    //
    //  ABISFBadgesDetailsNameWiseDataModel.m
    //  ABIHiFive
    //
    //  Created by Prsenjit Goswami on 16/08/16.
    //  Copyright © 2016 Cognizant. All rights reserved.
    //
#import "ABISFBadgesDetailsNameWiseDataModel.h"
#import "ABISFEarnBadgesDataModel.h"

@implementation ABISFBadgesDetailsNameWiseDataModel

#pragma mark - Custom Initializer
- (instancetype)initWithABISFBadgesDetailsNameWiseDataModelResponse:(id)response badgesName:(NSString *)badgesName {
    self = [super baseInit];
    if (self) {

        [self transposeIntoDataModelFromResponse:response badgesName:badgesName];
    }
    return self;
}

#pragma mark - Private Method
- (void)transposeIntoDataModelFromResponse:(NSArray *)response badgesName:(NSString *)badgesName {

    if (![NSArray isValidArray:response])
        return;
    NSPredicate *predicate = [NSPredicate predicateWithFormat:@"self.badgesName == %@", badgesName];
    NSArray *typeWiseBadges = [response filteredArrayUsingPredicate:predicate];
    NSMutableArray *arr = [NSMutableArray array];
    if (typeWiseBadges.count) {
        [arr addObjectsFromArray:typeWiseBadges];
        self.byNameEarnedbadges = arr;
    }
    self.badgesName = badgesName;
    self.numberOfEarnBadges = @(typeWiseBadges.count);
}

@end
