    //
    //  ABISFBadgesDetailsNameWiseDataModel.h
    //  ABIHiFive
    //
    //  Created by Prsenjit Goswami on 16/08/16.
    //  Copyright © 2016 Cognizant. All rights reserved.
    //
#import "ABISFEarnBadgesDataModel.h"
@interface ABISFBadgesDetailsNameWiseDataModel : ABISFEarnBadgesDataModel

- (instancetype)initWithABISFBadgesDetailsNameWiseDataModelResponse:(id)response badgesName:(NSString *)badgesName;

@property (strong, nonatomic) NSMutableArray<ABISFEarnBadgesDataModel *> *byNameEarnedbadges;

@end
