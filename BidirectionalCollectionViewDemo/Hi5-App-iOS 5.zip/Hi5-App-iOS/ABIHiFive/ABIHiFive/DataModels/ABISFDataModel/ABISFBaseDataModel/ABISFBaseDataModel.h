    //
    //  ABISFBaseDataModel.h
    //  ABIHiFive
    //
    //  Created by Prsenjit Goswami on 10/07/16.
    //  Copyright © 2016 Cognizant. All rights reserved.
    //
#import "EnumMaster.h"
#import "HelperUtilHeader.h"
#import "SalesForceConstants.h"
#import <Foundation/Foundation.h>

@interface ABISFBaseDataModel : NSObject

- (instancetype)init NS_UNAVAILABLE;
- (instancetype)baseInit;
@property (strong, nonatomic, readonly) NSString *uniqueIdentifier;

@end
