    //
    //  ABISFBaseDataModel.m
    //  ABIHiFive
    //
    //  Created by Prsenjit Goswami on 10/07/16.
    //  Copyright © 2016 Cognizant. All rights reserved.
    //
#import "ABISFBaseDataModel.h"
@implementation ABISFBaseDataModel

#pragma mark - Custom Initializer
- (instancetype)baseInit {

    return [super init];
}

+ (instancetype) new {

    return [[super alloc] baseInit];
}
@end
