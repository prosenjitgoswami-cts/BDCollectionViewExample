    //
    //  ABISFRosterDataModel+Additions.m
    //  AnheuserBusch
    //
    //  Created by Prsenjit Goswami on 21/06/16.
    //  Copyright © 2016 Cognizant. All rights reserved.
    //
#import "ABISFRosterDataModel+Additions.h"
#import "Constants.h"
#import <SalesforceSDKCore/SFAuthenticationManager.h>
#import <SalesforceSDKCore/SFIdentityCoordinator.h>
#import <SalesforceSDKCore/SFIdentityData.h>
@implementation ABISFRosterDataModel (Additions)
/*!
 *  Clean up all previous user details
 */
+ (void)cleanUserInformation {
    [NSUserDefaults removeUserDefault:kSOQLSignInUserRole__c];
    [NSUserDefaults removeUserDefault:kSOQLUser__c];
    [NSUserDefaults removeUserDefault:kSOQLID__c];
    [NSUserDefaults removeUserDefault:kSOQLDisplay__c];
    [NSUserDefaults removeUserDefault:kSOQLRole__c];
    [NSUserDefaults removeUserDefault:kSOQLName];
    ;
    [AppDelegate setGlobalSingedInRoster:nil];
    [AppDelegate setGlobalCurrentPageFlow:PageFlowUnknown];
}

/*!
 *  Current Roster Org ID
 *
 */
+ (NSString *)currentRosterOrgId {
    return [SFAuthenticationManager sharedManager].idCoordinator.idData.orgId;
}
/*!
 *  Current Roster Information
 *
 */
+ (SFIdentityData *)currentRosterInformation {
    SFIdentityData *idData = [SFAuthenticationManager sharedManager].idCoordinator.idData;
    return idData;
}

/*!
 *  Current Roster ID
 *
 */
+ (NSString *)currentRosterID {
    SFIdentityData *idData = [SFAuthenticationManager sharedManager].idCoordinator.idData;
    NSString *currentRosterIDForSOQL = idData.userId;
    return currentRosterIDForSOQL;
}
/*!
 *  Current Roster SOQL ID
 *
 */
+ (NSString *)currentRosterIDForSOQL {
    NSString *currentRosterIDForSOQL = [NSUserDefaults readUserDefault:kSOQLUser__c];
    return currentRosterIDForSOQL;
}
/*!
 *  Current Roster Role
 *
 */
+ (NSString *)signedInRosterRole {
    NSString *currentRosterIDForSOQL = [NSUserDefaults readUserDefault:kSOQLRole__c];
    return currentRosterIDForSOQL;
}
+ (RosterRole)rosterRole:(NSString *)rosterRoleString {
    RosterRole role = RosterRoleUnknown;
    if ([rosterRoleString isEqualToString:ABI_SF_USER_ROLE_DM]) {
        role = RosterRoleDM;
    } else if ([rosterRoleString isEqualToString:ABI_SF_USER_ROLE_SD]) {
        role = RosterRoleSD;
    }
    return role;
}

+ (PageFlow)pageFlow:(NSString *)rosterRoleString {
    PageFlow pageflow = PageFlowUnknown;
    if ([rosterRoleString isEqualToString:ABI_SF_USER_ROLE_DM]) {
        pageflow = PageFlowAsDM;
    } else if ([rosterRoleString isEqualToString:ABI_SF_USER_ROLE_SD]) {
        pageflow = PageFlowAsSD;
    }
    return pageflow;
}
+ (ABISFRosterDataModel *)signedInABISFRosterDataModel {
    return [AppDelegate appdelegateShareInstance].globalSingedInRoster;
}

- (BOOL)isLogedInRoster {

    return (self.rosterUserID && [self.rosterUserID isEqualToString:[ABISFRosterDataModel currentRosterID]]);
}
- (NSString *)rosterFirstName {
    NSArray *names = [self.rosterNameText componentsSeparatedByString:@" "];
    NSString *firstName = nil;
    if (names.count > 0) {
        firstName = names[0];
    }
    if ([NSString isNULLString:firstName]) {
        if (names.count > 1) {
            firstName = names[1];
        }
    }
    firstName = [firstName stringByReplacingOccurrencesOfString:@"'" withString:@""];
    firstName = [firstName stringByReplacingOccurrencesOfString:@"," withString:@""];
    firstName = [firstName stringByReplacingOccurrencesOfString:@" " withString:@""];
    return firstName;
}

- (BOOL)validABISFRosterDataModelClassObject {

    return ![NSObject isNullObject:self] && [self isKindOfClass:[self class]];
}
@end
