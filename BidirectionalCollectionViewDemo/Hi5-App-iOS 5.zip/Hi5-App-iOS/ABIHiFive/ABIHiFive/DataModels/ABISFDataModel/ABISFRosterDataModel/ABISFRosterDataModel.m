    //
    //  ABISFRosterDataModel.m
    //  ABIHiFive
    //
    //  Created by Prsenjit Goswami on 05/07/16.
    //  Copyright © 2016 Cognizant. All rights reserved.
    //
#import "ABISFRosterDataModel.h"
#import "ABIBusinessProtocol.h"
#import "Constants.h"

@interface ABISFRosterDataModel ()
@property (strong, nonatomic) NSString *rosterName;
@property (strong, nonatomic) NSString *rosterDisplayName;
@end

@implementation ABISFRosterDataModel

@synthesize rosterImageURLString = _rosterImageURLString;
@synthesize rosterRole = _rosterRole;
@synthesize managerRole = _managerRole;

- (instancetype)initWithResponse:(id)response {
    self = [super baseInit];
    if (self) {
        [self transposeIntoDataModelFromResponse:response];
    }
    return self;
}
#pragma mark -  Custom Accessor
- (NSString *)rosterImageURLString {

    return self.fullPhotoUrl;
}
- (void)setRoleInString:(NSString *)roleInString {
    _roleInString = roleInString;
    _rosterRole = [ABISFRosterDataModel rosterRole:_roleInString];
}
- (void)setManagerRoleInString:(NSString *)managerRoleInString {
    _managerRoleInString = managerRoleInString;
    _managerRole = [ABISFRosterDataModel rosterRole:_managerRoleInString];
}
- (NSString *)rosterNameText {
    return [ABIBusinessProtocol nameAndSurnameOfRoster:self.rosterName];
}
#pragma mark -  Private Method
/**
 *  Bind the response in Model
 *
 *  @param rosterDict Roster Details response
 */
- (void)transposeIntoDataModelFromResponse:(NSDictionary *)rosterDict {
    if (![NSDictionary isValidDictionary:rosterDict])
        return;

        //*** idName and rosterHireManagerID is same for Roster has no Hire Manager ****
    self.idName = [NSDictionary objectForKeySafe:rosterDict key:kSOQLName];
    self.rosterHireManagerID = [NSDictionary objectForKeySafe:rosterDict key:kSOQLRoster_Hier_SD__c];
    NSString *rosterDisplayName = [NSDictionary objectForKeySafe:rosterDict key:kSOQLDisplay__c];
    self.rosterDisplayName = rosterDisplayName;
    self.rosterName = [NSDictionary objectForKeySafe:rosterDict key:kSOQLRoster_Name__c];
    NSString *role = rosterDict[kSOQLRoster_Role__c];
    self.rosterID = rosterDict[kSOQLID__c];
    self.roleInString = role;
    [self setRegionDetails:rosterDict];
    [self setUserDetails:rosterDict];
    if (self.rosterUserID && [self.rosterUserID isEqualToString:[ABISFRosterDataModel currentRosterID]]) {
        self.managerRoleInString = role;
        if (![NSString isNULLString:self.roleInString]) {

            [NSUserDefaults saveObject:role forKey:kSOQLSignInUserRole__c];
            [NSUserDefaults saveObject:self.rosterName forKey:kSOQLName];
        }
    } else {
        self.managerRoleInString = [NSUserDefaults readUserDefault:kSOQLSignInUserRole__c];
    }
    [self saveRosterDetailsInUserDetails:self];
}
- (void)setRegionDetails:(NSDictionary *)response {
    id regionDictObject = [NSDictionary objectForKeySafe:response key:kSOQLSLS_Regn_Cd__r];
    if (![NSDictionary isValidDictionary:regionDictObject])
        return;
    if ([NSDictionary isValidDictionary:regionDictObject]) {
        NSDictionary *regionDict = (NSDictionary *)regionDictObject;
        self.regionName = [NSDictionary objectForKeySafe:regionDict key:kSOQLSLs_Regn_Nm__c];
    }
}
- (void)setUserDetails:(NSDictionary *)response {
    id user__rDictObject = [NSDictionary objectForKeySafe:response key:kSOQLUser_ID__r];
    if (![NSDictionary isValidDictionary:user__rDictObject])
        return;
    if ([NSDictionary isValidDictionary:user__rDictObject]) {
        self.rosterUserID = [NSDictionary objectForKeySafe:user__rDictObject key:kId];
        self.smallPhotoUrl = [NSDictionary objectForKeySafe:user__rDictObject key:kSOQLSmallPhotoUrl];
        self.fullPhotoUrl = [NSDictionary objectForKeySafe:user__rDictObject key:kSOQLFullPhotoUrl];
        self.sfRosterName = [NSDictionary objectForKeySafe:user__rDictObject key:kSOQLName];
    }
}
- (void)saveRosterDetailsInUserDetails:(ABISFRosterDataModel *)roster {
    [NSUserDefaults saveObject:roster.rosterDisplayName forKey:kSOQLDisplay__c];
    [NSUserDefaults saveObject:roster.rosterID forKey:kSOQLID__c];
    [NSUserDefaults saveObject:roster.roleInString forKey:kSOQLRole__c];
    [NSUserDefaults saveObject:roster.rosterUserID forKey:kSOQLUser__c];
}

@end
