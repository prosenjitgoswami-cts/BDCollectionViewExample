    //
    //  ABISFRosterDataModel+Additions.h
    //  ABIHiFive
    //
    //  Created by Prsenjit Goswami on 21/06/16.
    //  Copyright © 2016 Cognizant. All rights reserved.
    //
#import "ABISFRosterDataModel.h"
#import "EnumMaster.h"
#import <UIKit/UIKit.h>
@class SFIdentityData;
@interface ABISFRosterDataModel (Additions)
+ (void)cleanUserInformation;
+ (SFIdentityData *)currentRosterInformation;
+ (NSString *)currentRosterID;
+ (NSString *)currentRosterOrgId;
+ (RosterRole)rosterRole:(NSString *)rosterRoleString;
+ (ABISFRosterDataModel *)signedInABISFRosterDataModel;
- (NSString *)rosterFirstName;
+ (NSString *)signedInRosterRole;
+ (PageFlow)pageFlow:(NSString *)rosterRoleString;
- (BOOL)isLogedInRoster;
- (BOOL)validABISFRosterDataModelClassObject;
@end
