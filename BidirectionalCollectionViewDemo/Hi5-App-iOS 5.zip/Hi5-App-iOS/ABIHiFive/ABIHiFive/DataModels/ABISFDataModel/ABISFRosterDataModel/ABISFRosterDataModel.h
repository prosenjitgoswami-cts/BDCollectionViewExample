    //
    //  ABISFRosterDataModel.h
    //  ABIHiFive
    //
    //  Created by Prsenjit Goswami on 05/07/16.
    //  Copyright © 2016 Cognizant. All rights reserved.
    //
#import "ABISFBaseDataModel.h"
#import "EnumMaster.h"

@class ABISFEarnBadgesDataModel;
@class ABISFIncentiveDataModel;

@interface ABISFRosterDataModel : ABISFBaseDataModel

@property (strong, nonatomic) NSString *rosterUserID;
@property (strong, nonatomic) NSString *rosterID;
@property (strong, nonatomic) NSString *idName;
@property (strong, nonatomic) NSString *rosterHireManagerID;

@property (strong, nonatomic) NSString *roleInString;
@property (strong, nonatomic) NSString *managerRoleInString;
@property (strong, nonatomic) NSString *smallPhotoUrl;
@property (strong, nonatomic) NSString *fullPhotoUrl;
@property (strong, nonatomic) NSString *sfRosterName;
@property (strong, nonatomic) NSString *regionName;
@property (strong, nonatomic) NSNumber *earnedBadgeCount;
@property (strong, nonatomic) NSArray<NSString *> *incentiveNames;
@property (strong, nonatomic, readonly) NSString *rosterImageURLString;
@property (assign, nonatomic, readonly) RosterRole rosterRole;
@property (assign, nonatomic, readonly) RosterRole managerRole;

- (instancetype)initWithResponse:(id)response;
- (NSString *)rosterNameText;

@end
