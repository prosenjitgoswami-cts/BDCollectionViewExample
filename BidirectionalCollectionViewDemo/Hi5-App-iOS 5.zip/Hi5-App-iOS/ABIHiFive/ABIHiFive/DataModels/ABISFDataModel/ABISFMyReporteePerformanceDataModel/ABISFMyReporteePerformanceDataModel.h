    //
    //  ABISFMyReporteePerformanceDataModel.h
    //  ABIHiFive
    //
    //  Created by Prsenjit Goswami on 18/08/16.
    //  Copyright © 2016 Cognizant. All rights reserved.
    //
#import "ABISFBaseDataModel.h"

@interface ABISFMyReporteePerformanceDataModel : ABISFBaseDataModel

@property (strong, nonatomic) NSString *nameOfDM;
@property (strong, nonatomic) NSString *performancePoint;
@property (strong, nonatomic) NSString *progressStatusColor;

@end
