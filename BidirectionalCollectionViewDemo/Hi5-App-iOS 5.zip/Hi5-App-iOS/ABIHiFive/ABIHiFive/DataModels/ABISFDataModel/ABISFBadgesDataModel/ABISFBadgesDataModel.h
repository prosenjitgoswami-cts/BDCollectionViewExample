    //
    //  BadgesDataModel.h
    //  ABIHiFive
    //
    //  Created by Prsenjit Goswami on 16/08/16.
    //  Copyright © 2016 Cognizant. All rights reserved.
    //
#import "ABISFBaseDataModel.h"

@interface ABISFBadgesDataModel : ABISFBaseDataModel

@property (strong, nonatomic) NSString *incentiveName;
@property (strong, nonatomic) NSNumber *incentiveYear;
@property (strong, nonatomic) NSString *incentiveDateString;
@property (strong, nonatomic) NSString *badgesURLString;
@property (strong, nonatomic) NSNumber *priority;

- (instancetype)initWithResponse:(NSDictionary *)response year:(NSNumber *)year;

@end
