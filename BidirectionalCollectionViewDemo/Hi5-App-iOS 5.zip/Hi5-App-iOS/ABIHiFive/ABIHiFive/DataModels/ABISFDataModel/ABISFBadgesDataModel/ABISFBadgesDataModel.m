    //
    //  BadgesDataModel.m
    //  ABIHiFive
    //
    //  Created by Prsenjit Goswami on 04/07/16.
    //  Copyright © 2016 Cognizant. All rights reserved.
    //
#import "ABISFBadgesDataModel.h"

@implementation ABISFBadgesDataModel

#pragma mark - Custom Initializer
- (instancetype)initWithResponse:(NSDictionary *)response year:(NSNumber *)year {
    self = [super baseInit];
    if (self) {

        [self transposeIntoDataModelFromResponse:response year:year];
    }
    return self;
}

#pragma mark - Private Method
- (void)transposeIntoDataModelFromResponse:(NSDictionary *)response year:(NSNumber *)year {

    if (![NSDictionary isValidDictionary:response])
        return;

    self.incentiveYear = year;
    self.incentiveName = [NSDictionary objectForKeySafe:response key:kSOQLBadge_Desc__c];
        // self.incentiveName = [NSDictionary objectForKeySafe:dictIncntv_Id__r key:kSOQLIncntv_Nm__c];//FIXME: NOT FIND
    NSString *dateString = [NSDictionary objectForKeySafe:response key:kSOQLBadge_Award_DT__c];
    NSDate *date = [NSDate dateFromString:dateString andFormatterStyle:ABISFBADGE_AWARD_DATE_FORMAT];
    dateString = [NSDate stringFromDateInLocal:date andFormatterStyle:DISPLAY_BADGE_AWARD_DATE_FORMAT];
    self.incentiveDateString = [dateString nullStringTextCorrection];
    date = nil;
}
@end
