    //
    //  ABISFKPIsDetailsDataModel.h
    //  ABIHiFive
    //
    //  Created by Prsenjit Goswami on 04/07/16.
    //  Copyright © 2016 Cognizant. All rights reserved.
    //
#import "ABISFBaseDataModel.h"
@class ABISFMyReporteePerformanceDataModel, ABISFRosterDataModel;

@interface ABISFKPIsDetailsDataModel : ABISFBaseDataModel

@property (strong, nonatomic) NSString *channelName;
@property (strong, nonatomic) NSString *kpiID;
@property (strong, nonatomic) NSString *kpiName;
@property (strong, nonatomic) NSNumber *incentiveValue;
@property (strong, nonatomic) NSNumber *incentiveValueDisplay;
@property (strong, nonatomic) NSString *incentiveValueText;

@property (strong, nonatomic) NSString *progressStatusColor;
@property (strong, nonatomic) NSNumber *progress;
@property (strong, nonatomic) NSNumber *minRange;
@property (strong, nonatomic) NSNumber *maxRange;
@property (strong, nonatomic) NSString *progressUnit;
@property (strong, nonatomic) NSMutableArray<ABISFMyReporteePerformanceDataModel *> *myDMsPerformanceDataModels;
@property (strong, nonatomic) ABISFRosterDataModel *roster;

+ (NSArray *)sortChannelName:(NSMutableDictionary *)kpiChannelDict isAscending:(BOOL)isAscending;
+ (void)updateKPIDetailsModelWithMyDMsPerformace:(ABISFKPIsDetailsDataModel *)dataModel allReporteesKPIs:(NSMutableArray *)myDMsPerfomanceModels;
@end
