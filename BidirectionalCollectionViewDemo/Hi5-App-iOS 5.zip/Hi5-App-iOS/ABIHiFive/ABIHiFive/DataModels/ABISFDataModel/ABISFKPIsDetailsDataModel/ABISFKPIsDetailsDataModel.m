    //
    //  ABISFKPIsDetailsDataModel.m
    //  ABIHiFive
    //
    //  Created by Prsenjit Goswami on 04/07/16.
    //  Copyright © 2016 Cognizant. All rights reserved.
    //
#import "ABISFKPIsDetailsDataModel.h"
#import "ABISFMyReporteePerformanceDataModel.h"
#import "ABISFRosterDataModel.h"
#import "NSArray+ABISortedResults.h"

@implementation ABISFKPIsDetailsDataModel

#pragma mark -  Additions
+ (NSArray *)sortChannelName:(NSMutableDictionary *)kpiChannelDict isAscending:(BOOL)isAscending {
    NSArray *values = [kpiChannelDict allValues];
    NSSortDescriptor *sortDescriptor =
    [NSSortDescriptor sortDescriptorWithKey:nil ascending:isAscending selector:@selector(localizedCaseInsensitiveCompare:)];
    NSArray *sortedValues = [values sortedArrayUsingDescriptors:[NSArray arrayWithObject:sortDescriptor]];
    sortDescriptor = nil;
    return sortedValues;
}

+ (void)updateKPIDetailsModelWithMyDMsPerformace:(ABISFKPIsDetailsDataModel *)dataModel allReporteesKPIs:(NSMutableArray *)myDMsPerfomanceModels {
    if ([dataModel isKindOfClass:[ABISFKPIsDetailsDataModel class]]) {
        ABISFKPIsDetailsDataModel *kpisDetailsDataModel = (ABISFKPIsDetailsDataModel *)dataModel;
        NSPredicate *predicate = [NSPredicate predicateWithFormat:@"self.kpiName == %@ ", kpisDetailsDataModel.kpiName];
        NSArray<ABISFKPIsDetailsDataModel *> *dmsKPIsForKpiName = [myDMsPerfomanceModels filteredArrayUsingPredicate:predicate];
        NSMutableArray *dmsPerformanceDataModelsArray = [NSMutableArray array];
        for (ABISFKPIsDetailsDataModel *modelsub in dmsKPIsForKpiName) {
            if ([modelsub isKindOfClass:[ABISFKPIsDetailsDataModel class]]) {
                ABISFMyReporteePerformanceDataModel *dmsPerformanceDataModels = [ABISFMyReporteePerformanceDataModel new];
                dmsPerformanceDataModels.nameOfDM = modelsub.roster.rosterNameText;
                dmsPerformanceDataModels.performancePoint = [NSString stringWithFormat:@"%@", modelsub.incentiveValueText]; // TODO:KIP
                dmsPerformanceDataModels.progressStatusColor = modelsub.progressStatusColor;
                [dmsPerformanceDataModelsArray addObject:dmsPerformanceDataModels];
            }
        }
            //  [dmsPerformanceDataModelsArray sort ForKey:@"name OfDM" ascending:YES];
        [dmsPerformanceDataModelsArray abiSortedReporteePerformanceCollectionResults];
        kpisDetailsDataModel.myDMsPerformanceDataModels = dmsPerformanceDataModelsArray;
    }
}
@end
