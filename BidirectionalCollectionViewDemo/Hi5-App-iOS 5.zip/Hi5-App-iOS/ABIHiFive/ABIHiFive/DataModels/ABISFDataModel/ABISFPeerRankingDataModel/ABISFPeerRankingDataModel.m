    //
    //  ABISFPeerRankingDataModel.m
    //  ABIHiFive
    //
    //  Created by Prsenjit Goswami on 28/06/16.
    //  Copyright © 2016 Cognizant. All rights reserved.
    //
#import "ABISFPeerRankingDataModel.h"
#import "ABISFIncentiveDataModel.h"
#import "ABISFRosterDataModel.h"

@implementation ABISFPeerRankingDataModel

@synthesize rosterNameText = _rosterNameText;

- (instancetype)initWithPeerRankingResponse:(id)response singnedInRoster:(ABISFRosterDataModel *)singnedInRoster {
    self = [super baseInit];
    if (self) {
        [self transposeIntoDataModelFromResponse:response singnedInRoster:singnedInRoster];
    }
    return self;
}

#pragma mark - Override Method
- (BOOL)isEqual:(id)object {
    ABISFPeerRankingDataModel *prevObject = (ABISFPeerRankingDataModel *)object;
    return self.peerRoster.rosterUserID.length && prevObject.peerRoster.rosterUserID.length &&
    ([self.peerRoster.rosterUserID hash] == [prevObject.peerRoster.rosterUserID hash]);
}

#pragma mark - Public Method

+ (NSMutableArray<ABISFPeerRankingDataModel *> *)uniqueABISFPeerRankingDataModelCollection:(NSArray<ABISFPeerRankingDataModel *> *)collection {
    if (![NSArray isValidArray:collection])
        return nil;
    NSMutableArray *unique = [NSMutableArray array];
    for (ABISFPeerRankingDataModel *model in collection) {
        if (model && ![unique containsObject:model])
            [unique addObject:model];
    }
    return unique;
}

#pragma mark - Private Method

- (void)transposeIntoDataModelFromResponse:(NSDictionary *)response singnedInRoster:(ABISFRosterDataModel *)singnedInRoster {
    if (![NSDictionary isValidDictionary:response])
        return;
    self.incentive = [[ABISFIncentiveDataModel alloc] initWithIncentiveResponse:response];
    self.incentiveId = self.incentive.incentiveID;
    self.incentivePointsInNumber = self.incentive.overAllIncentiveProgress;
    self.incentiveName = self.incentive.incentiveName;
    [self setCurrentRosterDetails:response singnedInRoster:singnedInRoster];
}

/**
 *  Process Roster Details Dictionary
 *
 *  @param response        Response
 *  @param singnedInRoster SingnedInRoster Details.
 */
- (void)setCurrentRosterDetails:(NSDictionary *)response singnedInRoster:(ABISFRosterDataModel *)singnedInRoster {
        // Roster User Dict
    id roster_User_ID__r = [response valueForKeySafe:kSOQLRoster_User_ID__r];
    ABISFRosterDataModel *currentRosterUserDataModel = [[ABISFRosterDataModel alloc] initWithResponse:roster_User_ID__r];
    self.peerRoster = currentRosterUserDataModel;
    NSString *peerID = self.peerRoster.idName;
    NSString *singnedInRosterID = singnedInRoster.idName;
    [self checkAndSetCurrentUserWithRosterID:singnedInRosterID peerID:peerID];
    _rosterNameText = self.peerRoster.rosterNameText;
}

/**
 *  Check the Peer is current Roster that whose Peer are getting fetched.
 *
 *  @param rosterID Roster
 *  @param peerID   Peer ID
 */
- (void)checkAndSetCurrentUserWithRosterID:(NSString *)rosterID peerID:(NSString *)peerID {

    if (![NSString isNULLString:rosterID] && ![NSString isNULLString:peerID]) {
        BOOL isCirrentUser = [rosterID isEqualToString:peerID];
        if (isCirrentUser) {
            self.isCurrentUser = YES;
        }
    }
}
@end
