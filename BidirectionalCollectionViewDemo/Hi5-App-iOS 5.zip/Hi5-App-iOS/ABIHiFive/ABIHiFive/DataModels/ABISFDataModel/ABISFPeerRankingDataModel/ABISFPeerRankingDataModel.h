    //
    //  ABISFPeerRankingDataModel.h
    //  ABIHiFive
    //
    //  Created by Prsenjit Goswami on 28/06/16.
    //  Copyright © 2016 Cognizant. All rights reserved.
    //
#import "ABISFBaseDataModel.h"
@class ABISFRosterDataModel;
@class ABISFIncentiveDataModel;
@interface ABISFPeerRankingDataModel : ABISFBaseDataModel
@property (nonatomic, strong) NSString *incentiveId;
@property (nonatomic, strong) NSString *incentiveName;
@property (nonatomic, strong) NSNumber *incentivePointsInNumber;
@property (nonatomic, strong) NSNumber *incentivePointsInNumberRaw;
@property (nonatomic, strong) NSString *userRank;
@property (nonatomic, assign) BOOL isCurrentUser;
@property (nonatomic, strong) ABISFRosterDataModel *peerRoster;
@property (nonatomic, strong) ABISFIncentiveDataModel *incentive;
@property (nonatomic, strong, readonly) NSString *rosterNameText;

+ (NSMutableArray<ABISFPeerRankingDataModel *> *)uniqueABISFPeerRankingDataModelCollection:(NSArray<ABISFPeerRankingDataModel *> *)collection;

- (instancetype)initWithPeerRankingResponse:(id)response singnedInRoster:(ABISFRosterDataModel *)singnedInRoster;
@end
