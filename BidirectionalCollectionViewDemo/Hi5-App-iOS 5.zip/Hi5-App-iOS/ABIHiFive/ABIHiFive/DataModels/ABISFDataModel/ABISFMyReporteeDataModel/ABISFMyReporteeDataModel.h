    //
    //  ABISFMyReporteeDataModel.h
    //  ABIHiFive
    //
    //  Created by Prsenjit Goswami on 22/08/16.
    //  Copyright © 2016 Cognizant. All rights reserved.
    //
#import "ABISFBaseDataModel.h"

@interface ABISFMyReporteeDataModel : ABISFBaseDataModel

@property (nonatomic, strong) NSString *Id;
@property (nonatomic, strong) NSString *ID__c;
@property (nonatomic, strong) NSString *FullPhotoUrl;
@property (nonatomic, strong) NSString *Name;

- (instancetype)initWithResponse:(NSDictionary *)response;
@end
