    //
    //  ABISFMyReporteeDataModel.m
    //  ABIHiFive
    //
    //  Created by Prsenjit Goswami on 22/08/16.
    //  Copyright © 2016 Cognizant. All rights reserved.
    //
#import "ABISFMyReporteeDataModel.h"
#import "Constants.h"

@implementation ABISFMyReporteeDataModel

#pragma mark - Custom Initializer
- (instancetype)initWithResponse:(NSDictionary *)response {
    self = [super baseInit];
    if (self) {
        [self transposeIntoDataModelFromResponse:response];
    }
    return self;
}
#pragma mark - Private Method
- (void)transposeIntoDataModelFromResponse:(NSDictionary *)response {
    self.Id = [NSDictionary objectForKeySafe:response key:kID];
    self.ID__c = [NSDictionary objectForKeySafe:response key:kSOQLID__c];
}
@end
