    //
    //  ABISFEarnBadgesDataModel.m
    //  ABIHiFive
    //
    //  Created by Prsenjit Goswami on 10/07/16.
    //  Copyright © 2016 Cognizant. All rights reserved.
    //
#import "ABISFEarnBadgesDataModel.h"
#import "ABISFBadgesDataModel.h"
#import "ABISFBadgesDetailsNameWiseDataModel.h"
#import "ABISFRosterDataModel+Additions.h"
#import "NSArray+ABISortedResults.h"
#import "NSURL+ABIURL.h"

@implementation ABISFEarnBadgesDataModel

#pragma mark - Custom Initializer
- (instancetype)initWithEarnBadgesResponse:(id)response rosterID:(NSString *)rosterID {
    self = [super baseInit];
    if (self) {
        [self transposeIntoDataModelFromResponse:response rosterID:rosterID];
    }
    return self;
}

#pragma mark - Override Method
- (BOOL)isEqual:(id)object {
    ABISFEarnBadgesDataModel *obj = (ABISFEarnBadgesDataModel *)object;
    return [self.badgesName isEqualToString:obj.badgesName];
}

#pragma mark - Public Method
+ (void)sortByPriority:(nonnull NSMutableArray *)allCollection {
    [allCollection abiSortedBadgesCollectionResults];
}

#pragma mark - Private Method

+ (NSMutableArray<ABISFBadgesDetailsNameWiseDataModel *> *)__groupedBadgesByPriority:(NSMutableArray<ABISFEarnBadgesDataModel *> *)earnBadgesDetails {
    if (earnBadgesDetails.count == 0)
        return nil;
    NSMutableArray *priorities = [NSMutableArray array];
    NSMutableArray *nonPriorities = [NSMutableArray array];
    for (ABISFEarnBadgesDataModel *model in earnBadgesDetails) {
        if (!model || ![model isKindOfClass:[ABISFEarnBadgesDataModel class]])
            continue;
        NSNumber *priority = model.priority;
        if (priority) {
            if (![priorities containsObject:priority]) {
                [priorities addObject:priority];
            }
        } else {
            [nonPriorities addObject:model];
        }
    }
    NSMutableArray *earnBadgesDataModels = [NSMutableArray array];
    for (NSNumber *priority in priorities) {
        NSPredicate *predicate = [NSPredicate predicateWithFormat:@"self.priority == %@", priority];
        NSArray *typeWiseBadges = [earnBadgesDetails filteredArrayUsingPredicate:predicate];
        if (typeWiseBadges.count) {
            ABISFEarnBadgesDataModel *firstObject = [typeWiseBadges firstObject];
            ABISFBadgesDetailsNameWiseDataModel *groupedModel = [ABISFBadgesDetailsNameWiseDataModel new];
            groupedModel.badgesName = firstObject.badgesName;
            groupedModel.numberOfEarnBadges = typeWiseBadges.count ? @(typeWiseBadges.count) : @(0);
            groupedModel.priority = firstObject.priority;
            groupedModel.documentFolderName = firstObject.documentFolderName;
            groupedModel.badgesImageURLString = firstObject.badgesImageURLString;
            NSMutableArray *tempCollection = [NSMutableArray array];
            [tempCollection addObjectsFromArray:typeWiseBadges];
            groupedModel.byNameEarnedbadges = tempCollection;
            [earnBadgesDataModels addObject:groupedModel];
        }
    }
    for (ABISFEarnBadgesDataModel *model in nonPriorities) {
        if ([model isKindOfClass:[ABISFEarnBadgesDataModel class]])
            [earnBadgesDataModels addObject:model];
    }
    [ABISFEarnBadgesDataModel sortByPriority:earnBadgesDataModels];
    return earnBadgesDataModels;
}

+ (NSMutableArray<ABISFBadgesDetailsNameWiseDataModel *> *)groupedBadgesByPriority:(NSMutableArray<ABISFEarnBadgesDataModel *> *)earnBadgesDetails {

    if (earnBadgesDetails.count == 0)
        return nil;

    NSMutableArray *priorities = [NSMutableArray array];
    NSMutableArray *nonPriorities = [NSMutableArray array];

    for (ABISFEarnBadgesDataModel *model in earnBadgesDetails) {

        if (!model || ![model isKindOfClass:[ABISFEarnBadgesDataModel class]])
            continue;

        NSNumber *priority = model.priority;

        if (priority) {

            if (![priorities containsObject:priority]) {
                [priorities addObject:priority];
            }
        } else {
            [nonPriorities addObject:model];
        }
    }

    NSMutableArray *earnBadgesDataModels = [NSMutableArray array];

    for (NSNumber *priority in priorities) {

        NSPredicate *predicate = [NSPredicate predicateWithFormat:@"self.priority == %@", priority];
        NSArray *typeWiseBadges = [earnBadgesDetails filteredArrayUsingPredicate:predicate];

        if (typeWiseBadges.count) {

            ABISFEarnBadgesDataModel *firstObject = [typeWiseBadges firstObject];

            ABISFBadgesDetailsNameWiseDataModel *groupedModel = [ABISFBadgesDetailsNameWiseDataModel new];
            groupedModel.badgesName = firstObject.badgesName;
            groupedModel.numberOfEarnBadges = typeWiseBadges.count ? @(typeWiseBadges.count) : @(0);
            groupedModel.priority = firstObject.priority;
            groupedModel.documentFolderName = firstObject.documentFolderName;
            groupedModel.badgesImageURLString = firstObject.badgesImageURLString;
            NSMutableArray *tempCollection = [NSMutableArray array];
            [tempCollection addObjectsFromArray:typeWiseBadges];
            groupedModel.byNameEarnedbadges = tempCollection;

            [earnBadgesDataModels addObject:groupedModel];
        }
    }

    for (ABISFEarnBadgesDataModel *badges in nonPriorities) {

        if ([badges isKindOfClass:[ABISFEarnBadgesDataModel class]]) {

            ABISFBadgesDetailsNameWiseDataModel *groupedModel = [ABISFBadgesDetailsNameWiseDataModel new];
            groupedModel.badgesName = badges.badgesName;
            groupedModel.numberOfEarnBadges = @(1);
            groupedModel.priority = badges.priority;
            groupedModel.documentFolderName = badges.documentFolderName;
            groupedModel.badgesImageURLString = badges.badgesImageURLString;
            NSMutableArray *tempCollection = [NSMutableArray array];
            [tempCollection addObject:badges];
            groupedModel.byNameEarnedbadges = tempCollection;
            [earnBadgesDataModels addObject:groupedModel];
        }
    }

    [ABISFEarnBadgesDataModel sortByPriority:earnBadgesDataModels];

    return earnBadgesDataModels;
}

#pragma mark - Custom Accessor
- (void)setBadgesDataModel:(NSMutableArray<ABISFBadgesDataModel *> *)badgesDataModel {
    _badgesDataModel = badgesDataModel;
    self.numberOfEarnBadges = @(_badgesDataModel.count ? _badgesDataModel.count : 0);
}

- (void)setBadgeAwardDateString:(NSString *)badgeAwardDateString {
    _badgeAwardDateString = badgeAwardDateString;
    NSDate *badgeAwardDate = [NSDate dateFromString:_badgeAwardDateString andFormatterStyle:ABISFBADGE_AWARD_DATE_FORMAT];
    badgeAwardDate = badgeAwardDate;
    NSUInteger year = [badgeAwardDate year];
    self.year = @(year);
    badgeAwardDate = nil;
}

#pragma mark - Private Method
/*"Badge_Award_DT__c" = "2016-08-01";
 "Badge_Desc__c" = "Hi-5 Badge";
 "Badge_NM__c" = "Hi-5";
 "Badge_Priority__c" = 1;
 "Doc_Folder_NM1__c" = 0157A0000005mjZ;
 Id = a3r7A00000059emQAA;
 "Roster_User_ID__r" =     {
 "Roster_Name__c" = "KRUGER, MATT";
 attributes =         {
 type = "Incentive_Roster__c";
 url = "/services/data/v37.0/sobjects/Incentive_Roster__c/a3m7A000000z4FyQAI";
 };
 };
 attributes =     {
 type = "Badge_Earned__c";
 url = "/services/data/v37.0/sobjects/Badge_Earned__c/a3r7A00000059emQAA";
 };



 */
    //- (void)transposeIntoDataModelFromResponse:(NSDictionary *)response rosterID:(NSString *)rosterID {
    //    if (![NSDictionary isValidDictionary:response])
    //        return;
    //
    //    self.rosterID = rosterID;
    //    self.badgeAwardDateString = [NSDictionary objectForKeySafe:response key:kSOQLBadge_Award_DT__c];
    //    self.badgesDescName = [NSDictionary objectForKeySafe:response key:kSOQLBadge_Desc__c];
    //    NSString *strDocument_Name_Folder__c = [NSDictionary objectForKeySafe:response key:kSOQLDoc_Folder_NM1__c];
    //    self.documentFolderName = strDocument_Name_Folder__c;
    //    self.badgesImageURLString = [self getBadgesImagesURLPathString:strDocument_Name_Folder__c];
    //    NSDictionary *dictBadge_Id__r = [NSDictionary objectForKeySafe:response key:kBadge_Id__r];
    //    self.badgesName = [NSDictionary objectForKeySafe:response key:kSOQLBadge_NM__c];
    //    self.priority = [NSDictionary objectForKeySafe:dictBadge_Id__r key:kPriority__c];
    //    self.badgesID = [NSDictionary objectForKeySafe:response key:@"Id"];
    //    ABISFBadgesDataModel *bABISFIncentiveDataModel = [[ABISFBadgesDataModel alloc] initWithResponse:response year:self.year];
    //    self.badgesDataModel = [NSMutableArray arrayWithObject:bABISFIncentiveDataModel];
    //    bABISFIncentiveDataModel.priority = self.priority;
    //}
- (void)transposeIntoDataModelFromResponse:(NSDictionary *)response rosterID:(NSString *)rosterID {
    if (![NSDictionary isValidDictionary:response])
        return;

    self.rosterID = rosterID;
    self.badgeAwardDateString = [NSDictionary objectForKeySafe:response key:kSOQLBadge_Award_DT__c];
    self.badgesDescName = [NSDictionary objectForKeySafe:response key:kSOQLBadge_Desc__c];
    NSString *strDocument_Name_Folder__c = [NSDictionary objectForKeySafe:response key:kSOQLDoc_Folder_NM1__c];
    self.documentFolderName = strDocument_Name_Folder__c;
    self.priority = [NSDictionary objectForKeySafe:response key:kSOQLBadge_Priority__c];
    self.badgesImageURLString = [NSURL prepareBadgesImagesURLPathString:strDocument_Name_Folder__c];
        //    NSDictionary *dictBadge_Id__r = [NSDictionary objectForKeySafe:response key:kBadge_Id__r];
    self.badgesName = [NSDictionary objectForKeySafe:response key:kSOQLBadge_NM__c];
        //    self.priority = [NSDictionary objectForKeySafe:dictBadge_Id__r key:kPriority__c];
    self.badgesID = [NSDictionary objectForKeySafe:response key:@"Id"];
    ABISFBadgesDataModel *bABISFIncentiveDataModel = [[ABISFBadgesDataModel alloc] initWithResponse:response year:self.year];
    self.badgesDataModel = [NSMutableArray arrayWithObject:bABISFIncentiveDataModel];
    bABISFIncentiveDataModel.priority = self.priority;
}
@end
/*{
 "Badge_Award_DT__c" = "2016-09-23";
 "Badge_Desc__c" = Silverbadge;
 "Badge_NM__c" = Silver;
 "Doc_Folder_NM1__c" = 0157A0000005mjP;
 Id = a3r7A00000059WeQAI;
 "Roster_User_ID__r" =     {
 "Roster_Name__c" = "DEFACCI, THOMAS";
 attributes =         {
 type = "Incentive_Roster__c";
 url = "/services/data/v37.0/sobjects/Incentive_Roster__c/a3m7A00000056JGQAY";
 };
 };
 attributes =     {
 type = "Badge_Earned__c";
 url = "/services/data/v37.0/sobjects/Badge_Earned__c/a3r7A00000059WeQAI";
 };
 }*/