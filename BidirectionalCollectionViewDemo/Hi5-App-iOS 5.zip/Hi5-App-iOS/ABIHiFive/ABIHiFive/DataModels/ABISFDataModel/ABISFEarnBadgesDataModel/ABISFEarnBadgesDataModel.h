    //
    //  ABISFEarnBadgesDataModel.h
    //  ABIHiFive
    //
    //  Created by Prsenjit Goswami on 10/07/16.
    //  Copyright © 2016 Cognizant. All rights reserved.
    //
#import "ABISFBadgesDataModel.h"
#import "ABISFBaseDataModel.h"

@class ABISFBadgesDetailsNameWiseDataModel;

@interface ABISFEarnBadgesDataModel : ABISFBaseDataModel

@property (nullable, strong, nonatomic) NSString *rosterID;
@property (nullable, strong, nonatomic) NSString *badgesID;
@property (nullable, strong, nonatomic) NSString *documentFolderName;
@property (nullable, strong, nonatomic) NSString *badgesName;
@property (nullable, strong, nonatomic) NSString *badgesDescName;
@property (nullable, strong, nonatomic) NSNumber *numberOfEarnBadges;
@property (nullable, strong, nonatomic) NSString *badgesImageName;
@property (nullable, strong, nonatomic) NSString *badgesImageURLString;
@property (nullable, strong, nonatomic) NSNumber *priority;
@property (nullable, strong, nonatomic) NSString *badgeAwardDateString;
@property (nullable, strong, nonatomic) NSNumber *year;
@property (nullable, strong, nonatomic) NSMutableArray<ABISFBadgesDataModel *> *badgesDataModel;

- (nonnull instancetype)initWithEarnBadgesResponse:(nullable id)response rosterID:(nonnull NSString *)rosterID;

+ (nullable NSMutableArray<ABISFBadgesDetailsNameWiseDataModel *> *)groupedBadgesByPriority:
(nonnull NSMutableArray<ABISFEarnBadgesDataModel *> *)earnBadgesDetails;

+ (void)sortByPriority:(nonnull NSMutableArray *)allCollection;

@end
