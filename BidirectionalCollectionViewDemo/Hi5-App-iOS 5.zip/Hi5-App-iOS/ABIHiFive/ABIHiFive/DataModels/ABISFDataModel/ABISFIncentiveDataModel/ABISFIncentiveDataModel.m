    //
    //  ABISFIncentiveDataModel.m
    //  ABIHiFive
    //
    //  Created by Prsenjit Goswami on 28/06/16.
    //  Copyright © 2016 Cognizant. All rights reserved.
    //
#import "ABISFIncentiveDataModel.h"
#import "ABIBusinessProtocol.h"
#import "ABISFDataFetcherService.h"
#import "ABISFKPIsDetailsDataModel.h"
#import "ABISFMyReporteePerformanceDataModel.h"
#import "ABISFPeerRankingDataModel.h"
#import "ABISFRosterDataModel.h"
#import "Constants.h"

@implementation ABISFIncentiveDataModel
@synthesize channelWiseKPIsCollection = _channelWiseKPIsCollection;
@synthesize nuberOfDMs = _nuberOfDMs;
@synthesize maxDMPointsInNumber = _maxDMPointsInNumber;
@synthesize minDMPointsInNumber = _minDMPointsInNumber;
@synthesize uniqueIdentifier = _uniqueIdentifier;

/**
 It was discussed that "incentiveName" is ***UNIQUE*** For Roster
 */
#pragma mark - Custom Initializer
- (instancetype)initWithIncentiveResponse:(id)response {
    self = [super baseInit];
    if (self) {
        self.minIncentiveRange = @(0);
        self.maxIncentiveRange = @(100);
        [self transposeIntoDataModelFromResponse:response];
    }
    return self;
}

- (void)dealloc {
    [_channelWiseKPIsCollection removeAllObjects];
    _channelWiseKPIsCollection = nil;
}

#pragma mark - Override Method
- (BOOL)isEqual:(id)object {
    ABISFIncentiveDataModel *obj = (ABISFIncentiveDataModel *)object;
    return [self.incentiveName isEqualToString:obj.incentiveName];
}

#pragma mark - Private Method

- (void)transposeIntoDataModelFromResponse:(NSDictionary *)response {
    if (![NSDictionary isValidDictionary:response])
        return;
    self.incentiveID = [NSDictionary objectForKeySafe:response key:kID];

    self.rosterID = [NSDictionary objectForKeySafe:response key:kSOQLRoster_User__c];
    NSString *pointInString = [NSDictionary objectForKeySafe:response key:kSOQLINCNTV_POINTS__c];
    NSNumber *pointInNumber = @([pointInString integerValue]);
    self.overAllIncentiveProgress = pointInNumber;
    self.overAllIncentiveProgressRaw = pointInNumber;
    self.progressUnit = STATIC_TEXT_POINTS;
    self.statusTitle = [ABIBusinessProtocol incentivePerformanceStatusStringWRTPoints:pointInNumber];
    self.incentiveWeek = [NSDictionary objectForKeySafe:response key:kSOQLINCNTV_WEEK__c];
    NSDictionary *dictRoster_User_ID__r = [NSDictionary objectForKeySafe:response key:kSOQLRoster_User_ID__r];
    self.rosterDataModel = [[ABISFRosterDataModel alloc] initWithResponse:dictRoster_User_ID__r];

    [self incentiveDetails:response];
}

#pragma mark - Custom Accessor

- (NSString *)uniqueIdentifier {

    return self.incentiveName;
}
- (NSString *)incentiveCustomDisplayText {

    return [_incentiveDisplayName capitalizedString];
}
- (void)setOverAllIncentiveProgress:(NSNumber *)overAllIncentiveProgress {

    _overAllIncentiveProgress = overAllIncentiveProgress;

    self.progressStatusColorName = [ABIBusinessProtocol getIncentiveColor:_overAllIncentiveProgress];

        //	NSNumber *incentivePointInNumber = self.overAllIncentiveProgress ? self.overAllIncentiveProgress : nil;
        //	double overAllIncentiveProgressInDouble = incentivePointInNumber ? [incentivePointInNumber doubleValue] : 0;
        //	NSString *progressStatusColor = [NSString colorNameForIncentiveInPercentage:(overAllIncentiveProgressInDouble / 100)];
        //	self.progressStatusColorName = [progressStatusColor lowercaseString];
}
#pragma mark - Public Method

- (void)calculateNumberOfReportee:(NSArray<ABISFIncentiveDataModel *> *)allReporteeIncentices {

    if (self.overAllIncentiveProgress && self.overAllIncentiveProgress.floatValue < self.maxDMPointsInNumber.floatValue)
        return;

    if ([self respondsToSelector:@selector(setIncentiveDisplayName:)] && [self respondsToSelector:@selector(setIncentiveWeek:)]) {
        NSPredicate *predicate = [NSPredicate
                                  predicateWithFormat:@"self.incentiveDisplayName == %@ && self.incentiveWeek == %@", self.incentiveDisplayName, self.incentiveWeek];
        NSArray<ABISFIncentiveDataModel *> *result = [allReporteeIncentices filteredArrayUsingPredicate:predicate];
        if (result) {
            _nuberOfDMs = result.count;
            if ([self respondsToSelector:@selector(setOverAllIncentiveProgress:)]) {
                NSSortDescriptor *descriptor = [NSSortDescriptor sortDescriptorWithKey:@"overAllIncentiveProgress" ascending:NO];
                NSArray *sortedResult = [result sortedArrayUsingDescriptors:[NSArray arrayWithObject:descriptor]];
                if (sortedResult.count) {
                    ABISFIncentiveDataModel *model = [sortedResult firstObject];
                    ABISFIncentiveDataModel *modelmin = sortedResult[(sortedResult.count) - 1];
                    _maxDMPointsInNumber = [model overAllIncentiveProgress];
                    _minDMPointsInNumber = [modelmin overAllIncentiveProgress];
                    model = nil;
                }
                descriptor = nil;
            }
        }
        result = nil;
    }
}
- (nullable NSMutableArray<NSMutableArray<ABISFKPIsDetailsDataModel *> *> *)channelWiseKPIsCollection {
    if (!_channelWiseKPIsCollection) {
        _channelWiseKPIsCollection = [self kpiDetailsFromUserIncentiveWithResultsKPIsDetails];
    }
    return _channelWiseKPIsCollection;
}

#pragma mark - Private Method

- (NSMutableArray *)kpiDetailsFromUserIncentiveWithResultsKPIsDetails {
    NSMutableArray *incentiveKPIDetails = nil;
    if ([NSArray isValidArray:self.kpisDetails]) {
        NSDictionary *kipDict = [self.kpisDetails firstObject];
        if ([NSDictionary isValidDictionary:kipDict]) {
            incentiveKPIDetails = [NSMutableArray array];
            for (NSString *key in [kipDict allKeys]) {
                NSMutableArray *channelKPIs = kipDict[key];
                if ([NSArray isValidArray:channelKPIs]) {
                    if (channelKPIs.count)
                        [incentiveKPIDetails addObject:channelKPIs];
                }
            }
        }
    }
    return incentiveKPIDetails;
}

- (void)incentiveDetails:(NSDictionary *)response {
    NSDictionary *dictINCNTV_ID__r = [NSDictionary objectForKeySafe:response key:KSOQLINCNTV_ID__r];
    self.incentiveDisplayName = [NSDictionary objectForKeySafe:dictINCNTV_ID__r key:kSOQLIncntv_Nm__c];
    self.startDate = [NSDictionary objectForKeySafe:dictINCNTV_ID__r key:kSOQLINCNTV_Start__c];
    self.incentiveName = [NSDictionary objectForKeySafe:dictINCNTV_ID__r key:kSOQLName];
    self.endDate = [NSDictionary objectForKeySafe:dictINCNTV_ID__r key:kSOQLINCNTV_End__c];
}

+ (ABISFIncentiveDataModel *)getIncentiveWithName:(NSString *)incentiveName fromIncentives:(NSArray<ABISFIncentiveDataModel *> *)incentives {

    NSPredicate *predicate = [NSPredicate predicateWithFormat:@"self.incentiveName == %@ ", incentiveName];
    ABISFIncentiveDataModel *incentive = [[incentives filteredArrayUsingPredicate:predicate] firstObject];
    return incentive;
}

- (void)getAllReporteePerformanceDetailsWithManager:(nonnull ABISFRosterDataModel *)manager
                                          incentive:(nonnull ABISFIncentiveDataModel *)incentive
                                    extraDependency:(nullable NSDictionary<NSString *, id> *)extraDependency
                                          ascending:(BOOL)ascending
                                         sortByKeys:(nullable NSArray<NSString *> *)sortByKeys
                                        failedBlock:(nonnull ABIFailedBlock)failedBlock
                                    completionBlock:(nonnull ABIMutableArrayResponseBlock)completionBlock {
    __block NSMutableArray *kpis = incentive.kpisDetails;
    if (kpis && kpis.count) {
        NSDictionary *kpisDict = [kpis firstObject];
        [ABISFDataFetcherService
         fetchAndProcessAllReporteeKPIsWiseIncentivePerformanceDetailsWithManager:manager
         incentive:incentive
         extraDependency:extraDependency
         ascending:ascending
         sortByKeys:sortByKeys
         failedBlock:failedBlock
         completionBlock:^(NSMutableArray *dmKPIs, NSDictionary *extraInfo) {

             NSDictionary *dmKIPsResultDict = nil;
             if (dmKPIs.count) {
                 dmKIPsResultDict = dmKPIs[0];
             }
             if (dmKIPsResultDict.count) {

                 for (NSString *channelName in [kpisDict allKeys]) {
                     NSMutableArray *channelKPIs = kpisDict[channelName];
                     NSMutableArray *chnnelDMKpis = dmKIPsResultDict[channelName];

                     if ([NSArray isValidArray:channelKPIs]) {
                         for (id obj in channelKPIs) {
                             [ABISFKPIsDetailsDataModel
                              updateKPIDetailsModelWithMyDMsPerformace:obj
                              allReporteesKPIs:chnnelDMKpis];
                         }
                     }
                 }
             }
             if (completionBlock)
                 completionBlock([@[ incentive ] mutableCopy], nil);
         }];
    } else {
        if (failedBlock)
            failedBlock(nil, nil);
    }
}
- (void)updateKPIDetailsModelWithMyDMsPerformace:(ABISFKPIsDetailsDataModel *)dataModel
                           myDMsPerfomanceModels:(NSMutableArray *)myDMsPerfomanceModels {
    if ([dataModel isKindOfClass:[ABISFKPIsDetailsDataModel class]]) {
        ABISFKPIsDetailsDataModel *kpisDetailsDataModel = (ABISFKPIsDetailsDataModel *)dataModel;
        NSPredicate *predicate = [NSPredicate predicateWithFormat:@"self.kpiName == %@ ", kpisDetailsDataModel.kpiName];
        NSArray<ABISFKPIsDetailsDataModel *> *dmsKPIsForKpiName = [myDMsPerfomanceModels filteredArrayUsingPredicate:predicate];
        NSMutableArray *reporteePerformanceCollections = [NSMutableArray array];
        for (ABISFKPIsDetailsDataModel *modelsub in dmsKPIsForKpiName) {
            if ([modelsub isKindOfClass:[ABISFKPIsDetailsDataModel class]]) {
                ABISFMyReporteePerformanceDataModel *dmsPerformanceDataModels = [ABISFMyReporteePerformanceDataModel new];
                dmsPerformanceDataModels.nameOfDM = modelsub.roster.rosterNameText;
                dmsPerformanceDataModels.performancePoint = [NSString stringWithFormat:@"%@", modelsub.incentiveValueText]; // TODO:KIP
                dmsPerformanceDataModels.progressStatusColor = modelsub.progressStatusColor;
                [reporteePerformanceCollections addObject:dmsPerformanceDataModels];
            }
        }
        [reporteePerformanceCollections abiSortedReporteePerformanceCollectionResults];
            //		[dmsPerformanceDataModelsArray sort ForKey:@"name OfDM" ascending:YES];

        kpisDetailsDataModel.myDMsPerformanceDataModels = reporteePerformanceCollections;
    }
}

/**
 *  Find User rank among same role peer for a perticulat 'Incentive'
 *
 *  @param failedBlock     Failed Block
 *  @param completionBlock Rank Return as NSNumber object.
 */
- (void)getUserIncentiveRankAmongSameRolePeerWithCompletionBlock:(void (^)(NSNumber *rank))completionBlock {

    if (!self.rosterDataModel || ![self.rosterDataModel isKindOfClass:[ABISFRosterDataModel class]]) {

        if (completionBlock)
            completionBlock(nil);

    } else if (self.rank) {

            // If already is calculated, It returns;
        if (completionBlock)
            completionBlock(self.rank);
    } else {

        __weak typeof(self) weakSelf = self;

        [ABISFDataFetcherService fetchAndProcessAllPeerDetailsWithRoster:self.rosterDataModel
                                                               incentive:self
                                                             failedBlock:^(NSError *error, NSDictionary *extraInfo) {

                                                                 if (completionBlock)
                                                                     completionBlock(nil);

                                                             }
                                                         completionBlock:^(NSArray<ABISFPeerRankingDataModel *> *results, NSDictionary *extraInfo) {

                                                             NSString *idName = self.rosterDataModel.idName;

                                                             NSPredicate *predicate = [NSPredicate predicateWithFormat:@"self.peerRoster.idName == %@", idName];
                                                             NSArray<ABISFPeerRankingDataModel *> *filterResults = [results filteredArrayUsingPredicate:predicate];

                                                             NSNumber *rank = nil;

                                                             if (filterResults && filterResults.count) {

                                                                 ABISFPeerRankingDataModel *peerRankingDataModel = [filterResults firstObject];

                                                                 if (peerRankingDataModel) {
                                                                     NSInteger index = [results indexOfObject:peerRankingDataModel];

                                                                     if (![results indexOutOfBound:index]) {
                                                                         rank = @(index + 1);
                                                                             // Update Model with Rank
                                                                         weakSelf.rank = rank;
                                                                     }
                                                                 }
                                                             }

                                                             if (completionBlock)
                                                                 completionBlock(rank);

                                                         }];
    }
}

@end
