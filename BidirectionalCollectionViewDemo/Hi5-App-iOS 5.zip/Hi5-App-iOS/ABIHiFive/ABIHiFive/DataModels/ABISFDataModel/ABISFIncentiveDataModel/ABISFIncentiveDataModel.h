    //
    //  ABISFIncentiveDataModel.h
    //  ABIHiFive
    //
    //  Created by Prsenjit Goswami on 28/06/16.
    //  Copyright © 2016 Cognizant. All rights reserved.
    //
#import "ABISFBaseDataModel.h"
#import "Constants.h"

@class ABISFRosterDataModel;
@class ABISFKPIsDetailsDataModel;

@interface ABISFIncentiveDataModel : ABISFBaseDataModel

@property (nullable, strong, nonatomic) NSString *incentiveID;
@property (nullable, strong, nonatomic) NSString *rosterID;
@property (nullable, strong, nonatomic) NSString *profileUserName;
@property (nullable, strong, nonatomic) NSNumber *rank;
@property (nullable, strong, nonatomic) NSString *incentiveName;
@property (nullable, strong, nonatomic) NSString *incentiveDisplayName;
@property (nullable, strong, nonatomic) NSString *incentiveWeek;
@property (nullable, strong, nonatomic) NSString *startDate;
@property (nullable, strong, nonatomic) NSString *endDate;
@property (nullable, strong, nonatomic) NSNumber *overAllIncentiveProgress;
@property (nullable, strong, nonatomic) NSNumber *overAllIncentiveProgressRaw;
@property (nullable, strong, nonatomic) NSNumber *minIncentiveRange;
@property (nullable, strong, nonatomic) NSNumber *maxIncentiveRange;
@property (nullable, strong, nonatomic) NSString *progressUnit;
@property (nullable, strong, nonatomic) NSString *statusTitle;
@property (nullable, strong, nonatomic) NSString *statusDescription;
@property (nullable, strong, nonatomic) NSNumber *totalKPIsNumber, *countOfProgressColor;
@property (nullable, strong, nonatomic) NSString *progressStatusColorName;
@property (nullable, strong, nonatomic) NSMutableAttributedString *attributedString;
@property (nullable, strong, nonatomic) NSMutableArray<NSDictionary *> *kpisDetails;
@property (nullable, strong, nonatomic) ABISFRosterDataModel *rosterDataModel;
@property (assign, nonatomic, readonly) NSInteger nuberOfDMs;
@property (nullable, assign, nonatomic, readonly) NSNumber *maxDMPointsInNumber;
@property (nullable, assign, nonatomic, readonly) NSNumber *minDMPointsInNumber;
@property (nullable, strong, nonatomic, readonly) NSString *incentiveCustomDisplayText;

@property (nullable, readonly, strong, nonatomic) NSMutableArray<NSMutableArray<ABISFKPIsDetailsDataModel *> *> *channelWiseKPIsCollection;
- (nonnull instancetype)initWithIncentiveResponse:(nullable id)response;
- (void)calculateNumberOfReportee:(nonnull NSArray<ABISFIncentiveDataModel *> *)allReporteeIncentices;
    // This Collection is contains the channel wise KPI details.
- (nullable NSMutableArray<NSMutableArray<ABISFKPIsDetailsDataModel *> *> *)channelWiseKPIsCollection;

+ (nullable ABISFIncentiveDataModel *)getIncentiveWithName:(nonnull NSString *)incentiveName
                                            fromIncentives:(nonnull NSArray<ABISFIncentiveDataModel *> *)incentives;

- (void)getAllReporteePerformanceDetailsWithManager:(nonnull ABISFRosterDataModel *)manager
                                          incentive:(nonnull ABISFIncentiveDataModel *)incentive
                                    extraDependency:(nullable NSDictionary<NSString *, id> *)extraDependency
                                          ascending:(BOOL)ascending
                                         sortByKeys:(nullable NSArray<NSString *> *)sortByKeys
                                        failedBlock:(nonnull ABIFailedBlock)failedBlock
                                    completionBlock:(nonnull ABIMutableArrayResponseBlock)completionBlock;

- (void)getUserIncentiveRankAmongSameRolePeerWithCompletionBlock:(void (^_Nonnull)(NSNumber *_Nonnull rank))completionBlock;

@end
