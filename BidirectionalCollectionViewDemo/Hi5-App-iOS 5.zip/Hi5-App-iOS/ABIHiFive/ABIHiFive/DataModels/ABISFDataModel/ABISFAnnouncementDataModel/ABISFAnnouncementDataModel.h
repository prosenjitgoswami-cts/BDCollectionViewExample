    //
    //  ABISFAnnouncementDataModel.h
    //  ABIHiFive
    //
    //  Created by Prsenjit Goswami on 04/07/16.
    //  Copyright © 2016 Cognizant. All rights reserved.
    //
#import "ABISFBaseDataModel.h"

@interface ABISFAnnouncementDataModel : ABISFBaseDataModel

@property (nonatomic, strong) NSString *minsText;
@property (nonatomic, strong) NSString *daysText;
@property (nonatomic, strong) NSString *announcementName;
@property (nonatomic, strong) NSString *announcementID;
@property (nonatomic, strong) NSString *announcementBody;
@property (nonatomic, strong) NSString *announcementSubject;
@property (nonatomic, strong) NSString *announcementURLString;
@property (nonatomic, strong) NSString *announcementImageURLString;
@property (nonatomic, strong) NSString *createdDateString;
@property (nonatomic, strong) NSString *createdDateShortString;
@property (nonatomic, strong) NSString *lastModifiedDateString;
@property (nonatomic, strong) NSString *lastModifiedDateShortString;
@property (nonatomic, strong) NSDate *lastModifiedDate;
@property (nonatomic, strong) NSDate *createdDate;
@property (nonatomic, strong, readonly) NSString *refreshTimeInString;

- (instancetype)initWithResponse:(NSDictionary *)response;
@end
