    //
    //  ABISFAnnouncementDataModel.m
    //  ABIHiFive
    //
    //  Created by Prsenjit Goswami on 04/07/16.
    //  Copyright © 2016 Cognizant. All rights reserved.
    //
#import "ABISFAnnouncementDataModel.h"

@interface ABISFAnnouncementDataModel ()

@property (nonatomic, strong, readwrite) NSString *refreshTimeInString;
@end

@implementation ABISFAnnouncementDataModel

#pragma mark - Custom Initializer
- (instancetype)initWithResponse:(NSDictionary *)response {
    self = [super baseInit];
    if (self) {
        [self transposeIntoDataModelFromResponse:response];
    }
    return self;
}

#pragma mark - Custom Accessor
- (void)setLastModifiedDateString:(NSString *)lastModifiedDateString {
    _lastModifiedDateString = lastModifiedDateString;
    if (![NSString isNULLString:_lastModifiedDateString]) {
        NSDate *utcModifiedDate = [NSDate dateFromString:_lastModifiedDateString andFormatterStyle:DEFAULT_SF_DATE_FORMAT];
        if (utcModifiedDate) {
            self.refreshTimeInString = [utcModifiedDate formatterDateStringForAnnoucenent];
            self.lastModifiedDate = utcModifiedDate;
            self.lastModifiedDateShortString = [NSString stringWithFormat:@"%@\n%@", [NSDate stringFromDateInLocal:utcModifiedDate andFormatterStyle:@"dd"],
                                                [NSDate stringFromDateInLocal:utcModifiedDate andFormatterStyle:@"MMMM"]];
        }
        utcModifiedDate = nil;
    }
}

- (void)setCreatedDateString:(NSString *)createdDateString {
    _createdDateString = createdDateString;
    if (![NSString isNULLString:_createdDateString]) {
        NSDate *utcCretedDate = [NSDate dateFromString:_createdDateString andFormatterStyle:DEFAULT_SF_DATE_FORMAT];
        if (utcCretedDate) {
            self.createdDate = utcCretedDate;
            _createdDateShortString = [NSString stringWithFormat:@"%@\n%@", [NSDate stringFromDateInLocal:utcCretedDate andFormatterStyle:@"dd"],
                                       [NSDate stringFromDateInLocal:utcCretedDate andFormatterStyle:@"MMMM"]];
        }
        utcCretedDate = nil;
    }
}

#pragma mark - Private Method
/*{
 "Announcement_Body__c" = "SUMMER INCENTIVE BODY 1";
 "Announcement_End__c" = "2016-07-29";
 "Announcement_NM__c" = "SUMMER INCENTIVE ANNOUNCEMENT 1";
 "Announcement_SUBJ__c" = "SUMMER INCENTIVE SUBJECT 1";
 "Announcement_Start__c" = "2016-06-30";
 "Announcement_URL__c" = "http://abweb.corp.anheuser-busch.com/abweb2/default.aspx";
 attributes =     {
 type = "Announcement__c";
 url = "/services/data/v37.0/sobjects/Announcement__c/a3q7A0000009RjcQAE";
 };
 }*/
- (void)transposeIntoDataModelFromResponse:(NSDictionary *)response {
    self.announcementName = [NSDictionary objectForKeySafe:response key:kSOQLAnnouncement_NM__c];
    self.announcementBody = [NSDictionary objectForKeySafe:response key:kSOQLAnnouncement_Body__c];
    self.announcementSubject = [NSDictionary objectForKeySafe:response key:kSOQLAnnouncement_SUBJ__c];
    self.announcementImageURLString = [NSDictionary objectForKeySafe:response key:kSOQLAnnouncement_URL__c];
    self.createdDateString = [NSDictionary objectForKeySafe:response key:kSOQLCreatedDate];
    self.lastModifiedDateString = [NSDictionary objectForKeySafe:response key:kSOQLLastModifiedDate];
}

@end
