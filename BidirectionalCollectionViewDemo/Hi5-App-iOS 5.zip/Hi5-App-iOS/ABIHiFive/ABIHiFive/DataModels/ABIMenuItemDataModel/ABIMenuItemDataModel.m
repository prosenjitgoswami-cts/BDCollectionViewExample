    //
    //  ABIMenuItemDataModel.m
    //  ABIHiFive
    //
    //  Created by Prsenjit Goswami on 11/07/16.
    //  Copyright © 2016 Cognizant. All rights reserved.
    //
#import "ABIMenuItemDataModel.h"

@implementation ABIMenuItemDataModel

@end
