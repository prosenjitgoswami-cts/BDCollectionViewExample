    //
    //  ABISFChatterActorDataModel.m
    //  AnheuserBusch
    //
    //  Created by Prsenjit Goswami on 24/06/16.
    //  Copyright © 2016 Cognizant. All rights reserved.
    //
#import "ABISFChatterActorDataModel.h"
#import "ABISFChatterDataFetcherServices.h"
#import "Constants.h"
@implementation ABISFChatterActorDataModel
- (instancetype)initWithElement:(NSDictionary *)element {
    self = [super init];
    if (self) {
        if (element) {
            [self bindResponseDictionary:[NSObject objectForKeySafe:element key:kActor]];
        }
    }
    return self;
}
#pragma mark - Private method
- (void)bindResponseDictionary:(NSDictionary *)actorDict {
    if (![NSDictionary isValidDictionary:actorDict])
        return;
    self.actorID = [NSObject objectForKeySafe:actorDict key:kid];
}
#pragma mark - Dealloc
- (void)dealloc {
    _actorID = nil;
}
@end
