
    //
    //  ABISFChatterFeedElementDataModel.m
    //  AnheuserBusch
    //
    //  Created by Prsenjit Goswami on 23/06/16.
    //  Copyright © 2016 Cognizant. All rights reserved.
    //
#import "ABISFChatterFeedElementDataModel.h"
#import "ABISFChatterCommentItemModel.h"
#import "ABISFChatterDataFetcherServices.h"
#import "Constants.h"
@interface ABISFChatterFeedElementDataModel ()
@property (strong, nonatomic, readwrite) NSString *refreshTime;
@property (strong, nonatomic, readwrite) ABISFChatterCommentModel *comment;
@property (strong, nonatomic, readwrite) ABISFChatterParentDataModel *parent;
@property (strong, nonatomic, readwrite) ABISFChatterFilesDataModel *file;
@end
@implementation ABISFChatterFeedElementDataModel
#pragma mark - Synchonus call
+ (void)prepareABISFChatterFeedElementDataModel:(NSDictionary *)elementsDict
                                completionBlock:(void (^)(ABISFChatterFeedElementDataModel *model))completionBlock {
    NSString *feedID = elementsDict[@"id"];
    __block ABISFChatterFeedElementDataModel *feedElementDataModel = [ABISFChatterFeedElementDataModel new];
    feedElementDataModel.nextPageURLString = [NSDictionary objectForKeySafe:elementsDict key:kNextPageUrl];
    feedElementDataModel.updatesURLString = [NSDictionary objectForKeySafe:elementsDict key:kUpdatesUrl];
    feedElementDataModel.currentPageURLString = [NSDictionary objectForKeySafe:elementsDict key:kCurrentPageUrl];
    feedElementDataModel.relativeCreatedDate = [NSDictionary objectForKeySafe:elementsDict key:kRelativeCreatedDate];
    feedElementDataModel.createdDateString = [NSDictionary objectForKeySafe:elementsDict key:kCreatedDate];
    ;
    NSString *photoUrl = [NSDictionary objectForKeySafe:elementsDict key:kPhotoUrl];
    feedElementDataModel.photoUrl = photoUrl;
    feedElementDataModel.modifiedDate = [NSDictionary objectForKeySafe:elementsDict key:kModifiedDate];
    feedElementDataModel.feedID = feedID;
    NSString *text = [ABISFChatterDataFetcherServices getTextKeyValueFromBodyDictionary:[NSDictionary objectForKeySafe:elementsDict key:kBody]];
    feedElementDataModel.feedMessage = text;
    feedElementDataModel.parent =
    [[ABISFChatterParentDataModel alloc] initWithParentDictionary:[NSDictionary objectForKeySafe:elementsDict key:kParent]];
    feedElementDataModel.file = [[ABISFChatterFilesDataModel alloc]
                                 initWithFileDictionary:[ABISFChatterDataFetcherServices objectFromCompatibilityDictionaryForKey:kFiles elementDictionary:elementsDict]];
    NSDictionary *pages = [ABISFChatterDataFetcherServices commentsPagesDictionary:elementsDict];
    if (pages && pages.count) {
        [ABISFChatterCommentModel prepareDataModelWithParentFeedID:feedID
                                                      commentPages:pages
                                                        completion:^(ABISFChatterCommentModel *commentModel) {
                                                            feedElementDataModel.comment = commentModel;
                                                            if (completionBlock)
                                                                completionBlock(feedElementDataModel);
                                                        }];
    } else {
        if (completionBlock)
            completionBlock(feedElementDataModel);
    }
}
- (void)setElement:(NSDictionary *)element {
    _element = element;
    if (!_element)
        return;
    self.comment = [ABISFChatterDataFetcherServices prepareABISFChatterCommentModelForAFeed:element parentFeedID:self.feedID];
    self.parent = [[ABISFChatterParentDataModel alloc] initWithParentDictionary:[NSDictionary objectForKeySafe:element key:kParent]];
    self.file = [[ABISFChatterFilesDataModel alloc]
                 initWithFileDictionary:[ABISFChatterDataFetcherServices objectFromCompatibilityDictionaryForKey:kFiles elementDictionary:element]];
}
- (void)setCreatedDateString:(NSString *)createdDateString {
    _createdDateString = createdDateString;
    NSDate *date = [NSDate dateFromString:_createdDateString andFormatterStyle:DEFAULT_SF_DATE_FORMAT];
    self.createdDate = date;
    self.refreshTime = [NSDate dispalyTimeAsLocalTZFormatWithUTCDate:date];
}
#pragma mark - Dealloc
- (void)dealloc {
    _comment = nil;
    _parent = nil;
    _file = nil;
    _element = nil;
    _feedID = nil;
    _feedMessage = nil;
    _createdDateString = nil;
    _relativeCreatedDate = nil;
    _photoUrl = nil;
    _modifiedDate = nil;
}
@end
