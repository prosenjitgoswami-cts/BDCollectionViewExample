    //
    //  ABISFChatterFeedElementDataModel.h
    //  AnheuserBusch
    //
    //  Created by Prsenjit Goswami on 23/06/16.
    //  Copyright © 2016 Cognizant. All rights reserved.
    //
#import "ABISFChatterBaseDataModel.h"
#import "ABISFChatterCommentModel.h"
#import "ABISFChatterFilesDataModel.h"
#import "ABISFChatterParentDataModel.h"
#import <Foundation/Foundation.h>
@interface ABISFChatterFeedElementDataModel : ABISFChatterBaseDataModel
@property (strong, nonatomic) NSString *feedID;
@property (strong, nonatomic) NSString *feedMessage;
@property (strong, nonatomic) NSString *createdDateString, *relativeCreatedDate;
@property (strong, nonatomic) NSString *photoUrl;
@property (strong, nonatomic) NSString *modifiedDate;
@property (strong, nonatomic) NSString *nextPageURLString;
@property (strong, nonatomic) NSString *currentPageURLString;
@property (strong, nonatomic) NSString *updatesURLString;
@property (strong, nonatomic) NSDate *createdDate;
@property (strong, nonatomic) id element;
@property (strong, nonatomic, readonly) ABISFChatterCommentModel *comment;
@property (strong, nonatomic, readonly) ABISFChatterParentDataModel *parent;
@property (strong, nonatomic, readonly) ABISFChatterFilesDataModel *file;
@property (strong, nonatomic, readonly) NSString *refreshTime;
+ (void)prepareABISFChatterFeedElementDataModel:(NSDictionary *)elementsDict
                                completionBlock:(void (^)(ABISFChatterFeedElementDataModel *model))completionBlock;
@end