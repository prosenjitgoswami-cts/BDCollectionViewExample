    //
    //  ABISFChatterMessageRecipientDataModel.m
    //  ABIHiFive
    //
    //  Created by Prsenjit Goswami on 02/08/16.
    //  Copyright © 2016 Cognizant. All rights reserved.
    //
#import "ABISFChatterMessageRecipientDataModel.h"
@implementation ABISFChatterMessageRecipientDataModel
- (instancetype)initWithMessageRecipientDictionary:(id)recipientDictionary {
    self = [super initWithParentDictionary:recipientDictionary];
    return self;
}
@end
