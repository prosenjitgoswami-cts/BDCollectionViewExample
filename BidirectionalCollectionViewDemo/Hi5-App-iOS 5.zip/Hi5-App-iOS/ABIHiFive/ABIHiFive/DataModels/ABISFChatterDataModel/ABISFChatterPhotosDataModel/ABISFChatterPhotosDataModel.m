    //
    //  ABISFChatterPhotosDataModel.m
    //  ABIHiFive
    //
    //  Created by Prsenjit Goswami on 24/07/16.
    //  Copyright © 2016 Cognizant. All rights reserved.
    //
#import "ABISFChatterPhotosDataModel.h"
#import "Constants.h"
@implementation ABISFChatterPhotosDataModel
- (instancetype)initWithPhotoDictionary:(NSDictionary *)photoDictionary {
    self = [super init];
    if (self) {
        [self bindResponseDictionary:photoDictionary];
    }
    return self;
}
#pragma mark - Private method
- (void)bindResponseDictionary:(NSDictionary *)photoDictionary {
    if (![NSDictionary isValidDictionary:photoDictionary])
        return;
    self.photoVersionId = photoDictionary[kPhotoVersionId];
    self.mediumPhotoUrl = photoDictionary[kSmallPhotoUrl];
    self.fullEmailPhotoUrl = photoDictionary[kSmallPhotoUrl];
    self.smallPhotoUrl = photoDictionary[kSmallPhotoUrl];
    self.largePhotoUrl = photoDictionary[kSmallPhotoUrl];
}
#pragma mark - Dealloc
- (void)dealloc {
    _photoVersionId = nil;
    _mediumPhotoUrl = nil;
    _fullEmailPhotoUrl = nil;
    _smallPhotoUrl = nil;
    _largePhotoUrl = nil;
}
@end
