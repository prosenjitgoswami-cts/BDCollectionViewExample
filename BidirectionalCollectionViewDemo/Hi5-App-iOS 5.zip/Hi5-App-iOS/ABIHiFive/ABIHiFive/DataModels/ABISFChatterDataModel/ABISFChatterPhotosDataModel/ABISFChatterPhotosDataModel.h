    //
    //  ABISFChatterPhotosDataModel.h
    //  ABIHiFive
    //
    //  Created by Prsenjit Goswami on 24/07/16.
    //  Copyright © 2016 Cognizant. All rights reserved.
    //
#import "ABISFChatterBaseDataModel.h"
#import <Foundation/Foundation.h>
@interface ABISFChatterPhotosDataModel : NSObject
- (instancetype)initWithPhotoDictionary:(NSDictionary *)photoDictionary;
@property (strong, nonatomic) NSString *photoVersionId;
@property (strong, nonatomic) NSString *mediumPhotoUrl;
@property (strong, nonatomic) NSString *fullEmailPhotoUrl;
@property (strong, nonatomic) NSString *smallPhotoUrl;
@property (strong, nonatomic) NSString *largePhotoUrl;
@end
