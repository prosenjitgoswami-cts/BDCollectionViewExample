    //
    //  ABISFChatterMentionDataModel.h
    //  ABIHiFive
    //
    //  Created by Prsenjit Goswami on 29/07/16.
    //  Copyright © 2016 Cognizant. All rights reserved.
    //
#import "ABISFChatterBaseDataModel.h"
#import <Foundation/Foundation.h>
@interface ABISFChatterMentionDataModel : ABISFChatterBaseDataModel
@property (strong, nonatomic) NSString *name;
@property (strong, nonatomic) NSString *photoUrl;
@property (strong, nonatomic) NSString *recordId;
@property (strong, nonatomic) NSString *message;
@property (strong, nonatomic) NSString *type;
- (instancetype)initWithMentionCompletions:(NSDictionary *)mentionCompletions;
@end
