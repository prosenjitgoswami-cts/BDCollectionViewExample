    //
    //  ABISFChatterMentionDataModel.m
    //  ABIHiFive
    //
    //  Created by Prsenjit Goswami on 29/07/16.
    //  Copyright © 2016 Cognizant. All rights reserved.
    //
#import "ABISFChatterMentionDataModel.h"
#import "Constants.h"
@implementation ABISFChatterMentionDataModel
- (instancetype)initWithMentionCompletions:(NSDictionary *)mentionDictionary {
    self = [super init];
    if (self) {
        [self bindResponseDictionary:mentionDictionary];
    }
    return self;
}
- (void)bindResponseDictionary:(NSDictionary *)mentionDictionary {
    if (!mentionDictionary)
        return;
    self.name = [NSDictionary objectForKeySafe:mentionDictionary key:kname];
    self.recordId = [NSDictionary objectForKeySafe:mentionDictionary key:kRecordId];
    self.photoUrl = [NSDictionary objectForKeySafe:mentionDictionary key:kPhotoUrl];
}
#pragma mark - Dealloc
- (void)dealloc {
    _name = nil;
    _recordId = nil;
    _photoUrl = nil;
}
@end
