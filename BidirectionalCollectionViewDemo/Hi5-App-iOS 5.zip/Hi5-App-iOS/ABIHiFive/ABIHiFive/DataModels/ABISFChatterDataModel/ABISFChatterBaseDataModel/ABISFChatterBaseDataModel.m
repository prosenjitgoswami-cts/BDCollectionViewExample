    //
    //  ABISFChatterBaseDataModel.m
    //  ABIHiFive
    //
    //  Created by Prsenjit Goswami on 10/07/16.
    //  Copyright © 2016 Cognizant. All rights reserved.
    //
#import "ABISFChatterBaseDataModel.h"
@implementation ABISFChatterBaseDataModel
@end
