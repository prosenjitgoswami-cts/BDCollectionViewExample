    //
    //  ABISFChatterContentDataModel.m
    //  ABIHiFive
    //
    //  Created by Prsenjit Goswami on 25/07/16.
    //  Copyright © 2016 Cognizant. All rights reserved.
    //
#import "ABISFChatterContentDataModel.h"
#import "Constants.h"
#import "Constants.h"
@interface ABISFChatterContentDataModel ()
@property (assign, nonatomic, readwrite) BOOL isImageType;
@property (strong, nonatomic, readwrite) NSString *fileFullName;
@end
@implementation ABISFChatterContentDataModel
- (instancetype)initWithContentdictionary:(NSDictionary *)contentDict {
    self = [super init];
    if (self) {
        [self bindResponseDictionary:contentDict];
    }
    return self;
}
#pragma mark - Private method
- (void)bindResponseDictionary:(NSDictionary *)contentDict {
    if (![NSDictionary isValidDictionary:contentDict])
        return;
    self.ID = [NSDictionary objectForKeySafe:contentDict key:kid];
    self.renditionUrl = [NSDictionary objectForKeySafe:contentDict key:kRenditionUrl];
    self.renditionUrl720By480 = [NSDictionary objectForKeySafe:contentDict key:kRenditionUrl720By480];
    self.renditionUrl240By180 = [NSDictionary objectForKeySafe:contentDict key:kRenditionUrl240By180];
    self.versionId = [NSDictionary objectForKeySafe:contentDict key:kVersionId];
    self.fileExtension = [NSDictionary objectForKeySafe:contentDict key:kFileExtension];
    self.downloadUrl = [NSDictionary objectForKeySafe:contentDict key:kDownloadUrl];
    self.title = [NSDictionary objectForKeySafe:contentDict key:kTitle];
    self.fileType = [NSDictionary objectForKeySafe:contentDict key:kFileType];
    self.mimeType = [NSDictionary objectForKeySafe:contentDict key:kMimeType];
    if (self.mimeType)
        self.isImageType = !([[self.mimeType lowercaseString] rangeOfString:@"image"].location == NSNotFound);
}
#pragma mark - Dealloc
- (void)dealloc {
    _displayName = nil;
    _downloadUrl = nil;
    _fileExtension = nil;
    _ID = nil;
    _renditionUrl = nil;
    _renditionUrl240By180 = nil;
    _renditionUrl720By480 = nil;
    _title = nil;
    _versionId = nil;
    _fileType = nil;
    _mimeType = nil;
    _fileFullName = nil;
}
@end
