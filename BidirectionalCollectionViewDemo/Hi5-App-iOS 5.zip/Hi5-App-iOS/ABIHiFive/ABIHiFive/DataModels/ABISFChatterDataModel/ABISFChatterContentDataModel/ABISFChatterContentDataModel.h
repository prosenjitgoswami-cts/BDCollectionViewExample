    //
    //  ABISFChatterContentDataModel.h
    //  ABIHiFive
    //
    //  Created by Prsenjit Goswami on 25/07/16.
    //  Copyright © 2016 Cognizant. All rights reserved.
    //
#import "ABISFChatterBaseDataModel.h"
@interface ABISFChatterContentDataModel : ABISFChatterBaseDataModel
@property (strong, nonatomic, readwrite) NSString *displayName;
@property (strong, nonatomic, readwrite) NSString *downloadUrl;
@property (strong, nonatomic, readwrite) NSString *fileExtension;
@property (strong, nonatomic, readwrite) NSString *ID;
@property (strong, nonatomic, readwrite) NSString *renditionUrl;
@property (strong, nonatomic, readwrite) NSString *renditionUrl240By180;
@property (strong, nonatomic, readwrite) NSString *renditionUrl720By480;
@property (strong, nonatomic, readwrite) NSString *title;
@property (strong, nonatomic, readwrite) NSString *versionId;
@property (strong, nonatomic, readwrite) NSString *fileType;
@property (strong, nonatomic, readwrite) NSString *mimeType;
@property (assign, nonatomic, readonly) BOOL isImageType;
- (instancetype)initWithContentdictionary:(NSDictionary *)contentDict;
@end
