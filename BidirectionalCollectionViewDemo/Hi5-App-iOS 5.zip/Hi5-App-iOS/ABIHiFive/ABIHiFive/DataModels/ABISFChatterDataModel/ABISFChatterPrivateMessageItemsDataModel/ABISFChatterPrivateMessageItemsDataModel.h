    //
    //  ABISFChatterPrivateMessageItemsDataModel.h
    //  ABIHiFive
    //
    //  Created by Prsenjit Goswami on 02/08/16.
    //  Copyright © 2016 Cognizant. All rights reserved.
    //
#import "ABISFChatterBaseDataModel.h"
#import "ABISFChatterMessageSenderDataModel.h"
#import <Foundation/Foundation.h>
@interface ABISFChatterPrivateMessageItemsDataModel : NSObject
@property (strong, nonatomic) NSString *ID;
@property (strong, nonatomic) NSString *text;
@property (strong, nonatomic) NSString *conversationId;
@property (strong, nonatomic) NSString *conversationUrlSting;
@property (strong, nonatomic) NSString *sendingCommunity;
@property (strong, nonatomic) NSString *sentDate;
@property (strong, nonatomic) NSDate *createdDate;
@property (strong, nonatomic, readonly) ABISFChatterMessageSenderDataModel *sender;
@property (strong, nonatomic, readonly) NSMutableArray *recipients;
@property (strong, nonatomic, readonly) NSString *refreshTime;
- (instancetype)initWithResponse:(NSDictionary *)response;
@end
