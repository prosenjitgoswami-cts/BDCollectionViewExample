    //
    //  ABISFChatterPrivateMessageItemsDataModel.m
    //  ABIHiFive
    //
    //  Created by Prsenjit Goswami on 02/08/16.
    //  Copyright © 2016 Cognizant. All rights reserved.
    //
#import "ABISFChatterPrivateMessageItemsDataModel.h"
#import "ABISFChatterDataFetcherServices.h"
#import "ABISFChatterMessageRecipientDataModel.h"
#import "Constants.h"
@interface ABISFChatterPrivateMessageItemsDataModel ()
@property (strong, nonatomic, readwrite) ABISFChatterMessageSenderDataModel *sender;
@property (strong, nonatomic, readwrite) NSMutableArray *recipients;
@property (strong, nonatomic, readwrite) NSString *refreshTime;
@end
@implementation ABISFChatterPrivateMessageItemsDataModel
- (instancetype)initWithResponse:(NSDictionary *)response {
    self = [super init];
    if (self) {
        [self bindResponseDictionary:response];
    }
    return self;
}

#pragma mark -  Public method
- (void)setSentDate:(NSString *)sentDate {
    _sentDate = sentDate;
    NSDate *date = [NSDate dateFromString:_sentDate andFormatterStyle:DEFAULT_SF_DATE_FORMAT];
    self.createdDate = date;
    NSString *sendTimeString = [NSDate dispalyTimeAsLocalTZFormatWithUTCDate:self.createdDate];
    self.refreshTime = sendTimeString;
}

#pragma mark -  Private method
- (void)perseRecipients:(NSArray *)recipients {
    if (![NSArray isValidArray:recipients])
        return;
    self.recipients = [NSMutableArray array];
    for (id obj in recipients) {
        if ([NSDictionary isValidDictionary:obj]) {
            NSDictionary *messageRecipientItemDictionary = (NSDictionary *)obj;
            ABISFChatterMessageRecipientDataModel *messageRecipientDataModel =
            [[ABISFChatterMessageRecipientDataModel alloc] initWithMessageRecipientDictionary:messageRecipientItemDictionary];
            [self.recipients addObject:messageRecipientDataModel];
        }
    }
}
- (void)bindResponseDictionary:(NSDictionary *)response {
    if (![NSDictionary isValidDictionary:response])
        return;
    self.ID = [NSDictionary objectForKeySafe:response key:kid];
    self.conversationId = [NSDictionary objectForKeySafe:response key:kConversationId];
    self.conversationUrlSting = [NSDictionary objectForKeySafe:response key:kConversationUrl];
    self.sendingCommunity = [NSDictionary objectForKeySafe:response key:kConversationUrl];
    self.sentDate = [NSDictionary objectForKeySafe:response key:kSentDate];
    self.text = [ABISFChatterDataFetcherServices getTextKeyValueFromBodyDictionary:[NSDictionary objectForKeySafe:response key:kBody]];
    self.sender = [[ABISFChatterMessageSenderDataModel alloc] initWithMessageSenderDictionary:[NSDictionary objectForKeySafe:response key:kSender]];
    [self perseRecipients:[NSDictionary objectForKeySafe:response key:kRecipients]];
}

#pragma mark -  Dealloc
- (void)dealloc {
    _ID = nil;
    _text = nil;
    _conversationId = nil;
    _conversationUrlSting = nil;
    _sendingCommunity = nil;
    _sentDate = nil;
    _createdDate = nil;
    _sender = nil;
    _refreshTime = nil;
    if (_recipients.count)
        [_recipients removeAllObjects];
    _recipients = nil;
}
@end
