    //
    //  ABISFChatterMessageSenderDataModel.m
    //  ABIHiFive
    //
    //  Created by Prsenjit Goswami on 02/08/16.
    //  Copyright © 2016 Cognizant. All rights reserved.
    //
#import "ABISFChatterMessageSenderDataModel.h"
@implementation ABISFChatterMessageSenderDataModel
- (instancetype)initWithMessageSenderDictionary:(id)messageSenderDictionary {
    self = [super initWithParentDictionary:messageSenderDictionary];
    return self;
}
@end
