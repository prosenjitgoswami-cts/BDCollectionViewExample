    //
    //  ABISFChatterMessageSenderDataModel.h
    //  ABIHiFive
    //
    //  Created by Prsenjit Goswami on 02/08/16.
    //  Copyright © 2016 Cognizant. All rights reserved.
    //
#import "ABISFChatterParentDataModel.h"
#import <Foundation/Foundation.h>
@interface ABISFChatterMessageSenderDataModel : ABISFChatterParentDataModel
- (instancetype)initWithMessageSenderDictionary:(id)messageSenderDictionary;
@end
