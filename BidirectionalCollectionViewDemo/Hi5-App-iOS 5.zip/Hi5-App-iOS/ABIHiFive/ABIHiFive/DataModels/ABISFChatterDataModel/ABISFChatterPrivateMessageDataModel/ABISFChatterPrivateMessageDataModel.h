    //
    //  ABISFChatterPrivateMessageDataModel.h
    //  ABIHiFive
    //
    //  Created by Prsenjit Goswami on 02/08/16.
    //  Copyright © 2016 Cognizant. All rights reserved.
    //
#import "ABISFChatterBaseDataModel.h"
#import <Foundation/Foundation.h>
@interface ABISFChatterPrivateMessageDataModel : ABISFChatterBaseDataModel
@property (strong, nonatomic) NSString *nextPageUrl;
@property (strong, nonatomic) NSString *currentPageUrl;
@property (strong, nonatomic) NSMutableArray *messages;
- (instancetype)initWithMessageResponse:(NSDictionary *)mssageResponse;
@end
