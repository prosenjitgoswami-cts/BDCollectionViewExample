    //
    //  ABISFChatterPrivateMessageDataModel.m
    //  ABIHiFive
    //
    //  Created by Prsenjit Goswami on 02/08/16.
    //  Copyright © 2016 Cognizant. All rights reserved.
    //
#import "ABISFChatterPrivateMessageDataModel.h"
#import "ABISFChatterPrivateMessageItemsDataModel.h"
#import "Constants.h"
@implementation ABISFChatterPrivateMessageDataModel
- (instancetype)initWithMessageResponse:(NSDictionary *)mssageResponse {
    self = [self init];
    if (self) {
        self.nextPageUrl = mssageResponse[kNextPageUrl];
        self.currentPageUrl = mssageResponse[kCurrentPageUrl];
        [self bindResponseDictionary:mssageResponse[kMessages]];
    }
    return self;
}
#pragma mark - Private method
- (void)bindResponseDictionary:(NSArray *)messagesResponse {
    self.messages = [NSMutableArray array];
    for (id obj in messagesResponse) {
        NSDictionary *messageItems = (NSDictionary *)obj;
        ABISFChatterPrivateMessageItemsDataModel *messageItemsDataModel =
        [[ABISFChatterPrivateMessageItemsDataModel alloc] initWithResponse:messageItems];
        [self.messages addObject:messageItemsDataModel];
    }
}
#pragma mark - Dealloc
- (void)dealloc {
        //    _nextPageUrl = nil;
        //    _currentPageUrl = nil;
        //    [_messages removeAllObjects];
        //    _messages = nil;
}
@end
