    //
    //  ABISFChatterParentDataModel.m
    //  ABIHiFive
    //
    //  Created by Prsenjit Goswami on 24/07/16.
    //  Copyright © 2016 Cognizant. All rights reserved.
    //
#import "ABISFChatterParentDataModel.h"
#import "ABISFChatterDataFetcherServices.h"
#import "Constants.h"
@interface ABISFChatterParentDataModel ()
@property (strong, nonatomic, readwrite) ABISFChatterPhotosDataModel *photo;
@property (strong, nonatomic, readwrite) NSString *groupName;
;
@property (assign, nonatomic, readwrite) BOOL isGroupType;
@end
@implementation ABISFChatterParentDataModel
- (instancetype)initWithParentDictionary:(id)parentDictionary {
    self = [super init];
    if (self) {
        [self bindResponseDictionary:parentDictionary];
    }
    return self;
}
#pragma mark - Public method
- (void)setType:(NSString *)type {
    _type = type;
    self.isGroupType = (![NSString isNULLString:_type] && [_type isEqualToString:FEED_TYPE_COLLABRATION_GROOP]);
}
#pragma mark - Private method
- (void)bindResponseDictionary:(NSDictionary *)parentDictionary {
    if (![NSDictionary isValidDictionary:parentDictionary])
        return;
    self.parentID = [NSDictionary objectForKeySafe:parentDictionary key:@"id"];
    self.name = [NSDictionary objectForKeySafe:parentDictionary key:kname];
    self.displayName = [NSDictionary objectForKeySafe:parentDictionary key:kDisplayName];
    self.photo = [[ABISFChatterPhotosDataModel alloc] initWithPhotoDictionary:parentDictionary[kphoto]];
    self.type = [NSDictionary objectForKeySafe:parentDictionary key:kType];
}
#pragma mark - Dealloc
- (void)dealloc {
    _name = nil;
    _displayName = nil;
    _parentID = nil;
    _type = nil;
    _photo = nil;
}
@end
