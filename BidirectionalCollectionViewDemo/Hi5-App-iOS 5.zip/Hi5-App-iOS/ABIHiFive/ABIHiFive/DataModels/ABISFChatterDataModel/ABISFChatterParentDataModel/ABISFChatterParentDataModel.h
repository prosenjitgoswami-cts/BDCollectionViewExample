    //
    //  ABISFChatterParentDataModel.h
    //  ABIHiFive
    //
    //  Created by Prsenjit Goswami on 24/07/16.
    //  Copyright © 2016 Cognizant. All rights reserved.
    //
#import "ABISFChatterBaseDataModel.h"
#import "ABISFChatterPhotosDataModel.h"
#import <Foundation/Foundation.h>
@interface ABISFChatterParentDataModel : ABISFChatterBaseDataModel
- (instancetype)initWithParentDictionary:(id)parentDictionary;
@property (strong, nonatomic) NSString *name;
@property (strong, nonatomic) NSString *displayName;
@property (strong, nonatomic) NSString *firstName;
@property (strong, nonatomic) NSString *lastName;
@property (strong, nonatomic, readonly) NSString *fullNameText;
@property (strong, nonatomic) NSString *parentID;
@property (strong, nonatomic) NSString *type;
@property (assign, nonatomic, readonly) BOOL isGroupType;
@property (strong, nonatomic, readonly) ABISFChatterPhotosDataModel *photo;
@end
