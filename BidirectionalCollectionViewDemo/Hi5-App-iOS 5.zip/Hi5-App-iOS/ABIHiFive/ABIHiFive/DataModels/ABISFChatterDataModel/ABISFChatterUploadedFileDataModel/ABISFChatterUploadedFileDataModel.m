    //
    //  ABISFChatterUploadedFileDataModel.m
    //  ABIHiFive
    //
    //  Created by Prsenjit Goswami on 28/07/16.
    //  Copyright © 2016 Cognizant. All rights reserved.
    //
#import "ABISFChatterUploadedFileDataModel.h"
@implementation ABISFChatterUploadedFileDataModel
#pragma mark - Dealloc
- (void)dealloc {
    _contentModifiedDate = nil;
    _downloadUrl = nil;
    _fileExtension = nil;
}
@end
