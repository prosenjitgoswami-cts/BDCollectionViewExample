    //
    //  ABISFChatterUploadedFileDataModel.h
    //  ABIHiFive
    //
    //  Created by Prsenjit Goswami on 28/07/16.
    //  Copyright © 2016 Cognizant. All rights reserved.
    //
#import "ABISFChatterBaseDataModel.h"
#import <Foundation/Foundation.h>
@interface ABISFChatterUploadedFileDataModel : ABISFChatterBaseDataModel
@property (nonatomic, strong) NSString *contentModifiedDate;
@property (nonatomic, strong) NSString *downloadUrl;
@property (nonatomic, strong) NSString *fileExtension;
@end
