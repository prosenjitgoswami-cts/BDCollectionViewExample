    //
    //  ABISFChatterFilesDataModel.m
    //  ABIHiFive
    //
    //  Created by Prsenjit Goswami on 25/07/16.
    //  Copyright © 2016 Cognizant. All rights reserved.
    //
#import "ABISFChatterFilesDataModel.h"
#import "ABISFChatterContentDataModel.h"
#import "Constants.h"
#define kVersionId @"versionId"
@interface ABISFChatterFilesDataModel ()
@property (nonatomic, strong, readwrite) NSMutableArray<ABISFChatterContentDataModel *> *items;
@end
@implementation ABISFChatterFilesDataModel
- (instancetype)initWithFileDictionary:(NSDictionary *)filesDict {
    self = [super init];
    if (self) {
        [self bindResponseDictionary:[NSDictionary objectForKeySafe:filesDict key:kItems]];
    }
    return self;
}
- (void)bindResponseDictionary:(NSArray *)files {
    if (![NSArray isValidArray:files])
        return;
    self.items = [NSMutableArray array];
    for (NSDictionary *file in files) {
        ABISFChatterContentDataModel *contentDataModel = [[ABISFChatterContentDataModel alloc] initWithContentdictionary:file];
        if (contentDataModel.ID)
            [self.items addObject:contentDataModel];
    }
}
#pragma mark - Dealloc
- (void)dealloc {
    [_items removeAllObjects];
    _items = nil;
}
@end
