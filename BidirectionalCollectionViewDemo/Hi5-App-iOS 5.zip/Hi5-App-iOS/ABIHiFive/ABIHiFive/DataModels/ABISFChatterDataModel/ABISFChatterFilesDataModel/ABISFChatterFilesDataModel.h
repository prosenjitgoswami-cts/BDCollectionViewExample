    //
    //  ABISFChatterFilesDataModel.h
    //  ABIHiFive
    //
    //  Created by Prsenjit Goswami on 25/07/16.
    //  Copyright © 2016 Cognizant. All rights reserved.
    //
#import "ABISFChatterBaseDataModel.h"
#import <Foundation/Foundation.h>
@class ABISFChatterContentDataModel;
@interface ABISFChatterFilesDataModel : ABISFChatterBaseDataModel
@property (strong, nonatomic, readonly) NSMutableArray<ABISFChatterContentDataModel *> *items;
- (instancetype)initWithFileDictionary:(NSDictionary *)filesDict;
@end
