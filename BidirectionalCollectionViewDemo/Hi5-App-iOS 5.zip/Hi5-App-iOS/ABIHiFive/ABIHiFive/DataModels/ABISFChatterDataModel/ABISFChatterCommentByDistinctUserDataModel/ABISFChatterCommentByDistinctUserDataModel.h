    //
    //  ABISFChatterCommentByDistinctUserDataModel.h
    //  ABIHiFive
    //
    //  Created by Prsenjit Goswami on 05/08/16.
    //  Copyright © 2016 Cognizant. All rights reserved.
    //
#import "ABISFChatterBaseDataModel.h"
#import <Foundation/Foundation.h>
@interface ABISFChatterCommentByDistinctUserDataModel : ABISFChatterBaseDataModel
@property (nonatomic, assign, readonly) BOOL isMoreAvailable;
@property (nonatomic, strong, readonly) NSString *commentByDistinctUsersNameString;
@property (nonatomic, strong, readonly) NSMutableArray *commentByDistinctUsers;
@property (nonatomic, strong, readonly) NSMutableArray *allCommentItems;
+ (instancetype)initWithCommentByDistinctUsersName:(NSString *)commentByDistinctUsersNameString
                            commentByDistinctUsers:(NSMutableArray *)commentByDistinctUsers
                                   isMoreAvailable:(BOOL)isMoreAvailable
                                    allCommentItem:(NSMutableArray *)allCommentItem;
@end
