    //
    //  ABISFChatterCommentByDistinctUserDataModel.m
    //  ABIHiFive
    //
    //  Created by Prsenjit Goswami on 05/08/16.
    //  Copyright © 2016 Cognizant. All rights reserved.
    //
#import "ABISFChatterCommentByDistinctUserDataModel.h"
@interface ABISFChatterCommentByDistinctUserDataModel ()
@property (nonatomic, assign, readwrite) BOOL isMoreAvailable;
@property (nonatomic, strong, readwrite) NSString *commentByDistinctUsersNameString;
@property (nonatomic, strong, readwrite) NSMutableArray *commentByDistinctUsers;
@property (nonatomic, strong, readwrite) NSMutableArray *allCommentItems;
@end
@implementation ABISFChatterCommentByDistinctUserDataModel
+ (instancetype)initWithCommentByDistinctUsersName:(NSString *)commentByDistinctUsersNameString
                            commentByDistinctUsers:(NSMutableArray *)commentByDistinctUsers
                                   isMoreAvailable:(BOOL)isMoreAvailable
                                    allCommentItem:(NSMutableArray *)allCommentItem {
    ABISFChatterCommentByDistinctUserDataModel *selfObj = [ABISFChatterCommentByDistinctUserDataModel new];
    selfObj.isMoreAvailable = isMoreAvailable;
    selfObj.commentByDistinctUsers = commentByDistinctUsers;
    selfObj.allCommentItems = allCommentItem;
    selfObj.commentByDistinctUsersNameString = commentByDistinctUsersNameString;
    return selfObj;
}
#pragma mark - Dealloc
- (void)dealloc {
    _commentByDistinctUsersNameString = nil;
    if (_commentByDistinctUsers.count)
        [_commentByDistinctUsers removeAllObjects];
    _commentByDistinctUsers = nil;
    if (_allCommentItems.count)
        [_allCommentItems removeAllObjects];
    _allCommentItems = nil;
}
@end
