    //
    //  ABISFChatterCommentModel.m
    //  AnheuserBusch
    //
    //  Created by Prsenjit Goswami on 24/06/16.
    //  Copyright © 2016 Cognizant. All rights reserved.
    //
#import "ABISFChatterCommentModel.h"
#import "ABISFChatterCommentByDistinctUserDataModel.h"
#import "ABISFChatterCommentItemModel.h"
#import "ABISFChatterDataModelBinder.h"
#import "ABISFRestRequestManager.h"
#import "Constants.h"
@interface ABISFChatterCommentModel ()
@property (nonatomic, assign, readwrite) BOOL isMoreAvailable;
@property (nonatomic, strong, readwrite) NSString *uniqueUsersName;
@property (nonatomic, strong, readwrite) NSMutableArray<ABISFChatterCommentItemModel *> *uniqueCommentUsers;
@property (nonatomic, strong, readwrite) NSMutableArray<ABISFChatterCommentItemModel *> *commentItems;
@end
@implementation ABISFChatterCommentModel
- (instancetype)initWithCommentParentFeedID:(NSString *)parentFeedID commentPages:(NSDictionary *)commentPages {
    self = [super init];
    if (self) {
        /*!
         Comment model Object is contain the information of a Feed comment. Which have  informations
         1. ParentFeedID - Parent id of Feed.

         2. nextPageUrlString - Normally 3 comment are retrive in asingle invocation. if there is more than 3 comment if Feed then 'nextPageUrlString' is
         available.  We need to invoke the 'nextPageUrlString' for rest of comment.

         3. currentPageUrlString - 'currentPageUrlString' is the current Page url.

         4. totalInNumber - 'totalInNumber' is total number of all Feed Comment.
         */
        self.parentFeedID = parentFeedID;
        self.nextPageUrlString = [NSDictionary objectForKeySafe:commentPages key:kNextPageUrl];
        self.previousPageUrlString = [NSDictionary objectForKeySafe:commentPages key:kPreviousPageUrl];
        self.currentPageUrlString = [NSDictionary objectForKeySafe:commentPages key:kCurrentPageUrl];
        self.totalInNumber = [NSDictionary objectForKeySafe:commentPages key:kTotal];
    }
    return self;
}
#pragma mark - Public method
- (void)prepareDataModelWithParentFeedID:(NSString *)parentFeedID commentPages:(NSDictionary *)commentPages completion:(void (^)(void))completion {
    self.parentFeedID = parentFeedID;
    self.nextPageUrlString = [NSDictionary objectForKeySafe:commentPages key:kNextPageUrl];
    self.previousPageUrlString = [NSDictionary objectForKeySafe:commentPages key:kPreviousPageUrl];
    self.currentPageUrlString = [NSDictionary objectForKeySafe:commentPages key:kCurrentPageUrl];
    self.totalInNumber = [NSDictionary objectForKeySafe:commentPages key:kTotal];
    /*!
     *  Here I am binding the each comment as ABISFChatterCommentItemModel, in 'commentItems'.
     commentItems - It is collection of indivisual comment  (as ABISFChatterCommentItemModel).
     */
    __weak typeof(self) weakSelf = self;
    if (self.currentPageUrlString) {
        [ABISFRestRequestManager requestWithMethod:SFRestMethodGET
                                              path:self.currentPageUrlString
                                       queryParams:nil
                                       failedBlock:^(NSError *error, NSDictionary *extraInfo) {
                                           if (completion)
                                               completion();
                                       }
                                      successBlock:^(id response, NSDictionary *extraInfo) {
                                          if ([NSDictionary isValidDictionary:response]) {
                                              id itemsObject = [NSDictionary objectForKeySafe:response key:kItems];
                                              if ([NSArray isValidArray:itemsObject]) {
                                                  NSArray *items = (NSArray *)itemsObject;
                                                  if (items.count) {
                                                      ABISFChatterCommentByDistinctUserDataModel *model =
                                                      [ABISFChatterDataModelBinder bindResponseDataForCommentItems:items parentFeedID:self.parentFeedID isUniqueCommentUsersSerch:YES];
                                                      weakSelf.commentItems = model.allCommentItems;
                                                      weakSelf.uniqueCommentUsers = model.commentByDistinctUsers;
                                                      weakSelf.uniqueUsersName = model.commentByDistinctUsersNameString;
                                                      weakSelf.isMoreAvailable = model.isMoreAvailable;
                                                  }
                                              }
                                          }
                                          if (completion)
                                              completion();
                                      }];
    }
}
+ (void)prepareDataModelWithParentFeedID:(NSString *)parentFeedID
                            commentPages:(NSDictionary *)commentPages
                              completion:(void (^)(ABISFChatterCommentModel *commentModel))completion {
    __block ABISFChatterCommentModel *commentModel = [ABISFChatterCommentModel new];
    commentModel.parentFeedID = parentFeedID;
    commentModel.nextPageUrlString = [NSDictionary objectForKeySafe:commentPages key:kNextPageUrl];
    commentModel.previousPageUrlString = [NSDictionary objectForKeySafe:commentPages key:kPreviousPageUrl];
    NSString *currentURLString = [NSDictionary objectForKeySafe:commentPages key:kCurrentPageUrl];
    commentModel.currentPageUrlString = currentURLString;
    NSNumber *totalInNumber = [NSDictionary objectForKeySafe:commentPages key:kTotal];
    ;
    commentModel.totalInNumber = totalInNumber;
    NSArray *items = [NSDictionary objectForKeySafe:commentPages key:@"items"];
    /*!
     *  Here I am binding the each comment as ABISFChatterCommentItemModel, in 'commentItems'.
     commentItems - It is collection of indivisual comment  (as ABISFChatterCommentItemModel).
     */
    if (items.count > 0 && totalInNumber.integerValue > 0 && totalInNumber.integerValue <= DefaultChatterCommentSize &&
        items.count <= totalInNumber.integerValue) {
        ABISFChatterCommentByDistinctUserDataModel *model =
        [ABISFChatterDataModelBinder bindResponseDataForCommentItems:items parentFeedID:parentFeedID isUniqueCommentUsersSerch:YES];
        commentModel.commentItems = [model.allCommentItems mutableCopy];              // Check Why?
        commentModel.uniqueCommentUsers = [model.commentByDistinctUsers mutableCopy]; // Check Why?
        commentModel.uniqueUsersName = model.commentByDistinctUsersNameString;
        commentModel.isMoreAvailable = model.isMoreAvailable;
        if (completion)
            completion(commentModel);
    } else if (currentURLString && totalInNumber.integerValue > 0) {
        [ABISFRestRequestManager requestWithMethod:SFRestMethodGET
                                              path:currentURLString
                                       queryParams:nil
                                       failedBlock:^(NSError *error, NSDictionary *extraInfo) {
                                           if (completion)
                                               completion(commentModel);
                                       }
                                      successBlock:^(id response, NSDictionary *extraInfo) {
                                          if ([NSDictionary isValidDictionary:response]) {
                                              id itemsObject = [NSDictionary objectForKeySafe:response key:kItems];
                                              if ([NSArray isValidArray:itemsObject]) {
                                                  NSArray *items = (NSArray *)itemsObject;
                                                  if (items.count) {
                                                      ABISFChatterCommentByDistinctUserDataModel *model =
                                                      [ABISFChatterDataModelBinder bindResponseDataForCommentItems:items parentFeedID:parentFeedID isUniqueCommentUsersSerch:YES];
                                                      commentModel.commentItems = [model.allCommentItems mutableCopy];
                                                      commentModel.uniqueCommentUsers = [model.commentByDistinctUsers mutableCopy];
                                                      commentModel.uniqueUsersName = model.commentByDistinctUsersNameString;
                                                      commentModel.isMoreAvailable = model.isMoreAvailable;
                                                  }
                                              }
                                          }
                                          if (completion)
                                              completion(commentModel);
                                      }];
    } else {
        if (completion)
            completion(commentModel);
    }
}
#pragma mark - Dealloc
- (void)dealloc {
    [_commentItems removeAllObjects];
    _commentItems = nil;
    [_uniqueCommentUsers removeAllObjects];
    _uniqueCommentUsers = nil;
    _totalInNumber = nil;
    _parentFeedID = nil;
    _page = nil;
    _nextPageUrlString = nil;
    _previousPageUrlString = nil;
    _currentPageUrlString = nil;
    _uniqueUsersName = nil;
}
@end
