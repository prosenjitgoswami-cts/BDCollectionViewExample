    //
    //  ABISFChatterCommentModel.h
    //  AnheuserBusch
    //
    //  Created by Prsenjit Goswami on 24/06/16.
    //  Copyright © 2016 Cognizant. All rights reserved.
    //
#import <Foundation/Foundation.h>
@class ABISFChatterCommentItemModel;
@interface ABISFChatterCommentModel : NSObject
@property (nonatomic, assign) NSNumber *totalInNumber;
@property (nonatomic, strong) NSString *parentFeedID;
@property (nonatomic, strong) NSDictionary *page;
@property (nonatomic, strong) NSString *nextPageUrlString;
@property (nonatomic, strong) NSString *previousPageUrlString;
@property (nonatomic, strong) NSString *currentPageUrlString;
@property (nonatomic, assign, readonly) BOOL isMoreAvailable;
@property (nonatomic, strong, readonly) NSString *uniqueUsersName;
@property (nonatomic, strong, readonly) NSMutableArray<ABISFChatterCommentItemModel *> *uniqueCommentUsers;
@property (nonatomic, strong, readonly) NSMutableArray<ABISFChatterCommentItemModel *> *commentItems;
- (instancetype)initWithCommentParentFeedID:(NSString *)parentFeedID commentPages:(NSDictionary *)commentPages;
- (void)prepareDataModelWithParentFeedID:(NSString *)parentFeedID commentPages:(NSDictionary *)commentPages completion:(void (^)(void))completion;
;
+ (void)prepareDataModelWithParentFeedID:(NSString *)parentFeedID
                            commentPages:(NSDictionary *)commentPages
                              completion:(void (^)(ABISFChatterCommentModel *commentModel))completion;
@end
