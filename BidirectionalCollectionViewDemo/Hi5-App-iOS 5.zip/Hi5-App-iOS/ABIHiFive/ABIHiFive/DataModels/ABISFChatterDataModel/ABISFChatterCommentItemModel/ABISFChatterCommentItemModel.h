    //
    //  ABISFChatterCommentItemModel.h
    //  AnheuserBusch
    //
    //  Created by Prsenjit Goswami on 24/06/16.
    //  Copyright © 2016 Cognizant. All rights reserved.
    //
#import "ABISFChatterBaseDataModel.h"
#import "ABISFChatterContentDataModel.h"
#import "ABISFChatterParentDataModel.h"
#import <Foundation/Foundation.h>

@interface ABISFChatterCommentItemModel : ABISFChatterBaseDataModel
- (instancetype)initWithParentFeedID:(NSString *)parentFeedID commentItem:(id)commentItem;
@property (nonatomic, strong) NSString *parentFeedID;
@property (nonatomic, strong) NSString *commentItemID;
@property (nonatomic, strong) NSString *createdDateString;
@property (nonatomic, strong) NSDate *createdDate;
@property (nonatomic, strong) NSString *relativeCreatedDate;
@property (nonatomic, strong) NSString *message;
@property (nonatomic, strong) NSString *refreshTime;
@property (nonatomic, strong, readonly) ABISFChatterParentDataModel *parent;
@property (nonatomic, strong, readonly) ABISFChatterContentDataModel *content;
@end
