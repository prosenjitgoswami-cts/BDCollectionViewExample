    //
    //  ABISFChatterCommentItemModel.m
    //  AnheuserBusch
    //
    //  Created by Prsenjit Goswami on 24/06/16.
    //  Copyright © 2016 Cognizant. All rights reserved.
    //
#import "ABISFChatterCommentItemModel.h"
#import "ABISFChatterContentDataModel.h"
#import "ABISFChatterDataFetcherServices.h"
@interface ABISFChatterCommentItemModel ()
@property (nonatomic, strong, readwrite) ABISFChatterParentDataModel *parent;
@property (nonatomic, strong, readwrite) ABISFChatterContentDataModel *content;
@end
@implementation ABISFChatterCommentItemModel
/*!
 *  This data model class is the referance of a Commemt item. The Feed has multiple 'Comment Item'.
 *  This 'ABISFChatterCommentItemModel' model contains..
 *  @param parentFeedID Parent 'Feed ID' of commemtItem
 *  @param commentItem  Comment Item Dictionary type responce
 *
 *  @return As object referance ABISFChatterCommentItemModel .
 */
- (instancetype)initWithParentFeedID:(NSString *)parentFeedID commentItem:(id)commentItem {
    self = [super init];
    if (self) {
        self.parentFeedID = parentFeedID;
        self.commentItemID = [NSDictionary objectForKeySafe:commentItem key:kid];
        self.message = [ABISFChatterDataFetcherServices commentsItemBodyText:commentItem];
        self.createdDateString = [NSDictionary objectForKeySafe:commentItem key:kCreatedDate];
        self.relativeCreatedDate = [NSDictionary objectForKeySafe:commentItem key:kRelativeCreatedDate];
        NSDictionary *capabilities = commentItem[kCapabilities];
        if (capabilities) {
            NSDictionary *content = capabilities[kContent];
            if (content) {
                /*!
                 Descrioption: File contain of a Feed. This is the attachmet which is uploaded against a feed . It can be uploaed from device and Web.

                 - returns: content is ABISFChatterContentDataModel referance which holds all the inforformation of uploade file of a feed.
                 */
                ABISFChatterContentDataModel *tempObj = [[ABISFChatterContentDataModel alloc] initWithContentdictionary:content];
                if (tempObj.ID)
                    self.content = tempObj;
            }
        }
        self.parent = [[ABISFChatterParentDataModel alloc] initWithParentDictionary:[NSDictionary objectForKeySafe:commentItem key:kUser]];
    }
    return self;
}

#pragma mark -  Public method
- (void)setCreatedDateString:(NSString *)createdDateString {
    _createdDateString = createdDateString;
    if (![NSString isNULLString:_createdDateString]) {
        self.createdDate = [NSDate dateFromString:_createdDateString andFormatterStyle:DEFAULT_SF_DATE_FORMAT];
        self.refreshTime = [NSDate dispalyTimeAsLocalTZFormatWithUTCDate:self.createdDate];
    }
}

#pragma mark -  Over Ride Method
- (BOOL)isEqual:(id)object {
    ABISFChatterCommentItemModel *prevObject = (ABISFChatterCommentItemModel *)object;
    return [self.commentItemID hash] == [prevObject.commentItemID hash];
}

#pragma mark -  Dealloc
- (void)dealloc {
    _content = nil;
    _parentFeedID = nil;
    _commentItemID = nil;
    _message = nil;
    _createdDateString = nil;
    _relativeCreatedDate = nil;
    _parent = nil;
}
@end
