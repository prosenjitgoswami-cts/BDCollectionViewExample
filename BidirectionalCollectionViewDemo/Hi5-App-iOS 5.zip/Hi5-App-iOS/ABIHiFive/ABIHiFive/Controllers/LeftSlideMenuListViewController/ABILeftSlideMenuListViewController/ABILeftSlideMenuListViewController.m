    //
    //  MVYMenuViewController.m
    //  ABIHiFive
    //
    //  Created by Prsenjit Goswami on 10/06/16.
    //  Copyright © 2016 Cognizant. All rights reserved.
    //
#import "ABILeftSlideMenuListViewController.h"
#import "ABIMenuItemDataModel.h"
#import "ABISFDataFetcherService.h"
#import "Constants.h"
#import "HelperUtilHeader.h"
#import "LeftEdgeSlideMenuContainerViewController.h"
#import "ABILeftSlideMenuListTableViewListCell.h"
#import "ABIProfilePageViewController.h"
#import "ABIProfilePageViewcontroller.h"
#import "SFIdentityData.h"
@interface ABILeftSlideMenuListViewController ()
@property (strong, nonatomic) UIImageView *bgImageView;
@property (strong, nonatomic) UIImageView *userImageBorderView;
@property (strong, nonatomic) UIImageView *userImageView;
@property (strong, nonatomic) UILabel *userNameLabel;
@property (strong, nonatomic) UITableView *tableView;
@property (strong, nonatomic) UIImageView *imageBorderView;
@property (strong, nonatomic) NSIndexPath *selectedIndexPath;
@property (strong, nonatomic) NSMutableArray *menuItems;
@end
@implementation ABILeftSlideMenuListViewController
- (void)viewDidLoad {
    [super viewDidLoad];
    [self configureUI];
}
- (void)viewWillAppear:(BOOL)animated {
    [super viewWillAppear:animated];
    [_tableView reloadData];
}
#pragma mark - Private Method
/*!
 *  Create UI with Component
 */
- (void)configureUI {
    self.selectedIndexPath = [NSIndexPath indexPathForRow:0 inSection:0];
    [self.view addSubview:self.bgImageView];
    [self.view addSubview:self.userImageView];
    [self.view addSubview:self.userNameLabel];
    [self.view addSubview:self.tableView];
    [self.view addSubview:self.userImageBorderView];
    [self addConstraint];
}
/*!
 * Add Constraint for UI with Component
 */
- (void)addConstraint {
    NSDictionary *views = @{
                            @"bgImageView" : self.bgImageView,
                            @"userImageBorderView" : _userImageBorderView,
                            @"userImageView" : _userImageView,
                            @"userNameLabel" : _userNameLabel,
                            @"tableView" : _tableView
                            };
    [self.view addConstraintsWithVisualFormat:@"H:|[bgImageView]|" options:0 metrics:nil views:views];
    [self.view addConstraintsWithVisualFormat:@"V:|[bgImageView]|" options:0 metrics:nil views:views];
    [self.view addConstraintsWithVisualFormat:@"H:[userImageBorderView(90)]" options:0 metrics:nil views:views];
    [self.view addConstraintsWithVisualFormat:@"H:[userImageView(90)]" options:0 metrics:nil views:views];
    [self.view addConstraintsWithVisualFormat:@"V:|-30-[userImageView(90)]" options:0 metrics:nil views:views];
    [self.view addConstraintsWithVisualFormat:@"H:|-[userNameLabel]-|" options:0 metrics:nil views:views];
    [self.view addConstraintsWithVisualFormat:@"H:|[tableView]|" options:0 metrics:nil views:views];
    [self.view addConstraintsWithVisualFormat:@"V:|-30-[userImageBorderView(90)]-10-[userNameLabel]-20-[tableView]|" options:0 metrics:nil views:views];
    [self.view addConstraint:[NSLayoutConstraint constraintWithItem:self.userImageBorderView
                                                          attribute:NSLayoutAttributeCenterX
                                                          relatedBy:NSLayoutRelationEqual
                                                             toItem:self.view
                                                          attribute:NSLayoutAttributeCenterX
                                                         multiplier:1
                                                           constant:0]];
    [self.view addConstraint:[NSLayoutConstraint constraintWithItem:self.userImageView
                                                          attribute:NSLayoutAttributeCenterX
                                                          relatedBy:NSLayoutRelationEqual
                                                             toItem:self.view
                                                          attribute:NSLayoutAttributeCenterX
                                                         multiplier:1
                                                           constant:0]];
    [self.view addConstraint:[NSLayoutConstraint constraintWithItem:self.userImageView
                                                          attribute:NSLayoutAttributeCenterY
                                                          relatedBy:NSLayoutRelationEqual
                                                             toItem:self.userImageBorderView
                                                          attribute:NSLayoutAttributeCenterY
                                                         multiplier:1
                                                           constant:0]];
    [NSLayoutConstraint height:self.userImageView toItem:self.userImageBorderView multiplier:1 constant:0];
}
- (NSMutableArray *)populateDataSource {
    NSString *path = [[NSBundle mainBundle] pathForResource:@"HamburgerMenuList" ofType:@"plist"];
    NSArray *plistDatas = [[NSArray alloc] initWithContentsOfFile:path];
    NSMutableArray *results = [NSMutableArray array];
    for (NSDictionary *dict in plistDatas) {
        ABIMenuItemDataModel *menuItemDataModel = [ABIMenuItemDataModel new];
        menuItemDataModel.itemName = dict[@"ListMenuItem"];
        menuItemDataModel.selectedImageName = dict[@"SelectedImageName"];
        menuItemDataModel.deselectedImageName = dict[@"DeselectedImageName"];
        [results addObject:menuItemDataModel];
    }
    return results;
}
- (UIImageView *)bgImageView {
    if (!_bgImageView) {
        _bgImageView = [UIImageView new];
        _bgImageView.translatesAutoresizingMaskIntoConstraints = NO;
        _bgImageView.backgroundColor = [UIColor defaultMauveColorABI];
    }
    return _bgImageView;
}
- (UIImageView *)userImageView {
    if (!_userImageView) {
        _userImageView = [UIImageView initWithImage:[UIImage imageNamed:@"menu_profile_image"]];
        _userImageView.layer.cornerRadius = 45.0f;
        _userImageView.clipsToBounds = YES;
    }
    return _userImageView;
}
- (UIImageView *)userImageBorderView {
    if (!_userImageBorderView) {
        _userImageBorderView = [UIImageView initWithImage:[UIImage imageNamed:@"mainProfileCircle"]];
    }
    return _userImageBorderView;
}
- (UILabel *)userNameLabel {
    if (!_userNameLabel) {
        _userNameLabel = [UILabel labelWithText:@""
                                      textColor:SLIDE_MENU_USER_NAME_TEXT_COLOR
                                       textFont:SLIDE_MENU_USER_NAME_TEXT_FONT
                                  textAlignment:NSTextAlignmentCenter
                                  numberOfLines:0
                                backgroundColor:nil];
        _userNameLabel.lineBreakMode = NSLineBreakByWordWrapping;
        _userNameLabel.text = [NSString stringWithFormat:@""];
    }
    return _userNameLabel;
}
- (UITableView *)tableView {
    if (!_tableView) {
        _tableView = [UITableView plainTableView];
        _tableView.delegate = self;
        _tableView.dataSource = self;
        _tableView.backgroundColor = [UIColor whiteColor];
        _tableView.separatorColor = [UIColor clearColor];
    }
    return _tableView;
}
- (NSMutableArray *)menuItems {
    if (!_menuItems) {
        _menuItems = self.populateDataSource;
    }
    return _menuItems;
}
- (void)reloadMenuList {
    if (_tableView) {
        [_tableView reloadData];
    }
    [self.userImageView setABISignedInUserProfileImage];
    NSString *username = [AppDelegate globalSingedInABISFRosterDataModel].rosterNameText;
    if (![NSString isNULLString:username]) {
        _userNameLabel.text = [NSString stringWithFormat:@"Welcome %@", username];
    }
}
#pragma mark – UITableViewDataSource
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    return self.menuItems.count;
}
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    static NSString *cellIdentifier = @"MenuCell";
    ABILeftSlideMenuListTableViewListCell *cell = (ABILeftSlideMenuListTableViewListCell *)[tableView dequeueReusableCellWithIdentifier:cellIdentifier];
    cell.menuItemModel = [ABIMenuItemDataModel new];
    if (!cell) {
        cell = [[ABILeftSlideMenuListTableViewListCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:cellIdentifier];
    }
    cell.backgroundColor = [UIColor whiteColor];
    cell.menuItemModel = [_menuItems objectAtIndex:indexPath.row];
    cell.selectionStyle = UITableViewCellSelectionStyleNone;
    [cell updateOnSelection:(self.selectedIndexPath.section == indexPath.section && self.selectedIndexPath.row == indexPath.row)
                atIndexPath:(NSIndexPath *)indexPath];
    return cell;
}
- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath {
    return 40.0f;
}
- (CGFloat)tableView:(UITableView *)tableView heightForFooterInSection:(NSInteger)section {
        // This will create a "invisible" footer
    return 0.01f;
}
#pragma mark – UITableViewDelegate
- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
    if (SLIDEMENU_CONDITION) {
        if (SLIDEMENU_OPT_NOT_CHANGE_COLOR_CONDITION) {
        } else {
            self.selectedIndexPath = indexPath;
        }
        if (self.delegate && [self.delegate respondsToSelector:@selector(didSelectRowAtIndexPath:)]) {
            [self.delegate didSelectRowAtIndexPath:indexPath];
        }
    }
}
@end
