    //
    //  ABITermsAndConditionViewController.m
    //  Pods
    //
    //  Created by Prsenjit Goswami on 22/08/16.
    //
    //
#import "ABITermsAndConditionViewController.h"
#import "Constants.h"
#import "SalesforceSDKCore.h"
@interface ABITermsAndConditionViewController ()
@property (weak, nonatomic) IBOutlet UILabel *headerLabel;
@property (unsafe_unretained, nonatomic) IBOutlet UIView *navigationBar;
@property (unsafe_unretained, nonatomic) IBOutlet UIWebView *webView;
@property (unsafe_unretained, nonatomic) IBOutlet UIButton *backButton;
@property (unsafe_unretained, nonatomic) IBOutlet UIActivityIndicatorView *activityIndicator;
@end
@implementation ABITermsAndConditionViewController
+ (void)showTremsAndConditionPage {
    SFLoginViewController *sf = [SFLoginViewController sharedInstance];
    [sf setTermsAndConditionButtonTitle:TITLE_PRIVACY_POLICY];
    [sf tremsAndCOnditionCallBack:^{
        ABITermsAndConditionViewController *vc1 = [[ABITermsAndConditionViewController alloc] initWithNibName:@"ABITermsAndConditionViewController" bundle:nil];
        [sf presentViewController:vc1 animated:YES completion:NULL];
    }];
}
- (IBAction)clickedBackButton:(id)sender {
    [self dismissViewControllerAnimated:YES completion:NULL];
}
- (void)viewDidLoad {
    [super viewDidLoad];
    _webView.scrollView.bounces = NO;
    self.headerLabel.text = TITLE_PRIVACY_POLICY;
    self.headerLabel.font = [UIFont fontHelvetica67Condensed:18.0f];
    self.navigationBar.backgroundColor = [UIColor colorWithRed:14.0f / 255.0f green:113.0f / 255.0f blue:185.0f / 255.0f alpha:1];
    [self.webView loadRequest:[NSURLRequest requestWithURL:[NSURL URLWithString:TREMS_AND_CONDITION_URL_STRING]]];
}
- (void)dealloc {
    _webView.delegate = nil;
}

#pragma mark -  WebView Delegate
- (void)webViewDidStartLoad:(UIWebView *)webView {
    [self activityIndicatorVisibilityHidden:NO];
}
- (void)webViewDidFinishLoad:(UIWebView *)webView {
    [self activityIndicatorVisibilityHidden:YES];
}
- (void)webView:(UIWebView *)webView didFailLoadWithError:(nullable NSError *)error {
    [self activityIndicatorVisibilityHidden:YES];
}

#pragma mark -  Private Method
- (void)activityIndicatorVisibilityHidden:(BOOL)isHidden {
    dispatch_main_async_safeBlock(^{
        !isHidden ? [self.activityIndicator startAnimating] : [self.activityIndicator stopAnimating];
        self.activityIndicator.hidden = isHidden;
    });
}
@end
