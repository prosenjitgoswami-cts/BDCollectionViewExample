    //
    //  ABITermsAndConditionViewController.h
    //  Pods
    //
    //  Created by Prsenjit Goswami on 22/08/16.
    //
    //
#import "ABIBaseViewController.h"
#import <UIKit/UIKit.h>
@interface ABITermsAndConditionViewController : ABIBaseViewController
+ (void)showTremsAndConditionPage;
@end
