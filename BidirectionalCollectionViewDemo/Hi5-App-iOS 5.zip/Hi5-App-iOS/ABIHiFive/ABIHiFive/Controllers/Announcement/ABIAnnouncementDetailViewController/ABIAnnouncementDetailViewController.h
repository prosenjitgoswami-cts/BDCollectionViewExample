    //
    //  ABIAnnouncementDetailViewController.h
    //  ABIHiFive
    //
    //  Created by Prsenjit Goswami on 04/07/16.
    //  Copyright © 2016 Cognizant. All rights reserved.
    //
#import "ABIBaseViewController.h"
@class ABISFAnnouncementDataModel;
@interface ABIAnnouncementDetailViewController : UIViewController
@property (nonatomic, strong) ABISFAnnouncementDataModel *announcementDataModel;
@property (nonatomic, strong) NSString *incentiveName;
@property (nonatomic, strong) NSString *refreshDuration;
@property (nonatomic, strong) NSString *announcementsName;
@property (nonatomic, strong) NSString *imageName;
@property (nonatomic, strong) NSString *announcementBody;
@property (nonatomic, strong) NSDate *lastModifidDate;
@property (nonatomic, strong) NSDate *createdDate;
@end
