    //
    //  ABIAnnouncementDetailViewController.m
    //  ABIHiFive
    //
    //  Created by Prsenjit Goswami on 04/07/16.
    //  Copyright © 2016 Cognizant. All rights reserved.
    //
#import "ABISFAnnouncementDataModel.h"
#import "ABIUtilHeader.h"
#import "ABIAnnouncementDetailViewController.h"
#import "Constants.h"

@interface ABIAnnouncementDetailViewController ()

@property (nonatomic, strong) UIView *backGroundview;
@property (nonatomic, strong) UITableView *tableView;
@property (nonatomic, strong) UILabel *announcementSubjectLabel;
@property (nonatomic, strong) UILabel *announcementRefreshDurationLabel;
@property (nonatomic, strong) UILabel *announcementNameLabel;
@property (nonatomic, strong) UIImageView *announcementImageView;
@property (nonatomic, strong) UITextView *announcementBodyView;
@property (nonatomic, strong) UIImageView *announcementBgImgView;
@property (nonatomic, strong) UILabel *announcementSeperatorLabel;
@property (nonatomic, strong) NSArray *constraints;
@property (nonatomic, strong) NSDictionary *views;

@end

@implementation ABIAnnouncementDetailViewController

#pragma mark - ViewController Life Cycle
- (void)viewDidLoad {
    [super viewDidLoad];
    _announcementSubjectLabel = nil;
    _announcementRefreshDurationLabel = nil;
    _announcementNameLabel = nil;
    _announcementBodyView = nil;
    _announcementImageView = nil;
    [self initialSetup];
}

- (void)viewWillAppear:(BOOL)animated {
    [super viewWillAppear:animated];
    [self refreshData];
}
- (BOOL)gestureRecognizer:(UIGestureRecognizer *)gestureRecognizer
shouldRecognizeSimultaneouslyWithGestureRecognizer:(UIGestureRecognizer *)otherGestureRecognizer {
    return NO;
}
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
}
- (void)dealloc {
    _announcementSubjectLabel = nil;
    _announcementRefreshDurationLabel = nil;
    _announcementNameLabel = nil;
    _announcementBodyView = nil;
    _announcementImageView = nil;
}

#pragma mark - Public Method
- (void)setABISFAnnouncementDataModel:(ABISFAnnouncementDataModel *)announcementDataModel {
    _announcementDataModel = announcementDataModel;
}

#pragma mark - Custom Accessor
- (UIView *)backGroundview {
    if (!_backGroundview) {
        _backGroundview = [UIView new];
        _backGroundview.translatesAutoresizingMaskIntoConstraints = NO;
        _backGroundview.layer.cornerRadius = 3.0f;
        _backGroundview.backgroundColor = [UIColor whiteColor];
    }
    return _backGroundview;
}

- (UILabel *)announcementSubjectLabel {
    if (!_announcementSubjectLabel) {
        _announcementSubjectLabel = [[UILabel alloc] init];
        _announcementSubjectLabel.translatesAutoresizingMaskIntoConstraints = NO;
        [_announcementSubjectLabel setTextColor:[UIColor lightGreyColorABI]];
        [_announcementSubjectLabel setFont:PROFILE_SUMMER_INCENTIVE_FONT_SIZE];
    }
    return _announcementSubjectLabel;
}

- (UILabel *)announcementSeperatorLabel {
    if (!_announcementSeperatorLabel) {
        _announcementSeperatorLabel = [[UILabel alloc] init];
        _announcementSeperatorLabel.translatesAutoresizingMaskIntoConstraints = NO;
        _announcementSeperatorLabel.backgroundColor = [UIColor lightGreyColorABI];
    }
    return _announcementSeperatorLabel;
}

- (UILabel *)announcementRefreshDurationLabel {
    if (!_announcementRefreshDurationLabel) {
        _announcementRefreshDurationLabel = [[UILabel alloc] init];
        _announcementRefreshDurationLabel.translatesAutoresizingMaskIntoConstraints = NO;
        [_announcementRefreshDurationLabel setTextAlignment:NSTextAlignmentRight];
        [_announcementRefreshDurationLabel setTextColor:[UIColor darkGreyColorABI]];
        [_announcementRefreshDurationLabel setFont:TIMETOGOANDDAYSREMAINING_FONT_SIZE];
    }

    return _announcementRefreshDurationLabel;
}

- (UILabel *)announcementNameLabel {
    if (!_announcementNameLabel) {
        _announcementNameLabel = [[UILabel alloc] init];
        [_announcementNameLabel setTextColor:[UIColor darkGreyColorABI]];
        [_announcementNameLabel setFont:[UIFont fontHelvetica67Condensed:14.0f]];
        _announcementNameLabel.translatesAutoresizingMaskIntoConstraints = NO;
    }
    return _announcementNameLabel;
}

- (UIImageView *)announcementImageView {
    if (!_announcementImageView) {
        _announcementImageView = [[UIImageView alloc] init];
        _announcementImageView.backgroundColor = [UIColor lightGrayColor];
        _announcementImageView.translatesAutoresizingMaskIntoConstraints = NO;
    }
    return _announcementImageView;
}

- (UITextView *)announcementBodyView {
    if (!_announcementBodyView) {
        _announcementBodyView = [[UITextView alloc] init];
        _announcementBodyView.editable = NO;
        _announcementBodyView.translatesAutoresizingMaskIntoConstraints = NO;
        [_announcementBodyView setTextColor:[UIColor darkGreyColorABI]];
        [_announcementBodyView setFont:TEXTVIEW_FONT_SIZE];
        _announcementBodyView.text = self.announcementBody;
        _announcementBodyView.editable = NO;
    }
    return _announcementBodyView;
}

- (UIImageView *)announcementBgImgView {
    if (!_announcementBgImgView) {
        _announcementBgImgView = [[UIImageView alloc] init];
        [_announcementBgImgView setBackgroundColor:[UIColor defaultPageBGColor]];
        _announcementBgImgView.translatesAutoresizingMaskIntoConstraints = NO;
        _announcementBgImgView.backgroundColor = [UIColor lightGreyColorABI];
    }
    return _announcementBgImgView;
}

- (NSDictionary *)views {

    if (!_views) {
        _views = @{
                   @"backGroundview" : self.backGroundview,
                   @"announcementSubjectLabel" : self.announcementSubjectLabel,
                   @"announcementRefreshDurationLabel" : self.announcementRefreshDurationLabel,
                   @"announcementNameLabel" : self.announcementNameLabel,
                   @"announcementImageView" : self.announcementImageView,
                   @"announcementBodyView" : self.announcementBodyView,
                   @"announcementBgImgView" : self.announcementBgImgView,
                   @"announcementSeperatorLabel" : self.announcementSeperatorLabel
                   };
    }
    return _views;
}
#pragma mark - Private Method
- (void)initialSetup {
    [self createAndAddUI];
}
- (void)createAndAddUI {
    self.view.backgroundColor = [UIColor defaultPageBGColor];

    [self.view addSubview:self.backGroundview];
    [self.backGroundview addSubview:self.announcementBgImgView];
    [self.backGroundview addSubview:self.announcementRefreshDurationLabel];
    [self.backGroundview addSubview:self.announcementNameLabel];
    [self.backGroundview addSubview:self.announcementSeperatorLabel];
    [self.backGroundview addSubview:self.announcementImageView];
    [self.backGroundview addSubview:self.announcementBodyView];
    [self addConstraints];
}
/*!
 *  Add component Constraints
 */
- (void)addConstraints {

    [self.view
     addConstraints:[NSLayoutConstraint constraintsWithVisualFormat:@"H:|-10@999-[backGroundview]-10@999-|" options:0 metrics:nil views:self.views]];
    [self.view
     addConstraints:[NSLayoutConstraint constraintsWithVisualFormat:@"V:|-10@999-[backGroundview]-0@999-|" options:0 metrics:nil views:self.views]];
    [self.backGroundview
     addConstraints:[NSLayoutConstraint constraintsWithVisualFormat:@"H:|-[announcementNameLabel]-2-[announcementRefreshDurationLabel(>=10)]-|"
                                                            options:0
                                                            metrics:nil
                                                              views:self.views]];
    [self.backGroundview
     addConstraints:[NSLayoutConstraint constraintsWithVisualFormat:@"H:|-[announcementSeperatorLabel]-|" options:0 metrics:nil views:self.views]];
    [self.backGroundview
     addConstraints:[NSLayoutConstraint constraintsWithVisualFormat:@"H:|[announcementImageView]|" options:0 metrics:nil views:self.views]];
    [self.backGroundview
     addConstraints:[NSLayoutConstraint constraintsWithVisualFormat:@"H:|-[announcementBodyView]-|" options:0 metrics:nil views:self.views]];
    [self.backGroundview addConstraintForCenterY:self.announcementRefreshDurationLabel toItem:self.announcementNameLabel];

    [self updateVerticleConstraints];
}

- (void)updateVerticleConstraints {

        // NSString *imageURLString = self.announcementDataModel.announcementImageURLString;

    if (self.backGroundview && self.constraints.count) {
        [self.backGroundview removeConstraints:self.constraints];
    }

        //    if ([NSString isNULLString:imageURLString]) {
        //        self.constraints = [NSLayoutConstraint
        //                            constraintsWithVisualFormat:
        //                            @"V:|-10-[announcementNameLabel]-10-[announcementSeperatorLabel(1)]-10-[announcementImageView(0)]-[announcementBodyView]|"
        //                            options:0
        //                            metrics:nil
        //                            views:self.views];
        //    } else {
    self.constraints = [NSLayoutConstraint
                        constraintsWithVisualFormat:
                        @"V:|-10-[announcementNameLabel]-10-[announcementSeperatorLabel(1)]-10-[announcementImageView(150)]-[announcementBodyView]|"
                        options:0
                        metrics:nil
                        views:self.views];
        //  }
    if (self.constraints.count) {
        [self.backGroundview addConstraints:self.constraints];
        [self.backGroundview layoutIfNeeded];
    }
}
/*!
 *  Refresh UI
 */
- (void)refreshData {
    self.refreshDuration = _announcementDataModel.refreshTimeInString;

    self.announcementRefreshDurationLabel.text = self.refreshDuration;
    self.announcementNameLabel.text = self.announcementDataModel.announcementName;
    NSString *imageURLString = self.announcementDataModel.announcementImageURLString;

    if (![NSString isNULLString:imageURLString]) {

        __weak typeof(self) weakSelf = self;

        [self.announcementImageView setABIImageWithURL:imageURLString
                                      placeholderImage:nil
                                            completion:^(UIImage *image) {
                                                if (image == nil)
                                                    weakSelf.announcementDataModel.announcementImageURLString = nil;
                                            }];

            //		 imageWithURLString:imageURLString
            //                                      placeholderImage:nil
            //                                            completion:^(UIImage *_Nonnull image) {
            //                                                if (image == nil)
            //                                                    weakSelf.announcementDataModel.announcementImageURLString = nil;
            //                                            }];
    }
}
@end
