    //
    //  ABIAnnouncementDetailsPageViewController.h
    //  ABIHiFive
    //
    //  Created by Prsenjit Goswami on 04/07/16.
    //  Copyright © 2016 Cognizant. All rights reserved.
    //
#import "ABIBaseViewController.h"

@interface ABIAnnouncementDetailsPageViewController : ABIBaseViewController
- (void)showAnnouncements:(NSArray *)announcements atIndex:(NSInteger)index;
@property (nonatomic, strong) UIViewController *presentedVC;

@end
