    //
    //  ABIAnnouncementDetailsPageViewController.m
    //  ABIHiFive
    //
    //  Created by Prsenjit Goswami on 04/07/16.
    //  Copyright © 2016 Cognizant. All rights reserved.
    //
#import "ABIAnnouncementDetailsPageViewController.h"
#import "ABISFAnnouncementDataModel.h"
#import "ABIAnnouncementDetailViewController.h"
#import "Constants.h"
#import "CustomTabPagerViewController.h"
#import "ABIKPIDetailViewController.h"
#import "ABIKPIDetailsPageViewController.h"

@interface ABIAnnouncementDetailsPageViewController () <CustomTabPagerDataSource, CustomTabPagerDelegate>

@property (weak, nonatomic) IBOutlet UIView *pageViewControllerContainerView;
@property (nonatomic, strong) CustomTabPagerViewController *tabPageViewController;
@property (nonatomic, strong) NSArray *announcementDetails;
@property (nonatomic, assign) NSUInteger index;

@end

@implementation ABIAnnouncementDetailsPageViewController

#pragma mark - View Controller Life Cycle
- (void)viewDidLoad {
    [super viewDidLoad];
    [self initialSetup];
}

- (void)viewWillAppear:(BOOL)animated {
    [super viewWillAppear:animated];
}

- (void)viewDidLayoutSubviews {
    [super viewDidLayoutSubviews];
    self.tabPageViewController.view.frame = self.view.bounds;
}

- (void)dealloc {

    [self cleanup];
}

#pragma mark -  Public Method
- (void)showAnnouncements:(NSArray *)announcements atIndex:(NSInteger)index {
    self.announcementDetails = announcements;
    self.index = index;
    [self.tabPageViewController selectTabbarIndex:self.index animation:YES];
}

#pragma mark -  Custom Accessor
- (CustomTabPagerViewController *)tabPageViewController {
    if (!_tabPageViewController) {
        _tabPageViewController = [CustomTabPagerViewController initialisedTabPageViewController:self];
        _tabPageViewController.view.translatesAutoresizingMaskIntoConstraints = NO;
    }
    return _tabPageViewController;
}

#pragma mark -  Private Method

/**
 * InitialSetup
 */
- (void)initialSetup {
    [self initialUISetup];
}

/**
 * UI related Like- Set Navigation Title, UI decoration, UI Creation, like Set Font, Text Color, Create UI etc...
 */
- (void)initialUISetup {

        // Set Navigation Page Title
    [self setNavigationPageTitle];

        // Create UI Elment on run time
    [self createAndAddUI];
}

/**
 * Set Navigation Page Title
 */
- (void)setNavigationPageTitle {
    self.title = [NSString announcementsPageTitle];
}

- (void)createAndAddTabPageViewController {

    [self addChildViewController:self.tabPageViewController];
    [self.pageViewControllerContainerView addSubview:self.tabPageViewController.view];
    [self didMoveToParentViewController:self.tabPageViewController];
    self.tabPageViewController.view.frame = self.view.bounds;
    [self.tabPageViewController reloadData];
    [self.tabPageViewController selectTabbarIndex:self.index animation:YES];
}

/**
 * Create UI Element
 */
- (void)createAndAddUI {

    [self createAndAddTabPageViewController];
    [self addConstrains];
}

/**
 * Add Constrains
 */
- (void)addConstrains {
    NSDictionary *views = @{ @"tabPageViewController" : self.tabPageViewController.view };
    [self.pageViewControllerContainerView
     addConstraints:[NSLayoutConstraint constraintsWithVisualFormat:@"H:|[tabPageViewController]|" options:0 metrics:nil views:views]];
    [self.pageViewControllerContainerView
     addConstraints:[NSLayoutConstraint constraintsWithVisualFormat:@"V:|[tabPageViewController]|" options:0 metrics:nil views:views]];
}

/**
 * Release Memory
 */
- (void)cleanup {

    _tabPageViewController = nil;
}

- (UIViewController *)viewControllerForIndex:(NSInteger)index {
    ABIAnnouncementDetailViewController *customViewConroller = [[ABIAnnouncementDetailViewController alloc] init];
    ABISFAnnouncementDataModel *datamodel = [NSArray objectFromArray:self.announcementDetails atIndex:index];
    if (datamodel) {
        customViewConroller.announcementDataModel = datamodel;
        customViewConroller.refreshDuration = datamodel.minsText;
        customViewConroller.announcementsName = datamodel.daysText;
        customViewConroller.announcementBody = datamodel.announcementBody;
        customViewConroller.lastModifidDate = datamodel.lastModifiedDate;
        customViewConroller.createdDate = datamodel.createdDate; // [dateFormatter dateFromString:datamodel.createdDateString];
    }
    return customViewConroller;
}

#pragma mark - Data Source / Delegate
#pragma mark - Tab Pager Data Source
- (NSInteger)numberOfViewControllers {
    return [self.announcementDetails count];
}
- (UIColor *)tabColor {
    return [UIColor cyanColorABI];
}
- (UIColor *)tabBackgroundColor {
    return [UIColor defaultABIBlueColor];
}
- (UIFont *)titleFont {
    return [UIFont fontHelvetica57Condensed:15.0f];
}
- (UIColor *)titleColor {
    return [UIColor whiteColor];
}
- (UIColor *)deselectedTitleColor {
    return [UIColor cyanColorABI];
}

- (NSString *)titleForTabAtIndex:(NSInteger)index {
    return STATIC_TEXT_EMPTY_STRING;
}
- (CGFloat)tabHeight {
    return 0.0f;
}
#pragma mark - Tab Pager Delegate
- (void)tabPager:(CustomTabPagerViewController *)tabPager didTransitionToTabAtIndex:(NSInteger)index {
    self.index = index;
}

@end
