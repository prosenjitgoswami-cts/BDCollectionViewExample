    //
    //  AnnouncementsPopoverProtocol.h
    //  ABIHiFive
    //
    //  Created by Prsenjit Goswami on 04/07/16.
    //  Copyright © 2016 Cognizant. All rights reserved.
    //
#import "Constants.h"
#import <Foundation/Foundation.h>
@class ABISFAnnouncementDataModel;
@protocol AnnouncementsPopoverProtocol <NSObject>
@end
