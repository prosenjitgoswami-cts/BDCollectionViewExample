    //
    //  AssessmentsViewController.h
    //  HelloObjC
    //
    //  Created by KoliMac1 on 08/07/16.
    //  Copyright © 2016 KoliMac1. All rights reserved.
    //
#import "ABISFAnnouncementDataModel.h"
#import <UIKit/UIKit.h>
typedef void (^Comlition)(void);
@protocol AnnouncementsDataModelsDelegate <NSObject>
- (void)didTapOnAssessment:(NSArray *)selectedAssessment atIndex:(NSInteger)index;
@end
@interface ABIAnnouncementsPopoverViewController : UIViewController
@property (nonatomic, weak) id<AnnouncementsDataModelsDelegate> delegate;
@property (strong, nonatomic) NSArray<ABISFAnnouncementDataModel *> *announcements;
- (void)toggolVisibility;
- (void)show;
- (void)hide;
@end
