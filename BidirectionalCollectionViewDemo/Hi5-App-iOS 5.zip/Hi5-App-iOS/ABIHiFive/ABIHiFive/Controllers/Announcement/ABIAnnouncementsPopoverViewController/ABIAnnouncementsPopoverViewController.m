    //
    //  AssessmentsViewController.m
    //  HelloObjC
    //
    //  Created by KoliMac1 on 08/07/16.
    //  Copyright © 2016 KoliMac1. All rights reserved.
    //
#import "ABIAnnouncementsPopoverViewController.h"
#import "ABIAnnouncementsPopoverTableViewCell.h"
#import "ABISFDataFetcherService.h"
#import "Constants.h"

static CGFloat kCellHeight = 85.0f;
static CGFloat kMaxRowVisible = 3;

static CGFloat kIntervalTime = 0.3f;
@interface ABIAnnouncementsPopoverViewController () <UITableViewDelegate, UITableViewDataSource, UIGestureRecognizerDelegate>
@property (strong, nonatomic) UIView *customBackgroundView;
@property (strong, nonatomic) UILabel *headerLabel;
@property (strong, nonatomic) UITableView *announcementsTableView;
@property (strong, nonatomic) UITapGestureRecognizer *tapGesture;
@property (strong, nonatomic) UIWindow *window;
@property (strong, nonatomic) AppDelegate *appDelegate;
@property (strong, nonatomic) NSArray *bgHeightconstraints;
@property (strong, nonatomic) NSDictionary *views;
@end

@implementation ABIAnnouncementsPopoverViewController

#pragma mark -  ViewController Life Cycle
- (void)loadView {
    [super loadView];
    UIView *contentView = [[UIView alloc] initWithFrame:[UIScreen mainScreen].bounds];
    contentView.backgroundColor = [[UIColor blackColor] colorWithAlphaComponent:0.5];
    self.view = contentView;
}
- (void)viewDidLoad {
    [super viewDidLoad];
    [self configureUI];
}
- (void)dealloc {
    _customBackgroundView = nil;
    _headerLabel = nil;
    _announcementsTableView = nil;
    _tapGesture = nil;
    _window = nil;
    _appDelegate = nil;
    _announcements = nil;
}

#pragma mark -  Public Method
- (void)show {
    [self allComponetHidden:NO];
}
- (void)hide {
    [self allComponetHidden:YES];
}
- (void)showWithCompletion:(Comlition)comlition {
    if (!_window) {
        CGRect syncWindowFrame = [UIScreen mainScreen].bounds; //[UIScreen mainScreen].applicationFrame;
        _window = [[UIWindow alloc] initWithFrame:syncWindowFrame];
        _window.backgroundColor = [[UIColor blackColor] colorWithAlphaComponent:0.3];
    }
    _window.windowLevel = UIWindowLevelAlert;
    if (!_window.rootViewController)
        _window.rootViewController = self;
    [_window makeKeyAndVisible];
    [UIView animateWithDuration:kIntervalTime
                     animations:^{ _window.alpha = 1.0; }
                     completion:^(BOOL finished) {
                         if (comlition)
                             comlition();
                     }];
}
- (void)hideWithCompletion:(Comlition)comlition {
    _window.windowLevel = 0;
    _window.alpha = 1.0;
    [UIView animateWithDuration:kIntervalTime
                     animations:^{
                         _window.alpha = 0.0;
                         [_window resignKeyWindow];
                         [self.appDelegate.window makeKeyAndVisible];
                     }
                     completion:^(BOOL finished) {
                         if (comlition)
                             comlition();
                     }];
}
- (void)toggolVisibility {
    if (!self.window.alpha)
        [self showWithCompletion:nil];
    else
        [self hideWithCompletion:nil];
}

#pragma mark -  Private Method
- (void)allComponetHidden:(BOOL)isHidden {
    self.customBackgroundView.hidden = isHidden;
    self.headerLabel.hidden = isHidden;
    self.announcementsTableView.hidden = isHidden;
}
/*!
 *  Create UI with Component
 */
- (void)configureUI {
    [self.view addSubview:self.customBackgroundView];
    [self.customBackgroundView addSubview:self.headerLabel];
    [self.customBackgroundView addSubview:self.announcementsTableView];
    [self.view addGestureRecognizer:self.tapGesture];
    [self addContrains];
    self.customBackgroundView.alpha = 0.0;
}
/*!
 *  Add configure UI with Component
 */

- (void)updatebhHeightConstraint {

    if (self.bgHeightconstraints.count) {

        [self.view removeConstraints:self.bgHeightconstraints];
        self.bgHeightconstraints = nil;
    }
    CGFloat cellHeight = kCellHeight;
    cellHeight = cellHeight * self.announcements.count;
    cellHeight = MIN(cellHeight * kMaxRowVisible, cellHeight);
    cellHeight = MAX(kCellHeight, cellHeight);

    NSDictionary *metrics = @{ @"tableViewHeight" : @(cellHeight + 55) };

    self.bgHeightconstraints =
    [NSLayoutConstraint constraintsWithVisualFormat:@"V:[customBackgroundView(tableViewHeight)]" options:0 metrics:metrics views:self.views];
        // CustomBackgroundView - Center x, center y to view. width is 85% of view width.
        //    [self.view addConstraintsWithVisualFormat:@"V:[customBackgroundView(tableViewHeight)]" options:0 metrics:metrics views:self.views];
    [self.view addConstraints:self.bgHeightconstraints];
}

- (void)addContrains {
    [self updatebhHeightConstraint];
    [self.view addConstraints:self.bgHeightconstraints];
    [self.customBackgroundView widthMultiplyBy:0.85 toParent:self.view];
    [self.customBackgroundView centerXToParent:self.view];
    [self.customBackgroundView centerYToParent:self.view];

    [self.customBackgroundView addConstraintsWithVisualFormat:@"H:|[headerLabel]|" options:0 metrics:nil views:self.views];
    [self.customBackgroundView addConstraint:[NSLayoutConstraint sameWidth:self.announcementsTableView toItem:self.headerLabel]];
    [self.customBackgroundView addConstraint:[NSLayoutConstraint horizontallyCenter:self.announcementsTableView toItem:self.headerLabel]];
    [self.customBackgroundView addConstraintsWithVisualFormat:@"V:|[headerLabel(44.0)][announcementsTableView]|"
                                                      options:0
                                                      metrics:nil
                                                        views:self.views];
}

#pragma mark - Custom Accessors
- (NSDictionary *)views {
    if (!_views) {
        _views = @{
                   @"customBackgroundView" : self.customBackgroundView,
                   @"announcementsTableView" : self.announcementsTableView,
                   @"headerLabel" : self.headerLabel,
                   };
    }
    return _views;
}
- (AppDelegate *)appDelegate {
    if (!_appDelegate)
        _appDelegate = [[UIApplication sharedApplication] delegate];
    return _appDelegate;
}
- (UIView *)customBackgroundView {
    if (!_customBackgroundView) {
        _customBackgroundView = [UIView new];
        _customBackgroundView.translatesAutoresizingMaskIntoConstraints = NO;
        _customBackgroundView.layer.cornerRadius = 5.0;
        _customBackgroundView.clipsToBounds = YES;
    }
    return _customBackgroundView;
}
- (UITableView *)announcementsTableView {
    if (!_announcementsTableView) {
        _announcementsTableView = [[UITableView alloc] init];
        _announcementsTableView.delegate = self;
        _announcementsTableView.dataSource = self;
        _announcementsTableView.estimatedRowHeight = 150;
        _announcementsTableView.scrollEnabled = NO;
        _announcementsTableView.rowHeight = UITableViewAutomaticDimension;
        _announcementsTableView.separatorStyle = UITableViewCellSeparatorStyleSingleLine;
        _announcementsTableView.translatesAutoresizingMaskIntoConstraints = NO;
    }
    return _announcementsTableView;
}
- (UILabel *)headerLabel {
    if (!_headerLabel) {
        _headerLabel = [UILabel new];
        _headerLabel.translatesAutoresizingMaskIntoConstraints = NO;
        _headerLabel.font = ANNOUNCEMENT_TABLE_HEADER_TITLE_FONT;
        _headerLabel.backgroundColor = ANNOUNCEMENT_TABLE_HEADER_TITLE_COLOR;
        _headerLabel.textAlignment = NSTextAlignmentCenter;
        _headerLabel.text = PAGE_TITLE_ANNOUNCEMENTS_HEADER;
    }
    return _headerLabel;
}
- (UITapGestureRecognizer *)tapGesture {
    if (!_tapGesture) {
        _tapGesture = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(gestureHandler)];
        _tapGesture.numberOfTapsRequired = 1;
        _tapGesture.numberOfTouchesRequired = 1;
        _tapGesture.delegate = self;
    }
    return _tapGesture;
}
- (void)setAnnouncements:(NSArray<ABISFAnnouncementDataModel *> *)announcements {
    _announcements = announcements;

    if (_announcements.count) {

        [self.announcementsTableView reloadData];

    } else {
        UIView *noDataDisplayView = [UIView noDataDisplayViewWithDescriptionText:STATIC_TEXT_NO_ANNOUNCEMENTS textFont:nil textColor:nil];
        [_customBackgroundView addSubview:noDataDisplayView];

        [noDataDisplayView addContraintsWithParentView:_customBackgroundView insets:UIEdgeInsetsMake(44, 0, 0, 0)];
    }
    [self updatebhHeightConstraint];
    [UIView animateWithDuration:0.3 animations:^{ self.customBackgroundView.alpha = 1.0; }];
}

#pragma mark -  IB Event
- (void)gestureHandler {
    [self hideWithCompletion:nil];
}

#pragma mark -
#pragma mark UITableViewDataSource
- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
    return 1;
}
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    return self.announcements.count;
}
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    static NSString *cellIdentifier = @"CellIdentifier";
    ABIAnnouncementsPopoverTableViewCell *cell = (ABIAnnouncementsPopoverTableViewCell *)[tableView dequeueReusableCellWithIdentifier:cellIdentifier];
    if (!cell) {
        cell = [[ABIAnnouncementsPopoverTableViewCell alloc] init];
    }
    ABISFAnnouncementDataModel *datamodel = [NSArray objectFromArray:self.announcements atIndex:indexPath.row];
    [cell updateCellWithABISFAnnouncementDataModel:datamodel];
    return cell;
}
- (CGFloat)tableView:(UITableView *)tableView heightForFooterInSection:(NSInteger)section {
    return 5.0f;
}
- (UIView *)tableView:(UITableView *)tableView viewForFooterInSection:(NSInteger)section {
    return [UIView new];
}

#pragma mark -
#pragma mark UITableViewDelegate
- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath {
    return kCellHeight;
}
- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
    __weak typeof(self) weakSelf = self;
    [weakSelf hideWithCompletion:nil];
    [NSObject performInMainThreadAfterDelay:0.3
                                 completion:^{
                                     if (weakSelf.delegate && [weakSelf.delegate respondsToSelector:@selector(didTapOnAssessment:atIndex:)]) {
                                         [weakSelf.delegate didTapOnAssessment:weakSelf.announcements atIndex:indexPath.row];
                                     }
                                 }];
}
#pragma mark UIGestureRecognizer Delegate
- (BOOL)gestureRecognizer:(UIGestureRecognizer *)gestureRecognizer shouldReceiveTouch:(UITouch *)touch {
    if ([touch.view isDescendantOfView:self.announcementsTableView]) {
        return NO;
    }
    return YES;
}
@end
