    //
    //  DashBoardViewController.m
    //  ABIHiFive
    //
    //  Created by Prsenjit Goswami on 10/06/16.
    //  Copyright © 2016 Cognizant. All rights reserved.
    //
#import "ABIOnBoardingViewController.h"
#import "ABIOnBoardingModel.h"
#import "Constants.h"
#import "LoginViewController.h"
#import "ABIOnBoardingInternalPageViewController.h"
#import "ABIOnBoardingViewControllerPresenter.h"
#import "Reachability.h"
@interface ABIOnBoardingViewController () <UIPageViewControllerDataSource>
@property (weak, nonatomic) IBOutlet UIView *pageControllerContainerView;
@property (weak, nonatomic) IBOutlet UIButton *signInButton;
@property (strong, nonatomic) NSArray *dashBoardDataSource;
@property (strong, nonatomic) id<ABIOnBoardingViewControllerProtocol> presenter;
@end
@implementation ABIOnBoardingViewController
#pragma mark - View Controller Life Cycle
- (void)viewDidLoad {
    [super viewDidLoad];
    [self configureUI];
}
- (void)dealloc {
    _presenter = nil;
    _dashBoardDataSource = nil;
}
#pragma mark - IBAction
- (IBAction)clickedSignIn:(id)sender {
    if ([AppDelegate isOffline]) {
        [UIViewController alertInNoNetworkConnection:self clickedOkButton:NULL];
    } else {
        [self performSegueWithIdentifier:SEGUE_ID_ONBOARDING_TO_LOGIN sender:self];
    }
}
#pragma mark - Private Method
- (id<ABIOnBoardingViewControllerProtocol>)presenter {
    if (!_presenter) {
        _presenter = [ABIOnBoardingViewControllerPresenter new];
    }
    return _presenter;
}
- (NSArray *)dashBoardDataSource {
    if (!_dashBoardDataSource) {
        _dashBoardDataSource = [[self presenter] onBordingPages];
    }
    return _dashBoardDataSource;
}
/*!
 *  Create UI with Component
 */
- (void)configureUI {
    self.navigationController.navigationBarHidden = YES;
    self.signInButton.layer.cornerRadius = 2;
    self.signInButton.titleLabel.font = [UIFont fontHelvetica57Condensed:25.0f];
    self.view.backgroundColor = [UIColor blueColorABI];
    self.pageControllerContainerView.backgroundColor = [UIColor blueColorABI];
    self.signInButton.backgroundColor = [UIColor lightBlueColorABI];
    [self.pageControllerContainerView addSubview:self.pageViewController.view];
    [self addConstraints];
}
/*!
 * Add Constraint for UI with Component
 */
- (void)addConstraints {
    if (!self.pageViewController.view)
        return;
    NSDictionary *views = @{ @"pageViewController" : self.pageViewController.view };
    [self.pageControllerContainerView
     addConstraints:[NSLayoutConstraint constraintsWithVisualFormat:@"H:|[pageViewController]|" options:0 metrics:nil views:views]];
    [self.pageControllerContainerView
     addConstraints:[NSLayoutConstraint constraintsWithVisualFormat:@"V:|[pageViewController]-10-|" options:0 metrics:nil views:views]];
}
- (ABIOnBoardingInternalPageViewController *)viewControllerAtIndex:(NSUInteger)index {
    if (([self.dashBoardDataSource count] == 0) || (index >= [self.dashBoardDataSource count])) {
        return nil;
    }
    ABIOnBoardingInternalPageViewController *internalViewController = [NSArray objectFromArray:self.dashBoardDataSource atIndex:index];
    return internalViewController;
    return nil;
}
- (UIPageViewController *)pageViewController {
    if (!_pageViewController) {
        _pageViewController = [self.storyboard instantiateViewControllerWithIdentifier:kStoryBoardIDPageViewController];
        if (_pageViewController) {
            _pageViewController.dataSource = self;
            ABIOnBoardingInternalPageViewController *startingViewController = [self viewControllerAtIndex:0];
            NSArray *viewControllers = @[ startingViewController ];
            [_pageViewController setViewControllers:viewControllers direction:UIPageViewControllerNavigationDirectionForward animated:YES completion:NULL];
        }
        [_pageViewController.view setTranslatesAutoresizingMaskIntoConstraints:NO];
        _pageViewController.doubleSided = YES;
    }
    return _pageViewController;
}
#pragma mark - UIPageViewController Delegate
- (UIViewController *)pageViewController:(UIPageViewController *)pageViewController
      viewControllerBeforeViewController:(UIViewController *)viewController {
    NSUInteger index = ((ABIOnBoardingInternalPageViewController *)viewController).pageIndex;
    if ((index == 0) || (index == NSNotFound)) {
        return nil;
    }
    index--;
    return [self viewControllerAtIndex:index];
}
- (UIViewController *)pageViewController:(UIPageViewController *)pageViewController
       viewControllerAfterViewController:(UIViewController *)viewController {
    NSUInteger index = ((ABIOnBoardingInternalPageViewController *)viewController).pageIndex;
    if (index == NSNotFound) {
        return nil;
    }
    index++;
    return [self viewControllerAtIndex:index];
}
- (NSInteger)presentationCountForPageViewController:(UIPageViewController *)pageViewController {
    return [self.dashBoardDataSource count];
}
- (NSInteger)presentationIndexForPageViewController:(UIPageViewController *)pageViewController {
    return 0;
}
@end
