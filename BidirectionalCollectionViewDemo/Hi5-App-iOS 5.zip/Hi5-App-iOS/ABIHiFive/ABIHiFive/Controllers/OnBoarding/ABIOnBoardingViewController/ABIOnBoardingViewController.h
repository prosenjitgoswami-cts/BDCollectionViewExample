    //
    //  DashBoardViewController.h
    //  ABIHiFive
    //
    //  Created by Prsenjit Goswami on 10/06/16.
    //  Copyright © 2016 Cognizant. All rights reserved.
    //
#import "ABIBaseViewController.h"
#import <UIKit/UIKit.h>
@interface ABIOnBoardingViewController : UIViewController
@property (nonatomic, strong) UIPageViewController *pageViewController;
@end
