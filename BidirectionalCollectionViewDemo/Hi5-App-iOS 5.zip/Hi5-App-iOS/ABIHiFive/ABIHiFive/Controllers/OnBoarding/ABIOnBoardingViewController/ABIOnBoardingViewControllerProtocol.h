    //
    //  ABIOnBoardingViewControllerProtocol.h
    //  ABIHiFive
    //
    //  Created by Prsenjit Goswami on 10/07/16.
    //  Copyright © 2016 Cognizant. All rights reserved.
    //
#import <Foundation/Foundation.h>
@class ABIOnBoardingInternalPageViewController;
@protocol ABIOnBoardingViewControllerProtocol <NSObject>
- (NSArray<ABIOnBoardingInternalPageViewController *> *)onBordingPages;
@end
