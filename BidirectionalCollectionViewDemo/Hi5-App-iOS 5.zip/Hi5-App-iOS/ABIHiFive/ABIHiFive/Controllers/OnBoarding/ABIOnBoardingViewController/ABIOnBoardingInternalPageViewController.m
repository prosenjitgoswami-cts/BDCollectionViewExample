    //
    //  ABIOnBoardingInternalPageViewController.m
    //  ABIPOC
    //
    //  Created by Prsenjit Goswami on 6/10/16.
    //
#import "ABIOnBoardingInternalPageViewController.h"
#import "Constants.h"
@interface ABIOnBoardingInternalPageViewController ()
@property (weak, nonatomic) IBOutlet UILabel *screenName;
@property (weak, nonatomic) IBOutlet UIImageView *screenImage;
@property (weak, nonatomic) IBOutlet UILabel *screenDetails;
@end
@implementation ABIOnBoardingInternalPageViewController
- (void)viewDidLoad {
    [super viewDidLoad];
    self.screenDetails.lineBreakMode = NSLineBreakByWordWrapping;
    self.screenDetails.numberOfLines = 2;
    self.screenName.text = _titleText;
    self.screenName.font = [UIFont fontHelvetica57Condensed:30.0f];
    self.screenName.textColor = [UIColor whiteColor];
    self.screenDetails.text = _pageDescription;
    self.screenDetails.font = [UIFont fontHelvetica57Condensed:20.0f];
    self.screenDetails.textColor = [UIColor whiteColor];
    self.screenImage.image = [UIImage imageNamed:_imageFile];
}
- (void)viewDidAppear:(BOOL)animated {
    [super viewDidAppear:animated];
}
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
        // Dispose of any resources that can be recreated.
}

#pragma mark -  Public method
- (void)setTitleText:(NSString *)titleText {
    _titleText = titleText;
    if (![NSString isNULLString:_titleText]) {
        self.screenName.text = _titleText;
    }
}
- (void)setPageDescription:(NSString *)pageDescription {
    _pageDescription = pageDescription;
    if (![NSString isNULLString:_pageDescription]) {
        self.screenDetails.text = _pageDescription;
    }
}
- (void)setImageFile:(NSString *)imageFile {
    _imageFile = imageFile;
    if (![NSString isNULLString:_imageFile]) {
        _screenImage.image = [UIImage imageNamed:_imageFile];
    }
}
@end
