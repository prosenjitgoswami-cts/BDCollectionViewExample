    //
    //  ABIOnBoardingViewControllerPresenter.m
    //  ABIHiFive
    //
    //  Created by Prsenjit Goswami on 10/07/16.
    //  Copyright © 2016 Cognizant. All rights reserved.
    //
#import "ABIOnBoardingViewControllerPresenter.h"
#import "ABIOnBoardingModel.h"
#import "Constants.h"
#import "ABIOnBoardingInternalPageViewController.h"
@implementation ABIOnBoardingViewControllerPresenter
- (NSArray<ABIOnBoardingModel *> *)onborbdingDataSource {
    NSString *path = [[NSBundle mainBundle] pathForResource:OnBoarding ofType:plist];
    NSArray *plistDatas = [[NSArray alloc] initWithContentsOfFile:path];
    NSMutableArray *results = [NSMutableArray array];
    for (NSDictionary *dict in plistDatas) {
        ABIOnBoardingModel *onBoardingModel = [ABIOnBoardingModel new];
        onBoardingModel.heading = dict[heading1];
        onBoardingModel.imageName = dict[imageName1];
        onBoardingModel.pageDescription = dict[pageDescription1];
        [results addObject:onBoardingModel];
    }
    return results;
}
- (NSArray<ABIOnBoardingInternalPageViewController *> *)onBordingPages {
    NSArray *pages = [self onborbdingDataSource];
    NSUInteger idx = 0;
    NSMutableArray *results = [NSMutableArray array];
    for (ABIOnBoardingModel *onBoardingModel in pages) {
        ABIOnBoardingInternalPageViewController *internalViewController =
        (ABIOnBoardingInternalPageViewController *)[UIViewController instantiateViewControllerWithIdentifier:kStoryBoardIDInternalViewController];
        internalViewController.imageFile = onBoardingModel.imageName;
        internalViewController.titleText = onBoardingModel.heading;
        internalViewController.pageIndex = idx;
        internalViewController.pageDescription = onBoardingModel.pageDescription;
        [results addObject:internalViewController];
        idx += 1;
    }
    return results;
}
@end
