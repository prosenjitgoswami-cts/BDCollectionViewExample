    //
    //  ABIProfilePageViewController.m
    //  ABIHiFive
    //
    //  Created by Prsenjit Goswami on 27/06/16.
    //  Copyright © 2016 Cognizant. All rights reserved.
    //
#import "ABIProfilePageViewController.h"
#import "ABICustomBadgeScrollView.h"
#import "ABISFDataFetcherService.h"
#import "ABISFEarnBadgesDataModel.h"
#import "ABISFIncentiveDataModel.h"
#import "ABISFRosterDataModel.h"
#import "ABIBadgeDetailsViewController.h"
#import "ABIChatterNewPostViewController.h"
#import "Constants.h"
#import "CustomBadge.h"
#import "CustomTabPagerViewController.h"
#import "ABIReporteeListViewController.h"
#import "ABIProfileMyIncentivesViewController.h"
#import "ABIProfilePageViewControllerPresenter.h"

@interface ABIProfilePageViewController () <CustomTabPagerDataSource, CustomTabPagerDelegate, ABICustomBadgeScrollViewProtocol>
@property (weak, nonatomic) IBOutlet UILabel *districtLabel;
@property (weak, nonatomic) IBOutlet UIImageView *circleLogoImgView;
@property (weak, nonatomic) IBOutlet UIImageView *userImageView;
@property (weak, nonatomic) IBOutlet UILabel *userNameLabel;
@property (weak, nonatomic) IBOutlet UIView *profileDetailsView;
@property (weak, nonatomic) IBOutlet UIView *tabPagerVCContainerView;
@property (weak, nonatomic) IBOutlet UIButton *chatterButton;
@property (weak, nonatomic) IBOutlet ABICustomBadgeScrollView *ABICustomBadgeScrollView;
@property (nonnull, strong, nonatomic) NSString *sfUserID;
@property (assign, nonatomic) NSInteger selectedIndex;
@property (strong, nonatomic) CustomTabPagerViewController *tabPageViewController;
@property (strong, nonatomic) id<ABIProfilePageViewControllerProtocol> presenter;
@property (strong, nonatomic) NSArray<ABISFBadgesDetailsNameWiseDataModel *> *rosterEarnBadges;
@property (strong, nonatomic) NSArray *rosters;
@property (assign, nonatomic) RosterRole rosterRole;
@end
@implementation ABIProfilePageViewController

#pragma mark -  View Controller Life Cycle
- (void)viewDidLoad {
    [super viewDidLoad];
    self.title = STATIC_TEXT_EMPTY_STRING;
    [self initialSetup];
}
- (void)viewWillAppear:(BOOL)animated {
    [super viewWillAppear:animated];
}
- (void)viewDidAppear:(BOOL)animated {
    [super viewDidAppear:animated];
    [self restorePageOnAppearPage];
}
- (void)dealloc {
    [self cleanup];
}

#pragma mark -  Public Method
- (void)profileForRosterWithUserID:(nonnull NSString *)sfUserID andPageFlow:(PageFlow)pageFlow {
    self.sfUserID = sfUserID;
    self.pageFlow = pageFlow;
}

#pragma mark - Custom Accessors
- (nonnull id<ABIProfilePageViewControllerProtocol>)presenter {
    if (!_presenter) {
        _presenter = [ABIProfilePageViewControllerPresenter new];
    }
    return _presenter;
}
- (nonnull CustomTabPagerViewController *)tabPageViewController {
    if (!_tabPageViewController) {
        _tabPageViewController = [CustomTabPagerViewController initialisedTabPageViewController:self];
    }
    return _tabPageViewController;
}

#pragma mark -  Private Method
- (void)initialSetup {
    [self resetAll];
    [self initialUISetup];
    [self setNavigationPageTitle];
    [self fetchAndUpdateUI];
}

#pragma mark -  Fetch Service - Update Data Source - Update UI
/*!
 *  Fetch data from Salesforce
 */
- (void)fetchAndUpdateUI {
    if ([AppDelegate isOffline]) {
        [UIViewController alertInNoNetworkConnection:self clickedOkButton:NULL];
    } else {
        [CustomLoaderManager showLoader];

            // Fetch Roster details
        __weak typeof(self) weakSelf = self;
        [self.presenter fetchRosterDetailsThenFetchBadgesDetailsAndUpdateUI:self.sfUserID

                                                            extraDependency:nil
                                                   rosterDatailsfailedBlock:^(NSError *error, NSDictionary *extraInfo) {
                                                       [CustomLoaderManager hideLoader];
                                                       [self updateRosterDataSourceAndUI:nil];
                                                       [weakSelf updateBadgeDetailsDatasourceAndUI:nil];

                                                   }
                                                    rosterDatailsCompletion:^(NSArray<ABISFRosterDataModel *> *results, NSDictionary *extraInfo) {
                                                        [self updateRosterDataSourceAndUI:[results mutableCopy]];
                                                    }
                                                   badgesDatailsfailedBlock:^(NSError *error, NSDictionary *extraInfo) {
                                                       [CustomLoaderManager hideLoader];
                                                       [weakSelf updateBadgeDetailsDatasourceAndUI:nil];
                                                   }
                                                    badgesDetailsCompletion:^(NSArray<ABISFEarnBadgesDataModel *> *results, NSDictionary *extraInfo) {
                                                        [weakSelf updateBadgeDetailsDatasourceAndUI:[results mutableCopy]];
                                                    }];
    }
}
- (void)updateRosterDataSourceAndUI:(nullable NSMutableArray<ABISFRosterDataModel *> *)results {
    [self updateRosterDatasource:results];
    [self updateRosterUI];
    [self setNavigationPageTitle];
    [self setupConditionalUIComponent];
}
- (void)updateRosterDatasource:(nullable NSMutableArray<ABISFRosterDataModel *> *)results {
        // Main Entry Point
    if (results.count) {
        self.rosterDataModel = [NSArray objectFromArray:results atIndex:0];
    }
    self.rosterRole = self.rosterDataModel.rosterRole;
    if (self.pageFlow == PageFlowUnknown) {
        self.pageFlow = [ABISFRosterDataModel pageFlow:self.rosterDataModel.roleInString];
    }
    [AppDelegate setGlobalCurrentPageFlow:self.pageFlow];
}
- (void)updateBadgeDetailsDatasourceAndUI:(nullable NSMutableArray<ABISFEarnBadgesDataModel *> *)results {
    self.rosterEarnBadges = [ABISFEarnBadgesDataModel groupedBadgesByPriority:results];
    [self updateBadgeDetailsUI];
}
- (void)updateRosterUI {
    [self allUICoponeneHidden:NO];
    self.districtLabel.text = self.rosterDataModel.regionName;
    [self showUserName];
    [self.tabPageViewController reloadData];
    if (self.tabPageViewController) {
        [self.tabPageViewController repositionTab:self.selectedIndex];
    }
    NSString *rosterImageURL = self.rosterDataModel.rosterImageURLString;
    self.userImageView.hidden = NO;
    [self.userImageView setABIUserImageWithURL:rosterImageURL];
}
- (void)updateBadgeDetailsUI {
    [self.ABICustomBadgeScrollView setRosterEarnBadges:self.rosterEarnBadges];
    if (self.rosterEarnBadges.count) {
        self.ABICustomBadgeScrollView.delegate = self;
    }
}
#pragma mark
#pragma mark UI
- (void)initialUISetup {
    [self createAndAddUI];
    [self setupConditionalUIComponent];
    [self customUIDecoration];
    [self allUICoponeneHidden:YES];
    [self updateAnnouncementsBell:NULL];
}
- (void)createAndAddUI {
    [self addPagerViewContriller];
}
/*!
 *  Add Pager View Controller
 */
- (void)addPagerViewContriller {
    [self addChildViewController:self.tabPageViewController];
    [self.tabPagerVCContainerView addSubview:self.tabPageViewController.view];
    [self didMoveToParentViewController:self.tabPageViewController];
    [self addConstrains];
}
/*!
 *  Add Component Constrains
 */
- (void)addConstrains {
    NSDictionary *views = @{ @"tabPageViewController" : self.tabPageViewController.view };
    [self.tabPagerVCContainerView
     addConstraints:[NSLayoutConstraint constraintsWithVisualFormat:@"H:|[tabPageViewController]|" options:0 metrics:nil views:views]];
    [self.tabPagerVCContainerView
     addConstraints:[NSLayoutConstraint constraintsWithVisualFormat:@"V:|[tabPageViewController]|" options:0 metrics:nil views:views]];
}
- (void)setNavigationPageTitle {
    self.title = [NSString profilePageTitle];
}
- (void)setupConditionalUIComponent {
    BOOL isChatterVisible = ([AppDelegate globalCurrentPageFlow] == PageFlowAsMyDMAsSDLogin);
    self.chatterButton.hidden = !isChatterVisible;
    self.chatterButton.enabled = ![NSString isNULLString:self.rosterDataModel.rosterUserID];
}
- (void)customUIDecoration {
    self.chatterButton.imageEdgeInsets = UIEdgeInsetsMake(10, 5, 0, 0);
    self.userImageView.layer.cornerRadius = self.userImageView.frame.size.width / 2;
    self.circleLogoImgView.layer.cornerRadius = self.circleLogoImgView.frame.size.width / 2;
    self.circleLogoImgView.clipsToBounds = YES;
    self.userImageView.clipsToBounds = YES;
    self.circleLogoImgView.image = [UIImage imageABIOuterCircle];
    self.userNameLabel.textColor = [UIColor defaultTextDarkColor];
    self.districtLabel.textColor = [UIColor defaultTextDarkColor];
    [self.districtLabel setFont:[UIFont fontHelvetica57Condensed:12.0f]];
}
- (void)allUICoponeneHidden:(BOOL)isHidden {
    self.districtLabel.hidden = isHidden;
    self.circleLogoImgView.hidden = isHidden;
    self.tabPageViewController.view.hidden = isHidden;
    self.userNameLabel.hidden = isHidden;
    self.userImageView.hidden = isHidden;
}
#pragma mark
- (void)showUserName {
    NSString *username = self.rosterDataModel.rosterNameText;
    self.userNameLabel.text = username.length ? username : STATIC_TEXT_EMPTY_STRING;
    self.userNameLabel.font = PROFILE_USER_NAME_FONT_SIZE;
}
- (void)navigateToABIBadgeDetailsViewController {
    [self performSegueWithIdentifier:SEGUE_ID_PushToABIBadgeDetailsViewController sender:nil];
}
#pragma mark
- (void)restorePageOnAppearPage {
    if (self.tabPageViewController) {
        [self.tabPageViewController repositionTab:self.selectedIndex];
    }
}
- (void)resetAll {
    self.selectedIndex = 0;
    self.rosterEarnBadges = nil;
}
- (void)cleanup {
    _ABICustomBadgeScrollView.delegate = nil;
    [_ABICustomBadgeScrollView removeFromSuperview];
    _ABICustomBadgeScrollView = nil;
    _presenter = nil;
    _rosterEarnBadges = nil;
}

#pragma mark -  IBAction
- (IBAction)chatterBtnClick:(UIButton *)sender {
    if (![NSString isNULLString:self.rosterDataModel.rosterUserID]) {
        [ABIChatterNewPostViewController navigateToChatterNewPostPageFromViewController:self
                                                                      chatterFeature:ChatterFeatureOnlyPrivate
                                                                     rosterDataModel:self.rosterDataModel];
    }
}
- (void)tappedOnBadge {
    if ([AppDelegate isOffline]) {
        [UIViewController alertInNoNetworkConnection:self clickedOkButton:NULL];
    } else {
        [self navigateToABIBadgeDetailsViewController];
    }
}
#pragma mark
#pragma mark Perform Segue
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    if ([segue.identifier isEqualToString:SEGUE_ID_PushToABIBadgeDetailsViewController]) {
        ABIBadgeDetailsViewController *badgeDetailsViewController = [segue destinationViewController];
        if (badgeDetailsViewController) {
            badgeDetailsViewController.rosterDataModel = self.rosterDataModel;
        }
    }
}

#pragma mark -  Protocol conformance

#pragma mark -  Tab Pager Data Source
- (NSInteger)numberOfViewControllers {
    return [self.presenter channelNames:self.rosterDataModel.rosterRole].count;
}
- (UIColor *)tabColor {
    return [UIColor cyanColorABI];
}
- (UIColor *)tabBackgroundColor {
    return [UIColor defaultABIBlueColor];
}
- (UIFont *)titleFont {
    return [UIFont fontHelvetica57Condensed:15.0f];
}
- (UIColor *)titleColor {
    return [UIColor whiteColor];
}
- (UIColor *)deselectedTitleColor {
    return [UIColor cyanColorABI];
}
- (UIViewController *)viewControllerForIndex:(NSInteger)index {
    return [self selectedViewController:index];
}
- (UIViewController *)selectedViewController:(NSInteger)index {
    if (index == 0) {
        ABIProfileMyIncentivesViewController *profileChildViewController =
        (ABIProfileMyIncentivesViewController *)[UIViewController instantiateViewControllerWithIdentifier:@"ABIProfileMyIncentivesViewController"];
        [profileChildViewController incentiveForRoster:self.rosterDataModel];
        return profileChildViewController;
    } else if (index == 1) {
        ABIReporteeListViewController *profileDmChildViewController =
        (ABIReporteeListViewController *)[UIViewController instantiateViewControllerWithIdentifier:@"ABIReporteeListViewController"];
        profileDmChildViewController.rosterDataModel = self.rosterDataModel;
        return profileDmChildViewController;
    }
    return nil;
}
- (NSString *)titleForTabAtIndex:(NSInteger)index {
    NSString *channelName = [NSArray objectFromArray:[self.presenter channelNames:self.rosterDataModel.rosterRole] atIndex:index];
    return channelName;
}
- (CGFloat)tabHeight {
    return [self.presenter heighOfHeader:self.rosterRole];
}
- (void)tabPager:(nullable CustomTabPagerViewController *)tabPager willTransitionToTabAtIndex:(NSInteger)index {
    self.selectedIndex = index;
}
- (void)tabPager:(nullable CustomTabPagerViewController *)tabPager didTransitionToTabAtIndex:(NSInteger)index {
    self.selectedIndex = index;
}
@end
