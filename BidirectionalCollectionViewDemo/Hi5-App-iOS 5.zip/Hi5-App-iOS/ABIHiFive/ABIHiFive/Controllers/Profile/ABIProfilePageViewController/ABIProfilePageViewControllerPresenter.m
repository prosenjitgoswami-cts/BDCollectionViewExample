    //
    //  ABIProfilePageViewControllerPresenter.m
    //  ABIHiFive
    //
    //  Created by Prsenjit Goswami on 28/06/16.
    //  Copyright © 2016 Cognizant. All rights reserved.
    //
#import "ABIProfilePageViewControllerPresenter.h"
#import "ABIBusinessProtocol.h"
#import "ABISFDataFetcherService.h"
#import "ABISFEarnBadgesDataModel.h"
#import "ABISFIncentiveDataModel.h"
#import "ABISFIncentiveDataModel.h"
#import "ABISFKPIsDetailsDataModel.h"
#import "ABISFRosterDataModel.h"
#import "Constants.h"

@interface ABIProfilePageViewControllerPresenter () {
    NSInteger indexOfRecurssion;
}
@property (strong, nonatomic) NSString *rosterID;
@property (assign, nonatomic) NSInteger index;
@end
@implementation ABIProfilePageViewControllerPresenter
#pragma mark - ABIProfilePageViewControllerProtocol
#pragma mark - Down List
- (nullable NSArray<NSString *> *)getIncentiveNames:(nonnull NSArray<ABISFIncentiveDataModel *> *)incentiveDetails
                                    extraDependency:(nullable NSDictionary *)extraDependency {
        // FIXME:WHY Predicate
    NSMutableArray *incentiveNames = [NSMutableArray array];
    for (ABISFIncentiveDataModel *model in incentiveDetails) {
        NSString *incentiveName = model.incentiveCustomDisplayText;
        if (![NSString isNULLString:incentiveName]) {
            [incentiveNames addObject:incentiveName];
        }
    }
    return incentiveNames;
}
#pragma mark - Pager
- (nonnull NSArray *)channelNames:(RosterRole)rosterRole {
    NSArray *channelNames = @[ @"" ];
    switch (rosterRole) {
        case RosterRoleSD: channelNames = PAGER_TITLES_PRFILE_PAGE_AS_MANAGER_LOGIN; break;
        default: break;
    }
    return channelNames;
}
- (CGFloat)heighOfHeader:(RosterRole)rosterRole {
    CGFloat height = 0.0f;
    switch (rosterRole) {
        case RosterRoleSD: height = DEFAULT_PAGE_HEIGHT; break;
        default: break;
    }
    return height;
}
- (nonnull NSString *)headerTitle:(RosterRole)rosterRole {
    NSString *headerTitle = @"";
    switch (rosterRole) {
        case RosterRoleDM: headerTitle = STATIC_TEXT_MY_INCENTIVES; break;
        default: break;
    }
    return headerTitle;
}
#pragma mark - Fetch And Update UI
#pragma mark - Fetch Bagdes Detsils
/**
 *   Fetch Roster details, then Get Roster Id, With Roster Id then fetch BADGE DETAILS. Badges details is depends upon 'Roster Id'
 *
 *  @param rosterID                 Salesfoece User id
 *  @param years                    Specific year For Earnrd Badge details
 *  @param extraDependency          extraDependency if needed
 *  @param rosterDatailsfailedBlock Failed block Roster Details
 *  @param rosterDatailsCompletion  Success block Roster Details
 *  @param badgesDatailsfailedBlock Failed block Earnrd Badge Details
 *  @param badgesDetailsCompletion  Success block Earnrd Badge Details
 */
- (void)fetchRosterDetailsThenFetchBadgesDetailsAndUpdateUI:(nonnull NSString *)rosterID
                                            extraDependency:(nullable NSDictionary *)extraDependency
                                   rosterDatailsfailedBlock:(nonnull ABIFailedBlock)rosterDatailsfailedBlock
                                    rosterDatailsCompletion:(nonnull ABIMutableArrayResponseBlock)rosterDatailsCompletion
                                   badgesDatailsfailedBlock:(nonnull ABIFailedBlock)badgesDatailsfailedBlock
                                    badgesDetailsCompletion:(nonnull ABIMutableArrayResponseBlock)badgesDetailsCompletion {
    [ABISFDataFetcherService fetchAndProcessRosterDetailsWithRosterID:rosterID
                                                      extraDependency:extraDependency
                                                            ascending:NO
                                                           sortByKeys:nil
                                                          failedBlock:rosterDatailsfailedBlock
                                                      completionBlock:^(NSMutableArray<ABISFRosterDataModel *> *results, NSDictionary *extraInfo) {
                                                          if (rosterDatailsCompletion)
                                                              rosterDatailsCompletion(results, extraInfo);
                                                          /*!
                                                           *  Badge details invoke method depends up on Roster ID which get from
                                                           *
                                                           */
                                                          ABISFRosterDataModel *roster = [results firstObject];
                                                          NSString *abiSFRrosterID = rosterID;
                                                          abiSFRrosterID = roster.idName;

                                                          [ABISFDataFetcherService
                                                           fetchRosterBadgeDetailsWithRoster:roster
                                                           forYears:[ABIBusinessProtocol yearsForEarnedBadges]
                                                           extraDependency:extraDependency
                                                           ascending:NO
                                                           sortByKeys:nil
                                                           failedBlock:badgesDatailsfailedBlock
                                                           completionBlock:badgesDetailsCompletion];
                                                      }];
}
#pragma mark Fetch Incentive Detsils
/**
 *
 *
 *  @param rosterID        Roster ID
 *  @param rosterRole      Roster Role
 *  *  @param extraDependency Pass extra information as required
 *  @param sortByKeys      Results sort By key
 *  @param failedBlock     Failed Block
 *  @param completionBlock Collection of Incentive Data Model
 */
- (void)fetchRosterIncentiveDetailsAndUpdateUIWithRoster:(nonnull ABISFRosterDataModel *)roster
                                         extraDependency:(nullable NSDictionary<NSString *, id> *)extraDependency
                                             failedBlock:(nonnull ABIFailedBlock)failedBlock
                                         completionBlock:(nonnull ABIMutableArrayResponseBlock)completionBlock {

    [ABISFDataFetcherService fetchAndProcessRosterIncentiveDetailsWithRoster:roster
                                                             extraDependency:extraDependency
                                                                   ascending:NO
                                                                  sortByKeys:nil
                                                                 failedBlock:failedBlock
                                                             completionBlock:completionBlock];
}
#pragma mark MY DMs

/**
 *  Fetch all Reportee Details (For 'SD', Reportees are 'DM')
 *
 *  @param manegerID       Manager
 *  @param extraDependency Pass extra information as required
 *  @param sortByKeys      Results sort By key
 *  @param failedBlock     Failed Block
 *  @param completionBlock Roster Datamodel as (Reportee Details)
 */
- (void)fetchMyReporteeDetailsAndUpdateUIWithRoster:(nonnull ABISFRosterDataModel *)roster
                                    extraDependency:(nullable NSDictionary<NSString *, id> *)extraDependency
                                          ascending:(BOOL)ascending
                                         sortByKeys:(nullable NSArray *)sortByKeys
                                        failedBlock:(nullable ABIFailedBlock)failedBlock
                                    completionBlock:(nullable ABIMutableArrayResponseBlock)completionBlock {
    __weak typeof(self) weakSelf = self;
    [ABISFDataFetcherService fetchAndProcessAllReporteeDetailsWithRoster:roster
                                                            reporteeRole:ABI_SF_USER_ROLE_DM
                                                         extraDependency:extraDependency
                                                               ascending:ascending
                                                              sortByKeys:sortByKeys
                                                             failedBlock:failedBlock
                                                         completionBlock:^(NSMutableArray<ABISFRosterDataModel *> *results, NSDictionary *extraInfo) {
                                                                 //                                                                [results sortFor
                                                                 //                                                                Key:@"rosterNameText"
                                                                 //                                                                ascending:YES];//TODO: MOVE
                                                                 //                                                                TO COMMON FILE
                                                             indexOfRecurssion = 0;
                                                             [weakSelf badgesCountForMyDMsWithResults:results
                                                                              completeRecurssionBlock:^{
                                                                                  if (completionBlock) {
                                                                                      completionBlock(results, nil);
                                                                                  }
                                                                              }];
                                                         }];
}

#pragma mark - Badge
/**
 *  Fetch Badge Count for all Reportee
 - Get All Reportee
 - Fetch The Badge count for Roster
 - Update 'earnedBadgeCount' value of 'Roster Datamodel'
 *
 *  @param myDMsABISFRosterDataModels   All Reportee Details (Collection of Roster Datamodel)
 *  @param completeRecurssionBlock Success completion.
 */
- (void)badgesCountForMyDMsWithResults:(nonnull NSArray *)myDMsABISFRosterDataModels
               completeRecurssionBlock:(nonnull void (^)(void))completeRecurssionBlock {
    if (indexOfRecurssion >= myDMsABISFRosterDataModels.count) {
        if (completeRecurssionBlock)
            completeRecurssionBlock();
        return;
    }
    __block ABISFRosterDataModel *rosterDataModel = [NSArray objectFromArray:myDMsABISFRosterDataModels atIndex:indexOfRecurssion];
    indexOfRecurssion += 1;
    __weak typeof(self) weakSelf = self;
    [ABISFDataFetcherService fetchRosterBadgeDetailsWithRoster:rosterDataModel
                                                      forYears:[ABIBusinessProtocol yearsForEarnedBadges]
                                               extraDependency:nil
                                                     ascending:YES
                                                    sortByKeys:nil
                                                   failedBlock:^(NSError *error, NSDictionary *extraInfo) {
                                                           // Recurssion Continue on Fail
                                                       [self badgesCountForMyDMsWithResults:myDMsABISFRosterDataModels completeRecurssionBlock:completeRecurssionBlock];
                                                   }
                                               completionBlock:^(NSArray<ABISFEarnBadgesDataModel *> *results, NSDictionary *extraInfo) {
                                                   rosterDataModel.earnedBadgeCount = @(results.count);
                                                       // Recurssion Continue on Fail
                                                   [weakSelf badgesCountForMyDMsWithResults:myDMsABISFRosterDataModels completeRecurssionBlock:completeRecurssionBlock];
                                               }];
}
@end
