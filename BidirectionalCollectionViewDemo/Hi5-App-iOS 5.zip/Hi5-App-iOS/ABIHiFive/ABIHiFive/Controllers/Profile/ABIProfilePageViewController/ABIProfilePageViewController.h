    //
    //  ABIProfilePageViewController.h
    //  ABIHiFive
    //
    //  Created by Prsenjit Goswami on 27/06/16.
    //  Copyright © 2016 Cognizant. All rights reserved.
    //
#import "ABIBaseViewController.h"
@interface ABIProfilePageViewController : ABIBaseViewController
@property (nonnull, strong, nonatomic) ABISFRosterDataModel *rosterDataModel;

- (void)profileForRosterWithUserID:(nonnull NSString *)sfUserID andPageFlow:(PageFlow)pageFlow;
@end
