    //
    //  ABIProfilePageViewControllerPresenter.h
    //  ABIHiFive
    //
    //  Created by Prsenjit Goswami on 28/06/16.
    //  Copyright © 2016 Cognizant. All rights reserved.
    //
#import "ABIProfilePageViewControllerProtocol.h"
#import <Foundation/Foundation.h>
@interface ABIProfilePageViewControllerPresenter : NSObject <ABIProfilePageViewControllerProtocol>
@end
