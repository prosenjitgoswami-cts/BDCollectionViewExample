    //
    //  ABIProfilePageViewControllerProtocol.h
    //  ABIHiFive
    //
    //  Created by Prsenjit Goswami on 28/06/16.
    //  Copyright © 2016 Cognizant. All rights reserved.
    //
#import "ABISFIncentiveDataModel.h"
#import "ABISFRosterDataModel.h"
#import "Constants.h"
#import <Foundation/Foundation.h>
@protocol ABIProfilePageViewControllerProtocol <NSObject>

#pragma mark -  ABIProfilePageViewControllerProtocol

#pragma mark -  Down List
- (nullable NSArray<NSString *> *)getIncentiveNames:(nonnull NSArray<ABISFIncentiveDataModel *> *)incentiveDetails
                                    extraDependency:(nullable NSDictionary *)extraDependency;

#pragma mark -  Pager
- (nonnull NSArray *)channelNames:(RosterRole)rosterRole;
- (CGFloat)heighOfHeader:(RosterRole)rosterRole;
- (nonnull NSString *)headerTitle:(RosterRole)rosterRole;

#pragma mark -  Fetch And Update UI

#pragma mark -  Fetch Bagdes Detsils
- (void)fetchRosterDetailsThenFetchBadgesDetailsAndUpdateUI:(nonnull NSString *)rosterID
                                            extraDependency:(nullable NSDictionary *)extraDependency
                                   rosterDatailsfailedBlock:(nonnull ABIFailedBlock)rosterDatailsfailedBlock
                                    rosterDatailsCompletion:(nonnull ABIMutableArrayResponseBlock)rosterDatailsCompletion
                                   badgesDatailsfailedBlock:(nonnull ABIFailedBlock)badgesDatailsfailedBlock
                                    badgesDetailsCompletion:(nonnull ABIMutableArrayResponseBlock)badgesDetailsCompletion;

#pragma mark Fetch Incentive Detsils
- (void)fetchRosterIncentiveDetailsAndUpdateUIWithRoster:(nonnull ABISFRosterDataModel *)roster
                                         extraDependency:(nullable NSDictionary<NSString *, id> *)extraDependency
                                             failedBlock:(nonnull ABIFailedBlock)failedBlock
                                         completionBlock:(nonnull ABIMutableArrayResponseBlock)completionBlock;
#pragma mark MY DMs
- (void)fetchMyReporteeDetailsAndUpdateUIWithRoster:(nonnull ABISFRosterDataModel *)roster
                                    extraDependency:(nullable NSDictionary<NSString *, id> *)extraDependency
                                          ascending:(BOOL)ascending
                                         sortByKeys:(nullable NSArray *)sortByKeys
                                        failedBlock:(nullable ABIFailedBlock)failedBlock
                                    completionBlock:(nullable ABIMutableArrayResponseBlock)completionBlock;

@end
