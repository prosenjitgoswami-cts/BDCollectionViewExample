    //
    //  ABIReporteeListViewController.h
    //  ABIHiFive
    //
    //  Created by Prsenjit Goswami on 18/08/16.
    //  Copyright © 2016 Cognizant. All rights reserved.
    //
#import <UIKit/UIKit.h>
@class ABISFRosterDataModel;

@interface ABIReporteeListViewController : UIViewController
@property (strong, nonatomic) ABISFRosterDataModel *rosterDataModel;
@end
