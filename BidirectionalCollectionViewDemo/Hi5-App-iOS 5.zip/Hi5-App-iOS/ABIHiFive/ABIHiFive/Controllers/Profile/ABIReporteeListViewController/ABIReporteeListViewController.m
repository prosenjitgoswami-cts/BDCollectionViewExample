    //
    //  ABIReporteeListViewController.m
    //  ABIHiFive
    //
    //  Created by Prsenjit Goswami on 18/08/16.
    //  Copyright © 2016 Cognizant. All rights reserved.
    //
#import "ABIReporteeListViewController.h"
#import "ABIReporteeListTableViewCell.h"
#import "ABISFRosterDataModel.h"
#import "ABIChatterNewPostViewController.h"
#import "Constants.h"
#import "CustomView.h"
#import "ABIProfilePageViewController.h"
#import "ABIProfilePageViewControllerPresenter.h"

@interface ABIReporteeListViewController () <UITableViewDelegate, UITableViewDataSource, ABIReporteeListTableViewCellDelegate>
@property (weak, nonatomic) IBOutlet UITableView *myDmsTable;
@property (weak, nonatomic) IBOutlet UILabel *totalDmLabel;
@property (strong, nonatomic) id<ABIProfilePageViewControllerProtocol> presenter;
@property (strong, nonatomic) NSArray<ABISFRosterDataModel *> *myDMsDataSource;
@property (assign, nonatomic) BOOL isClickedMyDm;
@property (assign, nonatomic) PageFlow previousPageFlow;
@property (assign, nonatomic) BOOL once;
@property (assign, nonatomic) BOOL ONCELOADER;
@end
@implementation ABIReporteeListViewController
- (void)viewDidLoad {
    [super viewDidLoad];
    self.view.backgroundColor = [UIColor defaultPageBGColor];
    self.myDmsTable.dataSource = self;
    self.myDmsTable.separatorStyle = UITableViewCellSeparatorStyleNone;
    self.myDmsTable.delegate = self;
    _totalDmLabel.textColor = [UIColor defaultTextDarkColor];
    [_totalDmLabel setFont:[UIFont fontHelvetica57Condensed:15.0f]];
    self.previousPageFlow = [AppDelegate appdelegateShareInstance].globalCurrentPageFlow;
}
- (void)viewDidAppear:(BOOL)animated {
    [super viewDidAppear:animated];
    [AppDelegate setGlobalCurrentPageFlow:self.previousPageFlow];
    [self fetchServiceAndUpdateUI];
}

#pragma mark - Custom Accessors
- (id<ABIProfilePageViewControllerProtocol>)presenter {
    if (!_presenter) {
        _presenter = [ABIProfilePageViewControllerPresenter new];
    }
    return _presenter;
}
#pragma mark -  Fetch Service - Update Data Source - Update UI
- (void)fetchServiceAndUpdateUI {
    if ([AppDelegate isOffline]) {
        if (!self.once) {
            [UIViewController alertInNoNetworkConnection:self clickedOkButton:NULL];
            self.once = YES;
        }
    } else {
        if (!_ONCELOADER) {
            [CustomLoaderManager showLoader];
            _ONCELOADER = YES;
        }
        __weak typeof(self) weakSelf = self;
        [self.presenter fetchMyReporteeDetailsAndUpdateUIWithRoster:self.rosterDataModel
                                                    extraDependency:nil
                                                          ascending:YES
                                                         sortByKeys:@[ @"Name" ]
                                                        failedBlock:^(NSError *error, NSDictionary *extraInfo) { [CustomLoaderManager hideLoader]; }
                                                    completionBlock:^(NSArray *results, NSDictionary *extraInfo) {
                                                        weakSelf.myDMsDataSource = results;
                                                        [weakSelf updateUI:results];
                                                        [CustomLoaderManager hideLoaderOnDelay:1.0 completion:NULL];
                                                    }];
    }
}
- (void)updateUI:(NSArray<ABISFRosterDataModel *> *)reportee {
    if (!reportee || !reportee.count) {
        self.totalDmLabel.hidden = YES;
    }
    [self.totalDmLabel setText:[NSString displayTextForTotalDMsCountInProfileMyDMsVC:reportee.count]];
    [self.myDmsTable reloadData];
}

#pragma mark – UITableViewDataSource
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    return 1;
}
- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
    return self.myDMsDataSource.count;
}
- (CGFloat)tableView:(UITableView *)tableView heightForFooterInSection:(NSInteger)section {
    return 5.0f;
}
- (UIView *)tableView:(UITableView *)tableView viewForFooterInSection:(NSInteger)section {
    UIView *headerView = [[UIView alloc] initWithFrame:CGRectMake(0, 0, tableView.frame.size.width, 5.0f)];
    headerView.backgroundColor = [UIColor defaultPageBGColor];
    return headerView;
}
- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath {
    return 70.0f;
}
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    NSString *cellIdentifier = @"mydmscell";
    ABIReporteeListTableViewCell *cell = (ABIReporteeListTableViewCell *)[tableView dequeueReusableCellWithIdentifier:cellIdentifier];
    if (cell == nil) {
        cell = [[ABIReporteeListTableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:cellIdentifier];
    }
    [cell defaultABICellBackground];

    cell.delegate = self;
    ABISFRosterDataModel *rosterDataModel = [NSArray objectFromArray:self.myDMsDataSource atIndex:indexPath.section];
    [cell updateCellUI:rosterDataModel];
    return cell;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
    if ([AppDelegate isOffline]) {
        [UIViewController alertInNoNetworkConnection:self clickedOkButton:NULL];
    } else {
        ABISFRosterDataModel *rosterDataModel = [NSArray objectFromArray:self.myDMsDataSource atIndex:indexPath.section];
        if (rosterDataModel) {
            self.isClickedMyDm = YES;
            ABIProfilePageViewController *profilePageVC = [self.storyboard instantiateViewControllerWithIdentifier:@"ABIProfilePageViewController"];
            [AppDelegate setGlobalCurrentPageFlow:PageFlowAsMyDMAsSDLogin];
            profilePageVC.rosterDataModel = rosterDataModel;
            [profilePageVC profileForRosterWithUserID:rosterDataModel.rosterUserID andPageFlow:PageFlowAsMyDMAsSDLogin];

            [self.navigationController pushViewController:profilePageVC animated:YES];
        }
    }
}

#pragma mark - ABIReporteeListTableViewCellDelegate
- (void)clickedPostComment:(UIButton *)sender cell:(ABIReporteeListTableViewCell *)cell {
    ABISFRosterDataModel *rosterDataModel = cell.rosterDataModel;

    if (rosterDataModel && ![NSString isNULLString:rosterDataModel.rosterUserID]) {
        [ABIChatterNewPostViewController navigateToChatterNewPostPageFromViewController:self
                                                                      chatterFeature:ChatterFeatureOnlyPrivate
                                                                     rosterDataModel:rosterDataModel];
    }
}
@end
    // Delete Branch