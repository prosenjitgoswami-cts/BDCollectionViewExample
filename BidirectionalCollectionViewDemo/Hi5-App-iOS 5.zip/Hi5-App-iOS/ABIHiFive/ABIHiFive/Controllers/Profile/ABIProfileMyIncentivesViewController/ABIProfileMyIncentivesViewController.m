    //
    //  ABIProfileMyIncentivesViewController.m
    //  ABIHiFive
    //
    //  Created by Prsenjit Goswami on 17/08/16.
    //  Copyright © 2016 Cognizant. All rights reserved.
    //
#import "ABIProfileMyIncentivesViewController.h"
#import "ABIManagerIncentiveListTableViewCell.h"
#import "ABIReporteeIncentiveListTableViewCell.h"
#import "ABISFDataFetcherService.h"
#import "ABISFIncentiveDataModel.h"
#import "ABISFRosterDataModel.h"
#import "Constants.h"
#import "CustomBadge.h"
#import "ABIKPIDetailViewController.h"
#import "ABIKPIDetailsPageViewController.h"
#include "ABIPeerRankingPageViewController.h"
#import "ABIProfilePageViewControllerPresenter.h"
#import "SFIdentityData.h"

@interface ABIProfileMyIncentivesViewController () <ABIReporteeIncentiveListTableViewCellDelegate, UITableViewDelegate, UITableViewDataSource,
ABIManagerIncentiveListTableViewCellDelegate>
@property (weak, nonatomic) IBOutlet UITableView *incentiveTableView;
@property (weak, nonatomic) IBOutlet UILabel *headingLabel;
@property (strong, nonatomic) IBOutlet UIView *noIncentiveView;
@property (strong, nonatomic) id<ABIProfilePageViewControllerProtocol> presenter;
@property (strong, nonatomic) ABISFRosterDataModel *roster;
@property (strong, nonatomic) NSMutableArray<ABISFIncentiveDataModel *> *incentiveDetails;
@property (strong, nonatomic) ABISFIncentiveDataModel *selectedIncentive;
@property (weak, nonatomic) IBOutlet NSLayoutConstraint *tableViewTopConstraint;
@property (strong, nonatomic) UILabel *noIncentiveLabel;
@end
@implementation ABIProfileMyIncentivesViewController
#pragma mark - View Controller Life Cycle
- (void)viewDidLoad {
    [super viewDidLoad];
    [self initialSetup];
    [self createAndAddUIForNoIncentive];

    if ([self.roster.roleInString isEqualToString:ABI_SF_USER_ROLE_SD]) {
        _tableViewTopConstraint.constant = 5;
        [self.view layoutIfNeeded];
    } else {

        _tableViewTopConstraint.constant = 30;
    }

    [self.view layoutIfNeeded];
}
- (void)createAndAddUIForNoIncentive {
        //    self.noIncentiveView = [[UIView alloc] init];
        //    self.noIncentiveView.backgroundColor = [UIColor whiteColor];
        //    self.noIncentiveView.layer.cornerRadius = 5;
        //    self.noIncentiveView.layer.masksToBounds = YES;
        //    self.noIncentiveView.translatesAutoresizingMaskIntoConstraints = NO;
        //    [self.view addSubview:self.noIncentiveView];
        //    self.noIncentiveLabel = [[UILabel alloc] init];
        //    self.noIncentiveLabel.text = STATIC_TEXT_NO_INCENTIVE_ASSINGED;
        //    self.noIncentiveLabel.translatesAutoresizingMaskIntoConstraints = NO;
        //    self.noIncentiveLabel.textAlignment = NSTextAlignmentCenter;
        //    [self.noIncentiveView addSubview:self.noIncentiveLabel];
        //    self.noIncentiveLabel.font = [UIFont fontHelvetica67Condensed:14.0f];
        //
        //    NSDictionary *views =
        //    @{ @"noIncentiveLabel" : self.noIncentiveLabel,
        //       @"noIncentiveView" : self.noIncentiveView,
        //       @"headingLabel" : self.headingLabel };
        //    [self.view addConstraints:[NSLayoutConstraint constraintsWithVisualFormat:@"V:|-30-[noIncentiveView]|" options:0 metrics:nil views:views]];
        //    [self.view addConstraints:[NSLayoutConstraint constraintsWithVisualFormat:@"H:|-16-[noIncentiveView]-16-|" options:0 metrics:nil
        //    views:views]];
        //    [self.view addConstraints:[NSLayoutConstraint constraintsWithVisualFormat:@"H:|-16-[noIncentiveLabel]-16-|" options:0 metrics:nil
        //    views:views]];
        //    NSLayoutConstraint *h = [NSLayoutConstraint horizontallyCenter:self.noIncentiveLabel toItem:self.noIncentiveView];
        //    [self.noIncentiveView addConstraint:h];
        //    NSLayoutConstraint *v = [NSLayoutConstraint verticallyCenter:self.noIncentiveLabel toItem:self.noIncentiveView];
        //    [self.noIncentiveView addConstraint:v];

    self.noIncentiveView = [UIView noDataDisplayViewWithDescriptionText:STATIC_TEXT_NO_INCENTIVE_ASSINGED
                                                               textFont:[UIFont fontHelvetica57Condensed:14.0f]
                                                              textColor:[UIColor defaultTextDarkColor]];
    [self.view addSubview:self.noIncentiveView];

    [self.noIncentiveView addContraintsWithParentView:self.view insets:UIEdgeInsetsMake(30, 10, 0, 10)];

    self.noIncentiveLabel.hidden = YES;
    self.noIncentiveView.hidden = YES;
    self.headingLabel.hidden = YES;
}
- (void)viewWillAppear:(BOOL)animated {
    [super viewWillAppear:animated];
}
- (void)dealloc {
    [self cleanup];
}
#pragma mark - Public Method
- (void)incentiveForRoster:(nonnull ABISFRosterDataModel *)rosterDataModel {
    self.roster = rosterDataModel;
    [self fetchAndUpdateUI];
}
#pragma mark -  Custom Accessors
- (id<ABIProfilePageViewControllerProtocol>)presenter {
    if (!_presenter) {
        _presenter = [ABIProfilePageViewControllerPresenter new];
    }
    return _presenter;
}
#pragma mark - Private Method
#pragma mark - Fetch Service - Update Data Source - Update UI
/*!
 *  Fetch data from Salesforce
 */
- (void)fetchAndUpdateUI {
    if ([AppDelegate isOffline]) {
        [UIViewController alertInNoNetworkConnection:self clickedOkButton:NULL];
    } else {
        [CustomLoaderManager showLoader];

        __weak typeof(self) weakSelf = self;
        [weakSelf.presenter fetchRosterIncentiveDetailsAndUpdateUIWithRoster:self.roster
                                                             extraDependency:nil
                                                                 failedBlock:^(NSError *error, NSDictionary *extraInfo) { [weakSelf updateIncentiveDataSourceAndUI:nil]; }
                                                             completionBlock:^(NSMutableArray<ABISFIncentiveDataModel *> *results, NSDictionary *extraInfo) {
                                                                 [weakSelf updateIncentiveDataSourceAndUI:results];
                                                             }];
    }
}
- (void)updateIncentiveDataSourceAndUI:(nullable NSMutableArray<ABISFIncentiveDataModel *> *)results {
    [self updateIncentveDatasource:results];
    [self updateIncentveUI];

    [CustomLoaderManager hideLoaderOnDelay:1 completion:NULL];
}
/*!
 *  Up date Datasource Afret Fetching Data
 *
 */
- (void)updateIncentveDatasource:(nullable NSMutableArray<ABISFIncentiveDataModel *> *)results {
    self.incentiveDetails = results;
}
/*!
 *  Up date UI Afret Fetching Data
 *
 */
- (void)updateIncentveUI {

        //    self.heading Label.text = [self.presenter headerTitle:self.roster.rosterRole];
    [self setupConditionalUIComponent];

    [self.incentiveTableView reloadData];
}
#pragma mark
#pragma mark UI
/*!
 * All Common set up As customise Navigation, UI decoration, Initilize property if Needed etc.
 *
 */
- (void)initialSetup {
    [self resetAll];
        // Initial UI Set up
    [self initialUISetup];
}
/*!
 * initial set up As customise Navigation, UI decoration.
 *
 */
- (void)initialUISetup {
    [self setNavigationPageTitle];
    [self setupConditionalUIComponent];
    [self customUIDecoration];
}
/*!
 * Cutomise Navigation Bar, set Title
 */
- (void)setNavigationPageTitle {
    self.title = nil;
}

/*!
 * Some UI visibily depand on special use case
 */
- (void)setupConditionalUIComponent {
        //	if ([self.roster.managerRoleInString isEqualToString:ABI_SF_USER_ROLE_SD] &&
        //        [self.roster.roleInString isEqualToString:ABI_SF_USER_ROLE_DM]) {
        //        self.headingLabel.text = STATIC_TEXT_DM_INCENTIVES;
        //    } else {
        //        self.headingLabel.text = STATIC_TEXT_MY_INCENTIVES;
        //    }

    BOOL isAssingedIncentivesAvaiable = self.incentiveDetails && self.incentiveDetails.count;
    self.incentiveTableView.hidden = !isAssingedIncentivesAvaiable;
    [self.incentiveTableView setScrollEnabled:(isAssingedIncentivesAvaiable && self.incentiveDetails.count > 1)];

    self.headingLabel.hidden = !self.incentiveTableView.hidden && (self.roster.rosterRole == RosterRoleSD);
    self.noIncentiveLabel.hidden = !self.incentiveTableView.hidden;
    self.noIncentiveView.hidden = !self.incentiveTableView.hidden;
}
/*!
 * Decorate UI component's Font, Color, etc...
 */
- (void)customUIDecoration {
    self.headingLabel.text = [NSString rosterAssingedIncentiveDetailsTableHeader:self.roster];
    self.headingLabel.font = PROFILE_INCENTIVE_TABLE_HEADING_FONT_SIZE;
    self.headingLabel.textColor = [UIColor defaultTextDarkColor];
    self.headingLabel.hidden = YES;
    self.incentiveTableView.delegate = self;
    self.incentiveTableView.dataSource = self;
}
/*!
 *  Reset All Datasource
 */
- (void)resetAll {
    _selectedIncentive = nil;
}
/*!
 *  Cleanup Datasource, Delegate other nullyfy owned object
 */
- (void)cleanup {
    _presenter = nil;
    _incentiveDetails = nil;
}
#pragma mark
- (void)navigateToPeerRankingViewController {
    if ([AppDelegate isOffline]) {
        [UIViewController alertInNoNetworkConnection:self clickedOkButton:NULL];
    } else {
        ABIPeerRankingPageViewController *peerRankingPageVC =
        (ABIPeerRankingPageViewController *)[UIViewController instantiateViewControllerWithIdentifier:STORY_BOARD_ID_PEER_RANKING_PAGE_VC];
        if (peerRankingPageVC) {
            [peerRankingPageVC peerRankingForRoster:self.roster assingedIncentives:self.incentiveDetails selectedIncentive:self.selectedIncentive];
        }
        [self.navigationController pushViewController:peerRankingPageVC animated:YES];
    }
}
- (void)navigateToKIPDetailsViewController {
    if ([AppDelegate isOffline]) {
        [UIViewController alertInNoNetworkConnection:self clickedOkButton:NULL];
    } else {
        ABIKPIDetailsPageViewController *kpietailsPageVC =
        (ABIKPIDetailsPageViewController *)[UIViewController instantiateViewControllerWithIdentifier:STORY_BOARD_ID_KPI_DETAILS_PAGE_VC];
        if (kpietailsPageVC) {

            BOOL isLoginUser = [AppDelegate appdelegateShareInstance].globalCurrentPageFlow != PageFlowAsMyDMAsSDLogin;

            KPIDetailsPageType kpiDetailsPageType = isLoginUser ? KPIDetailsPageFromLogInUserProfilePage : KPIDetailsPageFromReporteeProfilePageOfLogInUser;

            [kpietailsPageVC kpiDetailsForIncentive:self.selectedIncentive
                                   incentiveDetails:self.incentiveDetails
                                          forRoster:self.roster
                                         OrPeerUser:nil
                                 kpiDetailsPageType:kpiDetailsPageType
                                    extraDependency:nil];
        }
        [self.navigationController pushViewController:kpietailsPageVC animated:YES];
    }
}
#pragma mark - IBAction
#pragma mark - ABIReporteeIncentiveListTableViewCellDelegate
- (void)clickedPeerRanking:(UIButton *)sender atIndex:(NSUInteger)index {
    self.selectedIncentive = [NSArray objectFromArray:self.incentiveDetails atIndex:index];
    [self navigateToPeerRankingViewController];
}
- (void)clickedKPIRanking:(UIButton *)sender atIndex:(NSUInteger)index {
    self.selectedIncentive = [NSArray objectFromArray:self.incentiveDetails atIndex:index];
    [self navigateToKIPDetailsViewController];
}

#pragma mark - Protocol conformance
#pragma mark - table view delegate methods
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    return 1;
}
- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath {
    CGFloat cellHeight = 200.0f;
    return cellHeight; // FIXME: Check me Why it is hard code?
}
- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
    return self.incentiveDetails.count;
}
- (CGFloat)tableView:(UITableView *)tableView heightForFooterInSection:(NSInteger)section {
    return DEFAULT_CELL_PADDING;
}
- (UIView *)tableView:(UITableView *)tableView viewForFooterInSection:(NSInteger)section {
    UIView *headerView = [[UIView alloc] initWithFrame:CGRectMake(0, 0, tableView.frame.size.width, DEFAULT_CELL_PADDING)];
    headerView.backgroundColor = [UIColor clearColor];
    return headerView;
}
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    switch (self.roster.rosterRole) {
        case RosterRoleDM: return [self reporteeTableViewCell:tableView cellForRowAtIndexPath:indexPath]; break;
        case RosterRoleSD: return [self managerTableVIewCell:tableView cellForRowAtIndexPath:indexPath]; break;
        default: return nil; break;
    }
}
- (UITableViewCell *)reporteeTableViewCell:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    static NSString *cellIdentifier = CELL_ID_DM_PROFILE_CELL;
    ABIReporteeIncentiveListTableViewCell *cell = (ABIReporteeIncentiveListTableViewCell *)[tableView dequeueReusableCellWithIdentifier:cellIdentifier];
    cell.delegate = self;
    cell.rosterDataModel = self.roster;
    if (cell == nil) {
        cell = [[ABIReporteeIncentiveListTableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:cellIdentifier];
    }
    [cell defaultABICellBackground];

    cell.delegate = self;
    cell.rosterDataModel = self.roster;
    ABISFIncentiveDataModel *incentive = (ABISFIncentiveDataModel *)[NSArray objectFromArray:self.incentiveDetails atIndex:indexPath.section];
    if (incentive) {
        [cell updateCell:incentive atIndex:indexPath.section];
    }
    return cell;
}
- (UITableViewCell *)managerTableVIewCell:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    static NSString *cellIdentifier = CELL_ID_SD_PROFILE_CELL;
    ABIManagerIncentiveListTableViewCell *cell = (ABIManagerIncentiveListTableViewCell *)[tableView dequeueReusableCellWithIdentifier:cellIdentifier];
    if (cell == nil) {
        cell = [[ABIManagerIncentiveListTableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:cellIdentifier];
    }
    [cell defaultABICellBackground];
    cell.delegate = self;
    cell.rosterDataModel = self.roster;
    ABISFIncentiveDataModel *incentive = (ABISFIncentiveDataModel *)[NSArray objectFromArray:self.incentiveDetails atIndex:indexPath.section];
    if (incentive) {
        [cell updateCell:incentive atIndex:indexPath.section];
    }

    return cell;
}
@end
