    //
    //  ABIProfileMyIncentivesViewController.h
    //  ABIHiFive
    //
    //  Created by Prsenjit Goswami on 16/08/16.
    //  Copyright © 2016 Cognizant. All rights reserved.
    //
#import "ABIBaseViewController.h"
#import <UIKit/UIKit.h>
@interface ABIProfileMyIncentivesViewController : UIViewController
- (void)incentiveForRoster:(nonnull ABISFRosterDataModel *)rosterDataModel;
@end
