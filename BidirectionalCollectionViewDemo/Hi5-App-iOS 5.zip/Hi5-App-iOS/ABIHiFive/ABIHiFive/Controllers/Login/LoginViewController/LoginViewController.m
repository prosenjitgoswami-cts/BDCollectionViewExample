    //
    //  LoginViewController.m
    //  ABIHiFive
    //
    //  Created by Prsenjit Goswami on 10/06/16.
    //  Copyright © 2016 Cognizant. All rights reserved.
    //
#import "LoginViewController.h"
#import "ABISFChatterDataFetcherServices.h"
#import "ABISFChatterParentDataModel.h"
#import "ABISFLogInManager.h"
#import "Constants.h"
#import "Reachability.h"
#import "SalesforceSDKCore.h"
#import "ABITermsAndConditionViewController.h"
#import "UIColor+ABIColor.h"
#import "UIViewController+ABIUtil.h"

@implementation LoginViewController
#pragma mark - Viewcontroller Life Cycle
- (void)viewDidLoad {
    [super viewDidLoad];
    self.view.backgroundColor = [UIColor blueColorABI];
}
- (void)viewWillAppear:(BOOL)animated {
    [super viewWillAppear:animated];
    self.navigationController.navigationBarHidden = YES;
    [self initialishedSalesForceAndLaunch];
    SFLoginViewController *sf = [SFLoginViewController sharedInstance];
    [sf setTermsAndConditionButtonTitle:TITLE_PRIVACY_POLICY];
    [ABITermsAndConditionViewController showTremsAndConditionPage];
}
- (void)viewDidDisappear:(BOOL)animated {
    [super viewDidDisappear:animated];
    self.navigationController.navigationBarHidden = NO;
}
#pragma mark - Private Method
- (void)initialishedSalesForceAndLaunch {
    if ([AppDelegate isOffline]) {
        [UIViewController alertInNoNetworkConnection:self clickedOkButton:NULL];
        [self alertWithTitle:nil
                     message:ALT_MSG_NO_INTERNET_CONNECTION
          defaultButtonTitle:ALT_BTN_TITLE_TRY_AGAIN
             clickedOkButton:^{ [self initialishedSalesForceAndLaunch]; }];
    } else {
        [[ABISFLogInManager shareInstance] initialishedSalesForce];
    }
}
@end
