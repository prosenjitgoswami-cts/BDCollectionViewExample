    //
    //  ABIBadgeDetailsViewControllerPresenter.m
    //  ABIHiFive
    //
    //  Created by Prsenjit Goswami on 19/08/16.
    //  Copyright © 2016 Cognizant. All rights reserved.
    //
#import "ABIBadgeDetailsViewControllerPresenter.h"
#import "ABIBusinessProtocol.h"
#import "ABISFBadgesDetailsNameWiseDataModel.h"
#import "ABISFDataFetcherService.h"
#import "ABISFEarnBadgesDataModel.h"
@implementation ABIBadgeDetailsViewControllerPresenter

- (NSMutableArray<DropDownListDataModel *> *)yearDropDownLists {

    NSMutableArray *dataModels = [NSMutableArray array];
    [dataModels addObject:kALL];
    for (id obj in [ABIBusinessProtocol yearsForEarnedBadges]) {
        [dataModels addObject:[NSString stringWithFormat:@"%@", obj]];
    }
    return dataModels;
}

- (NSMutableArray *)dropDownBadgesByName:(NSMutableArray<ABISFBadgesDetailsNameWiseDataModel *> *)badgesDetails {

    NSMutableArray *dataModels = [NSMutableArray array];
    [dataModels addObject:kALL_Badges];
    [ABISFEarnBadgesDataModel sortByPriority:badgesDetails];
    for (ABISFBadgesDetailsNameWiseDataModel *model in badgesDetails) {
        if (![NSString isNULLString:model.badgesName])
            [dataModels addObject:model.badgesName];
    }
    return dataModels;
}
- (void)fetchAndUpdateUIForAllEarnedBadgesDetailsAndUpdateUIWithRoster:(ABISFRosterDataModel *)roster
                                                              forYears:years
                                                       extraDependency:(NSDictionary *)extraDependency
                                                             ascending:(BOOL)ascending
                                                            sortByKeys:(NSMutableArray *)sortByKeys
                                                           failedBlock:(ABIFailedBlock)failedBlock
                                                       completionBlock:(ABIMutableArrayResponseBlock)completionBlock {
    [ABISFDataFetcherService fetchRosterBadgeDetailsWithRoster:roster
                                                      forYears:years
                                               extraDependency:extraDependency
                                                     ascending:ascending
                                                    sortByKeys:sortByKeys
                                                   failedBlock:failedBlock
                                               completionBlock:^(NSMutableArray<ABISFEarnBadgesDataModel *> *results, NSDictionary *extraInfo) {
                                                   if (completionBlock)
                                                       completionBlock(results, nil);
                                               }];
}
- (NSMutableArray<ABISFBadgesDetailsNameWiseDataModel *> *)filterBadgesByBadgesName:(NSString *)name
                                                                               year:(NSNumber *)year
                                                             allEarnedBadgesDetails:(NSArray<ABISFEarnBadgesDataModel *> *)badgesDetails {
    NSArray *filterBadges = badgesDetails;
    if (name.length && ![name isEqualToString:kALL_Badges]) {
        NSPredicate *predicate = [NSPredicate predicateWithFormat:@"self.badgesName == %@", name];
        filterBadges = [badgesDetails filteredArrayUsingPredicate:predicate];
    }
    if (year && year.integerValue) {
        NSPredicate *predicate = [NSPredicate predicateWithFormat:@"self.year == %@", year];
        filterBadges = [filterBadges filteredArrayUsingPredicate:predicate];
    }
    NSMutableArray *badgesDetailsNameWiseDataModels = [ABISFEarnBadgesDataModel groupedBadgesByPriority:[filterBadges mutableCopy]];
    return badgesDetailsNameWiseDataModels;
}
/*!
 *  Number of incentive by Indivisiul Badges
 *
 *  @param allBadges All
 *
 */
- (NSInteger)numberOfIncentive:(NSInteger)section nameWiseBagdes:(NSArray<ABISFBadgesDetailsNameWiseDataModel *> *)nameWiseBagdes {
    NSInteger numberOfIncentive = 0;
    ABISFBadgesDetailsNameWiseDataModel *model = [NSArray objectFromArray:nameWiseBagdes atIndex:section];
    if (model) {
        numberOfIncentive = [model.numberOfEarnBadges integerValue];
    }
    return numberOfIncentive;
}
- (ABISFBadgesDetailsNameWiseDataModel *)badgesDetailsNameWiseDataModelAtSection:(NSInteger)section
                                                                  nameWiseBagdes:
(NSMutableArray<ABISFBadgesDetailsNameWiseDataModel *> *)nameWiseBagdes {
    ABISFBadgesDetailsNameWiseDataModel *model = [NSArray objectFromArray:nameWiseBagdes atIndex:section];
    return model;
}
@end
