    //
    //  ABIBadgeDetailsViewControllerProtocol.h
    //  ABIHiFive
    //
    //  Created by Prsenjit Goswami on 19/08/16.
    //  Copyright © 2016 Cognizant. All rights reserved.
    //
#import "Constants.h"
#import <Foundation/Foundation.h>
@class DropDownListDataModel;
@class ABISFBadgesDetailsNameWiseDataModel;

@protocol ABIBadgeDetailsViewControllerProtocol <NSObject>

- (NSMutableArray<DropDownListDataModel *> *)yearDropDownLists;
- (NSMutableArray *)dropDownBadgesByName:(NSArray<ABISFBadgesDetailsNameWiseDataModel *> *)badgesDetails;
- (NSInteger)numberOfIncentive:(NSInteger)section nameWiseBagdes:(NSArray<ABISFBadgesDetailsNameWiseDataModel *> *)nameWiseBagdes;
- (ABISFBadgesDetailsNameWiseDataModel *)badgesDetailsNameWiseDataModelAtSection:(NSInteger)section
                                                                  nameWiseBagdes:(NSArray<ABISFBadgesDetailsNameWiseDataModel *> *)nameWiseBagdes;
- (NSMutableArray<ABISFBadgesDetailsNameWiseDataModel *> *)filterBadgesByBadgesName:(NSString *)name
                                                                               year:(NSNumber *)year
                                                             allEarnedBadgesDetails:
(NSMutableArray<ABISFEarnBadgesDataModel *> *)allEarnedBadgesDetails;
- (void)fetchAndUpdateUIForAllEarnedBadgesDetailsAndUpdateUIWithRoster:(ABISFRosterDataModel *)roster
                                                              forYears:(NSArray<NSString *> *)years
                                                       extraDependency:(NSDictionary *)extraDependency
                                                             ascending:(BOOL)ascending
                                                            sortByKeys:(NSArray *)sortByKeys
                                                           failedBlock:(ABIFailedBlock)failedBlock
                                                       completionBlock:(ABIMutableArrayResponseBlock)completionBlock;
@end
