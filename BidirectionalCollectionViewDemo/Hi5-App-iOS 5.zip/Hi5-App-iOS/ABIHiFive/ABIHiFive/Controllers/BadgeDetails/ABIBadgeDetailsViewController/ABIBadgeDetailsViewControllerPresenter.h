    //
    //  ABIBadgeDetailsViewControllerPresenter.h
    //  ABIHiFive
    //
    //  Created by Prsenjit Goswami on 19/08/16.
    //  Copyright © 2016 Cognizant. All rights reserved.
    //
#import "ABIBadgeDetailsViewControllerProtocol.h"
#import <Foundation/Foundation.h>
@interface ABIBadgeDetailsViewControllerPresenter : NSObject <ABIBadgeDetailsViewControllerProtocol>
@end
