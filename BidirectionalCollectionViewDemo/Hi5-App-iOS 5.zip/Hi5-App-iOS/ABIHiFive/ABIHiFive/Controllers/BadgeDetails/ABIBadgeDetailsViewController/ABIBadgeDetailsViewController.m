    //
    //  ABIBadgeDetailsViewController.m
    //  ABIHiFive
    //
    //  Created by Prsenjit Goswami on 11/08/16.
    //  Copyright © 2016 Cognizant. All rights reserved.
    //
#import "ABIBadgeDetailsViewController.h"
#import "ABIBadgeDetailTableViewCell.h"
#import "ABIBusinessProtocol.h"
#import "ABICustomBadgeScrollView.h"
#import "ABIDropDownComponentView.h"
#import "ABISFBadgesDetailsNameWiseDataModel.h"
#import "ABISFEarnBadgesDataModel.h"
#import "ABIBadgeDetailsViewControllerPresenter.h"
#import "Constants.h"

@interface ABIBadgeDetailsViewController () <ABIDropDownComponentViewDelegate>

@property (weak, nonatomic) IBOutlet UILabel *userName;
@property (weak, nonatomic) IBOutlet UILabel *badgesReceivedTextLabel;
@property (weak, nonatomic) IBOutlet UITableView *badgesDetailTableView;
@property (weak, nonatomic) IBOutlet ABICustomBadgeScrollView *ABICustomBadgeScrollView;
@property (weak, nonatomic) IBOutlet ABIDropDownComponentView *badgesDownComponentView;
@property (weak, nonatomic) IBOutlet ABIDropDownComponentView *yearDownComponentView;

@property (strong, nonatomic) NSArray<ABISFBadgesDetailsNameWiseDataModel *> *rosterEarnBadges;
@property (strong, nonatomic) id<ABIBadgeDetailsViewControllerProtocol> presenter;
@property (strong, nonatomic) NSMutableArray<ABISFEarnBadgesDataModel *> *allBadges;
@property (strong, nonatomic) NSMutableArray<ABISFBadgesDetailsNameWiseDataModel *> *filterBadges;
@property (strong, nonatomic) NSString *selectedBadgeName;
@property (strong, nonatomic) NSNumber *selectedyear;
@property (assign, nonatomic) BOOL noDataRowShown;
@property (assign, nonatomic) NSInteger ShouldShowLoader;

@end
@implementation ABIBadgeDetailsViewController
- (void)viewDidLoad {
    [super viewDidLoad];
    [self initialSetup];
}

- (void)viewWillAppear:(BOOL)animated {
    [super viewWillAppear:animated];
}

- (void)dealloc {
    _badgesDownComponentView.delegate = nil;
    _badgesDownComponentView = nil;
    _yearDownComponentView.delegate = nil;
    _yearDownComponentView = nil;
    _rosterEarnBadges = nil;
    _presenter = nil;
    _allBadges = nil;
    _filterBadges = nil;
    _selectedyear = nil;
    _selectedBadgeName = nil;
}

#pragma mark - Public Method
- (void)setRosterEarnBadges:(NSArray<ABISFBadgesDetailsNameWiseDataModel *> *)rosterEarnBadges {
    _rosterEarnBadges = rosterEarnBadges;
    self.ABICustomBadgeScrollView.rosterEarnBadges = _rosterEarnBadges;
}

- (void)setABISFRosterDataModel:(ABISFRosterDataModel *)rosterDataModel {
    _rosterDataModel = rosterDataModel;
    self.userName.text = _rosterDataModel.rosterNameText;
}

#pragma mark -  Fetch Service - Update Data Source - Update UI

- (void)fetchServiceBadgesDetails {
    if ([AppDelegate isOffline]) {
        [UIViewController alertInNoNetworkConnection:self clickedOkButton:NULL];
    } else {
        __weak typeof(self) weakSelf = self;
        [CustomLoaderManager showLoader];
        [self.presenter fetchAndUpdateUIForAllEarnedBadgesDetailsAndUpdateUIWithRoster:self.rosterDataModel
                                                                              forYears:[ABIBusinessProtocol yearsForEarnedBadges]
                                                                       extraDependency:nil
                                                                             ascending:NO
                                                                            sortByKeys:nil
                                                                           failedBlock:^(NSError *error, NSDictionary *extraInfo) {
                                                                               [CustomLoaderManager hideLoader];
                                                                               [weakSelf updateUI];
                                                                           }
                                                                       completionBlock:^(NSMutableArray *results, NSDictionary *extraInfo) { [weakSelf updateDataSourceAndUI:results]; }];
    }
}

- (void)updateDataSourceAndUI:(NSMutableArray<ABISFEarnBadgesDataModel *> *)earnBadges {
    [self updateDataSource:earnBadges];
    [self updateUI];
}

- (void)updateDataSource:(NSMutableArray<ABISFEarnBadgesDataModel *> *)results {
    self.userName.text = self.rosterDataModel.rosterNameText;
    self.allBadges = results;
    self.filterBadges = [ABISFEarnBadgesDataModel groupedBadgesByPriority:self.allBadges];
}

- (void)updateUI {
    [self.badgesDetailTableView reloadData];
    self.ABICustomBadgeScrollView.rosterEarnBadges = [ABISFEarnBadgesDataModel groupedBadgesByPriority:self.allBadges];
    [self setupDropDownList];

    [self allUICoponeneHidden:NO];
}

- (void)setFilterBadges:(NSMutableArray<ABISFBadgesDetailsNameWiseDataModel *> *)filterBadges {
    _filterBadges = filterBadges;
    NSInteger totalCount = 0;
    for (ABISFBadgesDetailsNameWiseDataModel *model in _filterBadges) {
        if (model && [model isMemberOfClass:[ABISFBadgesDetailsNameWiseDataModel class]]) {
            if (model.byNameEarnedbadges.count)
                totalCount += model.byNameEarnedbadges.count;
        }
    }
    self.badgesReceivedTextLabel.text = [NSString stringWithFormat:@"Total Received: %ld", (long)totalCount];
}

#pragma mark - Privte Method

- (void)initialSetup {
    [self initialUISetup];
    [self fetchServiceBadgesDetails];
}

- (void)initialUISetup {
    self.noDataRowShown = NO;

    [self allUICoponeneHidden:YES];
        // UI decoration like Set Font, Text Color
    [self customUIDecoration];
        // Set up Navigation Page Title
    [self setNavigationPageTitle];
        // Set up Dropdown list
    [self setupDropDownList];
}

- (void)setNavigationPageTitle {

    self.title = [NSString badgeDetailsPageTitle]; // PAGE_TITLE_BADGE_DETAILS;
}

- (void)allUICoponeneHidden:(BOOL)isHidden {
    self.badgesDownComponentView.hidden = isHidden;
    self.yearDownComponentView.hidden = isHidden;
    self.userName.hidden = isHidden;
    self.badgesReceivedTextLabel.hidden = isHidden;
    self.badgesDetailTableView.hidden = isHidden;
    self.ABICustomBadgeScrollView.hidden = isHidden;
}
- (void)customUIDecoration {
    [self customizeBadgesDetailTableView];
    [self customizeUserName];
    [self customizeBadgesReceivedTextLabel];
}

- (void)customizeBadgesDetailTableView {
    self.badgesDetailTableView.estimatedRowHeight = 100.0;
    self.badgesDetailTableView.rowHeight = UITableViewAutomaticDimension;
}

- (void)customizeUserName {
    self.userName.textColor = [UIColor defaultTextDarkColor];
    [self.userName setFont:[UIFont fontHelvetica57Condensed:18.0f]];
}

- (void)customizeBadgesReceivedTextLabel {
    self.badgesReceivedTextLabel.textColor = [UIColor defaultTextDarkColor];
    [self.badgesReceivedTextLabel setFont:[UIFont fontHelvetica57Condensed:12.0f]];
    self.badgesReceivedTextLabel.text = @"";
}

- (void)setupDropDownList {
    [self setupBadgesDownComponentView];
    [self setupYearDownComponentView];
}

- (void)setupBadgesDownComponentView {
    self.badgesDownComponentView.dropDownTitle = DROP_DOWN_TITLE_VIEW_BY;
    self.badgesDownComponentView.dropDownListType = DropDownListBages;
    self.badgesDownComponentView.isBadge = YES;
    NSMutableArray *dropDownBadgesByName = [self.presenter dropDownBadgesByName:self.filterBadges];
    [self.badgesDownComponentView dropDownDataSource:dropDownBadgesByName selectedItem:kALL_Badges displayTextKey:nil];
    self.badgesDownComponentView.delegate = self;
}

- (void)setupYearDownComponentView {

    self.yearDownComponentView.dropDownTitle = DROP_DOWN_TITLE_FOR_YEAR;
    self.yearDownComponentView.dropDownListType = DropDownListYear;
    self.yearDownComponentView.isBadge = YES;
    [self.yearDownComponentView dropDownDataSource:[self.presenter yearDropDownLists] selectedItem:kALL displayTextKey:nil];
    self.yearDownComponentView.delegate = self;
}

#pragma mark - Accessors
- (id<ABIBadgeDetailsViewControllerProtocol>)presenter {
    if (!_presenter) {
        _presenter = [ABIBadgeDetailsViewControllerPresenter new];
    }
    return _presenter;
}

#pragma mark - DataSource / Delegate

#pragma mark - TableView DataSource Methods
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    NSInteger numberOfRowsInSection = [self.presenter numberOfIncentive:section nameWiseBagdes:self.filterBadges];

    return numberOfRowsInSection > 0 ? numberOfRowsInSection : 1;
}

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
    return self.filterBadges.count > 0 ? self.filterBadges.count : (self.noDataRowShown) ? 1 : 0;
}

- (CGFloat)tableView:(UITableView *)tableView heightForFooterInSection:(NSInteger)section {
    return 2.0f;
}

- (CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section {
    return 2.0f;
}

- (UIView *)tableView:(UITableView *)tableView viewForFooterInSection:(NSInteger)section {
    UIView *headerView = [[UIView alloc] initWithFrame:CGRectMake(0, 0, tableView.frame.size.width, DEFAULT_CELL_PADDING)];
    headerView.layer.cornerRadius = 1.0f;
    headerView.backgroundColor = [UIColor clearColor];
    return headerView;
}

- (UIView *)tableView:(UITableView *)tableView viewForHeaderInSection:(NSInteger)section {
    UIView *headerView = [[UIView alloc] initWithFrame:CGRectMake(0, 0, tableView.frame.size.width, DEFAULT_CELL_PADDING)];
    headerView.layer.cornerRadius = 1.0f;
    headerView.backgroundColor = [UIColor clearColor];
    return headerView;
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath {
    return 70.0f;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    Boolean hideSeperator = NO;
    static NSString *cellIdentifier = @"myCell";
    ABIBadgeDetailTableViewCell *cell = (ABIBadgeDetailTableViewCell *)[tableView dequeueReusableCellWithIdentifier:cellIdentifier];
    if (cell == nil) {
        cell = [[ABIBadgeDetailTableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:cellIdentifier];
    }
    cell.backgroundColor = [UIColor clearColor];
    ABISFBadgesDetailsNameWiseDataModel *badgesDetailsNameWiseDataModel =
    [self.presenter badgesDetailsNameWiseDataModelAtSection:indexPath.section nameWiseBagdes:self.filterBadges];

    if ([badgesDetailsNameWiseDataModel isMemberOfClass:[ABISFBadgesDetailsNameWiseDataModel class]] &&
        [badgesDetailsNameWiseDataModel respondsToSelector:@selector(byNameEarnedbadges)]) {
        NSArray *byNameEarnedbadges = badgesDetailsNameWiseDataModel.byNameEarnedbadges;

        if (byNameEarnedbadges.count) {
            ABISFEarnBadgesDataModel *earnBadgesDataModel = [NSArray objectFromArray:byNameEarnedbadges atIndex:indexPath.row];
            NSInteger numberOfRowsInSection = [self.presenter numberOfIncentive:indexPath.section nameWiseBagdes:self.filterBadges];
            NSInteger _lastRow = numberOfRowsInSection - 1;
            hideSeperator = (indexPath.row == _lastRow);

            if (earnBadgesDataModel)
                [cell updateCellAtindexPath:indexPath
               withABISFEarnBadgesDataModel:earnBadgesDataModel
                     totalGroupedBadgeCount:badgesDetailsNameWiseDataModel.numberOfEarnBadges
                          isSeperatorHidden:hideSeperator];
        }
    } else {
        [cell updateCellAtindexPath:indexPath withABISFEarnBadgesDataModel:nil totalGroupedBadgeCount:nil isSeperatorHidden:YES];
    }
    [cell setBackgroundColor:[UIColor whiteColorABI]];
    cell.selectionStyle = UITableViewCellSelectionStyleNone;
    return cell;
}
#pragma mark - ABIDropDownComponentViewDelegate
- (void)dropDownComponentView:(ABIDropDownComponentView *)dropDownComponentView selectedItem:(id)selectedItem indexPath:(NSIndexPath *)indexPath {
    self.noDataRowShown = YES;
    [CustomLoaderManager showLoader];

    switch (dropDownComponentView.dropDownListType) {
        case DropDownListBages: {
            self.selectedBadgeName = selectedItem;

        } break;
        case DropDownListYear: {
            self.selectedyear = @([selectedItem integerValue]);
        }

            break;
        default: break;
    }
    self.filterBadges = [self.presenter filterBadgesByBadgesName:self.selectedBadgeName year:self.selectedyear allEarnedBadgesDetails:self.allBadges];
    [self.badgesDetailTableView reloadData];
    [CustomLoaderManager hideLoader];
}
@end
