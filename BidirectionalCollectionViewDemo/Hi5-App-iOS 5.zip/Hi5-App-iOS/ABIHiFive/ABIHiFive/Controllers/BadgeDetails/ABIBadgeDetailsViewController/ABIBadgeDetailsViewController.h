    //
    //  ABIBadgeDetailsViewController.h
    //  ABIHiFive
    //
    //  Created by Prsenjit Goswami on 11/08/16.
    //  Copyright © 2016 Cognizant. All rights reserved.
    //
#import "ABIBaseViewController.h"
#import <UIKit/UIKit.h>
@interface ABIBadgeDetailsViewController : ABIBaseViewController

@property (strong, nonatomic) ABISFRosterDataModel *rosterDataModel;
@end
