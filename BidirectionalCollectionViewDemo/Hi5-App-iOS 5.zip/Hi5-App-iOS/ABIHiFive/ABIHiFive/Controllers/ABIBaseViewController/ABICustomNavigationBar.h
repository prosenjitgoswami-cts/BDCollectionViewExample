    //
    //  ABICustomNavigationBar.h
    //  ABIHiFive
    //
    //  Created by Prsenjit Goswami on 31/08/16.
    //  Copyright © 2016 Cognizant. All rights reserved.
    //
#import <UIKit/UIKit.h>
@interface ABICustomNavigationBar : UIView
@end
