    //
    //  PageABIBaseViewController.h
    //  ABIHiFive
    //
    //  Created by Prsenjit Goswami on 11/06/16.
    //  Copyright © 2016 Cognizant. All rights reserved.
    //
#import "Constants.h"
#import <UIKit/UIKit.h>
@interface ABIBaseViewController : UIViewController
@property (assign, nonatomic) PageFlow pageFlow;
- (void)updateAnnouncementsBell:(void (^)(NSArray *results))completion;
- (void)clickedToggleMenu:(UIButton *)sender;
+ (void)emptyBarItem:(UIViewController *)vc;
@end
