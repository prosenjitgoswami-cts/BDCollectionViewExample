    //
    //  ABICustomNavigationBar.m
    //  ABIHiFive
    //
    //  Created by Prsenjit Goswami on 31/08/16.
    //  Copyright © 2016 Cognizant. All rights reserved.
    //
#import "ABICustomNavigationBar.h"
@implementation ABICustomNavigationBar
    //- (void)touchesBegan:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event {
    //
    //
    //	UIView *touchView = [[touches allObjects]firstObject];
    //
    //
    //}
@end
