    //
    //  PageABIBaseViewController.m
    //  ABIHiFive
    //
    //  Created by Prsenjit Goswami on 11/06/16.
    //  Copyright © 2016 Cognizant. All rights reserved.
    //
#import "ABIBaseViewController.h"
#import "ABISFAnnouncementDataModel.h"
#import "ABISFDataFetcherService.h"
#import "ABIAnnouncementDetailsPageViewController.h"
#import "ABIAnnouncementsPopoverViewController.h"
#import "ABIChatterFileViewerViewController.h"
#import "ABICustomNavigationBar.h"
#import "LeftEdgeSlideMenuContainerViewController.h"
    //#import "PeerKPIsPageViewController.h"
#import "ABIProfilePageViewController.h"
@interface ABIBaseViewController () <AnnouncementsDataModelsDelegate>
@property (nonatomic, assign) BOOL isTest;
;
@property (nonatomic, strong) NSArray *announcementsDataModelVCs;
@property (nonatomic, strong) ABIAnnouncementsPopoverViewController *announcementsDataModelVC;
@end
@implementation ABIBaseViewController

#pragma mark -  Viewcontroller Life Cycle
- (void)viewDidLoad {
    [super viewDidLoad];
    self.view.backgroundColor = [UIColor defaultPageBGColor];
    [self createButtonInNavigationBar];
    [self addLeftEdgeGesture];
}
- (void)viewWillAppear:(BOOL)animated {
    [super viewWillAppear:animated];
    [self addLeftEdgeGesture];
}
- (void)createButtonInNavigationBar {
        // http://stackoverflow.com/questions/23853617/uinavigationbar-hide-back-button-text
    if (![ABISFDataFetcherService shareInstance].notificationBellImage)
        [ABISFDataFetcherService shareInstance].notificationBellImage = [UIImage imageNamed:notification_inactive];
    if ([self.navigationController.topViewController isKindOfClass:[ABIChatterFileViewerViewController class]]) {
            //        [self commonHeaderWithLeftMenuButtonImage:[UIImage imageNamed:back_IMAGE] rightMenuButtonImage:nil];
        [self commonHeaderWithLeftMenuButtonImage:nil rightMenuButtonImage:[ABISFDataFetcherService shareInstance].notificationBellImage];
    } else if ([self.navigationController.topViewController isKindOfClass:[ABIAnnouncementDetailsPageViewController class]]) {
        [self commonHeaderWithLeftMenuButtonImage:nil rightMenuButtonImage:[ABISFDataFetcherService shareInstance].notificationBellImage];
            //        [self commonHeaderWithLeftMenuButtonImage:[UIImage imageNamed:back_IMAGE] rightMenuButtonImage:[ABISFDataFetcherService
            //        shareInstance].notificationBellImage];
    } else {
        if (self.navigationController.viewControllers.count > 1) {
            [self commonHeaderWithLeftMenuButtonImage:nil rightMenuButtonImage:[ABISFDataFetcherService shareInstance].notificationBellImage];
        } else {
            [self commonHeaderWithLeftMenuButtonImage:[UIImage imageNamed:menu_icon]
                                 rightMenuButtonImage:[ABISFDataFetcherService shareInstance].notificationBellImage];
        }
    }
    [self navigationBarCustomiseABI];
}
+ (void)emptyBarItem:(UIViewController *)vc{
        //    vc.navigationItem.backBarButtonItem = [[UIBarButtonItem alloc] initWithTitle:STATIC_TEXT_EMPTY_STRING
        //    style:vc.navigationItem.backBarButtonItem.style target:nil action:nil];
};

#pragma mark -  Private Method
- (void)addLeftEdgeGesture {
    UIScreenEdgePanGestureRecognizer *leftEdgeGesture =
    [[UIScreenEdgePanGestureRecognizer alloc] initWithTarget:self action:@selector(handleLeftEdgeGesture:)];
    leftEdgeGesture.edges = UIRectEdgeLeft;
    leftEdgeGesture.delegate = self.navigationController.interactivePopGestureRecognizer.delegate;
    [self.view addGestureRecognizer:leftEdgeGesture];
    if ([self.navigationController respondsToSelector:@selector(interactivePopGestureRecognizer)]) {
        self.navigationController.interactivePopGestureRecognizer.enabled = NO;
    }
}
- (void)addLeftMenuButtonWithImage:(UIImage *)buttonImage {
    [self addNavigationItem:buttonImage addTarget:self action:@selector(clickedToggleMenu:) customBarButtonItem:BarButtonItemLeft];
}
- (void)addRightMenuButtonWithImage:(UIImage *)buttonImage {
    [self addNavigationItem:buttonImage addTarget:self action:@selector(clickedNotificationButton:) customBarButtonItem:BarButtonItemRight];
}
- (void)commonHeaderWithLeftMenuButtonImage:(UIImage *)leftMenuButtonImage rightMenuButtonImage:(UIImage *)rightMenuButtonImage {
    if (leftMenuButtonImage) {
        [self addLeftMenuButtonWithImage:leftMenuButtonImage];
    }
    if (rightMenuButtonImage) {
        [self addRightMenuButtonWithImage:rightMenuButtonImage];
    }
}
#pragma mark UIScreenEdgePanGestureRecognizer
- (void)handleLeftEdgeGesture:(UIScreenEdgePanGestureRecognizer *)gesture {
        // Get the current view we are touching
        // UIView *view = [self.view hitTest:[gesture locationInView:gesture.view] withEvent:nil];
    if (UIGestureRecognizerStateBegan == gesture.state) {
        [[self sideMenuController] toggleMenu];
    }
}

#pragma mark -  IBAction
    //- (void)clickedNotificationButton:(UIButton *)sender {
    //    if ([AppDelegate isOffline]) {
    //        [UIViewController alertInNoNetworkConnection:self clickedOkButton:NULL];
    //    } else {
    //        [CustomLoaderManager showLoader];
    //        [self showNotificationPopOverWithAnnouncementsDrtails];
    //        [self.announcementsDataModelVC hide];
    //        __weak typeof(self) weakSelf = self;
    //
    //        [self updateAnnouncementsBell:^(NSArray *results) {
    //            if (results && results.count) {
    //                [weakSelf.announcementsDataModelVC setAnnouncements:results];
    //                [self.announcementsDataModelVC show];
    //
    //                [CustomLoaderManager hideLoader];
    //
    //            } else {
    //                [CustomLoaderManager hideLoader];
    //                [self.announcementsDataModelVC toggolVisibility];
    //                [weakSelf alertWithMessage:ALT_MSG_NO_ANNOUANCE];
    //            }
    //        }];
    //    }
    //}

- (void)clickedNotificationButton:(UIButton *)sender {
    if ([AppDelegate isOffline]) {
        [UIViewController alertInNoNetworkConnection:self clickedOkButton:NULL];
    } else {
        [CustomLoaderManager showLoader];
        [self showNotificationPopOverWithAnnouncementsDrtails];
        [self.announcementsDataModelVC hide];
        __weak typeof(self) weakSelf = self;

        [self updateAnnouncementsBell:^(NSArray *results) {
            if (results && results.count) {
                [weakSelf.announcementsDataModelVC setAnnouncements:results];
                [self.announcementsDataModelVC show];

            } else {
                [weakSelf.announcementsDataModelVC setAnnouncements:results];

                [self.announcementsDataModelVC show];
                [CustomLoaderManager hideLoader];
                    //                [self.announcementsDataModelVC toggolVisibility];
                    //                [weakSelf alertWithMessage:ALT_MSG_NO_ANNOUANCE];
            }
            [CustomLoaderManager hideLoader];

        }];
    }
}
- (void)clickedToggleMenu:(UIButton *)sender {
    if ([self.navigationController.topViewController isKindOfClass:[ABIAnnouncementDetailsPageViewController class]])
        [self.navigationController popViewControllerAnimated:NO];
        // [self dismissViewControllerAnimated:YES completion:nil];
    else
        [[self sideMenuController] toggleMenu];
}
- (void)showNotificationPopOverWithAnnouncementsDrtails {
    self.announcementsDataModelVC = [[ABIAnnouncementsPopoverViewController alloc] init];
    self.announcementsDataModelVC.delegate = self;
    [self.announcementsDataModelVC toggolVisibility];
}

#pragma mark -
#pragma mark AnnouncementsDataModelsDelegate
- (void)didTapOnAssessment:(NSArray *)selectedAssessment atIndex:(NSInteger)index {
    ABIAnnouncementDetailsPageViewController *announcementDetailsContainerViewController =
    (ABIAnnouncementDetailsPageViewController *)[UIViewController instantiateViewControllerWithIdentifier:STORY_BOARD_ID_ANNOUNCEMENT_VC];
    if ([self isKindOfClass:[ABIAnnouncementDetailsPageViewController class]]) {
        announcementDetailsContainerViewController = (ABIAnnouncementDetailsPageViewController *)self;
    }
    [announcementDetailsContainerViewController showAnnouncements:selectedAssessment atIndex:index];
    if (![self isKindOfClass:[ABIAnnouncementDetailsPageViewController class]]) {
        announcementDetailsContainerViewController.presentedVC = self.navigationController;
        [self.navigationController pushViewController:announcementDetailsContainerViewController animated:NO];
    }
}
- (void)updateAnnouncementIcon:(BOOL)isActive {
    [ABISFDataFetcherService shareInstance].notificationBellImage =
    isActive ? [UIImage imageNamed:notification_active] : [UIImage imageNamed:notification_inactive];
    [self addRightMenuButtonWithImage:[ABISFDataFetcherService shareInstance].notificationBellImage];
}

#pragma mark -  Public Method
/*!
 *  Update the Notification bell image
 *
 *  @param isActive announcement are available, then it Active
 */
- (void)updateAnnouncementsBell:(void (^)(NSArray *results))completion {
    __weak typeof(self) weakSelf = self;
    [ABISFDataFetcherService fetchAndProcessAnnouncementsDetailsWithExtraDependency:nil
                                                                          ascending:NO
                                                                         sortByKeys:nil
                                                                        failedBlock:^(NSError *error, NSDictionary *extraInfo) {
                                                                            if (completion)
                                                                                completion(nil);
                                                                        }
                                                                    completionBlock:^(NSArray *results, NSDictionary *extraInfo) {
                                                                        [weakSelf updateAnnouncementIcon:(results != nil)];
                                                                        if (completion)
                                                                            completion(results);
                                                                    }];
}

@end
