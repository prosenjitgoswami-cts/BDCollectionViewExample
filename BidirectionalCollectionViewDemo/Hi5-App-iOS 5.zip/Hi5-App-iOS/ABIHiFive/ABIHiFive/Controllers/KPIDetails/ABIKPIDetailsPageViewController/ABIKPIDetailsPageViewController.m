    //
    //  ABIKPIDetailsPageViewController.m
    //  ABIHiFive
    //
    //  Created by Prsenjit Goswami on 30/06/16.
    //  Copyright © 2016 Cognizant. All rights reserved.
    //
#import "ABIKPIDetailsPageViewController.h"
#import "ABIBusinessProtocol.h"
#import "ABIDropDownComponentView.h"
#import "ABISFDataFetcherService.h"
#import "ABISFKPIsDetailsDataModel.h"
#import "ABISFPeerRankingDataModel.h"
#import "CustomTabPagerViewController.h"
#import "ABIKPIDetailViewController.h"
#import "ABIKPIDetailViewControllerPresenter.h"
#import "ABIPeerRankingPageViewControllerPresenter.h"

@interface ABIKPIDetailsPageViewController () <ABIDropDownComponentViewDelegate>

@property (strong, nonatomic) CustomTabPagerViewController *tabPageViewController;
@property (assign, nonatomic) NSInteger currentIndex;
@property (weak, nonatomic) IBOutlet UIView *tabPageViewContainer;
@property (weak, nonatomic) IBOutlet UIView *profileDetailsView;
@property (weak, nonatomic) IBOutlet UILabel *userNameLabel;
@property (weak, nonatomic) IBOutlet UILabel *pointsLabel;
@property (weak, nonatomic) IBOutlet UILabel *pointStaticTextLabel;
@property (weak, nonatomic) IBOutlet UIImageView *KpiDetailsImageBorderView;
@property (weak, nonatomic) IBOutlet UIImageView *KpiDetailsUserProfileView;
@property (weak, nonatomic) IBOutlet ABIDropDownComponentView *dropDownComponent;
@property (strong, nonatomic) UIImageView *peerRankingImageView;
@property (strong, nonatomic) UILabel *rankLabel;

@property (strong, nonatomic) ABISFRosterDataModel *rosterDataModel;
@property (strong, nonatomic) ABISFPeerRankingDataModel *peerUser;
@property (strong, nonatomic) ABISFIncentiveDataModel *selectedIncentive;
@property (strong, nonatomic) ABIKPIDetailViewController *selectedVC;
@property (assign, nonatomic) KPIDetailsPageType kpiDetailsPageType;
@property (assign, nonatomic) NSDictionary *extraDependency;

@property (strong, nonatomic) id<ABIKPIDetailViewControllerProtocol> presenter;
@property (strong, nonatomic) NSMutableArray *fiterKPIsDetails;

@property (strong, nonatomic) NSArray *constraintsUserNameWidth;

@end

@implementation ABIKPIDetailsPageViewController

#pragma mark -  View Controller Life Cycle
- (void)viewDidLoad {
    [super viewDidLoad];
    [self initialSetup];
}

- (void)viewWillAppear:(BOOL)animated {
    [super viewWillAppear:animated];
}

- (void)dealloc {

    [self cleanup];
}

#pragma mark -  Public Method
/**
 *   Initial the KPI details Page
 *
 *  @param incentive          Selected Incentive
 *  @param incentiveDetails   All Incentive of Roster
 *  @param roster             Roster (ABISFRosterDataModel referance)
 *  @param peerUser           Peer user (ABISFPeerRankingDataModel referance) (It applicable for when KPI details page navigate from PeerRankingPage
 othre
 * wise 'nil')
 *  @param kpiDetailsPageType NavigationType. It is identify that the KPI details navigate from a Page.

 KIP Details navigate from 2 Page:
 1.Profile Page
 2.Peer Rank page

 ----------------------------------------- Profile Page ----------------------------------------
 - Case 1: Profile Page [Login as Manager(SD) or Login as Manager(DM)]-> ABIKPIDetailsPageViewController :KPIDetailsPageFromLogInUserProfilePage

 - Case 2: Login as Manager(SD), In profile page HAS 2 tab- i)My Incentive, ii)My DMs.
 Click On My DMs -> Profile Page -> KPIDetailsPage:KPIDetailsPageFromReporteeProfilePageOfLogInUser

 ----------------------------------------- Peer Rank page----------------------------------------
 - Case 3: Login as Manager(SD), In Peer Rank page has 2 tab- i)My Peer Rank, ii)My DMs Rank.
 Click 'i)My Peer Rank' -> KPIDetailsPage:KPIDetailsFromMyPeerRankingTab

 - Case 4: Login as Manager(SD), In Peer Rank page has 2 Tab- i)My Peer Rank, ii)My DMs Rank.
 Click 'i)My DMs Rank' -> KPIDetailsFromMyDMsPeerRankingTab

 *  @param extraDependency Pass extraDependency is neeed.

 **************************************** NOTE **********************************************

 - User Profile Details below Dropdown list is hidden- ONLY FOR 'Case 1'. OTHERWISE IT IS VISIBLE
 - In Rank label: Static text will such as, 'Overall Rank'- ONLY FOR 'Case 4'. OTHERWISE It will be 'Rank'.
 */
- (void)kpiDetailsForIncentive:(ABISFIncentiveDataModel *)incentive
              incentiveDetails:(NSMutableArray<ABISFIncentiveDataModel *> *)incentiveDetails
                     forRoster:(ABISFRosterDataModel *)roster
                    OrPeerUser:(ABISFPeerRankingDataModel *)peerUser
            kpiDetailsPageType:(KPIDetailsPageType)kpiDetailsPageType
               extraDependency:(NSDictionary *)extraDependency {
    self.rosterDataModel = roster;
    self.selectedIncentive = incentive;
    self.kpiDetailsPageType = kpiDetailsPageType;
    self.peerUser = peerUser;
    self.extraDependency = extraDependency;

    if (self.peerUser.peerRoster) {
        self.rosterDataModel = self.peerUser.peerRoster;
    }
}

#pragma mark -  Custom Accessor
- (UIImageView *)peerRankingImageView {
    if (!_peerRankingImageView) {
        _peerRankingImageView = [[UIImageView alloc] init];
        _peerRankingImageView.translatesAutoresizingMaskIntoConstraints = NO;
        [_peerRankingImageView setImage:[UIImage imageNamed:@"rankImage"]];
    }
    return _peerRankingImageView;
}
- (UILabel *)rankLabel {
    if (!_rankLabel) {
        _rankLabel = [[UILabel alloc] init];
        _rankLabel.translatesAutoresizingMaskIntoConstraints = NO;
        _rankLabel.textAlignment = NSTextAlignmentCenter;
    }
    return _rankLabel;
}

- (id<ABIKPIDetailViewControllerProtocol>)presenter {
    if (!_presenter) {
        _presenter = [ABIKPIDetailViewControllerPresenter new];
    }
    return _presenter;
}

- (NSMutableArray *)fiterKPIsDetails {
    if (!_fiterKPIsDetails) {
        _fiterKPIsDetails = [NSMutableArray array];
    }

    return _fiterKPIsDetails;
}
- (CustomTabPagerViewController *)tabPageViewController {
    if (!_tabPageViewController) {
        _tabPageViewController = [CustomTabPagerViewController initialisedTabPageViewController:self];
    }
    return _tabPageViewController;
}

#pragma mark -  Fetch Service - Update Data Source - Update UI

- (void)fetchRosterIncentiveAndPopulateDropDownList {

    if ([AppDelegate isOffline]) {
        [UIViewController alertInNoNetworkConnection:self clickedOkButton:NULL];
    } else {

        [CustomLoaderManager showLoader];
        __weak typeof(self) weakSelf = self;

        [self updateUserProfileImage];

        [self.presenter incentiveDetailsOfRoster:self.rosterDataModel
                                     failedBlock:^(NSError *error, NSDictionary *extraInfo) {
                                         [CustomLoaderManager hideLoader];

                                     }
                                 completionBlock:^(NSMutableArray<ABISFIncentiveDataModel *> *_Nullable incentives, NSDictionary *_Nullable extraInfo) {
                                         //		if(incentives.count && !weakSelf.selectedIncentive )  {
                                         //			weakSelf.selectedIncentive = [incentives firstObject];
                                         //}

                                     [weakSelf updateDropDownList:incentives];
                                 }];
    }
}

- (void)getKPIsDetailsForIncentive:(ABISFIncentiveDataModel *)incentive {
    if ([AppDelegate isOffline]) {
        [UIViewController alertInNoNetworkConnection:self clickedOkButton:NULL];
    } else {
        [CustomLoaderManager showLoader];
        __weak typeof(self) weakSelf = self;
        [self.presenter getUpdatedKPIsDetailsForIncentive:incentive
                                                forRoster:self.rosterDataModel
                                              failedBlock:^(NSError *error, NSDictionary *extraInfo) {

                                                  [weakSelf updateUIWithSelectedIncentive:nil];
                                                  [CustomLoaderManager hideLoader];
                                              }
                                          completionBlock:^(ABISFIncentiveDataModel *updatedIncentive) {
                                              if (updatedIncentive) {
                                                  NSMutableArray *channelKpis = updatedIncentive.kpisDetails;
                                                  [self.fiterKPIsDetails removeAllObjects];
                                                  _fiterKPIsDetails = nil;

                                                  if (channelKpis.count) {
                                                      NSDictionary *dict = [channelKpis firstObject];
                                                      for (NSString *key in dict) {
                                                          NSMutableArray *channels = dict[key];
                                                          if (channels.count)
                                                              [self.fiterKPIsDetails addObject:channels];
                                                      }
                                                  }
                                                  [weakSelf updateUIWithSelectedIncentive:updatedIncentive];
                                              } else {
                                                  [CustomLoaderManager hideLoader];
                                              }
                                          }];
    }
}

#pragma mark Update UI
- (void)updateUserProfileImage {

    NSString *rosterImageURLString = self.rosterDataModel.rosterImageURLString;
    [self.KpiDetailsUserProfileView setABIUserImageWithURL:rosterImageURLString];
}

- (void)updateDropDownList:(NSMutableArray<ABISFIncentiveDataModel *> *)rosterAssingedIncentives {

    [self.dropDownComponent dropDownDataSource:rosterAssingedIncentives
                                  selectedItem:self.selectedIncentive
                                displayTextKey:[ABIBusinessProtocol dropDownDisplayKeyIncentive]];
}
- (void)updateDataOnChannelChange:(NSInteger)channelIndex
                 filterKPIDetails:(nonnull NSMutableArray *)filterKPIDetails
          kpiDetailViewController:(nonnull ABIKPIDetailViewController *)kpiDetailViewController
                           roster:(nonnull ABISFRosterDataModel *)roster {
    if ([NSArray isValidArray:filterKPIDetails] && kpiDetailViewController && channelIndex >= 0) {
        NSMutableArray *channelFiterKPIsDetails = [NSArray objectFromArray:filterKPIDetails atIndex:channelIndex];
        [kpiDetailViewController updateChannelKPIsDetails:channelFiterKPIsDetails
                                                   roster:roster
                                       kpiDetailsPageType:self.kpiDetailsPageType
                                          extraDependency:self.extraDependency];
    }
}
- (void)updateUIWithSelectedIncentive:(ABISFIncentiveDataModel *)incentive {

    NSString *incentivePointe = [NSString stringWithFormat:@"%ld", (long)[incentive.overAllIncentiveProgress integerValue]];
    self.pointsLabel.text = [incentivePointe nullStringTextCorrection];

    NSAttributedString *decoratedRankText = [NSAttributedString
                                             decoratedRankStringWithRankValueNumber:incentive.rank
                                             staticRankText:(self.kpiDetailsPageType == KPIDetailsFromMyDMsPeerRankingTab) ? STATIC_TEXT_OVER_ALL_RANK
                                             : STATIC_TEXT_RANK];
    [self.rankLabel setAttributedText:decoratedRankText];

    [self updateDataOnChannelChange:self.currentIndex
                   filterKPIDetails:self.fiterKPIsDetails
            kpiDetailViewController:self.selectedVC
                             roster:self.rosterDataModel];
    if (self.fiterKPIsDetails.count) {
        [self.tabPageViewController reloadData];
        [self.tabPageViewController show];
        [_tabPageViewController repositionTab:self.currentIndex];
    } else {
        [self.tabPageViewController hide];
    }
    self.pointsLabel.hidden = [NSString isNULLString:incentivePointe];
    self.pointStaticTextLabel.hidden = self.pointsLabel.hidden;
    self.rankLabel.hidden = ![NSString isNULLString:decoratedRankText];
    self.peerRankingImageView.hidden = self.rankLabel.hidden;
    self.tabPageViewContainer.hidden = !self.fiterKPIsDetails.count;

    [self setupConditionalUI];
    [CustomLoaderManager hideLoader];
}

#pragma mark -  Private Method

/**
 * InitialSetup
 */
- (void)initialSetup {
    self.currentIndex = 0;
    [self initialUISetup];
    [self fetchRosterIncentiveAndPopulateDropDownList];
}

/**
 * UI related Like- Set Navigation Title, UI decoration, UI Creation, like Set Font, Text Color, Create UI etc...
 */
- (void)initialUISetup {

        // Set Navigation Page Title

    [self setNavigationPageTitle];

        // Create UI Elment on run time
    [self createAndAddUI];
        // UI decoration like Set Font, Text Color

    [self customUIDecoration];

        // Set up Dropdown list
    [self setUpdownList];

        // Initial All UI element is hidden, Visible after data fetched
    [self allUICoponeneHidden:YES];
}

/**
 * Set Navigation Page Title
 */
- (void)setNavigationPageTitle {

    NSString *titleText = @"";

    if (self.peerUser.peerRoster) {
        titleText = [NSString peerKPIsPageTitle:self.rosterDataModel isCurrentUser:self.peerUser.isCurrentUser];
    } else {
        titleText = [NSString kpiDetailsPageTitle:self.rosterDataModel];
    }
    self.title = titleText;
}

/**
 * Create UI Element
 */
- (void)createAndAddUI {
    [self createRankLabel];
    [self createAndAddTabPageViewController];
    [self addConstrains];
}
- (void)createAndAddTabPageViewController {
    [self addChildViewController:self.tabPageViewController];
    [self.tabPageViewContainer addSubview:self.tabPageViewController.view];
    [self didMoveToParentViewController:self.tabPageViewController];
}
- (void)createRankLabel {
    [self.profileDetailsView addSubview:self.peerRankingImageView];
    [self.profileDetailsView addSubview:self.rankLabel];
    NSDictionary *views = @{
                            @"profileDetailsView" : self.profileDetailsView,
                            @"userNameLabel" : self.userNameLabel,
                            @"peerRankingImageView" : self.peerRankingImageView,
                            @"rankLabel" : self.rankLabel
                            };
    [self.profileDetailsView addConstraints:[NSLayoutConstraint constraintsWithVisualFormat:@"H:[rankLabel]-40-|" options:0 metrics:nil views:views]];
    [self.profileDetailsView addConstraints:[NSLayoutConstraint constraintsWithVisualFormat:@"V:[rankLabel(17)]" options:0 metrics:nil views:views]];
    [self.profileDetailsView addConstraint:[NSLayoutConstraint constraintWithItem:self.peerRankingImageView
                                                                        attribute:NSLayoutAttributeWidth
                                                                        relatedBy:NSLayoutRelationEqual
                                                                           toItem:self.rankLabel
                                                                        attribute:NSLayoutAttributeWidth
                                                                       multiplier:1
                                                                         constant:40.0f]];
    [self.profileDetailsView addConstraint:[NSLayoutConstraint constraintWithItem:self.peerRankingImageView
                                                                        attribute:NSLayoutAttributeHeight
                                                                        relatedBy:NSLayoutRelationEqual
                                                                           toItem:self.rankLabel
                                                                        attribute:NSLayoutAttributeHeight
                                                                       multiplier:1
                                                                         constant:4.0f]];
    [self.profileDetailsView addConstraint:[NSLayoutConstraint constraintWithItem:self.peerRankingImageView
                                                                        attribute:NSLayoutAttributeCenterX
                                                                        relatedBy:NSLayoutRelationEqual
                                                                           toItem:self.rankLabel
                                                                        attribute:NSLayoutAttributeCenterX
                                                                       multiplier:1
                                                                         constant:0]];
    [self.profileDetailsView addConstraint:[NSLayoutConstraint constraintWithItem:self.peerRankingImageView
                                                                        attribute:NSLayoutAttributeCenterY
                                                                        relatedBy:NSLayoutRelationEqual
                                                                           toItem:self.rankLabel
                                                                        attribute:NSLayoutAttributeCenterY
                                                                       multiplier:1
                                                                         constant:1]];
    [self.profileDetailsView addConstraint:[NSLayoutConstraint constraintWithItem:self.rankLabel
                                                                        attribute:NSLayoutAttributeTop
                                                                        relatedBy:NSLayoutRelationEqual
                                                                           toItem:self.userNameLabel
                                                                        attribute:NSLayoutAttributeTop
                                                                       multiplier:1
                                                                         constant:1]];

    NSNumber *width =
    (self.kpiDetailsPageType == KPIDetailsFromMyDMsPeerRankingTab) ? (IS_IPHONE_5_LESS ? @(60) : @(145)) : (IS_IPHONE_5_LESS ? @(95) : @(180));

    NSDictionary *metrics = @{ @"width" : width };

    self.constraintsUserNameWidth =
    [NSLayoutConstraint constraintsWithVisualFormat:@"H:[userNameLabel(<=width)]" options:0 metrics:metrics views:views];
    [self.profileDetailsView addConstraints:self.constraintsUserNameWidth];
        //		if ([AppDelegate appdelegateShareInstance].globalCurrentPageFlow != PageFlowAsMyDMAsSDLogin)
    if (self.kpiDetailsPageType == KPIDetailsPageFromLogInUserProfilePage) {
        [self.profileDetailsView
         addConstraints:[NSLayoutConstraint constraintsWithVisualFormat:@"V:[profileDetailsView(0)]" options:0 metrics:nil views:views]];
    }
    [self.view layoutIfNeeded];
}

/**
 * Add Constrains
 */
- (void)addConstrains {
    NSDictionary *views = @{ @"tabPageViewController" : self.tabPageViewController.view };
    [self.tabPageViewContainer
     addConstraints:[NSLayoutConstraint constraintsWithVisualFormat:@"H:|-0@999-[tabPageViewController]-0@999-|" options:0 metrics:nil views:views]];
    [self.tabPageViewContainer
     addConstraints:[NSLayoutConstraint constraintsWithVisualFormat:@"V:|-0@999-[tabPageViewController]-0@999-|" options:0 metrics:nil views:views]];
}

/**
 * UI decoration like Set Font, Text Color etc...
 */
- (void)customUIDecoration {
    [self customiseUserNameLabel];
    [self customisePointsLabel];
    [self customiseKpiDetailsImageBorderView];
    [self customisePointStaticTextLabel];
}

- (void)customiseUserNameLabel {
    self.userNameLabel.text = _rosterDataModel.rosterNameText;
    self.userNameLabel.font = PEER_PROFILE_PROFILE_USER_NAME_FONT_SIZE;
    self.userNameLabel.textColor = [UIColor defaultTextDarkColor];
}

- (void)customisePointsLabel {
    self.pointsLabel.font = PEER_PROFILE_POINTS_FONT_SIZE;
    self.pointsLabel.textColor = [UIColor defaultTextDarkColor];
}

- (void)customiseKpiDetailsImageBorderView {
    self.KpiDetailsImageBorderView.image = [UIImage imageABIOuterCircle];
    self.KpiDetailsUserProfileView.layer.cornerRadius = self.KpiDetailsUserProfileView.frame.size.width / 2;
    self.KpiDetailsImageBorderView.layer.cornerRadius = self.KpiDetailsImageBorderView.frame.size.width / 2;
    self.KpiDetailsImageBorderView.clipsToBounds = YES;
    self.KpiDetailsUserProfileView.clipsToBounds = YES;
}

- (void)customisePointStaticTextLabel {
    self.pointStaticTextLabel.font = PEER_PROFILE_POINTS_TEXT_FONT_SIZE;
}

- (void)setUpdownList {
    self.dropDownComponent.delegate = self;
    self.dropDownComponent.isBadge = NO;
    self.dropDownComponent.hidden = YES;
    NSString *displayText = [NSString textForKey:[ABIBusinessProtocol dropDownDisplayKeyIncentive] object:self.selectedIncentive];
    self.dropDownComponent.hidden = !displayText.length;
    self.dropDownComponent.dropDownButtonTitle = displayText;
}

/**
 * Visibility Change UICoponene
 */
- (void)allUICoponeneHidden:(BOOL)isHidden {
    self.tabPageViewContainer.hidden = isHidden;
    self.pointStaticTextLabel.hidden = isHidden;
    self.rankLabel.hidden = isHidden;
    self.peerRankingImageView.hidden = isHidden;
    self.profileDetailsView.hidden = isHidden;
}

/**
 * setup UI based on Special Condion
 */
- (void)setupConditionalUI {

    self.profileDetailsView.hidden = (self.kpiDetailsPageType == KPIDetailsPageFromLogInUserProfilePage);

        //[AppDelegate appdelegateShareInstance].globalCurrentPageFlow != PageFlowAsMyDMAsSDLogin;
}

/**
 * Release Memory
 */
- (void)cleanup {

    _peerRankingImageView = nil;
    _rankLabel = nil;
    _presenter = nil;
    _peerRankingImageView = nil;
    _constraintsUserNameWidth = nil;
}

- (ABIKPIDetailViewController *)customViewConrollerAtIndex:(NSInteger)index {
    ABIKPIDetailViewController *customViewConroller = [[ABIKPIDetailViewController alloc] init];
    customViewConroller.channelName = [self titleForTabAtIndex:index];
    customViewConroller.channelIndex = index;
    if (index == 0) {
        self.currentIndex = 0;
        self.selectedVC = customViewConroller;
    }
    [self updateDataOnChannelChange:self.currentIndex
                   filterKPIDetails:self.fiterKPIsDetails
            kpiDetailViewController:self.selectedVC
                             roster:self.rosterDataModel];
    return customViewConroller;
}

#pragma mark -  Tab Pager Data Source
- (NSInteger)numberOfViewControllers {
    if (self.fiterKPIsDetails && self.fiterKPIsDetails.count) {
        return self.fiterKPIsDetails.count;
    }
    return 0;
}

- (CGFloat)tabHeight {
    return DEFAULT_PAGE_HEIGHT;
}

- (UIColor *)tabColor {
    return [UIColor cyanColorABI];
}

- (UIColor *)tabBackgroundColor {
    return [UIColor defaultABIBlueColor];
}

- (UIFont *)titleFont {
    return [UIFont fontHelvetica57Condensed:15.0f];
}

- (UIColor *)titleColor {
    return [UIColor whiteColor];
}

- (UIColor *)deselectedTitleColor {
    return [UIColor cyanColorABI];
}

- (UIViewController *)viewControllerForIndex:(NSInteger)index {
    return [self customViewConrollerAtIndex:index];
}

- (NSString *)titleForTabAtIndex:(NSInteger)index {
    NSString *channelName = STATIC_TEXT_EMPTY_STRING;
    if ([NSArray isValidArray:self.fiterKPIsDetails] && self.fiterKPIsDetails.count && self.fiterKPIsDetails.count > index) {
        NSArray *channelsWithKPIsDetails = self.fiterKPIsDetails[index];
        if ([NSArray isValidArray:channelsWithKPIsDetails]) {
            ABISFKPIsDetailsDataModel *kpisDetailsDataModel = [channelsWithKPIsDetails firstObject];
            if (![NSString isNULLString:kpisDetailsDataModel.channelName]) {
                channelName = kpisDetailsDataModel.channelName;
            }
        }
    }
    return channelName;
}

- (UIView *)hintView {
    return [UIView loadViewFromNIB:IncentiveHintView];
}

#pragma mark -  Tab Pager Delegate
- (void)tabPager:(CustomTabPagerViewController *)tabPager didTransitionToTabAtIndex:(NSInteger)index {
    self.selectedVC = [tabPager selectViewControllerIndex:index];
    self.currentIndex = index;
    [self updateDataOnChannelChange:self.currentIndex
                   filterKPIDetails:self.fiterKPIsDetails
            kpiDetailViewController:self.selectedVC
                             roster:self.rosterDataModel];
}

#pragma mark - ABIDropDownComponentViewDelegate
- (void)dropDownComponentView:(ABIDropDownComponentView *)dropDownComponentView selectedItem:(id)selectedItem indexPath:(NSIndexPath *)indexPath {

    [self getKPIsDetailsForIncentive:selectedItem];
}

@end
