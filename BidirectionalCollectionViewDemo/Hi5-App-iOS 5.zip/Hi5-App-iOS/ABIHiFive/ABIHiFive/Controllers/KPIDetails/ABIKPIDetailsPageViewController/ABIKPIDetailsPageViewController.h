    //
    //  ABIKPIDetailsPageViewController.h
    //  ABIHiFive
    //
    //  Created by Prsenjit Goswami on 30/06/16.
    //  Copyright © 2016 Cognizant. All rights reserved.
    //
#import "ABISFIncentiveDataModel.h"
#import "ABIBaseViewController.h"

@interface ABIKPIDetailsPageViewController : ABIBaseViewController

- (void)kpiDetailsForIncentive:(ABISFIncentiveDataModel *)incentive
              incentiveDetails:(NSMutableArray<ABISFIncentiveDataModel *> *)incentiveDetails
                     forRoster:(ABISFRosterDataModel *)roster
                    OrPeerUser:(ABISFPeerRankingDataModel *)peerUser
            kpiDetailsPageType:(KPIDetailsPageType)kpiDetailsPageType
               extraDependency:(NSDictionary *)extraDependency;

@end
