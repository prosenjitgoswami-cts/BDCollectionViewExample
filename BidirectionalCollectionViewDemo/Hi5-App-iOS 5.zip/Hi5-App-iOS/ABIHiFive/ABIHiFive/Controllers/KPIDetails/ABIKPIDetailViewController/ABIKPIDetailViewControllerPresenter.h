    //
    //  ABIKPIDetailViewControllerPresenter.h
    //  ABIHiFive
    //
    //  Created by Prsenjit Goswami on 18/08/16.
    //  Copyright © 2016 Cognizant. All rights reserved.
    //
#import <Foundation/Foundation.h>
@interface SectionInfoDetailsDataModel : NSObject
@property (assign, nonatomic) BOOL isExpand;
@property (assign, nonatomic) NSInteger numberOfRow;
@property (assign, nonatomic) BOOL shouldExpandable;
@end
#import "ABIKPIDetailViewControllerProtocol.h"
@interface ABIKPIDetailViewControllerPresenter : NSObject <ABIKPIDetailViewControllerProtocol>
@end
