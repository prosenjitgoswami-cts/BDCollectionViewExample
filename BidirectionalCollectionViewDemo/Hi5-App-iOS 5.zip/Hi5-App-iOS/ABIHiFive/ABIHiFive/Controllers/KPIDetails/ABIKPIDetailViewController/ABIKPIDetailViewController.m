    //
    //  ABIKPIDetailViewController.m
    //  ABIHiFive
    //
    //  Created by Prsenjit Goswami on 30/06/16.
    //  Copyright © 2016 Cognizant. All rights reserved.
    //
#import "ABIKPIDetailViewController.h"
#import "ABIDMPerformaceView.h"
#import "ABIKPIChannelTableViewCell.h"
#import "ABIReporteePerformanceTableViewCell.h"
#import "ABISFIncentiveDataModel.h"
#import "ABISFKPIsDetailsDataModel.h"
#import "Constants.h"
#import "CustomProgressBarView.h"
#import "ABIKPIDetailViewControllerPresenter.h"

@interface ABIKPIDetailViewController () <UITableViewDataSource, UITableViewDelegate, ABIKPIChannelTableViewCellDelegate>
@property (nonatomic, strong) UITableView *tableView;
@property (nonatomic, strong) NSMutableDictionary *dict;
@property (nonatomic, strong) NSMutableArray *sectionInfoDetails;
@property (nonatomic, strong) id<ABIKPIDetailViewControllerProtocol> presenter;
@property (strong, nonatomic) NSMutableArray<ABISFKPIsDetailsDataModel *> *kpiDetsils;

@property (strong, nonatomic, nullable) ABISFRosterDataModel *rosterDataModel;
@property (assign, nonatomic) KPIDetailsPageType kpiDetailsPageType;
@property (assign, nonatomic) NSDictionary *extraDependency;

@end
@implementation ABIKPIDetailViewController
#pragma mark - ViewController Life Cycle
- (void)viewDidLoad {
    [super viewDidLoad];
    [self initialSetup];
}

- (BOOL)gestureRecognizer:(UIGestureRecognizer *)gestureRecognizer
shouldRecognizeSimultaneouslyWithGestureRecognizer:(UIGestureRecognizer *)otherGestureRecognizer {
    return NO;
}
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
}
- (void)dealloc {
    _tableView = nil;
    _sectionInfoDetails = nil;
    _presenter = nil;
    [_kpiDetsils removeAllObjects];
    _kpiDetsils = nil;
}
#pragma mark - Public Method
- (void)updateChannelKPIsDetails:(nonnull NSMutableArray *)channelDetails
                          roster:(nonnull ABISFRosterDataModel *)roster
              kpiDetailsPageType:(KPIDetailsPageType)kpiDetailsPageType
                 extraDependency:(nullable NSDictionary *)extraDependency {
    self.rosterDataModel = roster;
    self.kpiDetailsPageType = kpiDetailsPageType;
    self.extraDependency = extraDependency;
    if (channelDetails.count) {
        [self.kpiDetsils removeAllObjects];
        [self.kpiDetsils addObjectsFromArray:channelDetails];
    }

    [self.tableView reloadData];
}

#pragma mark - Custom Accessor

- (id<ABIKPIDetailViewControllerProtocol>)presenter {
    if (!_presenter) {
        _presenter = [ABIKPIDetailViewControllerPresenter new];
    }
    return _presenter;
}

- (NSMutableArray<ABISFKPIsDetailsDataModel *> *)kpiDetsils {

    if (!_kpiDetsils) {

        _kpiDetsils = [NSMutableArray array];
    }
    return _kpiDetsils;
}
#pragma mark - Private Method
- (void)initialSetup {
    [self initialUISetup];
}
/**
 * UI decoration like Set Font, Text Color, Create UI
 */
- (void)initialUISetup {
        // Create UI Elment
    [self createAndAddUI];
}
- (NSMutableArray *)sectionInfoDetails {
    if (!_sectionInfoDetails) {
        _sectionInfoDetails = [self.presenter sectionInfoDetails:self.kpiDetsils];
    }
    return _sectionInfoDetails;
}

/*!
 *  Create UI
 */
- (void)createAndAddUI {
    self.tableView.estimatedRowHeight = TABLEVIEW_ESTIMATED_ROW_HEIGHT;
    self.tableView.rowHeight = UITableViewAutomaticDimension;
    self.dict = [NSMutableDictionary dictionary];
    [self.view addSubview:self.tableView];
    [self addConstraints];
}
/*!
 * Add Constraint for UI with Component
 */
- (void)addConstraints {
    NSDictionary *views = @{ @"tableView" : self.tableView };
    [self.view addConstraints:[NSLayoutConstraint constraintsWithVisualFormat:@"H:|-0@999-[tableView]-0@999-|" options:0 metrics:nil views:views]];
    [self.view addConstraints:[NSLayoutConstraint constraintsWithVisualFormat:@"V:|-0@999-[tableView]-0@999-|" options:0 metrics:nil views:views]];
}
- (UITableView *)tableView {
    if (!_tableView) {
        _tableView = [[UITableView alloc] initWithFrame:CGRectZero style:UITableViewStylePlain];
        _tableView.dataSource = self;
        _tableView.delegate = self;
        _tableView.translatesAutoresizingMaskIntoConstraints = NO;
        _tableView.separatorColor = [UIColor clearColor];
        _tableView.backgroundColor = [UIColor clearColor];
        [_tableView setSeparatorStyle:UITableViewCellSeparatorStyleNone];
    }
    return _tableView;
}
#pragma mark - TableView Datasource
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    SectionInfoDetailsDataModel *model = [NSArray objectFromArray:self.sectionInfoDetails atIndex:section];
    if (model) {
        return model.numberOfRow;
    }
    return 1;
}
- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
    return self.kpiDetsils.count;
}
- (CGFloat)tableView:(UITableView *)tableView heightForFooterInSection:(NSInteger)section {
    return DEFAULT_CELL_PADDING;
}
- (UIView *)tableView:(UITableView *)tableView viewForFooterInSection:(NSInteger)section {
    UIView *headerView = [[UIView alloc] initWithFrame:CGRectMake(0, 0, tableView.frame.size.width, DEFAULT_CELL_PADDING)];
    headerView.backgroundColor = [UIColor clearColor];
    return headerView;
}
- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath {
    if (indexPath.row == 0)
        return TABLEVIEW_ESTIMATED_ROW_HEIGHT;
    else {
        ABISFKPIsDetailsDataModel *kpisDetailsDataModel = [NSArray objectFromArray:self.kpiDetsils atIndex:indexPath.section];
        if (kpisDetailsDataModel.myDMsPerformanceDataModels.count < 1) {
            return 80;
        } else {
            return (kpisDetailsDataModel.myDMsPerformanceDataModels.count * 55) + 35;
        }
    }
    return 0;
}
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    NSString *cellIdentifier = [NSString stringWithFormat:@"%ld-%ld", (long)indexPath.section, (long)indexPath.row];
    ABISFKPIsDetailsDataModel *kpisDetailsDataModel = [NSArray objectFromArray:self.kpiDetsils atIndex:indexPath.section];
    if (![kpisDetailsDataModel isKindOfClass:[ABISFKPIsDetailsDataModel class]])
        return nil;
    if (indexPath.row == 0) {
        ABIKPIChannelTableViewCell *cell = [self.dict objectForKey:cellIdentifier];
        if (!cell) {
            cell = [[ABIKPIChannelTableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:cellIdentifier];
            [self.dict setObject:cell forKey:cellIdentifier];
        }
        cell.indexPath = indexPath;
        cell.delegate = self;

        cell.dropDownButton.hidden = YES;

        if (self.kpiDetailsPageType == KPIDetailsPageFromLogInUserProfilePage) {
            switch (self.rosterDataModel.rosterRole) {
                case RosterRoleSD:
                    if (!(kpisDetailsDataModel.myDMsPerformanceDataModels.count)) {
                        cell.dropDownButton.hidden = NO;
                    } else {
                        cell.dropDownButton.hidden = NO;
                    }
                    break;
                case RosterRoleDM: cell.dropDownButton.hidden = YES; break;
                default: break;
            }
        }

        if ([kpisDetailsDataModel isMemberOfClass:[ABISFKPIsDetailsDataModel class]] && kpisDetailsDataModel) {
            cell.kpiName = kpisDetailsDataModel.kpiName;
            cell.incentiveBarChartView.progressStatusColorName = kpisDetailsDataModel.progressStatusColor;
            cell.incentiveBarChartView.minRange = kpisDetailsDataModel.minRange;
            cell.incentiveBarChartView.maxRange = kpisDetailsDataModel.maxRange;
            cell.incentiveBarChartView.progressDisplayText = kpisDetailsDataModel.incentiveValueText;
            cell.incentiveBarChartView.progressAmount = kpisDetailsDataModel.progress;
            cell.incentiveBarChartView.progressAmountRaw = kpisDetailsDataModel.progress;
            cell.incentiveBarChartView.unitName = kpisDetailsDataModel.progressUnit;
        }
        cell.backGroundViewColor = [UIColor whiteColorABI];
        cell.seperatorColorColor = [UIColor lightGreyColorABI];
        cell.titleTextColor = [UIColor defaultTextDarkColor];
        cell.selectionStyle = UITableViewCellSelectionStyleNone;
        cell.backgroundColor = [UIColor clearColor];
        return cell;
    } else {
        ABIReporteePerformanceTableViewCell *cell = (ABIReporteePerformanceTableViewCell *)[self.dict objectForKey:cellIdentifier];
        if (!cell) {
            cell = [[ABIReporteePerformanceTableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:cellIdentifier];
            [self.dict setObject:cell forKey:cellIdentifier];
        }

        if (self.kpiDetailsPageType == KPIDetailsPageFromLogInUserProfilePage && self.rosterDataModel.rosterRole == RosterRoleSD) {
            cell.myDMsPerformanceDataModels = kpisDetailsDataModel.myDMsPerformanceDataModels;
            if (cell.myDMsPerformanceDataModels.count) {
                cell.dmLabelsCreateView.noDmKpi.hidden = YES;
                cell.dmLabelsCreateView.noDmKpiView.hidden = YES;
            }
        }
        cell.selectionStyle = UITableViewCellSelectionStyleNone;
        cell.backgroundColor = [UIColor clearColor];

        return cell;
    }
    return nil;
}
#pragma mark - ABIKPIChannelTableViewCellDelegate
- (void)toggleReporteePerformanceView:(ABIKPIChannelTableViewCell *)cell indexPath:(NSIndexPath *)indexPath {
    ABISFKPIsDetailsDataModel *kpisDetailsDataModel = [NSArray objectFromArray:self.kpiDetsils atIndex:indexPath.section];
    SectionInfoDetailsDataModel *model = [NSArray objectFromArray:self.sectionInfoDetails atIndex:indexPath.section];
    if (model.shouldExpandable || kpisDetailsDataModel.myDMsPerformanceDataModels.count) {
        model.isExpand = !model.isExpand;
        [self.sectionInfoDetails replaceObjectAtIndex:indexPath.section withObject:model];
            // FIXME: Transfer In to Common Class
        if (model.isExpand) {
            UIImage *btnImage = [UIImage imageNamed:@"dropUpImg"];
            [cell.dropDownButton setImage:btnImage forState:UIControlStateNormal];
        } else {
            UIImage *btnImage = [UIImage imageNamed:@"dropDownImg"];
            [cell.dropDownButton setImage:btnImage forState:UIControlStateNormal];
        }
        [[self tableView] reloadData];
    } else {
        model.isExpand = !model.isExpand;
        if (model.isExpand) {
            UIImage *btnImage = [UIImage imageNamed:@"dropUpImg"];
            [cell.dropDownButton setImage:btnImage forState:UIControlStateNormal];
        } else {
            UIImage *btnImage = [UIImage imageNamed:@"dropDownImg"];
            [cell.dropDownButton setImage:btnImage forState:UIControlStateNormal];
        }
        [[self tableView] reloadData];
    }
}
@end
