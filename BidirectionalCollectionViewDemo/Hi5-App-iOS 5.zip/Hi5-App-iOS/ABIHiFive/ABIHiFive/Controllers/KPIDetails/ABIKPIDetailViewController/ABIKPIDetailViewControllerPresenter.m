    //
    //  ABIKPIDetailViewControllerPresenter.m
    //  ABIHiFive
    //
    //  Created by Prsenjit Goswami on 18/08/16.
    //  Copyright © 2016 Cognizant. All rights reserved.
    //
#import "ABIKPIDetailViewControllerPresenter.h"
#import "ABIDropDownComponentView.h"
#import "ABISFDataFetcherService.h"
#import "ABISFIncentiveDataModel.h"
#import "ABISFKPIsDetailsDataModel.h"
#import "ABISFMyReporteePerformanceDataModel.h"
#import "ABIKPIDetailViewController.h"

@implementation SectionInfoDetailsDataModel
- (void)setIsExpand:(BOOL)isExpand {
    _isExpand = isExpand;
    if (isExpand)
        self.numberOfRow = 2;
    else
        self.numberOfRow = 1;
}
@end
@interface ABIKPIDetailViewControllerPresenter () {
    NSInteger recurritionINdex;
    NSMutableArray *recurritionCollection;
}
@property (strong, nonatomic) NSMutableDictionary *ALLKPIDetailsDictionary;
@end

@implementation ABIKPIDetailViewControllerPresenter
- (nullable NSMutableArray<SectionInfoDetailsDataModel *> *)sectionInfoDetails:(nonnull NSArray<ABISFKPIsDetailsDataModel *> *)kpiDetsils {
    NSMutableArray *arr = [NSMutableArray new];
    for (NSInteger i = 0; i < kpiDetsils.count; i++) {
        ABISFKPIsDetailsDataModel *kPIsDetailsDataModel = [kpiDetsils objectAtIndex:i];
        if (!kPIsDetailsDataModel && ![kPIsDetailsDataModel isKindOfClass:[ABISFKPIsDetailsDataModel class]])
            continue;
        SectionInfoDetailsDataModel *model = [SectionInfoDetailsDataModel new];
        model.isExpand = NO;
        model.numberOfRow = 1;
        model.shouldExpandable = kPIsDetailsDataModel && kPIsDetailsDataModel.myDMsPerformanceDataModels.count ? YES : NO;
        [arr addObject:model];
    }
    return arr;
}
- (NSMutableDictionary<NSString *, id> *)ALLKPIDetailsDictionary {
    if (!_ALLKPIDetailsDictionary) {
        _ALLKPIDetailsDictionary = [NSMutableDictionary dictionary];
    }
    return _ALLKPIDetailsDictionary;
}

- (void)incentiveDetailsOfRoster:(ABISFRosterDataModel *)roster
                     failedBlock:(nonnull ABIFailedBlock)failedBlock
                 completionBlock:(void (^)(NSMutableArray<ABISFIncentiveDataModel *> *incentives, NSDictionary *extraInfo))completionBlock {

    [ABISFDataFetcherService fetchAndProcessRosterIncentiveDetailsWithRoster:roster
                                                             extraDependency:[NSDictionary extraDDSkipFetchingKPIDetails]
                                                                   ascending:NO
                                                                  sortByKeys:nil
                                                                 failedBlock:failedBlock
                                                             completionBlock:completionBlock];
}

    // FIXME: my custom function
- (void)getUpdatedKPIsDetailsForIncentive:(ABISFIncentiveDataModel *)incentive
                                forRoster:(nonnull ABISFRosterDataModel *)roster
                              failedBlock:(nonnull ABIFailedBlock)failedBlock
                          completionBlock:(nonnull void (^)(ABISFIncentiveDataModel *_Nullable updateIncentive))completionBlock {

        // Check Proper Class object
    if (![incentive isKindOfClass:[ABISFIncentiveDataModel class]] || ![roster validABISFRosterDataModelClassObject]) {
        if (completionBlock)
            completionBlock(nil);
        return;
    }

    __weak typeof(self) weakSelf = self;
    NSString *incentiveName = nil;
    ABISFIncentiveDataModel *filterIncentive = nil;

    incentiveName = incentive.incentiveName;

    if (![NSString isNULLString:incentiveName])
        filterIncentive = [NSDictionary objectForKeySafe:self.ALLKPIDetailsDictionary key:incentive.incentiveName];

    if (filterIncentive && filterIncentive.kpisDetails.count && filterIncentive.rank) {
        if (completionBlock)
            completionBlock(filterIncentive);
    }

        //	} else if (incentive && incentive.kpisDetails.count && incentive.rank) {
        //
        //		[weakSelf.ALLKPIDetailsDictionary setObject:incentive forKey:incentiveName];
        //
        //		if (completionBlock)
        //			completionBlock(incentive);

        //	}
    else if (incentive) {

        void (^CallBackWithUpdatedIncentive)(ABISFIncentiveDataModel *updateIncntv) = ^(ABISFIncentiveDataModel *updateIncntv) {

                // Fetch User Rank if not fetched.
            [updateIncntv getUserIncentiveRankAmongSameRolePeerWithCompletionBlock:^(NSNumber *_Nonnull rank) {
                [weakSelf.ALLKPIDetailsDictionary setObject:incentive forKey:incentiveName];
                if (completionBlock)
                    completionBlock(incentive);

            }];
        };

        [ABISFDataFetcherService fetchAndProcessKIPsDetailsForAnIncentiveWithIncentive:incentive
                                                                                roster:roster
                                                                       extraDependency:nil
                                                                             ascending:NO
                                                                            sortByKeys:nil
                                                                           failedBlock:^(NSError *error, NSDictionary *extraInfo) { CallBackWithUpdatedIncentive(incentive); }
                                                                       completionBlock:^(NSMutableArray<NSDictionary *> *kpisDetails, NSDictionary *_Nullable extraInfo) {

                                                                           incentive.kpisDetails = nil;
                                                                               // Update KPI DETAILS
                                                                           incentive.kpisDetails = kpisDetails;

                                                                               //  fetch the KIP detail of All Reportee For Manager . Show in click on dropdown

                                                                           if ([roster.roleInString isEqualToString:ABI_SF_USER_ROLE_SD]) {

                                                                               [incentive getAllReporteePerformanceDetailsWithManager:roster
                                                                                                                            incentive:incentive
                                                                                                                      extraDependency:nil
                                                                                                                            ascending:NO
                                                                                                                           sortByKeys:nil
                                                                                                                          failedBlock:^(NSError *error, NSDictionary *extraInfo) {

                                                                                                                              CallBackWithUpdatedIncentive(incentive);

                                                                                                                          }
                                                                                                                      completionBlock:^(NSMutableArray *results, NSDictionary *extraInfo) {
                                                                                                                          CallBackWithUpdatedIncentive(incentive);

                                                                                                                      }];
                                                                           } else {

                                                                               CallBackWithUpdatedIncentive(incentive);
                                                                           }

                                                                       }];

    } else {

        if (failedBlock)
            failedBlock(nil, nil);
    }
}

    //- (void)rosterIncentive:(NSArray<ABISFRosterDataModel *> *)collectionresults completion:(void (^)(NSArray *arr))completion {
    //	recurritionINdex += 1;
    //	if (recurritionINdex >= collectionresults.count) {
    //		if (completion) {
    //			completion(recurritionCollection);
    //		}
    //		return;
    //	}
    //	ABISFRosterDataModel *roster = [NSArray objectFromArray:collectionresults atIndex:recurritionINdex];
    //	if (!roster) {
    //		[self rosterIncentive:collectionresults completion:completion];
    //	} else {
    //		[ABISFDataFetcherService fetchIncentiveDetailsAndPrecessKPIsDetailsWithRoster:roster
    //																   reporteeIncentives:NULL
    //																	  extraDependency:NULL
    //																		  failedBlock:^(NSError *error,
    //NSDictionary *extraInfo)
    //		 {
    //		 [self rosterIncentive:collectionresults completion:completion];
    //		 }
    //																	  completionBlock:^(NSArray *results,
    //NSDictionary *extraInfo)
    //		 {
    //		 for (ABISFIncentiveDataModel *model in results) {
    //			 model.rosterDataModel = roster;
    //			 model.profileUserName = roster.rosterNameText;
    //		 }
    //		 [recurritionCollection addObjectsFromArray:results];
    //		 [self rosterIncentive:collectionresults completion:completion];
    //		 }];
    //	}
    //}
@end
