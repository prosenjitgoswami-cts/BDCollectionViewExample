    //
    //  ABIKPIDetailViewController.h
    //  ABIHiFive
    //
    //  Created by Prsenjit Goswami on 30/06/16.
    //  Copyright © 2016 Cognizant. All rights reserved.
    //
#import "ABISFRosterDataModel.h"
#import <UIKit/UIKit.h>
@class ABISFKPIsDetailsDataModel;
@interface ABIKPIDetailViewController : UIViewController
@property (strong, nonatomic, nonnull) NSString *channelName;
@property (assign, nonatomic) NSInteger channelIndex;

- (void)updateChannelKPIsDetails:(nonnull NSMutableArray *)channelDetails
                          roster:(nonnull ABISFRosterDataModel *)roster
              kpiDetailsPageType:(KPIDetailsPageType)kpiDetailsPageType
                 extraDependency:(nullable NSDictionary *)extraDependency;
;
@end
