    //
    //  ABIKPIDetailViewControllerProtocol.h
    //  ABIHiFive
    //
    //  Created by Prsenjit Goswami on 18/08/16.
    //  Copyright © 2016 Cognizant. All rights reserved.
    //
#import "Constants.h"
#import <Foundation/Foundation.h>
@class ABISFKPIsDetailsDataModel, ABIKPIDetailViewController;
@protocol ABIKPIDetailViewControllerProtocol <NSObject>
- (nullable NSMutableArray<SectionInfoDetailsDataModel *> *)sectionInfoDetails:(nonnull NSArray<ABISFKPIsDetailsDataModel *> *)kpiDetsils;
- (void)incentiveDetailsOfRoster:(ABISFRosterDataModel *_Nullable)roster
                     failedBlock:(nonnull ABIFailedBlock)failedBlock
                 completionBlock:(void (^_Nullable)(NSMutableArray<ABISFIncentiveDataModel *> *_Nullable incentives,
                                                    NSDictionary *_Nullable extraInfo))completionBlock;

- (void)getUpdatedKPIsDetailsForIncentive:(nonnull ABISFIncentiveDataModel *)incentive
                                forRoster:(nonnull ABISFRosterDataModel *)roster
                              failedBlock:(nonnull ABIFailedBlock)failedBlock
                          completionBlock:(nonnull void (^)(ABISFIncentiveDataModel *_Nullable updateIncentive))completionBlock;

@end
