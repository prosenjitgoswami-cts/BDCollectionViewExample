    //
    //  ABIPeerRankingListViewController.h
    //  ABIHiFive
    //
    //  Created by Prsenjit Goswami on 28/06/16.
    //  Copyright © 2016 Cognizant. All rights reserved.
    //
#import "EnumMaster.h"
#import <UIKit/UIKit.h>
@class ABISFIncentiveDataModel, ABISFRosterDataModel;
@interface ABIPeerRankingListViewController : UIViewController
@property (weak, nonatomic) UIViewController *parentVC;
- (void)selectedIncentive:(ABISFIncentiveDataModel *)selectedIncentive
                   roster:(ABISFRosterDataModel *)currentABISFRosterDataModel
      rosterAllIncentives:(NSArray<ABISFIncentiveDataModel *> *)rosterAllIncentives
          peerRankingType:(PeerRankingType)peerRankingType;
@end
