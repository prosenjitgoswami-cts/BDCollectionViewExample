
    //  ABIHiFive
    //
    //  Created by Prsenjit Goswami on 28/06/16.
    //  Copyright © 2016 Cognizant. All rights reserved.
    //

typedef enum {
    PeerRankingFirst = 0,
    PeerRankingSecond = 1,
    PeerRankingThird = 2,

} PeerRanking;

#import "ABIPeerRankingListViewController.h"
#import "ABIPeerRankingDetailPageCell.h"
#import "ABISFIncentiveDataModel.h"
#import "ABISFPeerRankingDataModel.h"
#import "ABISFRosterDataModel.h"
#import "CommonHeader.h"
#import "Constants.h"
#import "ABIKPIDetailsPageViewController.h"
#import "ABIPeerRankingPageViewControllerPresenter.h"

@interface ABIPeerRankingListViewController ()
@property (weak, nonatomic) IBOutlet UILabel *viewHeading;

@property (weak, nonatomic) IBOutlet UIView *usersPointsContainerView;
@property (weak, nonatomic) IBOutlet UITableView *userRankingTable;

@property (weak, nonatomic) IBOutlet UIView *secondRankedColumnsContainerView;
@property (weak, nonatomic) IBOutlet UIImageView *secondRankedColumnStaticImageView;
@property (weak, nonatomic) IBOutlet UIImageView *secondRankedUserBorderImageView;
@property (weak, nonatomic) IBOutlet UIImageView *secondRankUserImageView;
@property (weak, nonatomic) IBOutlet UIImageView *secondRankTagImageView;
@property (weak, nonatomic) IBOutlet UILabel *secondRankedUserNameLabel;
@property (weak, nonatomic) IBOutlet UILabel *secondRankedUserPointLabel;

@property (weak, nonatomic) IBOutlet UIView *firstRankedColumnsContainerView;
@property (weak, nonatomic) IBOutlet UIImageView *firstRankedColumnStaticImageView;
@property (weak, nonatomic) IBOutlet UIImageView *firstRankedUserBorderImageView;
@property (weak, nonatomic) IBOutlet UIImageView *firstRankUserImageView;
@property (weak, nonatomic) IBOutlet UIImageView *firstRankTagImageView;
@property (weak, nonatomic) IBOutlet UILabel *firstRankedUserNameLabel;
@property (weak, nonatomic) IBOutlet UILabel *firstRankedUserPointLabel;

@property (weak, nonatomic) IBOutlet UIView *thirdRankedColumnsContainerView;
@property (weak, nonatomic) IBOutlet UIImageView *thirdRankedColumnStaticImageView;
@property (weak, nonatomic) IBOutlet UIImageView *thirdRankedUserBorderImageView;
@property (weak, nonatomic) IBOutlet UIImageView *thirdRankUserImageView;
@property (weak, nonatomic) IBOutlet UIImageView *thirdRankTagImageView;
@property (weak, nonatomic) IBOutlet UILabel *thirdRankedUserNameLabel;
@property (weak, nonatomic) IBOutlet UILabel *thirdRankedUserPointLabel;

@property (strong, nonatomic) ABISFRosterDataModel *currentABISFRosterDataModel;
@property (strong, nonatomic) NSArray<ABISFIncentiveDataModel *> *rosterIncentiveDetails;
@property (strong, nonatomic) ABISFIncentiveDataModel *selectedIncentive;
@property (assign, nonatomic) PeerRankingType peerRankingType;
@property (assign, nonatomic) NSInteger selectedIndex;
@property (strong, nonatomic) NSMutableArray<ABISFPeerRankingDataModel *> *filteredResults;
@property (strong, nonatomic) id<ABIPeerRankingPageViewControllerProtocol> presenter;
@property (strong, nonatomic) NSIndexPath *youAreHereIndexPath;
@property (strong, nonatomic) NSMutableArray<ABISFPeerRankingDataModel *> *peersRankingCollection;
@property (strong, nonatomic) UITapGestureRecognizer *tapGestureFor1stRankedPeer, *tapGestureFor2ndRankedPeer, *tapGestureFor3rdRankedPeer;

@end
@implementation ABIPeerRankingListViewController
#pragma mark - View Controller Life Cycle
- (void)viewDidLoad {
    [super viewDidLoad];
    [self initialSetup];
}

- (void)viewDidAppear:(BOOL)animated {
    [super viewDidAppear:animated];
}

- (void)viewWillAppear:(BOOL)animated {
    [super viewWillAppear:YES];
}

- (void)dealloc {
    _filteredResults = nil;
    _presenter = nil;
    _tapGestureFor1stRankedPeer = nil;
    _tapGestureFor2ndRankedPeer = nil;
    _tapGestureFor3rdRankedPeer = nil;
}

#pragma mark - Public Method
- (void)selectedIncentive:(ABISFIncentiveDataModel *)selectedIncentive
                   roster:(ABISFRosterDataModel *)currentABISFRosterDataModel
      rosterAllIncentives:(NSArray<ABISFIncentiveDataModel *> *)rosterAllIncentives
          peerRankingType:(PeerRankingType)peerRankingType {
    self.peerRankingType = peerRankingType;
    self.currentABISFRosterDataModel = currentABISFRosterDataModel;
    self.rosterIncentiveDetails = rosterAllIncentives;
    self.selectedIncentive = selectedIncentive;
}

- (void)setSelectedIncentive:(ABISFIncentiveDataModel *)selectedIncentive {

    _selectedIncentive = selectedIncentive;
    if ([AppDelegate isOffline]) {
        [self refreshUIOnOffLineState];
    } else {
        [CustomLoaderManager showLoader];
        switch (self.peerRankingType) {
            case MyPeerRankingList: {
                [self fetchDataAndUpdateUIWRTIncentive:self.selectedIncentive];
            } break;
            case MyDMsPeerRankingList: {
                [self fetchDataForMyDMsAndUpdateUIWRTIncentive:self.selectedIncentive];
            } break;
            default: break;
        }
    }
}

#pragma mark -  Fetch Service - Update Data Source - Update UI

- (void)fetchDataAndUpdateUIWRTIncentive:(ABISFIncentiveDataModel *)incentive {
    __weak typeof(self) weakSelf = self;

    ABISFRosterDataModel *currentABISFRosterDataModel = self.currentABISFRosterDataModel;
    [self.presenter fetchAndUpdateUIForAllPeerDetailsWithRoster:currentABISFRosterDataModel
                                                      incentive:incentive
                                                extraDependency:nil
                                                    failedBlock:^(NSError *error, NSDictionary *extraInfo) {

                                                        [weakSelf updatePerRankingDatasourceAndUpdateUI:nil];

                                                    }
                                                completionBlock:^(NSMutableArray<ABISFPeerRankingDataModel *> *results, NSDictionary *extraInfo) {

                                                    [weakSelf updatePerRankingDatasourceAndUpdateUI:results];
                                                }];
}

- (void)fetchDataForMyDMsAndUpdateUIWRTIncentive:(ABISFIncentiveDataModel *)incentive {
    __weak typeof(self) weakSelf = self;

    [self.presenter fetchMyDMsRankingWithRoster:self.currentABISFRosterDataModel
                                  incentiveName:incentive.incentiveName
                                extraDependency:nil
                                     completion:^(NSMutableArray<ABISFPeerRankingDataModel *> *results, NSError *error, SOQLStatus status) {
                                         weakSelf.peersRankingCollection = results;
                                         [self filterANDUpdateUIMyDMsPeerRankingWRTSelectedIncentive:incentive];
                                     }];
}

- (void)filterANDUpdateUIMyDMsPeerRankingWRTSelectedIncentive:(ABISFIncentiveDataModel *)incentive {
    NSArray<ABISFPeerRankingDataModel *> *filterDMsPeers =
    [self.presenter filterPeerRankingForMyDMsWithIncentive:incentive peerRankingCollection:self.peersRankingCollection];
    self.filteredResults = [ABISFPeerRankingDataModel uniqueABISFPeerRankingDataModelCollection:filterDMsPeers];
    [self updatePageUI];
}

#pragma mark
- (void)updatePerRankingDatasourceAndUpdateUI:(NSMutableArray<ABISFPeerRankingDataModel *> *)results {
    self.filteredResults = results;
    [self updatePageUI];
}

- (void)updatePageUI {
    [self allUICoponeneHidden:NO];

    self.userRankingTable.hidden = !(self.filteredResults && self.filteredResults.count > 0);
    [self.userRankingTable reloadData];
    [self updatePeerRankedColumnUI];
    [self focusCurrentUser];
}

- (void)updatePeerRankedColumnUI {

    [_firstRankedColumnsContainerView setHidden:YES];
    [_secondRankedColumnsContainerView setHidden:YES];
    [_thirdRankedColumnsContainerView setHidden:YES];

        //	if ([self.filteredResults count]) {
        //	self.secondRankUserImageView.image = [UIImage imageABIDummyUser];
        //	self.firstRankUserImageView.image = [UIImage imageABIDummyUser];
        //	self.thirdRankUserImageView.image = [UIImage imageABIDummyUser];

        //		[self updateFirstRankedPeerUI];
        //		[self updateSecondRankedPeerUI];
        //		[self updateThirdRankedPeerUI];

    [self updateColunmRankedPeerUI:PeerRankingFirst];
    [self updateColunmRankedPeerUI:PeerRankingSecond];
    [self updateColunmRankedPeerUI:PeerRankingThird];

        //	dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0), ^{
        //
        //		[self userImageSet];
        //	});
        //}

        // TODO: CHECK DELAY
    [CustomLoaderManager hideLoaderOnDelay:1.0 completion:NULL];
}

- (void)updateColunmRankedPeerUI:(PeerRanking)peerRanking {

    if (![NSArray isValidArray:self.filteredResults])
        return;

    ABISFPeerRankingDataModel *peer = [NSArray objectFromArray:self.filteredResults atIndex:peerRanking];
    if (!peer)
        return;

    UIImageView *rankTagImageView = nil;
    UIImageView *borderImageView = nil;
    UIImageView *userImageView = nil;
    UILabel *userNameLabel = nil;
    UILabel *userPoint = nil;

    switch (peerRanking) {
        case PeerRankingFirst:
            [_firstRankedColumnsContainerView setHidden:NO];
            borderImageView = self.firstRankedUserBorderImageView;
            rankTagImageView = self.firstRankTagImageView;
            userImageView = self.firstRankUserImageView;
            userNameLabel = self.firstRankedUserNameLabel;
            userPoint = self.firstRankedUserPointLabel;
            break;

        case PeerRankingSecond:
            [self.secondRankedColumnsContainerView setHidden:NO];

            borderImageView = self.secondRankedUserBorderImageView;
            rankTagImageView = self.secondRankTagImageView;
            userImageView = self.secondRankUserImageView;
            userNameLabel = self.secondRankedUserNameLabel;
            userPoint = self.secondRankedUserPointLabel;
            break;

        case PeerRankingThird:
            [self.thirdRankedColumnsContainerView setHidden:NO];

            borderImageView = self.thirdRankedUserBorderImageView;
            rankTagImageView = self.thirdRankTagImageView;
            userImageView = self.thirdRankUserImageView;
            userNameLabel = self.thirdRankedUserNameLabel;
            userPoint = self.thirdRankedUserPointLabel;
            break;

        default: break;
    }

    if (peer.isCurrentUser) {
        [rankTagImageView setImage:[UIImage imageABIYorRHereRight]];
        rankTagImageView.hidden = ([_currentABISFRosterDataModel.managerRoleInString isEqualToString:ABI_SF_USER_ROLE_SD] &&
                                   [_currentABISFRosterDataModel.roleInString isEqualToString:ABI_SF_USER_ROLE_DM]);

    } else {
        [rankTagImageView setHidden:YES];
    }
    userImageView.layer.cornerRadius = userImageView.frame.size.height / 2;
    userImageView.clipsToBounds = YES;
    userNameLabel.text = [peer peerRoster].rosterNameText;
    NSInteger incentivePoints = (long)peer.incentivePointsInNumber.integerValue;
    [userPoint setText:[NSString stringWithFormat:@"%ld %@", (long)incentivePoints, STATIC_TEXT_POINTS]];
    NSString *imageURLString = [peer peerRoster].rosterImageURLString;

    [userImageView setABIUserImageWithURL:imageURLString];

        //	dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0), ^{
        //	//	if (imageURLString.length) {
        //			//[userImageView downloadSFImageFromURLString:imageURLString placeholderImage:[UIImage imageABIDummyUser]];
        //	//	}
        //	});
}

#pragma mark - Custom Accessor
- (id<ABIPeerRankingPageViewControllerProtocol>)presenter {
    if (!_presenter) {
        _presenter = [ABIPeerRankingPageViewControllerPresenter new];
    }
    return _presenter;
}

- (UITapGestureRecognizer *)tapGestureFor1stRankedPeer {

    if (!_tapGestureFor1stRankedPeer) {

        self.firstRankedColumnsContainerView.userInteractionEnabled = YES;
        _tapGestureFor1stRankedPeer = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(tapFirstPosition:)];
        [self.view bringSubviewToFront:self.firstRankedColumnsContainerView];
    }
    return _tapGestureFor1stRankedPeer;
}

- (UITapGestureRecognizer *)tapGestureFor2ndRankedPeer {
    if (!_tapGestureFor2ndRankedPeer) {
        self.secondRankedColumnsContainerView.userInteractionEnabled = YES;
        _tapGestureFor2ndRankedPeer = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(tapSecondRankPosition:)];
        [self.view bringSubviewToFront:self.secondRankedColumnsContainerView];
    }
    return _tapGestureFor2ndRankedPeer;
}

- (UITapGestureRecognizer *)tapGestureFor3rdRankedPeer {
    if (!_tapGestureFor3rdRankedPeer) {
        self.thirdRankedColumnsContainerView.userInteractionEnabled = YES;
        _tapGestureFor3rdRankedPeer = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(tapThirdRankPosition:)];
        [self.view bringSubviewToFront:self.thirdRankedColumnsContainerView];
    }
    return _tapGestureFor3rdRankedPeer;
}

#pragma mark - Tap Event
- (void)tapFirstPosition:(UITapGestureRecognizer *)sender {
    if (self.filteredResults.count > 0) {
        self.selectedIndex = 0;
        [self navigateToPeerRankingDetailsPage];
    }
}

- (void)tapSecondRankPosition:(UITapGestureRecognizer *)sender {
    if (self.filteredResults.count > 1) {
        self.selectedIndex = 1;
        [self navigateToPeerRankingDetailsPage];
    }
}

- (void)tapThirdRankPosition:(UITapGestureRecognizer *)sender {
    if (self.filteredResults.count > 2) {
        self.selectedIndex = 2;
        [self navigateToPeerRankingDetailsPage];
    }
}

#pragma mark - Private Method

- (void)initialSetup {
    [self initialUISetup];
    [self allUICoponeneHidden:YES];
    [self addTapGestureInRankedPiller];
}
/*!
 *  Create UI with Component
 */
- (void)initialUISetup {

    self.viewHeading.text = STATIC_TEXT_OVER_ALL_KIP_RANKING;
    self.viewHeading.font = [UIFont fontHelvetica57Condensed:15.0f];
    self.secondRankedUserNameLabel.font = [UIFont fontHelvetica57Condensed:11.0f];
    self.firstRankedUserNameLabel.font = [UIFont fontHelvetica57Condensed:11.0f];
    self.thirdRankedUserNameLabel.font = [UIFont fontHelvetica57Condensed:11.0f];
    self.secondRankedUserPointLabel.font = [UIFont fontHelvetica57Condensed:19.0f];
    self.firstRankedUserPointLabel.font = [UIFont fontHelvetica57Condensed:24.0f];
    self.thirdRankedUserPointLabel.font = [UIFont fontHelvetica57Condensed:19.0f];

    self.viewHeading.textColor = [UIColor darkTextColor];
    self.secondRankedUserNameLabel.textColor = [UIColor darkTextColor];
    self.firstRankedUserNameLabel.textColor = [UIColor darkTextColor];
    self.thirdRankedUserNameLabel.textColor = [UIColor darkTextColor];

    self.secondRankedUserNameLabel.numberOfLines = 2;
    self.firstRankedUserNameLabel.numberOfLines = 2;
    self.thirdRankedUserNameLabel.numberOfLines = 2;

    self.secondRankedUserNameLabel.lineBreakMode = NSLineBreakByWordWrapping;
    self.firstRankedUserNameLabel.lineBreakMode = NSLineBreakByWordWrapping;
    self.thirdRankedUserNameLabel.lineBreakMode = NSLineBreakByWordWrapping;

    self.usersPointsContainerView.backgroundColor = [UIColor defaultMauveColorABI];

    self.secondRankedUserPointLabel.font = [UIFont fontHelvetica57Condensed:17.0f];
    self.firstRankedUserPointLabel.font = [UIFont fontHelvetica57Condensed:22.0f];
    self.thirdRankedUserPointLabel.font = [UIFont fontHelvetica57Condensed:15.0f];

    self.firstRankedColumnStaticImageView.backgroundColor = [UIColor clearColor];
    self.secondRankedColumnStaticImageView.backgroundColor = [UIColor clearColor];
    self.thirdRankedColumnStaticImageView.backgroundColor = [UIColor clearColor];

    self.secondRankTagImageView.backgroundColor = [UIColor clearColor];
    self.firstRankTagImageView.backgroundColor = [UIColor clearColor];
    self.thirdRankTagImageView.backgroundColor = [UIColor clearColor];

    self.secondRankedColumnStaticImageView.image = [UIImage imageNamed:SecondPlace_IMAGE];
    self.firstRankedColumnStaticImageView.image = [UIImage imageNamed:FirstPlace_IMAGE];
    self.thirdRankedColumnStaticImageView.image = [UIImage imageNamed:ThirdPlace_IMAGE];

    self.firstRankedUserBorderImageView.image = [UIImage imageABIOuterCircle];
    self.secondRankedUserBorderImageView.image = [UIImage imageABIOuterCircle];
    self.thirdRankedUserBorderImageView.image = [UIImage imageABIOuterCircle];

    self.view.backgroundColor = [UIColor defaultMauveColorABI];
}

- (void)addTapGestureInRankedPiller {
    [self.firstRankedColumnsContainerView addGestureRecognizer:self.tapGestureFor1stRankedPeer];
    [self.secondRankedColumnsContainerView addGestureRecognizer:self.tapGestureFor2ndRankedPeer];
    [self.thirdRankedColumnsContainerView addGestureRecognizer:self.tapGestureFor3rdRankedPeer];
}

- (void)allUICoponeneHidden:(BOOL)isHidden {

    self.viewHeading.hidden = isHidden;
    self.usersPointsContainerView.hidden = isHidden;
    self.userRankingTable.hidden = isHidden;
    [self.firstRankedColumnsContainerView setHidden:isHidden];
    [self.secondRankedColumnsContainerView setHidden:isHidden];
    [self.thirdRankedColumnsContainerView setHidden:isHidden];
}

- (void)navigateToPeerRankingDetailsPage {

    [self navigateToKIPDetailsViewController];
}

- (void)focusCurrentUser {

    NSIndexPath *focusCurrentUserIndex = [self.presenter currentUserIndexOfTableWhenMoreThan3UsersAvailable:self.filteredResults];

    if (focusCurrentUserIndex && self.userRankingTable) {
        [self.userRankingTable scrollToRowAtIndexPath:focusCurrentUserIndex atScrollPosition:UITableViewScrollPositionTop animated:NO];
    }
}
- (void)refreshUIOnOffLineState {
    [UIViewController alertInNoNetworkConnection:self clickedOkButton:NULL];
}

#pragma mark - table view delegate methods
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    if (self.filteredResults.count == 0 || self.filteredResults.count < 3) {
        return 0;
    }
    return self.filteredResults.count - 3;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    static NSString *cellIdentifier = @"myCell";
    ABIPeerRankingDetailPageCell *cell = (ABIPeerRankingDetailPageCell *)[tableView dequeueReusableCellWithIdentifier:cellIdentifier];
    if (cell == nil) {
        cell = [[ABIPeerRankingDetailPageCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:cellIdentifier];
    }
    if (self.filteredResults.count > indexPath.row) {
        ABISFPeerRankingDataModel *peerRankingDataModel = [NSArray objectFromArray:self.filteredResults atIndex:indexPath.row + 3];
        peerRankingDataModel.userRank = [NSString stringWithFormat:@"%ld", (long)(indexPath.row + 4)];
        if (peerRankingDataModel) {
            [cell updateCell:peerRankingDataModel];

            if (peerRankingDataModel.isCurrentUser)
                self.youAreHereIndexPath = indexPath;
        }
    }
    cell.backgroundColor = [UIColor clearColor];
    cell.selectionStyle = UITableViewCellSelectionStyleNone;
    return cell;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
    self.selectedIndex = indexPath.row + 3;
    [self navigateToPeerRankingDetailsPage];
}

- (void)navigateToKIPDetailsViewController {
    if ([AppDelegate isOffline]) {
        [UIViewController alertInNoNetworkConnection:self clickedOkButton:NULL];
    } else {
        ABIKPIDetailsPageViewController *destination =
        (ABIKPIDetailsPageViewController *)[UIViewController instantiateViewControllerWithIdentifier:STORY_BOARD_ID_KPI_DETAILS_PAGE_VC];
        if (destination && self.filteredResults.count > self.selectedIndex) {
            ABISFPeerRankingDataModel *peerRankingDataModel = [self.filteredResults objectAtIndex:self.selectedIndex];
            peerRankingDataModel.userRank = [NSString stringWithFormat:@"%ld", (long)self.selectedIndex + 1];
            KPIDetailsPageType kpiDetailsPageType =
            (self.peerRankingType == MyPeerRankingList) ? KPIDetailsFromMyPeerRankingTab : KPIDetailsFromMyDMsPeerRankingTab;

            [destination kpiDetailsForIncentive:self.selectedIncentive
                               incentiveDetails:nil
                                      forRoster:nil
                                     OrPeerUser:peerRankingDataModel
                             kpiDetailsPageType:kpiDetailsPageType
                                extraDependency:nil];
        }
        [self.parentVC.navigationController pushViewController:destination animated:YES];
    }
}
@end
/*


 - (void)updateFirstRankedPeerUI {
 if ([self.filteredResults count] > 0) {
 [_firstRankedColumnsContainerView setHidden:NO];
 ABISFPeerRankingDataModel *firstRankedPeer = [self.filteredResults objectAtIndex:0];
 if (firstRankedPeer.isCurrentUser) {
 if ([_currentABISFRosterDataModel.managerRoleInString isEqualToString:ABI_SF_USER_ROLE_SD] &&
 [_currentABISFRosterDataModel.roleInString isEqualToString:ABI_SF_USER_ROLE_DM]) {
 [self.firstRankTagImageView setImage:[UIImage imageNamed:youAreHereRight_Image]];
 [self.firstRankTagImageView setHidden:YES];
 } else {
 [self.firstRankTagImageView setImage:[UIImage imageNamed:youAreHereRight_Image]];
 [self.firstRankTagImageView setHidden:NO];
 }
 } else {
 [self.firstRankTagImageView setHidden:YES];
 }
 self.firstRankUserImageView.layer.cornerRadius = self.firstRankUserImageView.frame.size.height / 2;
 self.firstRankUserImageView.clipsToBounds = YES;
 self.firstRankedUserNameLabel.text = [firstRankedPeer peerRoster].rosterNameText;

 NSInteger incentivePoints = (long)firstRankedPeer.incentivePointsInNumber.integerValue;
 [self.firstRankedUserPointLabel setText:[NSString stringWithFormat:@"%ld %@", (long)incentivePoints, STATIC_TEXT_POINTS]];
 }
 }

 - (void)updateSecondRankedPeerUI {

 if ([self.filteredResults count] > 1) {
 [_secondRankedColumnsContainerView setHidden:NO];
 ABISFPeerRankingDataModel *secondRankedPeer = [self.filteredResults objectAtIndex:1];
 if (secondRankedPeer.isCurrentUser) {
 if ([_currentABISFRosterDataModel.managerRoleInString isEqualToString:ABI_SF_USER_ROLE_SD] &&
 [_currentABISFRosterDataModel.roleInString isEqualToString:ABI_SF_USER_ROLE_DM]) {
 [self.secondRankTagImageView setImage:[UIImage imageNamed:youAreHereRight_Image]];
 [self.secondRankTagImageView setHidden:YES];
 } else {
 [self.secondRankTagImageView setImage:[UIImage imageNamed:youAreHereRight_Image]];
 [self.secondRankTagImageView setHidden:NO];
 }
 } else {
 [self.secondRankTagImageView setHidden:YES];
 }
 self.secondRankUserImageView.layer.cornerRadius = self.secondRankUserImageView.frame.size.width / 2;
 self.secondRankUserImageView.clipsToBounds = YES;
 self.secondRankedUserNameLabel.text = [secondRankedPeer peerRoster].rosterNameText;
 [self.secondRankedUserPointLabel
 setText:[NSString stringWithFormat:@"%ld %@", (long)secondRankedPeer.incentivePointsInNumber.integerValue, STATIC_TEXT_POINTS]];
 }
 }

 - (void)updateThirdRankedPeerUI {

 if ([self.filteredResults count] > 2) {
 [_thirdRankedColumnsContainerView setHidden:NO];
 ABISFPeerRankingDataModel *peerRankingModelObj = [self.filteredResults objectAtIndex:2];
 if (peerRankingModelObj.isCurrentUser) {
 if ([self.currentABISFRosterDataModel.managerRoleInString isEqualToString:ABI_SF_USER_ROLE_SD] &&
 [self.currentABISFRosterDataModel.roleInString isEqualToString:ABI_SF_USER_ROLE_DM]) {
 [self.thirdRankTagImageView setImage:[UIImage imageNamed:youAreHereRight_Image]];
 [self.thirdRankTagImageView setHidden:YES];
 } else {
 [self.thirdRankTagImageView setImage:[UIImage imageNamed:youAreHereRight_Image]];
 [self.thirdRankTagImageView setHidden:NO];
 }
 } else {
 [self.thirdRankTagImageView setHidden:YES];
 }

 self.thirdRankedUserBorderImageView.layer.cornerRadius = self.thirdRankedUserBorderImageView.frame.size.width / 2;
 self.thirdRankedUserBorderImageView.clipsToBounds = YES;

 self.thirdRankUserImageView.layer.cornerRadius = self.thirdRankUserImageView.frame.size.width / 2;
 self.thirdRankUserImageView.clipsToBounds = YES;
 self.thirdRankedUserNameLabel.text = [peerRankingModelObj peerRoster].rosterNameText;
 [self.thirdRankedUserPointLabel
 setText:[NSString stringWithFormat:@"%ld %@", (long)peerRankingModelObj.incentivePointsInNumber.integerValue, STATIC_TEXT_POINTS]];
 }
 }
 - (void)userImageSet {

 if (self.filteredResults.count > 0) {

 ABISFPeerRankingDataModel *peerRankingModelObj = [self.filteredResults objectAtIndex:0];
 NSString *imageURLString = [peerRankingModelObj peerRoster].rosterImageURLString;
 if (imageURLString.length) {
 [self.firstRankUserImageView downloadSFImageFromURLString:imageURLString placeholderImage:[UIImage imageABIDummyUser]];
 }
 //		else {
 //			self.firstRankUserImageView.image = [UIImage imageABIDummyUser];
 //		}
 if (self.filteredResults.count > 1) {
 peerRankingModelObj = [self.filteredResults objectAtIndex:1];
 imageURLString = [peerRankingModelObj peerRoster].rosterImageURLString;
 if (imageURLString.length) {
 [self.secondRankUserImageView downloadSFImageFromURLString:imageURLString placeholderImage:[UIImage imageABIDummyUser]];
 }
 //			else {
 //				self.secondRankUserImageView.image = [UIImage imageABIDummyUser];
 //			}
 }
 if (self.filteredResults.count > 2) {
 peerRankingModelObj = [self.filteredResults objectAtIndex:2];
 imageURLString = [peerRankingModelObj peerRoster].rosterImageURLString;
 if (imageURLString.length) {
 [self.thirdRankUserImageView downloadSFImageFromURLString:imageURLString placeholderImage:[UIImage imageABIDummyUser]];
 }
 //			else {
 //				self.thirdRankUserImageView.image = [UIImage imageABIDummyUser];
 //			}
 }
 }
 }
 */