    //
    //  ABIPeerRankingPageViewControllerProtocol.h
    //  ABIHiFive
    //
    //  Created by Prsenjit Goswami on 16/08/16.
    //  Copyright © 2016 Cognizant. All rights reserved.
    //
#import "Constants.h"
#import <Foundation/Foundation.h>
@class DropDownListDataModel;
@class ABISFIncentiveDataModel, ABISFPeerRankingDataModel;
@protocol ABIPeerRankingPageViewControllerProtocol <NSObject>
    // Peer Ranking With Same Ranking
- (void)fetchAndUpdateUIForAllPeerDetailsWithRoster:(nullable ABISFRosterDataModel *)roster
                                          incentive:(nullable ABISFIncentiveDataModel *)incentive
                                    extraDependency:(nullable NSDictionary *)extraDependency
                                        failedBlock:(_Nonnull ABIFailedBlock)failedBlock
                                    completionBlock:(_Nonnull ABIMutableArrayResponseBlock)completionBloc;

#pragma mark - My DMs Peer Ranking
- (void)fetchMyDMsRankingWithRoster:(nonnull ABISFRosterDataModel *)roster
                      incentiveName:(nullable NSString *)incentiveName
                    extraDependency:(nullable NSDictionary *)extraDependency
                         completion:(nonnull SOQLCompletion)completion;
    // KIP Peer ranking Incentive
- (nullable NSMutableArray<ABISFPeerRankingDataModel *> *)
filterPeerRankingForMyDMsWithIncentive:(nonnull ABISFIncentiveDataModel *)incentive
peerRankingCollection:(nonnull NSMutableArray<ABISFPeerRankingDataModel *> *)peerRankingCollection;

- (nullable NSArray<NSString *> *)peerRankingChannelNames:(RosterRole)rosterRole;
- (nullable NSString *)peerRankingChannelNameAtIndex:(NSInteger)index rosterRole:(RosterRole)rosterRole;
- (CGFloat)heighOfHeader:(RosterRole)rosterRole;

- (nullable NSIndexPath *)currentUserIndexOfTableWhenMoreThan3UsersAvailable:(nonnull NSArray *)peers;

@end
