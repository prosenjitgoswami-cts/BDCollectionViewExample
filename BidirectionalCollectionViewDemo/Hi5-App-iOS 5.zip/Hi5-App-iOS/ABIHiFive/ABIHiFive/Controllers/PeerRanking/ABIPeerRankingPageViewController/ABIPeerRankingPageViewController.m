    //
    //  ABIPeerRankingPageViewController.m
    //  ABIHiFive
    //
    //  Created by Prsenjit Goswami on 16/08/16.
    //  Copyright © 2016 Cognizant. All rights reserved.
    //
#import "ABIPeerRankingPageViewController.h"
#import "ABIBusinessProtocol.h"
#import "ABIDropDownComponentView.h"
#import "ABISFIncentiveDataModel.h"
#import "ABISFRosterDataModel.h"
#import "CustomTabPagerViewController.h"
#import "ABIPeerRankingListViewController.h"
#import "ABIPeerRankingPageViewControllerPresenter.h"

@interface ABIPeerRankingPageViewController () <CustomTabPagerDataSource, CustomTabPagerDelegate, ABIDropDownComponentViewDelegate>
@property (weak, nonatomic) IBOutlet NSLayoutConstraint *topConstraintsOfTapPager;
@property (weak, nonatomic) IBOutlet ABIDropDownComponentView *downComponentView;
@property (weak, nonatomic) IBOutlet CustomTabPagerView *tabPagerVCContainerView;
@property (strong, nonatomic) id<ABIPeerRankingPageViewControllerProtocol> presenter;
@property (assign, nonatomic) NSInteger currentIndex;
@property (weak, nonatomic) ABIPeerRankingListViewController *selectedVC;
@property (strong, nonatomic) ABISFIncentiveDataModel *selectedIncentive;
@property (strong, nonatomic) ABISFRosterDataModel *currentRoster;
@property (strong, nonatomic) NSMutableArray<ABISFIncentiveDataModel *> *assingedIncentives;
@end
@implementation ABIPeerRankingPageViewController
#pragma mark - View Controller Life Cycle
- (void)viewDidLoad {
    [super viewDidLoad];
    [self initialSetup];
}
- (void)viewWillAppear:(BOOL)animated {
    [super viewWillAppear:animated];
    if (_tabPagerVCContainerView) {
        [_tabPagerVCContainerView repositionTab:self.currentIndex];
    }
    [self setNavigationPageTitle];
    self.downComponentView.isBadge = NO;
}
- (void)dealloc {

    [self cleanup];
}
#pragma mark - Public Method
- (void)peerRankingForRoster:(nonnull ABISFRosterDataModel *)roster
          assingedIncentives:(nonnull NSMutableArray<ABISFIncentiveDataModel *> *)assingedIncentives
           selectedIncentive:(nonnull ABISFIncentiveDataModel *)selectedIncentive {

    if ([NSArray isValidArray:assingedIncentives]) {
        [self.assingedIncentives removeAllObjects];
        [self.assingedIncentives addObjectsFromArray:assingedIncentives];
    }
    self.currentRoster = roster;
    self.selectedIncentive = selectedIncentive;
}
#pragma mark - Custom Accessors
- (id<ABIPeerRankingPageViewControllerProtocol>)presenter {
    if (!_presenter) {
        _presenter = [ABIPeerRankingPageViewControllerPresenter new];
    }
    return _presenter;
}

- (NSMutableArray<ABISFIncentiveDataModel *> *)assingedIncentives {

    if (!_assingedIncentives) {
        _assingedIncentives = [NSMutableArray array];
    }
    return _assingedIncentives;
}

#pragma mark - Private Method
#pragma mark UI
- (void)initialSetup {
    [self resetAll];
    [self setNavigationPageTitle];
    [self initialUISetup];
}
- (void)initialUISetup {
    [self createAndAddUI];
    [self setNavigationPageTitle];
}
- (void)createAndAddUI {
    [self addPagerViewController];
    self.downComponentView.delegate = self;
    if (self.downComponentView) {
        [self.downComponentView dropDownDataSource:self.assingedIncentives
                                      selectedItem:self.selectedIncentive
                                    displayTextKey:[ABIBusinessProtocol dropDownDisplayKeyIncentive]];
    }
    [_tabPagerVCContainerView reloadData];
}
- (void)addPagerViewController {
    [_tabPagerVCContainerView initialisedTabPageViewController:self];
    [self.tabPagerVCContainerView reloadData];
}
- (void)setNavigationPageTitle {
    self.title = [NSString peerRankingPageTitle:self.currentRoster pagerTabIndex:self.currentIndex];
}
- (void)allUICoponeneHidden:(BOOL)isHidden {
    _downComponentView.hidden = isHidden;
    _tabPagerVCContainerView.hidden = isHidden;
    ;
}

#pragma mark
- (void)resetAll {
    self.currentIndex = 0;
}
- (void)cleanup {
    _downComponentView.delegate = nil;
    [_tabPagerVCContainerView removeFromSuperview];
    _tabPagerVCContainerView = nil;
    _presenter = nil;
    _selectedVC = nil;
    [_assingedIncentives removeAllObjects];
    _assingedIncentives = nil;
}
#pragma mark
    // Chage UI on Tab Change Pager
- (void)refreshOnTabChange {
        // Change the Title Of Peer Ranking Page og Tab change.
    [self setNavigationPageTitle];
        // update Peer List Page
    [self updatePeerRankingPage:self.selectedVC atTapIndex:self.currentIndex selectedIncentive:self.selectedIncentive];
}
#pragma mark - Protocol conformance
#pragma mark - Tab Pager Data Source
- (CGFloat)tabHeight {
    return [self.presenter heighOfHeader:self.currentRoster.rosterRole];
}
- (NSInteger)numberOfViewControllers {
    NSInteger countOfTab = [self.presenter peerRankingChannelNames:self.currentRoster.rosterRole].count;
    if (countOfTab == 1) {
        self.view.backgroundColor = [UIColor defaultMauveColorABI];
        [self.view layoutIfNeeded];
    }
    return countOfTab;
}
- (UIColor *)tabColor {
    return [UIColor cyanColorABI];
}
- (UIColor *)tabBackgroundColor {
    return [UIColor defaultABIBlueColor];
}
- (UIFont *)titleFont {
    return [UIFont fontHelvetica57Condensed:15.0f];
}
- (UIColor *)titleColor {
    return [UIColor whiteColor];
}
- (UIColor *)deselectedTitleColor {
    return [UIColor cyanColorABI];
}
- (UIViewController *)viewControllerForIndex:(NSInteger)index {
    return [self selectedViewController:index];
}
- (ABIPeerRankingListViewController *)selectedViewController:(NSInteger)index {
    ABIPeerRankingListViewController *peerRankingListVC =
    (ABIPeerRankingListViewController *)[UIViewController instantiateViewControllerWithIdentifier:STORY_BOARD_ID_PEER_RANKING_DETAILS_VC];
    peerRankingListVC.parentVC = self;
    if (index == 0) {
        self.selectedVC = peerRankingListVC;
        self.currentIndex = index;
        [self setNavigationPageTitle];
    }
    [self updatePeerRankingPage:peerRankingListVC atTapIndex:index selectedIncentive:self.selectedIncentive];
    return peerRankingListVC;
}
- (NSString *)titleForTabAtIndex:(NSInteger)index {
    NSString *channelName = [self.presenter peerRankingChannelNameAtIndex:index rosterRole:self.currentRoster.rosterRole];
    return channelName;
}
#pragma mark - Tab Pager Delegate
- (void)tabPager:(CustomTabPagerViewController *)tabPager didTransitionToTabAtIndex:(NSInteger)index {
    if (self.currentIndex == index)
        return;
    self.selectedVC = [tabPager selectViewControllerIndex:index];
    self.currentIndex = index;
    [self refreshOnTabChange];
}
#pragma mark -ABIDropDownComponentViewDelegate
- (void)dropDownComponentView:(ABIDropDownComponentView *)dropDownComponentView selectedItem:(id)selectedItem indexPath:(NSIndexPath *)indexPath {
    if ([AppDelegate isOffline]) {
        [UIViewController alertInNoNetworkConnection:self clickedOkButton:NULL];
    } else {

        self.selectedIncentive = (ABISFIncentiveDataModel *)selectedItem;
        [self updatePeerRankingPage:self.selectedVC atTapIndex:self.currentIndex selectedIncentive:self.selectedIncentive];
    }
}
- (void)updatePeerRankingPage:(ABIPeerRankingListViewController *)controller
                   atTapIndex:(NSInteger)index
            selectedIncentive:(ABISFIncentiveDataModel *)selectedIncentive {

        // peerRankingType is confirmed that which is currently selected tab.
        // As Manager Login(e.g.Login as SD user). there is 2 tab.
        // 1. My Peer Ranking 2. My DMs Ranking
        // Othre wise 1 tab. 'My Peer Ranking'

    PeerRankingType peerRankingType = (index == MyPeerRankingList) ? MyPeerRankingList : MyDMsPeerRankingList;
    [controller selectedIncentive:selectedIncentive
                           roster:self.currentRoster
              rosterAllIncentives:self.assingedIncentives
                  peerRankingType:peerRankingType];
}
@end
