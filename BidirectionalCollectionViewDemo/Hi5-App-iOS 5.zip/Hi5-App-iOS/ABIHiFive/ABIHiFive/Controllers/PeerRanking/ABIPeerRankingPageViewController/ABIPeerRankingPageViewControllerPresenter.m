    //
    //  ABIPeerRankingPageViewControllerPresenter.m
    //  ABIHiFive
    //
    //  Created by Prsenjit Goswami on 16/08/16.
    //  Copyright © 2016 Cognizant. All rights reserved.
    //
#import "ABIPeerRankingPageViewControllerPresenter.h"
#import "ABIDropDownComponentView.h"
#import "ABISFDataFetcherService.h"
#import "ABISFIncentiveDataModel.h"
#import "ABISFPeerRankingDataModel.h"
#import "ABIUtilHeader.h"
#import "HelperUtilHeader.h"

@interface ABIPeerRankingPageViewControllerPresenter () {
    NSMutableArray<ABISFPeerRankingDataModel *> *peerRankingDataModels;
    NSInteger recurrritionIndex;
}
@end
@implementation ABIPeerRankingPageViewControllerPresenter
#pragma mark - Fetch Service Data
- (void)fetchAndUpdateUIForAllPeerDetailsWithRoster:(nullable ABISFRosterDataModel *)roster
                                          incentive:(nullable ABISFIncentiveDataModel *)incentive
                                    extraDependency:(nullable NSDictionary *)extraDependency
                                        failedBlock:(_Nonnull ABIFailedBlock)failedBlock
                                    completionBlock:(_Nonnull ABIMutableArrayResponseBlock)completionBlock {

    [ABISFDataFetcherService fetchAndProcessAllPeerDetailsWithRoster:roster
                                                           incentive:incentive
                                                     extraDependency:extraDependency
                                                           ascending:NO
                                                          sortByKeys:nil
                                                         failedBlock:failedBlock
                                                     completionBlock:completionBlock];
}
- (void)fetchMyDMsRankingWithRoster:(nonnull ABISFRosterDataModel *)roster
                      incentiveName:(nullable NSString *)incentiveName
                    extraDependency:(nullable NSDictionary *)extraDependency
                         completion:(nonnull SOQLCompletion)completion {
    __weak typeof(self) weakSelf = self;
    recurrritionIndex = -1;
    [ABISFDataFetcherService fetchAndProcessAllReporteeDetailsWithRoster:roster
                                                            reporteeRole:ABI_SF_USER_ROLE_DM
                                                         extraDependency:extraDependency
                                                               ascending:YES
                                                              sortByKeys:nil
                                                             failedBlock:^(NSError *error, NSDictionary *extraInfo) {
                                                                 if (completion)
                                                                     completion(nil, nil, 0);
                                                             }
                                                         completionBlock:^(NSArray *results, NSDictionary *extraInfo) {
                                                             peerRankingDataModels = [NSMutableArray array];
                                                             [weakSelf fetchIncentiveOfMyDMsWithMyDMCollection:results
                                                                                               completionBlock:^(NSArray<ABISFIncentiveDataModel *> *results) {
                                                                                                       //                                                                                                   peerRankingDataModels
                                                                                                       //                                                                                                   =

                                                                                                   [peerRankingDataModels abiSortedPeerCollectionResults];

                                                                                                       //
                                                                                                       //																								   [[peerRankingDataModels
                                                                                                       // sortArrayForKey:incentivePointsInNumber1 ascending:NO] mutableCopy];
                                                                                                   if (completion)
                                                                                                       completion(peerRankingDataModels, nil, 1);
                                                                                               }];
                                                         }];
}
- (nullable NSArray<ABISFPeerRankingDataModel *> *)filterPeerRankingForMyDMsWithIncentive:(nonnull ABISFIncentiveDataModel *)incentive
                                                                    peerRankingCollection:
(nonnull NSMutableArray<ABISFPeerRankingDataModel *> *)peerRankingCollection {

    NSArray *results = peerRankingCollection;
    if ([incentive isKindOfClass:[ABISFIncentiveDataModel class]]) {
        NSPredicate *predicate = [NSPredicate predicateWithFormat:@"self.incentiveName == %@ && self.incentive.incentiveWeek == %@",
                                  incentive.incentiveDisplayName, incentive.incentiveWeek];

        results = [peerRankingCollection filteredArrayUsingPredicate:predicate];
    }
    return results;
}

/**
 *  @brief Reportee(DM) Ranking Details. This is only applicable for Manager Login(SD).
 (e.g. DM is reportee of SD).
 *
 *  @param myDMCollection  My Reportee Details (As ABISFRosterDataModel Collection)
 *  @param completionBlock My Reportee Ranking (As ABISFPeerRankingDataModel Collection)
 */
- (void)fetchIncentiveOfMyDMsWithMyDMCollection:(NSArray<ABISFRosterDataModel *> *)myDMCollection
                                completionBlock:(void (^)(NSArray<ABISFPeerRankingDataModel *> *results))completionBlock {
    recurrritionIndex += 1;
    if (myDMCollection.count == 0 || recurrritionIndex >= myDMCollection.count) {
        if (completionBlock)
            completionBlock(peerRankingDataModels);
        return;
    }
    __weak typeof(self) weakSelf = self;
    ABISFRosterDataModel *dmRosterModel = [NSArray objectFromArray:myDMCollection atIndex:recurrritionIndex];

    [ABISFDataFetcherService fetchIncentiveDetailsAndPrecessKPIsDetailsWithRoster:dmRosterModel
                                                               reporteeIncentives:nil
                                                                  extraDependency:NULL
                                                                      failedBlock:^(NSError *error, NSDictionary *extraInfo) {
                                                                          [weakSelf fetchIncentiveOfMyDMsWithMyDMCollection:myDMCollection completionBlock:completionBlock];
                                                                      }
                                                                  completionBlock:^(NSArray<ABISFIncentiveDataModel *> *results, NSDictionary *extraInfo) {
                                                                      NSMutableArray<ABISFPeerRankingDataModel *> *peerRankingOfDMs = [NSMutableArray array];
                                                                      for (ABISFIncentiveDataModel *model in results) {
                                                                          ABISFPeerRankingDataModel *peerRankingDataModel = [ABISFPeerRankingDataModel new];
                                                                          peerRankingDataModel.incentive = model;
                                                                              // Incentive ID
                                                                          peerRankingDataModel.incentiveId = model.incentiveID;
                                                                              // Incentive Name
                                                                          peerRankingDataModel.incentiveName = model.incentiveDisplayName;
                                                                          peerRankingDataModel.incentivePointsInNumber = model.overAllIncentiveProgress;
                                                                          [dmRosterModel setRoleInString:ABI_SF_USER_ROLE_DM];
                                                                          peerRankingDataModel.peerRoster = dmRosterModel;
                                                                          [peerRankingOfDMs addObject:peerRankingDataModel];
                                                                      }
                                                                      [peerRankingDataModels addObjectsFromArray:peerRankingOfDMs];
                                                                      [weakSelf fetchIncentiveOfMyDMsWithMyDMCollection:myDMCollection completionBlock:completionBlock];
                                                                  }];
}

- (NSArray *)peerRankingChannelNames:(RosterRole)rosterRole {
    NSArray *channelNames = nil;
    switch (rosterRole) {
        case RosterRoleSD: channelNames = PAGER_TITLES_PEER_RANKING_AS_SD; break;
        default: channelNames = @[ @"" ]; break;
    }
    return channelNames;
}

/**
 *   Tab Title
 As Manager Login(e.g.Login as SD user). there is 2 tab. (1. My Peer Ranking 2. My DMs Ranking)

 Other wise there is one tab with no tab header Title.

 *
 *  @param index      Index of tab
 *  @param rosterRole Roster Role
 *
 *  @return Tab header Title
 */
- (NSString *)peerRankingChannelNameAtIndex:(NSInteger)index rosterRole:(RosterRole)rosterRole {
    return [self peerRankingChannelNames:rosterRole][index];
}

/**
 *	Tab header height
 As Manager Login(e.g.Login as SD user). there is 2 tab (1. My Peer Ranking 2. My DMs Ranking)
 Other wise there is one tab with no tab header.
 *
 *  @param rosterRole Roster Referance
 *
 *  @return Tab header height
 */
- (CGFloat)heighOfHeader:(RosterRole)rosterRole {
    CGFloat height = 0.0f;
    switch (rosterRole) {
        case RosterRoleSD: height = DEFAULT_PAGE_HEIGHT; break;
        default: break;
    }
    return height;
}

- (nullable NSIndexPath *)currentUserIndexOfTableWhenMoreThan3UsersAvailable:(nonnull NSArray *)peers {
    NSIndexPath *indexPath = nil;

    if (![NSArray isValidArray:peers] && peers.count > 4)
        return indexPath;
    NSPredicate *predicate = [NSPredicate predicateWithFormat:@"self.isCurrentUser == YES"];
    NSArray *result = [peers filteredArrayUsingPredicate:predicate];
    if (result.count) {
        ABISFPeerRankingDataModel *model = [result firstObject];

        if (model) {
            NSInteger index = [peers indexOfObject:model];
            if (index > 4) {
                index -= 3;
                index = MIN(index, [peers count] - 4);
                index = MAX(0, index);
                NSIndexPath *indexPath = [NSIndexPath indexPathForRow:index inSection:0];
                BOOL indexOutOfBound = [peers indexOutOfBound:indexPath.row];
                indexPath = indexOutOfBound ? indexPath : nil;
            }
        }
    }
    return indexPath;
}
@end
