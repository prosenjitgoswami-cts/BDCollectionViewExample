    //
    //  ABIPeerRankingPageViewController.h
    //  ABIHiFive
    //
    //  Created by Prsenjit Goswami on 16/08/16.
    //  Copyright © 2016 Cognizant. All rights reserved.
    //
#import "ABIBaseViewController.h"
#import <UIKit/UIKit.h>
@class ABISFIncentiveDataModel;
@interface ABIPeerRankingPageViewController : ABIBaseViewController
- (void)peerRankingForRoster:(nonnull ABISFRosterDataModel *)roster
          assingedIncentives:(nonnull NSMutableArray<ABISFIncentiveDataModel *> *)assingedIncentives
           selectedIncentive:(nonnull ABISFIncentiveDataModel *)selectedIncentive;
@end
