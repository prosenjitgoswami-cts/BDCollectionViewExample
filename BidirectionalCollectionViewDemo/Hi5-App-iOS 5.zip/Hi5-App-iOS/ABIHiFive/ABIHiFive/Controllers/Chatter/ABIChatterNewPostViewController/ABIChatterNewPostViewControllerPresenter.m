    //
    //  ABIChatterNewPostViewControllerPresenter.m
    //  ABIHiFive
    //
    //  Created by Prsenjit Goswami on 31/07/16.
    //  Copyright © 2016 Cognizant. All rights reserved.
    //
#import "ABIChatterNewPostViewControllerPresenter.h"
#import "ABISFChatterDataFetcherServices.h"
#import "ABISFChatterMentionDataModel.h"
#import "ABISFChatterParentDataModel.h"
#import "ABISFChatterPathBuilder.h"
#import "ABISFRestJSONParamsBuilder.h"
#import "Constants.h"
@implementation ABIChatterNewPostViewControllerPresenter

#pragma mark -  Private Message

#pragma mark -  Private Message
- (void)postPrivateMessageWith:(NSString *)postBody
        selectedReciapientName:(NSArray *)selectedReciapientName
              recipientRecords:(NSArray *)recipientRecords
                   failedBlock:(ABIFailedBlock)failedBlock
                  successBlock:(ABIResponseBlock)successBlock {
    NSArray *recordIds = [self getReciapientIDsWithSelectedReciapientName:selectedReciapientName recipientRecords:recipientRecords];
    if (recordIds.count) {
        NSDictionary *queryParams = [ABISFRestJSONParamsBuilder queryParamsForPrivateMessageWithPostBody:postBody recipientIds:recordIds];
        if ([NSDictionary isValidDictionary:queryParams]) {
            [ABISFChatterDataFetcherServices postPrivateMessageWithQueryParams:queryParams failedBlock:failedBlock successBlock:successBlock];
        } else {
            if (failedBlock)
                failedBlock(nil, nil);
        }
    }
}
- (void)postPrivateMessageForMyDMsWithPostBody:(NSString *)postBody
                              recipientRecords:(NSArray *)recipientRecords
                                   failedBlock:(ABIFailedBlock)failedBlock
                                  successBlock:(ABIResponseBlock)successBlock {
    if (recipientRecords.count) {
        NSDictionary *queryParams = [ABISFRestJSONParamsBuilder queryParamsForPrivateMessageWithPostBody:postBody recipientIds:recipientRecords];
        if ([NSDictionary isValidDictionary:queryParams]) {
            [ABISFChatterDataFetcherServices postPrivateMessageWithQueryParams:queryParams failedBlock:failedBlock successBlock:successBlock];
        } else {
            if (failedBlock)
                failedBlock(nil, nil);
        }
    }
}
- (NSArray *)getReciapientIDsWithSelectedReciapientName:(NSArray *)selectedReciapientName recipientRecords:(NSArray *)recipientRecords {
    NSArray *visibelTags = selectedReciapientName;
    NSMutableArray *recordIds = [NSMutableArray array];
    for (NSString *name in visibelTags) {
        NSString *_name = [name stringByReplacingOccurrencesOfString:AT_THE_RATE_TAG_MENTIONS_NAME withString:STATIC_TEXT_EMPTY_STRING];
        _name = [_name stringByReplacingOccurrencesOfString:PRE_TAG_MENTIONS_NAME withString:STATIC_TEXT_EMPTY_STRING];
        _name = [_name stringByReplacingOccurrencesOfString:POST_TAG_MENTIONS_NAME withString:STATIC_TEXT_EMPTY_STRING];
        if (selectedReciapientName.count) {
            for (id obj in recipientRecords) {
                if (![obj isKindOfClass:[ABISFChatterMentionDataModel class]])
                    continue;
                ABISFChatterMentionDataModel *mentionDataModel = (ABISFChatterMentionDataModel *)obj;
                NSString *nameRecipent = mentionDataModel.name;
                if (![NSString isNULLString:nameRecipent] && [nameRecipent isEqualToString:_name]) {
                    NSString *ID = mentionDataModel.recordId;
                    if (![NSString isNULLString:ID])
                        [recordIds addObject:ID];
                }
            }
        }
    }
    return recordIds;
}

#pragma mark -  Serch Mentioned
- (void)searchMentionedWithSearchWord:(NSString *)searchWord
                    mentionSearchType:(MentionSearchType)mentionSearchType
                               failed:(ABIFailedBlock)failed
                              success:(ABIResponseBlock)success {
    [ABISFChatterDataFetcherServices invokeMentionedListWithSearchWord:searchWord
                                                     mentionSearchType:mentionSearchType
                                                            completion:^(id result, NSError *error, SOQLStatus status) {
                                                                NSMutableArray *_result = (NSMutableArray *)result;
                                                                if (_result.count) {
                                                                    if (success)
                                                                        success(_result, nil);
                                                                } else {
                                                                    if (failed)
                                                                        failed([NSError errorNoDataAvailable], nil);
                                                                }
                                                            }];
}
    //- (void)fetchChatterUserName:(void (^) (NSString *userName)) completion {
    //
    //	NSString *chatterUserName = [AppDelegate appdelegateShareInstance].chatterUserName;
    //
    //	if([NSString isNULLString:chatterUserName]) {
    //
    //		[ABISFChatterDataFetcherServices invokeChatterUserDetailsWithFailedBlock:NULL
    //													  successBlock:^(NSMutableArray<ABISFChatterParentDataModel
    //*>
    //*
    //_Nullable
    // parents, NSDictionary * _Nullable extraInfo) {
    //
    //														  ABISFChatterParentDataModel *parent =
    //[parents
    // firstObject];
    //
    //														  [AppDelegate
    // appdelegateShareInstance].chatterUserName
    //=
    // parent.name;
    //
    //														  NSString *chatterUserName =
    //[AppDelegate
    // appdelegateShareInstance].chatterUserName;
    //
    //														  if(completion)
    //															  completion
    //(chatterUserName);
    //													  }]	;
    //	} else {
    //
    //		if(completion)
    //			completion (chatterUserName);
    //	}
    //
    //}
@end
