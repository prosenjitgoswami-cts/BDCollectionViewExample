    //
    //  ABIChatterNewPostViewControllerPresenter.h
    //  ABIHiFive
    //
    //  Created by Prsenjit Goswami on 31/07/16.
    //  Copyright © 2016 Cognizant. All rights reserved.
    //
#import "ABIChatterNewPostViewControllerProtocol.h"
#import <Foundation/Foundation.h>
@interface ABIChatterNewPostViewControllerPresenter : NSObject <ABIChatterNewPostViewControllerProtocol>
@end
