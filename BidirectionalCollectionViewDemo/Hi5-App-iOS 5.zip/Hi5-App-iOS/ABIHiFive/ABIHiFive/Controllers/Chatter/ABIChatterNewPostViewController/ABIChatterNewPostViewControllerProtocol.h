    //
    //  ABIChatterNewPostViewControllerProtocol.h
    //  ABIHiFive
    //
    //  Created by Prsenjit Goswami on 31/07/16.
    //  Copyright © 2016 Cognizant. All rights reserved.
    //
#import "Constants.h"
#import <Foundation/Foundation.h>
@protocol ABIChatterNewPostViewControllerProtocol <NSObject>
- (void)postPrivateMessageWith:(NSString *)postBody
        selectedReciapientName:(NSArray *)selectedReciapientName
              recipientRecords:(NSArray *)recipientRecords
                   failedBlock:(ABIFailedBlock)failedBlock
                  successBlock:(ABIResponseBlock)successBlock;
- (void)searchMentionedWithSearchWord:(NSString *)searchWord
                    mentionSearchType:(MentionSearchType)mentionSearchType
                               failed:(ABIFailedBlock)failed
                              success:(ABIResponseBlock)success;
- (void)postPrivateMessageForMyDMsWithPostBody:(NSString *)postBody
                              recipientRecords:(NSArray *)recipientRecords
                                   failedBlock:(ABIFailedBlock)failedBlock
                                  successBlock:(ABIResponseBlock)successBlock;
@end