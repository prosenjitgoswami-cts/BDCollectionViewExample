    //
    //  ABIChatterNewPostViewController.h
    //  AnheuserBusch
    //
    //  Created by IR Mac Mini on 20/07/16.
    //  Copyright © 2016 Cognizant. All rights reserved.
    //
#import "ABIBaseViewController.h"
#import "EnumMaster.h"
#import <UIKit/UIKit.h>
@interface ABIChatterNewPostViewController : ABIBaseViewController
@property (strong, nonatomic) ABISFRosterDataModel *rosterDataModel;
+ (void)navigateToChatterNewPostPageFromViewController:(UIViewController *)fromViewController
                                        chatterFeature:(ChatterFeature)chatterFeature
                                       rosterDataModel:(ABISFRosterDataModel *)rosterDataModel;
@end
