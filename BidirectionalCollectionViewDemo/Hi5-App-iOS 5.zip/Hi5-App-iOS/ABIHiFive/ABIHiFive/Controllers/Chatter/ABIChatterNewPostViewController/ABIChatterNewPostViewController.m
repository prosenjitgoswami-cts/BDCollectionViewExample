    //
    //  ABIChatterNewPostViewController.m
    //  AnheuserBusch
    //
    //  Created by IR Mac Mini on 20/07/16.
    //  Copyright © 2016 Cognizant. All rights reserved.
    //
#import "ABIChatterNewPostViewController.h"
#import "ABISFChatterContentDataModel.h"
#import "ABISFChatterDataFetcherServices.h"
#import "ABISFChatterMentionDataModel.h"
#import "ABISFRestJSONParamsBuilder.h"
#import "ABISFRosterDataModel.h"
#import "AppDelegate.h"
#import "ABIChatterNewPostViewControllerPresenter.h"
#import "Constants.h"
#import "CustomTextView.h"
#import "ImagePickerController.h"
#import "TagsControlScrollerView.h"
@interface ABIChatterNewPostViewController () <UINavigationControllerDelegate, TagsControlScrollerViewDelegate, UISearchBarDelegate, UITextViewDelegate,
UIImagePickerControllerDelegate, UITextFieldDelegate, UITableViewDelegate, UITableViewDataSource>
@property (weak, nonatomic) IBOutlet NSLayoutConstraint *topConstraintFileName;
@property (weak, nonatomic) IBOutlet NSLayoutConstraint *searchBarTopConstraint;
@property (weak, nonatomic) IBOutlet NSLayoutConstraint *heightConstraintsFileNameLabel;
@property (weak, nonatomic) IBOutlet UIImageView *userImageBorderView;
@property (weak, nonatomic) IBOutlet UIImageView *userImageView;
@property (weak, nonatomic) IBOutlet UILabel *userNameLbl;
@property (weak, nonatomic) IBOutlet UIButton *privateBtn;
@property (weak, nonatomic) IBOutlet UIButton *attachmentBtn;
@property (weak, nonatomic) IBOutlet UITextField *searchTextField;
@property (weak, nonatomic) IBOutlet UIButton *searchButton;
@property (weak, nonatomic) IBOutlet UIView *postTextViewCintainerView;
@property (weak, nonatomic) IBOutlet UILabel *privateLabel;
@property (weak, nonatomic) IBOutlet UILabel *fileNameLabel;
@property (weak, nonatomic) IBOutlet UIButton *fileDeleteButton;
@property (weak, nonatomic) IBOutlet NSLayoutConstraint *postContainerBottomConstraint;
@property (weak, nonatomic) IBOutlet UIButton *postBtn;
@property (weak, nonatomic) IBOutlet CustomTextView *postTextView;
@property (weak, nonatomic) IBOutlet TagsControlScrollerView *privateMentionScrollView;
@property (strong, nonatomic) UIBarButtonItem *btnDone;
@property (strong, nonatomic) UITableView *searchDataTableView;
@property (strong, nonatomic) UIView *searchDataContainerView;
@property (strong, nonatomic) UIView *parentSearchDataContainerView;
@property (strong, nonatomic) UIView *selectedResponderView;
@property (strong, nonatomic) NSMutableArray *searchResults;
@property (strong, nonatomic) NSMutableString *postBodyText;
@property (strong, nonatomic) NSMutableArray *mentionedDetails;
@property (strong, nonatomic) NSMutableArray *recipientRecords;
@property (strong, nonatomic) NSData *selectedData;
@property (strong, nonatomic) NSString *fileName;
@property (assign, nonatomic) BOOL isPrivate;
@property (assign, nonatomic) ChatterFeature chatterFeature;
@property (strong, nonatomic) id<ABIChatterNewPostViewControllerProtocol> presenter;
@end
@implementation ABIChatterNewPostViewController
+ (void)navigateToChatterNewPostPageFromViewController:(UIViewController *)fromViewController
                                        chatterFeature:(ChatterFeature)chatterFeature
                                       rosterDataModel:(ABISFRosterDataModel *)rosterDataModel {
    if (fromViewController) {
        ABIChatterNewPostViewController *chatterNewPostViewController = [fromViewController.storyboard instantiateViewControllerWithIdentifier:@"chatView"];
        if (chatterNewPostViewController) {
            chatterNewPostViewController.rosterDataModel = rosterDataModel;
            chatterNewPostViewController.chatterFeature = chatterFeature;
            [fromViewController.navigationController pushViewController:chatterNewPostViewController animated:YES];
        }
    }
}

- (void)viewDidLoad {
    [super viewDidLoad];
    [self initialSetup];
}
- (void)viewWillAppear:(BOOL)animated {
    [super viewWillAppear:animated];
    if (self.selectedResponderView) {
        [self.selectedResponderView becomeFirstResponder];
    }
    [AppDelegate appdelegateShareInstance].isNewPostDone = NO;
}
- (void)dealloc {
    _privateMentionScrollView = nil;
    _selectedData = nil;
    _searchDataTableView.delegate = nil;
    _searchDataTableView.dataSource = nil;
    _searchDataTableView = nil;
    _searchDataContainerView = nil;
    _parentSearchDataContainerView = nil;
    _selectedResponderView = nil;
    _searchResults = nil;
    _postBodyText = nil;
    _mentionedDetails = nil;
    _recipientRecords = nil;
    [self removeKeyBoardNotification];
}
#pragma mark - Private Method

- (void)initialSetup {
    [self setNavigationPageTitle];
    [self configureUI];
    [self addKeyBoardNotification];
    [self addTapGesture];
    [self resetFormData];
    [self privateMentionScrollVw];
    if (self.chatterFeature == ChatterFeatureOnlyPrivate) {
        [self chatterFeatureOnlyPrivate];
    } else {
        [self updateConstraintReduceSpace];
    }
}

- (void)setNavigationPageTitle {
    self.title = [NSString newChatterPageTitle];
}

- (void)createSeachMentions {
    self.parentSearchDataContainerView = [[UIView alloc] init];
    self.parentSearchDataContainerView.backgroundColor = [UIColor clearColor];
    self.parentSearchDataContainerView.translatesAutoresizingMaskIntoConstraints = NO;
    self.searchDataContainerView = [[UIView alloc] init];
    self.searchDataContainerView.backgroundColor = [UIColor whiteColor];
    self.searchDataContainerView.translatesAutoresizingMaskIntoConstraints = NO;
    self.searchDataTableView = [[UITableView alloc] init];
    self.searchDataTableView.backgroundColor = [UIColor lightTextColor];
    self.searchDataTableView.translatesAutoresizingMaskIntoConstraints = NO;
    self.searchDataTableView.autoresizingMask = UIViewAutoresizingFlexibleHeight | UIViewAutoresizingFlexibleWidth;
    self.searchDataTableView.delegate = self;
    self.searchDataTableView.dataSource = self;
    [self.searchDataTableView reloadData];
    self.searchDataTableView.backgroundColor = [UIColor clearColor];
    [self.searchDataContainerView addSubview:self.searchDataTableView];
    [self.parentSearchDataContainerView addSubview:self.searchDataContainerView];
    [self.view addSubview:self.parentSearchDataContainerView];
    NSDictionary *views = @{
                            @"searchTextField" : self.searchTextField,
                            @"searchDataTableView" : self.searchDataTableView,
                            @"searchDataContainerView" : self.searchDataContainerView,
                            @"parentSearchDataContainerView" : self.parentSearchDataContainerView
                            };
    [self.view addConstraints:[NSLayoutConstraint constraintsWithVisualFormat:@"V:[searchTextField][parentSearchDataContainerView]|"
                                                                      options:0
                                                                      metrics:nil
                                                                        views:views]];
    [self.view
     addConstraints:[NSLayoutConstraint constraintsWithVisualFormat:@"H:|[parentSearchDataContainerView]|" options:0 metrics:nil views:views]];
    [self.parentSearchDataContainerView
     addConstraints:[NSLayoutConstraint constraintsWithVisualFormat:@"V:|[searchDataContainerView]-44-|" options:0 metrics:nil views:views]];
    [self.parentSearchDataContainerView
     addConstraints:[NSLayoutConstraint constraintsWithVisualFormat:@"H:|-[searchDataContainerView]-|" options:0 metrics:nil views:views]];
    [self.searchDataContainerView
     addConstraints:[NSLayoutConstraint constraintsWithVisualFormat:@"V:|-[searchDataTableView]-|" options:0 metrics:nil views:views]];
    [self.searchDataContainerView
     addConstraints:[NSLayoutConstraint constraintsWithVisualFormat:@"H:|[searchDataTableView]|" options:0 metrics:nil views:views]];
    self.parentSearchDataContainerView.hidden = YES;
}
- (void)addKeyBoardNotification {
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(keyboardShown:) name:UIKeyboardDidShowNotification object:nil];
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(keyboardHidden:) name:UIKeyboardDidHideNotification object:nil];
}
- (void)removeKeyBoardNotification {
    [[NSNotificationCenter defaultCenter] removeObserver:self name:UIKeyboardDidShowNotification object:nil];
    [[NSNotificationCenter defaultCenter] removeObserver:self name:UIKeyboardDidHideNotification object:nil];
}
- (void)addTapGesture {
    UITapGestureRecognizer *singleFingerTap = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(handleSingleTap:)];
    [singleFingerTap setCancelsTouchesInView:NO];
    [self.view addGestureRecognizer:singleFingerTap];
}
- (void)configureUI {
    _userNameLbl.text = [AppDelegate globalSingedInABISFRosterDataModel].sfRosterName;
    [self.postBtn setBackgroundColor:[UIColor blueColorABI]];
    self.userNameLbl.font = USERNAME_FONT_SIZE;
    self.userNameLbl.textColor = [UIColor darkGreyColorABI];
    self.privateBtn.clipsToBounds = YES;
    self.privateLabel.font = Private_FONT_SIZE;
    self.privateLabel.textColor = [UIColor defaultTextLightColor];
    self.privateLabel.text = STATIC_TEXT_PRIVATE;
    self.privateBtn.backgroundColor = [UIColor clearColor];
    self.postTextView.placeholder = PLACEHOLDER_TEXT_POST_MSG_BOX;
        // Add Input Accessory View
    [self.postTextView inputAccessoryViewWithAction:@selector(clickedAccessoryDoneButton) target:self barButtonSystemItem:UIBarButtonSystemItemDone];
    self.postTextView.font = COMMENT_FONT_SIZE;
    self.postTextView.textColor = [UIColor darkGreyColorABI];
    self.postTextView.backgroundColor = [UIColor whiteColorABI];
    self.postBtn.titleLabel.font = POSTBTN_FONT_SIZE;
    self.postBtn.titleLabel.textColor = [UIColor whiteColorABI];
    self.fileNameLabel.backgroundColor = [UIColor clearColor];
    self.fileNameLabel.font = [UIFont fontHelvetica57Condensed:12.0f];
    self.fileNameLabel.textColor = [UIColor darkGreyColorABI];
    [self.fileDeleteButton setTitleColor:[UIColor darkGreyColorABI] forState:UIControlStateNormal];
    self.fileDeleteButton.hidden = true;
    self.userImageBorderView.image = [UIImage imageNamed:chatterPostProfile];
    self.userImageView.image = [UIImage imageABIDummyUser];
    [self.userImageView setABISignedInUserProfileImage];
    self.userImageView.clipsToBounds = YES;
    self.userImageView.layer.cornerRadius = self.userImageView.frame.size.height / 2;
    [self.attachmentBtn setBackgroundImage:[UIImage imageNamed:attachment] forState:UIControlStateNormal];
    [self.searchButton setBackgroundImage:[UIImage imageNamed:search_icon] forState:UIControlStateNormal];
    self.searchTextField.font = [UIFont fontHelvetica57Condensed:16.0f];
    self.searchTextField.returnKeyType = UIReturnKeySearch;
        // Add Input Accessory View
    [self.searchTextField inputAccessoryViewWithAction:@selector(clickedSearchTextFieldAccessoryButton)
                                                target:self
                                   barButtonSystemItem:UIBarButtonSystemItemDone];
    [self createSeachMentions];
    self.privateMentionScrollView.delegate = self;
}
- (void)dismissKeyBoard {
    if (self.selectedResponderView && [self.selectedResponderView isFirstResponder]) {
        [self updateViewConstraintsOnKeyBoardHide];
        [self.selectedResponderView resignFirstResponder];
    }
    _selectedResponderView = nil;
}
- (void)openAttachmentOption:(void (^)(void))completion {
    __weak typeof(self) weakSelf = self;
    UIAlertController *actionSheet = [UIAlertController alertControllerWithTitle:nil message:nil preferredStyle:UIAlertControllerStyleActionSheet];
    [actionSheet addAction:[UIAlertAction actionWithTitle:ALT_BTN_TITLE_CANCEL
                                                    style:UIAlertActionStyleCancel
                                                  handler:^(UIAlertAction *action) {
                                                      [self dismissViewControllerAnimated:YES
                                                                               completion:^{
                                                                                   if (completion)
                                                                                       completion();
                                                                               }];
                                                  }]];
    [actionSheet addAction:[UIAlertAction actionWithTitle:ALT_TAKE_PHOTO
                                                    style:UIAlertActionStyleDefault
                                                  handler:^(UIAlertAction *action) {
                                                      [weakSelf openImageControllerWithType:ImagePickerTypeCamera];
                                                      if (completion)
                                                          completion();
                                                  }]];
    [actionSheet addAction:[UIAlertAction actionWithTitle:ALT_PICK_FROM_CAMERA_ROLL
                                                    style:UIAlertActionStyleDefault
                                                  handler:^(UIAlertAction *action) {
                                                      [weakSelf openImageControllerWithType:ImagePickerTypePhotoGallery];
                                                      if (completion)
                                                          completion();
                                                  }]];
    [self presentViewController:actionSheet animated:YES completion:nil];
}
- (void)appendTextMention:(NSString *)mention {
    NSString *text = self.postTextView.text;
    if (text) {
        _postBodyText = nil;
        [self.postBodyText appendString:text];
    }
    if (![NSString isNULLString:mention]) {
        [self.postBodyText appendString:PREFIX_TAG_MENTIONS_NAME];
        [self.postBodyText appendString:mention];
        [self.postBodyText appendString:POST_TAG_MENTIONS_NAME];
        [self.postBodyText appendString:STATIC_TEXT_EMPTY_STRING];
    }
    if (self.postBodyText.length) {
        self.postTextView.text = self.postBodyText;
        if (![self.postTextView isFirstResponder])
            [self.postTextView becomeFirstResponder];
    }
}
- (void)chatterFeatureOnlyPrivate {
    [self.privateBtn setBackgroundImage:[UIImage imageNamed:checkedBox] forState:UIControlStateNormal];
    [self.privateBtn setEnabled:NO];
    [self.attachmentBtn setEnabled:NO];
    self.searchTextField.font = Private_FONT_SIZE;
    self.searchTextField.textColor = [UIColor defaultTextLightColor];
    self.searchButton.hidden = YES;
    self.searchTextField.hidden = YES;
        // self.searchTextField.text = _rosterDataModel.rosterNameText;
    self.privateMentionScrollView.hidden = NO;
    self.privateMentionScrollView.userInteractionEnabled = NO;
    [self.privateMentionScrollView addTag:self.rosterDataModel.sfRosterName];
    self.searchBarTopConstraint.constant = -25.0;
    self.privateMentionScrollView.mode = TagsControlScrollerViewModeList;
}
#pragma mark Reset Page
- (void)resetPageOnClickedForRemoveAttachmentButton {
    self.parentSearchDataContainerView.hidden = YES;
    self.selectedData = nil;
    self.fileNameLabel.text = STATIC_TEXT_EMPTY_STRING;
    if ([self.fileNameLabel.text isEqualToString:STATIC_TEXT_EMPTY_STRING]) {
        self.fileDeleteButton.hidden = true;
    }
    [self updateConstraintReduceSpace];
}
- (void)resetFormData {
    [self dismissKeyBoard];
    [self featureNotAvailableInPrivate];
    [_mentionedDetails removeAllObjects];
    [_recipientRecords removeAllObjects];
    _selectedData = nil;
    _postBodyText = nil;
    _postTextView.text = nil;
    [self updateConstraintReduceSpace];
}
- (void)featureNotAvailableInPrivate {
    self.fileNameLabel.text = STATIC_TEXT_EMPTY_STRING;
    self.searchTextField.text = STATIC_TEXT_EMPTY_STRING;
    self.fileDeleteButton.hidden = true;
    self.selectedData = nil;
    self.fileName = nil;
}
#pragma mark Private Toggol Event
- (void)togglePrivateButton {
    self.isPrivate = !self.isPrivate;
}
#pragma mark Search
- (void)searchMention {
    NSString *searchWord = self.searchTextField.text;
    searchWord = [searchWord toDefaultEncode];

    if ([NSString isNULLString:searchWord]) {
            //--[self.privateBtn setEnabled:YES];
            //--[self.attachmentBtn setEnabled:YES];
        [self alertWithMessage:ALT_MSG_NO_SEARCH_WORD_TEXT clickedOkButton:NULL];
    } else if ([AppDelegate isOffline]) {
        [UIViewController alertInNoNetworkConnection:self clickedOkButton:NULL];
        [self dismissKeyBoard];
    } else {
        [self dismissKeyBoard];
        [CustomLoaderManager showLoader];
        __weak typeof(self) weakSelf = self;
        [self.presenter searchMentionedWithSearchWord:searchWord
                                    mentionSearchType:_isPrivate ? MentionSearchTypeUser : MentionSearchTypeAll
                                               failed:^(NSError *error, NSDictionary *extraInfo) {
                                                   [CustomLoaderManager hideLoader];
                                                   [CustomLoaderManager showFlashWithMessage:ALT_MSG_NO_SEARCH_RESULT_FOUND];
                                               }
                                              success:^(id response, NSDictionary *extraInfo) {
                                                  [weakSelf.privateBtn setEnabled:NO];
                                                  [weakSelf.attachmentBtn setEnabled:NO];
                                                  weakSelf.parentSearchDataContainerView.hidden = NO;
                                                  weakSelf.searchResults = response;
                                                  [weakSelf.searchDataTableView reloadData];
                                                  [CustomLoaderManager hideLoader];
                                              }];
    }
}
#pragma mark Post Feed Event
- (void)clickedAccessoryDoneButton {
    [self updateViewConstraintsOnKeyBoardHide];
    [self.postTextView resignFirstResponder];
}
- (void)clickedSearchTextFieldAccessoryButton {
    [self.searchTextField resignFirstResponder];
}
- (void)postButtonClickForChatterFeatureOnlyPrivate:(UIButton *)sender {
    [self dismissKeyBoard];
    if (self.rosterDataModel.rosterUserID) {
        [self.recipientRecords addObject:self.rosterDataModel.rosterUserID];
    }
    self.parentSearchDataContainerView.hidden = YES;
    NSString *postMessage = self.postTextView.text;

    __weak typeof(self) weakSelf = self;
    void (^completion)(NSString *message, BOOL isSuccess) = ^(NSString *message, BOOL isSuccess) {
        _selectedData = nil;
        dispatch_main_async_safeBlock(^{
            [CustomLoaderManager hideLoader];
            [weakSelf resetFormData];
            weakSelf.isPrivate = NO;
            if (message.length) {
                [CustomLoaderManager showFlashWithMessage:message];
            }
            if (isSuccess) {
                [AppDelegate appdelegateShareInstance].isNewPostDone = YES;
                [NSObject performInMainThreadAfterDelay:2.0 completion:^{ [self.navigationController popViewControllerAnimated:YES]; }];
            }
        });
    };
    if (self.isPrivate && [NSString isNULLString:postMessage]) {
        [self alertWithMessage:ALT_MSG_NO_POST_MGS_TEXT clickedOkButton:NULL];
    } else if (self.isPrivate && self.recipientRecords.count == 0) {
        [self alertWithMessage:ALT_MSG_NO_RECIPIENT_IN_PRIVATE_MESSAGE clickedOkButton:NULL];
    } else if (!self.isPrivate && [NSString isNULLString:postMessage] && !self.selectedData) {
        [self alertWithMessage:ALT_MSG_NO_POST_MGS_TEXT clickedOkButton:NULL];
    } else if ([AppDelegate isOffline]) {
        [UIViewController alertInNoNetworkConnection:self clickedOkButton:NULL];
    } else if (self.isPrivate) {
        [CustomLoaderManager showLoader];
        [self postPrivateMessageForMyDMs:postMessage recipientID:self.rosterDataModel.rosterUserID completion:completion];
    }
}
- (void)postButtonClickWithAllFeature:(UIButton *)sender {
    [self dismissKeyBoard];
    self.parentSearchDataContainerView.hidden = YES;
    NSString *postMessage = self.postTextView.text;

    const char *utfString = [postMessage UTF8String];
    postMessage = [NSString stringWithUTF8String:utfString];

    __weak typeof(self) weakSelf = self;
    void (^completion)(NSString *message, BOOL isSuccess) = ^(NSString *message, BOOL isSuccess) {
        _selectedData = nil;
        dispatch_main_async_safeBlock(^{
            [CustomLoaderManager hideLoader];
            [weakSelf resetFormData];
            weakSelf.isPrivate = NO;
            if (message.length) {
                [CustomLoaderManager showFlashWithMessage:message];
            }
            if (isSuccess) {
                    // Show flash message in Success/Failed Post
                [AppDelegate appdelegateShareInstance].isNewPostDone = YES;
                [NSObject performInMainThreadAfterDelay:FLASH_MESSAGE_DISPLAY_TIME
                                             completion:^{
                                                 [self.navigationController popViewControllerAnimated:YES];
                                                 [CustomLoaderManager hideLoader];
                                             }];
            }
        });
    };
    if (self.isPrivate && [NSString isNULLString:postMessage]) {
        [self alertWithMessage:ALT_MSG_NO_POST_MGS_TEXT clickedOkButton:NULL];
    } else if (self.isPrivate && self.recipientRecords.count == 0) {
        [self alertWithMessage:ALT_MSG_NO_RECIPIENT_IN_PRIVATE_MESSAGE clickedOkButton:NULL];
    } else if (!self.isPrivate && [NSString isNULLString:postMessage] && !self.selectedData) {
        [self alertWithMessage:ALT_MSG_NO_POST_MGS_TEXT clickedOkButton:NULL];
    } else if ([AppDelegate isOffline]) {
        [UIViewController alertInNoNetworkConnection:self clickedOkButton:NULL];
    } else if (self.isPrivate) {
        [CustomLoaderManager showLoader];
        [self postPrivateMessage:postMessage completion:completion];
    } else {
        if ([NSString isNULLString:postMessage]) {
            [self alertWithTitle:STATIC_TEXT_EMPTY_STRING
                         message:ALT_NO_TEXT_WHEN_POST_A_FEED
              defaultButtonTitle:ALT_BTN_TITLE_SEND_ANYWAY
             defaultButtonHander:^{
                 [CustomLoaderManager showLoader];
                 [self postCommomMessage:postMessage completion:completion];
             }
               cancelButtonTitle:ALT_BTN_TITLE_CANCEL
              cancelButtonHander:NULL];
        } else {
            [CustomLoaderManager showLoader];
            [self postCommomMessage:postMessage completion:completion];
        }
    }
}
- (void)postPrivateMessage:(NSString *)postMessage completion:(void (^)(NSString *message, BOOL isSuccess))comoletion {
    NSArray *visibelTags = [self.privateMentionScrollView tags];
    [self.presenter postPrivateMessageWith:postMessage
                    selectedReciapientName:visibelTags
                          recipientRecords:self.recipientRecords
                               failedBlock:^(NSError *error, NSDictionary *extraInfo) {
                                   if (comoletion)
                                       comoletion(ALT_MSG_FAILED_POST, NO);
                               }
                              successBlock:^(id result, NSDictionary *extraInfo) {
                                  if (comoletion)
                                      comoletion(ALT_MSG_SUCESS_POST, YES);
                              }];
}
- (void)postPrivateMessageForMyDMs:(NSString *)postMessageBody
                       recipientID:(NSString *)recipientID
                        completion:(void (^)(NSString *message, BOOL isSuccess))comoletion {
    if (![NSString isNULLString:recipientID]) {
        NSArray *recipientRecords = @[ recipientID ];
        [self.presenter postPrivateMessageForMyDMsWithPostBody:postMessageBody
                                              recipientRecords:recipientRecords
                                                   failedBlock:^(NSError *error, NSDictionary *extraInfo) {
                                                       if (comoletion)
                                                           comoletion(ALT_MSG_FAILED_POST, NO);
                                                   }
                                                  successBlock:^(id result, NSDictionary *extraInfo) {
                                                      if (comoletion)
                                                          comoletion(ALT_MSG_SUCESS_POST, YES);
                                                  }];
    } else if (comoletion)
        comoletion(ALT_MSG_FAILED_POST, NO);
}
- (void)postCommomMessage:(NSString *)postMessage completion:(void (^)(NSString *_Nullable message, BOOL isSuccess))completion {
    NSArray *messageSegments = [ABISFRestJSONParamsBuilder getMessageSegments:postMessage selectedMentionedDetails:self.mentionedDetails];
    [ABISFChatterDataFetcherServices uploadFileWithMessageSegments:messageSegments
                                                          fileData:self.selectedData
                                                         imageName:self.fileName
                                                       description:self.fileName
                                                          mimeType:nil
                                                        completion:^(id result, NSError *error, SOQLStatus status) {
                                                            NSString *message = nil;
                                                            if (completion) {
                                                                switch (status) {
                                                                    case kSOQLStatusFailed: message = ALT_MSG_FAILED_POST; break;
                                                                    case kSOQLStatusSucccess: message = ALT_MSG_SUCESS_POST; break;
                                                                    case kSOQLStatusAttachmentUploadFailed:
                                                                        message = ALT_MSG_FAILED_TO_UPLOAD_ATTACHMENT;
                                                                        break;
                                                                    default: break;
                                                                }
                                                            }
                                                            if (result)
                                                                message = ALT_MSG_SUCESS_POST;
                                                            completion(message, result ? YES : NO);
                                                        }];
}
- (void)cancleBtnClick {
    [self.parentSearchDataContainerView removeFromSuperview];
}
#pragma mark
- (void)updateConstraintsCreateSpace {
    self.searchBarTopConstraint.constant = 10.0f;
    [self.view layoutIfNeeded];
}
- (void)updateConstraintReduceSpace {
    self.searchBarTopConstraint.constant = -20.0f;
    [self.view layoutIfNeeded];
}
- (void)updateViewConstraintsOnKeyBoardHide {
    if (!self.postTextView.text.length) {
        self.postTextView.text = @"";
    }
    [self.postTextView resignFirstResponder];
    self.postContainerBottomConstraint.constant = 44;
    [self.view layoutIfNeeded];
}
#pragma mark
- (void)openImageControllerWithType:(ImagePickerType)imagePickerType {
    __weak typeof(self) weakSelf = self;
    ImagePickerController *imagePickerController = [[ImagePickerController alloc] initWithType:imagePickerType
                                                                                   cancelBlock:^(UIImagePickerController *_Nullable picker) { [weakSelf dismissViewControllerAnimated:YES completion:nil]; }
                                                                                  successBlock:^(NSData *_Nullable data, NSString *_Nullable assetName, NSError *_Nullable error, NSDictionary *_Nullable info) {
                                                                                      weakSelf.fileName = assetName;
                                                                                      [weakSelf dismissViewControllerAnimated:YES
                                                                                                                   completion:^{
                                                                                                                       weakSelf.selectedData = data;
                                                                                                                           //[weakSelf takePermisionForUpDateImage:data completion:^(BOOL willDiscard)
                                                                                                                           //{
                                                                                                                       if (imagePickerController.sourceType == UIImagePickerControllerSourceTypeCamera) {
                                                                                                                               // weakSelf.fileName = [NSString stringWithFormat:IMAGE_FORMAT,[NSDate timeIntervalSinceReferenceDate]];
                                                                                                                           weakSelf.fileName = [NSString stringWithFormat:@"IMG_%.0f.JPG", [NSDate timeIntervalSinceReferenceDate]];
                                                                                                                           self.fileNameLabel.text = STATIC_TEXT_EMPTY_STRING;
                                                                                                                           self.fileNameLabel.text = weakSelf.fileName;
                                                                                                                           self.fileDeleteButton.hidden = NO;
                                                                                                                       } else {
                                                                                                                           weakSelf.fileNameLabel.text = STATIC_TEXT_EMPTY_STRING;
                                                                                                                           weakSelf.fileNameLabel.text = weakSelf.fileName;
                                                                                                                           if (![weakSelf.fileName isEqualToString:STATIC_TEXT_EMPTY_STRING]) {
                                                                                                                               weakSelf.fileDeleteButton.hidden = NO;
                                                                                                                               [weakSelf updateViewConstraintsOnKeyBoardHide];
                                                                                                                           }
                                                                                                                       }
                                                                                                                           //}];
                                                                                                                       [weakSelf updateConstraintsCreateSpace];
                                                                                                                   }];
                                                                                  }];
    [self presentViewController:imagePickerController animated:YES completion:nil];
}
#pragma mark - Accessors
- (id<ABIChatterNewPostViewControllerProtocol>)presenter {
    if (!_presenter) {
        _presenter = [ABIChatterNewPostViewControllerPresenter new];
    }
    return _presenter;
}
- (void)privateMentionScrollVw {
    if (_privateMentionScrollView) {
        _privateMentionScrollView.tagsBackgroundColor = [UIColor blueColorABI];
        _privateMentionScrollView.tagsTextColor = [UIColor whiteColor];
        _privateMentionScrollView.tagsDeleteButtonColor = [UIColor whiteColor];
        _privateMentionScrollView.mode = TagsControlScrollerViewModeEdit;
        [_privateMentionScrollView reloadTagSubviews];
        [_privateMentionScrollView setTapDelegate:self];
    }
}
- (NSMutableString *)postBodyText {
    if (!_postBodyText)
        _postBodyText = [NSMutableString string];
    return _postBodyText;
}
- (NSMutableArray *)mentionedDetails {
    if (!_mentionedDetails) {
        _mentionedDetails = [NSMutableArray new];
    }
    return _mentionedDetails;
}
- (NSMutableArray *)recipientRecords {
    if (!_recipientRecords) {
        _recipientRecords = [NSMutableArray array];
    }
    return _recipientRecords;
}
- (void)setABISFRosterDataModel:(ABISFRosterDataModel *)rosterDataModel {
    _rosterDataModel = rosterDataModel;
}
- (void)setChatterFeature:(ChatterFeature)chatterFeature {
    _chatterFeature = chatterFeature;
    self.isPrivate = (_chatterFeature == ChatterFeatureOnlyPrivate);
}
- (void)setIsPrivate:(BOOL)isPrivate {
    _isPrivate = isPrivate;
    [self.privateBtn setBackgroundImage:[UIImage imageNamed:_isPrivate ? checkedBox : uncheckedBox] forState:UIControlStateNormal];
    [self.attachmentBtn setEnabled:!_isPrivate];
    self.searchTextField.text = nil;
    [self dismissKeyBoard];
    if (_isPrivate) {
        [self featureNotAvailableInPrivate];
    }
    self.privateMentionScrollView.hidden = !_isPrivate;
    if (self.recipientRecords.count)
        [self.recipientRecords removeAllObjects];
    if (self.recipientRecords.count)
        [self.recipientRecords removeAllObjects];
    if (self.privateMentionScrollView)
        [_privateMentionScrollView.tags removeAllObjects];
    [_privateMentionScrollView reloadTagSubviews];
    if (_chatterFeature == ChatterFeatureOnlyPrivate)
        [self chatterFeatureOnlyPrivate];
}
#pragma mark - IBAction
- (IBAction)privateBtnPressed:(id)sender {
    self.parentSearchDataContainerView.hidden = YES;
    NSString *messageText = self.isPrivate ? ALT_MSG_WHEN_PRIVATE_CHECKED : ALT_MSG_WHEN_RESET_NEW_CHATTER_PAGE;
    [self alertWithTitle:nil
                 message:messageText
      defaultButtonTitle:ALT_BTN_TITLE_OK
     defaultButtonHander:^{
         [self resetFormData];
         [self togglePrivateButton];
     }
       cancelButtonTitle:nil
      cancelButtonHander:NULL];
}
- (IBAction)attachmentBtnPressed:(UIButton *)sender {
    if (_isPrivate)
        return;
    self.parentSearchDataContainerView.hidden = YES;
    if (self.selectedData) {
        [self alertWithTitle:STATIC_TEXT_EMPTY_STRING
                     message:ALT_MSG_WHEN_PRIVATE_CLICKED
          defaultButtonTitle:ALT_BTN_TITLE_SURE_BTN_TITLE
         defaultButtonHander:^{
             [self resetPageOnClickedForRemoveAttachmentButton];
             [self openAttachmentOption:NULL];
         }
           cancelButtonTitle:ALT_BTN_TITLE_CANCEL
          cancelButtonHander:NULL];
    } else {
        [self openAttachmentOption:NULL];
    }
}
- (IBAction)postButtonClick:(UIButton *)sender {
    sender.enabled = NO;
    [NSObject performInMainThreadAfterDelay:0.5 completion:^{ sender.enabled = YES; }];
    if (self.chatterFeature == ChatterFeatureAll) {
        [self postButtonClickWithAllFeature:sender];
    } else {
        [self postButtonClickForChatterFeatureOnlyPrivate:sender];
    }
}
- (IBAction)deleteFileBtnClick:(UIButton *)sender {
    [self resetPageOnClickedForRemoveAttachmentButton];
}
- (IBAction)searchIconBtnClick:(UIButton *)sender {
    [self searchMention];
}
#pragma mark - Keyboard Delegate
- (void)keyboardShown:(NSNotification *)notification {
    CGRect initialFrame = [[[notification userInfo] objectForKey:UIKeyboardFrameEndUserInfoKey] CGRectValue];
    CGRect convertedFrame = [self.view convertRect:initialFrame fromView:nil];
    self.postContainerBottomConstraint.constant = convertedFrame.size.height + 5.0f;
    [self.view layoutIfNeeded];
}
- (void)keyboardHidden:(NSNotification *)notification {
    [self updateViewConstraintsOnKeyBoardHide];
}
#pragma mark - TableView DataSource Implementation
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    return self.searchResults.count;
}
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    static NSString *cellIdentifier = @"Cell";
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:cellIdentifier];
    if (cell == nil)
        cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:cellIdentifier];
    ABISFChatterMentionDataModel *mentionDataModel = [NSArray objectFromArray:self.searchResults atIndex:indexPath.row];
    cell.textLabel.font = [UIFont fontHelvetica57Condensed:14.0f];
    if (mentionDataModel) {
        if (![NSString isNULLString:mentionDataModel.name])
            cell.textLabel.text = mentionDataModel.name;
    }
    cell.backgroundColor = cell ? [UIColor whiteColor] : [UIColor clearColor];
    return cell;
}
- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath {
    return 35.0f;
}
- (CGFloat)tableView:(UITableView *)tableView heightForFooterInSection:(NSInteger)section {
    return 0.01f;
}
- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
    self.searchTextField.text = nil;
    ABISFChatterMentionDataModel *mentionDataModel = [NSArray objectFromArray:self.searchResults atIndex:indexPath.row];
    if (mentionDataModel) {
        NSString *name = mentionDataModel.name;
        if (name) {
            if (_isPrivate) {
                /*if(self.privateMentionScrollView.tags.count > 9) {
                 [self alertWithMessage:ALT_MSG_MAX_RECIPIENT_IN_PRIVATE_MESSAGE clickedOkButton:NULL];
                 } else*/
                [self.recipientRecords addObject:mentionDataModel];
                [self.privateMentionScrollView addTag:name];
                [self updateConstraintsCreateSpace];
            } else {
                if (![NSString isNULLString:name]) {
                    [self appendTextMention:name];
                }
                [self.mentionedDetails addObject:mentionDataModel];
            }
        }
    }
    [self.privateBtn setEnabled:YES];
    if (self.isPrivate) {
        [self.attachmentBtn setEnabled:NO];
    } else {
        [self.attachmentBtn setEnabled:YES];
    }
    self.parentSearchDataContainerView.hidden = YES;
    [self.searchTextField resignFirstResponder];
}
#pragma mark - UITapGestureRecognizer Event
- (void)handleSingleTap:(UITapGestureRecognizer *)recognizer {
    CGPoint location = [recognizer locationInView:recognizer.view];
    if (CGRectContainsPoint(self.parentSearchDataContainerView.frame, location)) {
        return;
    }
    if (self.chatterFeature == ChatterFeatureAll) {
        self.parentSearchDataContainerView.hidden = YES;
        if (self.isPrivate) {
            [self.attachmentBtn setEnabled:NO];
        } else {
            [self.attachmentBtn setEnabled:YES];
        }
        [self.privateBtn setEnabled:YES];
    } else {
        [self chatterFeatureOnlyPrivate];
    }
}
#pragma mark - UITextView Delegate
- (BOOL)textViewShouldBeginEditing:(UITextView *)textView {
    self.selectedResponderView = textView;
    if (!self.postTextView.text.length) {
        self.postTextView.text = @"";
    }
    return YES;
}
#pragma mark - UITextField delegate
- (BOOL)textFieldShouldBeginEditing:(UITextField *)textField {
    self.selectedResponderView = textField;
    return YES;
}
- (BOOL)textFieldShouldReturn:(UITextField *)textField {
    [self updateViewConstraintsOnKeyBoardHide];
    [textField resignFirstResponder];
    [self searchMention];
    return NO;
}
#pragma mark - TagsControlScrollerViewDelegate
- (void)deleteItems:(NSInteger)index {
    if (index == 0)
        [self updateConstraintReduceSpace];
}
@end
