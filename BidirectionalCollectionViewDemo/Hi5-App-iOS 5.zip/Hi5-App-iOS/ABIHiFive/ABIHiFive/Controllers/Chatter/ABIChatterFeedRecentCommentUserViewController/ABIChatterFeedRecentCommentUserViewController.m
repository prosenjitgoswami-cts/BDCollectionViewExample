    //
    //  AssessmentsViewController.m
    //  HelloObjC
    //
    //  Created by KoliMac1 on 08/07/16.
    //  Copyright © 2016 KoliMac1. All rights reserved.
    //
#import "ABIChatterFeedRecentCommentUserViewController.h"
#import "ABIAnnouncementsPopoverTableViewCell.h"
#import "ABISFChatterCommentItemModel.h"
#import "ABISFDataFetcherService.h"
#import "Constants.h"
#import "ABIChatterFeedRecentCommentUserViewControllerCell.h"
static CGFloat kIntervalTime = 0.6f;
@interface ABIChatterFeedRecentCommentUserViewController () <UITableViewDelegate, UITableViewDataSource, UIGestureRecognizerDelegate>
@property (strong, nonatomic) UIView *customBackgroundView;
@property (strong, nonatomic) UILabel *headerLabel;
@property (strong, nonatomic) UITableView *announcementsTableView;
@property (strong, nonatomic) UITapGestureRecognizer *tapGesture;
@property (strong, nonatomic) UIWindow *window;
@property (strong, nonatomic) AppDelegate *appDelegate;
@property (strong, nonatomic) ProgressHUD *hud;
@property (strong, nonatomic) UIView *headerView;
@property (strong, nonatomic) UIButton *dismissButton;
@property (strong, nonatomic) NSNumber *parentViewBackgroundHeight;
@property (strong, nonatomic) NSMutableDictionary *metrices;
@end
@implementation ABIChatterFeedRecentCommentUserViewController
#pragma mark - ViewController Life Cycle
- (void)loadView {
    [super loadView];
    UIView *contentView = [[UIView alloc] initWithFrame:[UIScreen mainScreen].bounds];
    contentView.backgroundColor = [[UIColor blackColor] colorWithAlphaComponent:0.5];
    self.view = contentView;
}
- (void)viewDidLoad {
    [super viewDidLoad];
    [self configureUI];
}
- (void)viewWillAppear:(BOOL)animated {
    [super viewWillAppear:animated];
        //    if([NSArray isValidArray:[ABISFDataFetcherService shareInstance].announcementsDrtails]) {
        //
        //        self.announcements = [ABISFDataFetcherService shareInstance].announcementsDrtails;
        //        [self.announcementsTableView reloadData];
        //    }
}
- (void)dealloc {
    _customBackgroundView = nil;
    _headerLabel = nil;
    _announcementsTableView = nil;
    _tapGesture = nil;
    _window = nil;
    _appDelegate = nil;
    _announcements = nil;
    _headerView = nil;
}
#pragma mark - Public Method
- (void)showWithCompletion:(Comlition)comlition {
    if (!_window) {
        CGRect syncWindowFrame = [UIScreen mainScreen].bounds; //[UIScreen mainScreen].applicationFrame;
        _window = [[UIWindow alloc] initWithFrame:syncWindowFrame];
        _window.backgroundColor = [[UIColor blackColor] colorWithAlphaComponent:0.3];
    }
    _window.windowLevel = UIWindowLevelAlert;
    if (!_window.rootViewController)
        _window.rootViewController = self;
    [_window makeKeyAndVisible];
    [UIView animateWithDuration:kIntervalTime
                     animations:^{ _window.alpha = 1.0; }
                     completion:^(BOOL finished) {
                         if (comlition)
                             comlition();
                     }];
}
- (void)hideWithCompletion:(Comlition)comlition {
    _window.windowLevel = 0;
    _window.alpha = 1.0;
    [UIView animateWithDuration:kIntervalTime
                     animations:^{
                         _window.alpha = 0.0;
                         [_window resignKeyWindow];
                         [self.appDelegate.window makeKeyAndVisible];
                     }
                     completion:^(BOOL finished) {
                         if (comlition)
                             comlition();
                     }];
}
- (void)toggolVisibility {
    if (!self.window.alpha)
        [self showWithCompletion:nil];
    else
        [self hideWithCompletion:nil];
}
#pragma mark - Private Method
/*!
 *  Create UI with Component
 */
- (void)configureUI {
    [self.view addSubview:self.customBackgroundView];
    [self.customBackgroundView addSubview:self.headerView];
    [self.customBackgroundView addSubview:self.announcementsTableView];
    [self.headerView addSubview:self.headerLabel];
    [self.headerView addSubview:self.dismissButton];
    [self.view addGestureRecognizer:self.tapGesture];
        //[self addContrains];
    self.customBackgroundView.alpha = 0.0;
    [CustomLoaderManager showLoader];
}
/*!
 *  Add configure UI with Component
 */
- (void)addContrains {
    NSDictionary *views = @{
                            @"customBackgroundView" : self.customBackgroundView,
                            @"announcementsTableView" : self.announcementsTableView,
                            @"headerLabel" : self.headerLabel,
                            @"headerView" : self.headerView,
                            @"dismissButton" : self.dismissButton
                            };
    [self.view addConstraintsWithVisualFormat:@"V:|-94-[customBackgroundView(ParentViewHeight)]" options:0 metrics:self.metrices views:views];
    [self.customBackgroundView widthMultiplyBy:0.85 toParent:self.view];
    [self.customBackgroundView centerXToParent:self.view];
    [self.customBackgroundView addConstraintsWithVisualFormat:@"H:|[headerView]|" options:0 metrics:nil views:views];
    [self.customBackgroundView addConstraintsWithVisualFormat:@"H:|[announcementsTableView]|" options:0 metrics:nil views:views];
    [self.customBackgroundView addConstraintsWithVisualFormat:@"V:|[headerView(30.0)][announcementsTableView]|" options:0 metrics:nil views:views];
    [self.headerView addConstraintsWithVisualFormat:@"H:|-10-[headerLabel][dismissButton(20)]-10-|" options:0 metrics:nil views:views];
    [self.headerView addConstraintsWithVisualFormat:@"V:|-5-[dismissButton]-5-|" options:0 metrics:nil views:views];
    [self.headerView addConstraintsWithVisualFormat:@"V:|[headerLabel]|" options:0 metrics:nil views:views];
}

- (void)aMethod {
    [self hideWithCompletion:nil];
}
#pragma mark - Accessors
- (AppDelegate *)appDelegate {
    if (!_appDelegate)
        _appDelegate = [[UIApplication sharedApplication] delegate];
    return _appDelegate;
}
- (UIView *)headerView {
    if (!_headerView) {
        _headerView = [UIView new];
        _headerView.translatesAutoresizingMaskIntoConstraints = NO;
        _headerView.backgroundColor = [UIColor clearColor];
    }
    return _headerView;
}
- (UIView *)customBackgroundView {
    if (!_customBackgroundView) {
        _customBackgroundView = [UIView new];
        _customBackgroundView.translatesAutoresizingMaskIntoConstraints = NO;
        _customBackgroundView.layer.cornerRadius = 5.0;
        _customBackgroundView.clipsToBounds = YES;
        _customBackgroundView.backgroundColor = ANNOUNCEMENT_TABLE_HEADER_TITLE_COLOR;
    }
    return _customBackgroundView;
}
- (UITableView *)announcementsTableView {
    if (!_announcementsTableView) {
        _announcementsTableView = [[UITableView alloc] init];
        _announcementsTableView.delegate = self;
        _announcementsTableView.dataSource = self;
        _announcementsTableView.estimatedRowHeight = 150;
        _announcementsTableView.rowHeight = UITableViewAutomaticDimension;
        _announcementsTableView.separatorStyle = UITableViewCellSeparatorStyleSingleLine;
        _announcementsTableView.translatesAutoresizingMaskIntoConstraints = NO;
    }
    return _announcementsTableView;
}
- (UILabel *)headerLabel {
    if (!_headerLabel) {
        _headerLabel = [UILabel new];
        _headerLabel.translatesAutoresizingMaskIntoConstraints = NO;
        _headerLabel.font = ANNOUNCEMENT_TABLE_HEADER_TITLE_FONT;
        _headerLabel.backgroundColor = ANNOUNCEMENT_TABLE_HEADER_TITLE_COLOR;
        _headerLabel.text = kComment;
    }
    return _headerLabel;
}
- (UITapGestureRecognizer *)tapGesture {
    if (!_tapGesture) {
        _tapGesture = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(gestureHandler)];
        _tapGesture.numberOfTapsRequired = 1;
        _tapGesture.numberOfTouchesRequired = 1;
        _tapGesture.delegate = self;
    }
    return _tapGesture;
}
- (UIButton *)dismissButton {
    if (!_dismissButton) {
        _dismissButton = [UIButton new];
        _dismissButton.backgroundColor = [UIColor clearColor];
        [_dismissButton addTarget:self action:@selector(aMethod) forControlEvents:UIControlEventTouchUpInside];
        [_dismissButton setBackgroundImage:[UIImage imageNamed:cancelButtonImage] forState:UIControlStateNormal];
        _dismissButton.translatesAutoresizingMaskIntoConstraints = NO;
            //        _dismissButton.layer.cornerRadius = 10; // this value vary as per your desire
            //        _dismissButton.clipsToBounds = YES;
            //        [[_dismissButton layer] setBorderWidth:1.0f];
            //        [[_dismissButton layer] setBorderColor:[UIColor blackColorABI].CGColor];
            // [_dismissButton setTitle:@"Show View" forState:UIControlStateNormal];
    }
    return _dismissButton;
}
    // MARK:  Setter Method
- (void)setAnnouncements:(NSArray<ABISFAnnouncementDataModel *> *)announcements {
    _announcements = announcements;
    NSNumber *n = [NSNumber numberWithInteger:_announcements.count];
    if ([n intValue] <= 6) {
        self.announcementsTableView.scrollEnabled = NO;
        self.parentViewBackgroundHeight = @([n integerValue] * 54 + 30);
    } else {
        self.announcementsTableView.scrollEnabled = YES;
        self.parentViewBackgroundHeight = @(6 * 54 + 30);
    }
    self.metrices = [NSMutableDictionary dictionary];
    [self.metrices setObject:@(self.parentViewBackgroundHeight.floatValue) forKey:@"ParentViewHeight"];
    [self addContrains];
    [self.announcementsTableView reloadData];
    [CustomLoaderManager hideLoader];
    [UIView animateWithDuration:0.3 animations:^{ self.customBackgroundView.alpha = 1.0; }];
}

#pragma mark - IB Event
- (void)gestureHandler {
    [self hideWithCompletion:nil];
}
#pragma mark -
#pragma mark UITableViewDataSource
- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
    return 1;
}
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    return self.announcements.count;
}
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    static NSString *cellIdentifier = @"CellIdentifier";
    ABIChatterFeedRecentCommentUserViewControllerCell *cell = (ABIChatterFeedRecentCommentUserViewControllerCell *)[tableView dequeueReusableCellWithIdentifier:cellIdentifier];
    if (!cell) {
        cell = [[ABIChatterFeedRecentCommentUserViewControllerCell alloc] initWithStyle:UITableViewCellStyleSubtitle reuseIdentifier:cellIdentifier];
    }
    ABISFChatterCommentItemModel *datamodel = [NSArray objectFromArray:self.announcements atIndex:indexPath.row];
    [cell updateCellWithABISFChatterCommentItemModel:datamodel];
    cell.selectionStyle = UITableViewCellSelectionStyleNone;
    return cell;
}
- (CGFloat)tableView:(UITableView *)tableView heightForFooterInSection:(NSInteger)section {
    return 1.0f;
}
- (UIView *)tableView:(UITableView *)tableView viewForFooterInSection:(NSInteger)section {
    return [UIView new];
}
#pragma mark -
#pragma mark UITableViewDelegate
- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath {
    return 54.0;
}

#pragma mark UIGestureRecognizer Delegate
- (BOOL)gestureRecognizer:(UIGestureRecognizer *)gestureRecognizer shouldReceiveTouch:(UITouch *)touch {
    
    return NO;
}
@end
