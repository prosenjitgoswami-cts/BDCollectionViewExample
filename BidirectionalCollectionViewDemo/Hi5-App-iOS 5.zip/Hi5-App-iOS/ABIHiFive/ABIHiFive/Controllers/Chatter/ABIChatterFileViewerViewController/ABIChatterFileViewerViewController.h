    //
    //  ABIChatterFileViewerViewController.h
    //  ABIHiFive
    //
    //  Created by Prsenjit Goswami on 02/08/16.
    //  Copyright © 2016 Cognizant. All rights reserved.
    //
#import "ABIBaseViewController.h"
#import <UIKit/UIKit.h>
@class ABISFChatterContentDataModel;
@interface ABIChatterFileViewerViewController : ABIBaseViewController
@property (strong, nonatomic) ABISFChatterContentDataModel *contentDataModel;
@end
