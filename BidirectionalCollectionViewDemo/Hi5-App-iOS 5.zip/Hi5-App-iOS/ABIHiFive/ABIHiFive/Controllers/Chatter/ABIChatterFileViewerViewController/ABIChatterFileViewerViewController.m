    //
    //  ABIChatterFileViewerViewController.m
    //  ABIHiFive
    //
    //  Created by Prsenjit Goswami on 02/08/16.
    //  Copyright © 2016 Cognizant. All rights reserved.
    //
#import "ABIChatterFileViewerViewController.h"
#import "ABISFChatterContentDataModel.h"
#import "ABISFRestRequestManager.h"
#import "Constants.h"
@interface ABIChatterFileViewerViewController () <UIWebViewDelegate>
@property (strong, nonatomic) UIWebView *webView;
@property (weak, nonatomic) SFRestRequest *request;
@end
@implementation ABIChatterFileViewerViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    [self configureUI];
    [self loadContain:self.contentDataModel];
}

#pragma mark -  Private Method
- (void)configureUI {
    [self.view addSubview:self.webView];
    [self addConstraints];
}
- (void)clickedToggleMenu {
    [self cancelRequest];
    [self dismissViewControllerAnimated:YES completion:nil];
}
- (UIWebView *)webView {
    if (!_webView) {
        _webView = [[UIWebView alloc] init];
        _webView.delegate = self;
        _webView.translatesAutoresizingMaskIntoConstraints = NO;
        _webView.clipsToBounds = YES;
    }
    return _webView;
}
- (void)setNavigationPageTitle {
    self.title = [NSString chatterFileViewer:self.contentDataModel];
}

- (void)loadContain:(ABISFChatterContentDataModel *)contentDataModel {
    [self setNavigationPageTitle]; // self.contentDataModel.title;
    if ([AppDelegate isOffline]) {
        [UIViewController alertInNoNetworkConnection:self clickedOkButton:NULL];
        [CustomLoaderManager hideLoader];
    } else {
        _contentDataModel = contentDataModel;
        NSString *fileExtension = contentDataModel.fileExtension;
        fileExtension = [fileExtension lowercaseString];
        if ([fileExtension containsString:m4v] || [fileExtension containsString:mp4] || [fileExtension containsString:mov] ||
            [fileExtension containsString:pdf] || [fileExtension containsString:docx] || [fileExtension containsString:txt] ||
            [fileExtension containsString:xlsx] || [fileExtension containsString:xls]) {
            [CustomLoaderManager showLoader];
            __weak typeof(self) weakSelf = self;
            self.request = [ABISFRestRequestManager requestForFileContentsWithABISFChatterContentDataModel:_contentDataModel
                                                                                                completion:^(NSString *filePath, BOOL isNewFile) {
                                                                                                    [weakSelf loadContainFilesInWebView:filePath];
                                                                                                }];
        } else {
            [self alertWithMessage:ALT_MSG_INCOMPATIBLE_FILE_TYPE];
        }
    }
}
- (void)addConstraints {
    NSDictionary *views = @{ @"webView" : self.webView };
    [self.view addConstraints:[NSLayoutConstraint constraintsWithVisualFormat:@"H:|-10-[webView]-10-|" options:0 metrics:nil views:views]];
    [self.view addConstraints:[NSLayoutConstraint constraintsWithVisualFormat:@"V:|-10-[webView]-10-|" options:0 metrics:nil views:views]];
}
- (void)loadContainFilesInWebView:(NSString *)containFilePathString {
    if (containFilePathString.length) {
        NSURL *targetURL = [NSURL fileURLWithPath:containFilePathString];
        NSURLRequest *request = [NSURLRequest requestWithURL:targetURL];
        [self.webView loadRequest:request];
    } else {
        [self cancelRequest];
    }
}
- (void)webViewDidFinishLoad:(UIWebView *)webView {
    [self cancelRequest];
}
- (void)webView:(UIWebView *)webView didFailLoadWithError:(nullable NSError *)error {
    [self cancelRequest];
}
- (void)cancelRequest {
    if (self.request) {
        [self.request cancel];
        _request = nil;
    }
    [CustomLoaderManager hideLoader];
}
- (void)clickedToggleMenu:(UIButton *)sender {
    [self dismissViewControllerAnimated:YES completion:nil];
}
@end
