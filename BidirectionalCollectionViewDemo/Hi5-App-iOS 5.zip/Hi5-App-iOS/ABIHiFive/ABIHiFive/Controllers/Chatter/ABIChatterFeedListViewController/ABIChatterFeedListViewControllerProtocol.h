    //
    //  ABIChatterFeedListViewControllerProtocol.h
    //  ABIHiFive
    //
    //  Created by Prsenjit Goswami on 24/07/16.
    //  Copyright © 2016 Cognizant. All rights reserved.
    //
#import "Constants.h"
#import <Foundation/Foundation.h>
@protocol ABIChatterFeedListViewControllerProtocol <NSObject>
- (void)invokeUserFeedsAndRefreshUIWithFeedType:(ChatterFeedType)chatterFeedType
                                    nextPageURL:(NSString *)nextPageURL
                                       feedInfo:(void (^)(id feedInfoObject))feedInfo
                                     completion:(SOQLCompletion)completion;
- (void)postCommentOnAfeedWithFeedID:(NSString *)feedID commentText:(NSString *)commentText completion:(SOQLCompletion)completionBlock;
@end
