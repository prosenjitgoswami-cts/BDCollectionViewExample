    //
    //  ABIChatterFeedListViewController.m
    //  AnheuserBusch
    //
    //  Created by Prsenjit Goswami on 21/07/16.
    //  Copyright © 2016 Cognizant. All rights reserved.
    //
#import "ABIChatterFeedListViewController.h"
#import "ABIChatterFeedListTableViewCell.h"
#import "ABISFChatterCommentItemModel.h"
#import "ABISFChatterDataFetcherServices.h"
#import "ABIChatterDetailsViewController.h"
#import "ABIChatterFileViewerViewController.h"
#import "ABIChatterFeedListViewControllerPresenter.h"
#import "Constants.h"
#import "ABIChatterFeedRecentCommentUserViewController.h"
@interface ABIChatterFeedListViewController () <UITableViewDelegate, UITableViewDataSource, ABIChatterFeedListTableViewCellDelegate>
    // UI Elements
@property (strong, nonatomic) NSLayoutConstraint *tableViewBottomConstraint;
@property (strong, nonatomic) UITableView *postListTableView;
@property (strong, nonatomic) UIView *tableFooter;
@property (strong, nonatomic) UIButton *seeMoreButton;
    // Constrainst
@property (strong, nonatomic) NSDictionary *views;
@property (strong, nonatomic) NSMutableDictionary *metrics;
@property (strong, nonatomic) NSArray *verticalContraints;
@property (assign, nonatomic) CGFloat initialHeight;
@property (assign, nonatomic) CGRect initialTableViewFrame;
/*--------------------------------------------*/
@property (strong, nonatomic) id<ABIChatterFeedListViewControllerProtocol> presenter;
@property (strong, nonatomic) NSMutableArray *chatterFeeds;
@property (strong, nonatomic) NSString *nextPageUrl;
    //@property (strong, nonatomic) NSMutableDictionary *dict;
@property (weak, nonatomic) ABIChatterFeedListTableViewCell *selectedCell;
@property (strong, nonatomic) id selectedDataModel;
@property (assign, nonatomic) BOOL isFetchRunning;
@property (strong, nonatomic) NSIndexPath *indexPath;
@end
@implementation ABIChatterFeedListViewController
#pragma mark - View Controller Life Cycle Methods
- (instancetype)initWithChatterType:(ChatterFeedType)chatterFeedType {
    self = [super init];
    if (self) {
        self.chatterFeedType = chatterFeedType;
    }
    return self;
}
- (void)viewDidLoad {
    [super viewDidLoad];
    [self configureUI];
    self.tableFooter.hidden = YES;
    self.isNeedRefreshUI = YES;
    [AppDelegate appdelegateShareInstance].isNewPostDone = YES;
}
- (void)viewDidAppear:(BOOL)animated {
    [super viewDidAppear:animated];
    _selectedDataModel = nil;
    if (self.isNeedRefreshUI) {
        [self invokeServiceAndRefreshUIWithFeedType:self.chatterFeedType completion:NULL];
        self.isNeedRefreshUI = NO;
    }
}

- (void)viewWillDisappear:(BOOL)animated {
    [super viewWillDisappear:animated];
    [self.selectedCell dismissKeyBoard];
}
- (void)dealloc {
    [[NSNotificationCenter defaultCenter] removeObserver:self name:UIKeyboardDidShowNotification object:nil];
    [[NSNotificationCenter defaultCenter] removeObserver:self name:UIKeyboardDidHideNotification object:nil];
    _postListTableView.delegate = nil;
    _postListTableView.dataSource = nil;
    _postListTableView = nil;
        //    [self cleanUpCell];
    [_chatterFeeds removeAllObjects];
    _chatterFeeds = nil;
}
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(UIButton *)sender {
    NSString *segueIdentifier = [segue identifier];
    if ([segueIdentifier isEqualToString:SEGUE_ID_PushToABIChatterDetailsViewController]) {
        ABIChatterDetailsViewController *destination = [segue destinationViewController];
        if (destination && self.selectedDataModel) {
            [destination setDataModel:self.selectedDataModel];
        }
    }
}
#pragma mark - Public Method
- (void)refreshOnTabChange {
    [self invokeServiceAndRefreshUIWithFeedType:self.chatterFeedType completion:NULL];
}

- (void)setChatterFeeds:(NSMutableArray *)chatterFeeds {
    _chatterFeeds = chatterFeeds;
    [self.postListTableView reloadData];
}
- (void)setChatterFeedType:(ChatterFeedType)chatterFeedType {
    _chatterFeedType = chatterFeedType;
    [self invokeServiceAndRefreshUIWithFeedType:self.chatterFeedType completion:NULL];
}
#pragma mark - Service
    //- (void)cleanUpCell {
    //    for (ABIChatterFeedListTableViewCell *obj in [self.dict allValues]) {
    //        obj.delegate = nil;
    //        [obj removeFromSuperview];
    //    }
    //    if (self.dict && self.dict.count) {
    //        [self.dict removeAllObjects];
    //    }
    //        _dict = nil;
    //    for (ABIChatterFeedListTableViewCell *obj in [self.dict allValues]) {
    //        obj.delegate = nil;
    //        [obj removeFromSuperview];
    //    }
    //
    //}
- (void)invokeServiceAndRefreshUIWithFeedType:(ChatterFeedType)chatterFeedType completion:(void (^)(void))completion {
    if ([AppDelegate isOffline]) {
        [UIViewController alertInNoNetworkConnection:self clickedOkButton:NULL];
        [CustomLoaderManager hideLoader];
    } else {
        if (self.isFetchRunning)
            return;
        [CustomLoaderManager showLoader];
        __weak typeof(self) weakSelf = self;
        __block BOOL shouldReloadTableVw = ![NSArray isValidArray:weakSelf.chatterFeeds];
        [self.presenter invokeUserFeedsAndRefreshUIWithFeedType:chatterFeedType
                                                    nextPageURL:self.nextPageUrl
                                                       feedInfo:^(id feedInfoObject) {
                                                           weakSelf.nextPageUrl = feedInfoObject;
                                                           [weakSelf addSeeMoreButton];
                                                       }
                                                     completion:^(id result, NSError *error, SOQLStatus status) {
                                                         NSMutableArray *results = (NSMutableArray *)result;

                                                         if (results && results.count) {
                                                             switch (chatterFeedType) {
                                                                 case ChatterFeedTypeCustomPath:
                                                                 case ChatterFeedTypeMessageCustomPath: {

                                                                         // NSUInteger previousCount = weakSelf.chatterFeeds.count;

                                                                     [weakSelf.chatterFeeds addObjectsFromArray:results];
                                                                     NSArray *sortedArray = [weakSelf.chatterFeeds sortArrayForKey:kCreatedDate ascending:NO];
                                                                     weakSelf.chatterFeeds = [sortedArray mutableCopy];

                                                                         //                                                                     if(previousCount > 0 && ![weakSelf.chatterFeeds
                                                                         //                                                                     indexOutOfBound:previousCount+1]) {
                                                                         //                                                                      [self.postListTableView scrollToRowAtIndexPath:[NSIndexPath
                                                                         //                                                                      indexPathForRow:0 inSection:previousCount+1] atScrollPosition:
                                                                         //                                                                      UITableViewScrollPositionBottom  animated:NO];
                                                                         // }
                                                                 } break;
                                                                 case ChatterFeedTypeAll:
                                                                 case ChatterFeedTypeMe:
                                                                 case ChatterGetMessages:
                                                                     [weakSelf.chatterFeeds removeAllObjects];
                                                                     _chatterFeeds = nil;
                                                                     shouldReloadTableVw = ![NSArray isValidArray:weakSelf.chatterFeeds];
                                                                     weakSelf.chatterFeeds = results;
                                                                         // shouldReloadTableVw = YES;
                                                                     break;
                                                                 default: break;
                                                             }
                                                         } else {
                                                             [weakSelf.chatterFeeds removeAllObjects];
                                                             _chatterFeeds = nil;
                                                             switch (chatterFeedType) {
                                                                 case ChatterFeedTypeAll: [self alertWithMessage:ALT_MSG_NO_POST]; break;
                                                                 case ChatterGetMessages: [self alertWithMessage:ALT_MSG_NO_MSG]; break;
                                                                 default: break;
                                                             }
                                                             weakSelf.tableFooter.hidden = YES;
                                                         }

                                                         if (shouldReloadTableVw) {
                                                             [weakSelf.postListTableView reloadData];
                                                             [self.postListTableView scrollToRowAtIndexPath:[NSIndexPath indexPathForRow:0 inSection:0]
                                                                                           atScrollPosition:UITableViewScrollPositionTop
                                                                                                   animated:NO];
                                                         }

                                                             //                                                         if([AppDelegate appdelegateShareInstance].isNewPostDone) {
                                                             //                                                             [self.postListTableView scrollToRowAtIndexPath:[NSIndexPath indexPathForRow:0
                                                             //                                                             inSection:0]
                                                             //                                                                                           atScrollPosition:UITableViewScrollPositionTop
                                                             //                                                                                                   animated:NO];
                                                             //                                                         }

                                                         [CustomLoaderManager hideLoaderOnDelay:2.0
                                                                                     completion:^{
                                                                                         if (completion)
                                                                                             completion();

                                                                                     }];

                                                     }];
        self.isFetchRunning = NO;
    }
}
- (void)addSeeMoreButton {
    dispatch_main_async_safeBlock(^{
        if (![NSString isNULLString:self.nextPageUrl]) {
            self.tableFooter.hidden = NO;
            self.postListTableView.tableFooterView = self.tableFooter;
        } else {
            self.tableFooter.hidden = YES;
            self.postListTableView.tableFooterView = nil;
        }
    });
}
#pragma mark - Private Method
- (void)configureUI {
    [self.view addSubview:self.postListTableView];
    [self addConstraints];
    [self addKeyBoardNotificationObserver];
}
- (void)didSelectMenuOptionAtIndex:(NSInteger)row {
    NSLog(@"Floating action tapped index %tu", row);
}
- (void)addConstraints {
        // self.views = @{@"postListTableView": self.postListTableView};
    [self.view addConstraints:[NSLayoutConstraint constraintsWithVisualFormat:@"H:|-5-[postListTableView]-5-|" options:0 metrics:nil views:self.views]];
    self.verticalContraints = [NSLayoutConstraint constraintsWithVisualFormat:@"V:|-10-[postListTableView]|" options:0 metrics:nil views:self.views];
    [self.view addConstraints:self.verticalContraints];
    [self.tableFooter
     addConstraints:[NSLayoutConstraint constraintsWithVisualFormat:@"V:|-5-[seeMoreButton]-5-|" options:0 metrics:nil views:self.views]];
    [self.tableFooter addConstraints:[NSLayoutConstraint constraintsWithVisualFormat:@"H:|[seeMoreButton(60)]" options:0 metrics:nil views:self.views]];
}
- (void)addKeyBoardNotificationObserver {
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(keyboardShown:) name:UIKeyboardDidShowNotification object:nil];
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(keyboardHidden:) name:UIKeyboardDidHideNotification object:nil];
}
- (void)keyboardShown:(NSNotification *)notification {
    _initialHeight = _postListTableView.frame.size.height;
    CGRect initialFrame = [[[notification userInfo] objectForKey:UIKeyboardFrameEndUserInfoKey] CGRectValue];
    CGRect convertedFrame = [self.view convertRect:initialFrame fromView:nil];
    [self.metrics setObject:@(convertedFrame.size.height) forKey:@"hPadding"];
    if (self.verticalContraints) {
        [self.view removeConstraints:self.verticalContraints];
    }
    self.verticalContraints =
    [NSLayoutConstraint constraintsWithVisualFormat:@"V:|-10-[postListTableView]-hPadding-|" options:0 metrics:self.metrics views:self.views];
    [self.view addConstraints:self.verticalContraints];
    [self.view layoutIfNeeded];
}
- (void)keyboardHidden:(NSNotification *)notification {
    self.tableViewBottomConstraint.constant = 0;
    if (self.verticalContraints) {
        [self.view removeConstraints:self.verticalContraints];
    }
    self.verticalContraints = [NSLayoutConstraint constraintsWithVisualFormat:@"V:|-10-[postListTableView]|" options:0 metrics:nil views:self.views];
    [self.view addConstraints:self.verticalContraints];
    [self.view layoutIfNeeded];
}

#pragma mark - Accessors
- (id<ABIChatterFeedListViewControllerProtocol>)presenter {
    if (!_presenter) {
        _presenter = [ABIChatterFeedListViewControllerPresenter new];
    }
    return _presenter;
}
- (UITableView *)postListTableView {
    if (!_postListTableView) {
        _postListTableView = [[UITableView alloc] init];
        _postListTableView.translatesAutoresizingMaskIntoConstraints = NO;
        _postListTableView.dataSource = self;
        _postListTableView.delegate = self;
        _postListTableView.backgroundColor = [UIColor clearColor];
        _postListTableView.estimatedRowHeight = 45.0;
        _postListTableView.rowHeight = UITableViewAutomaticDimension;
        _postListTableView.separatorStyle = UITableViewCellSeparatorStyleNone;
    }
    return _postListTableView;
}
- (UIView *)tableFooter {
    if (!_tableFooter) {
        CGRect footerRect = CGRectMake(0, 0, 320, 35);
        _tableFooter = [[UIView alloc] initWithFrame:footerRect];
        _tableFooter.backgroundColor = [UIColor defaultPageBGColor];
        [_tableFooter addSubview:self.seeMoreButton];
    }
    return _tableFooter;
}
    //- (NSMutableDictionary *)dict {
    //    if (!_dict)
    //        _dict = [NSMutableDictionary dictionary];
    //    return _dict;
    //}
- (NSDictionary *)views {
    if (!_views) {
        _views = @{ @"postListTableView" : self.postListTableView, @"tableFooter" : self.tableFooter, @"seeMoreButton" : self.seeMoreButton };
    }
    return _views;
}
- (NSMutableDictionary *)metrics {
    if (!_metrics) {
        _metrics = [NSMutableDictionary dictionary];
        [self.metrics setObject:@(264.0) forKey:@"hPadding"];
    }
    return _metrics;
}
- (UIButton *)seeMoreButton {
    if (!_seeMoreButton) {
        _seeMoreButton = [[UIButton alloc] init];
        _seeMoreButton.translatesAutoresizingMaskIntoConstraints = NO;
        [_seeMoreButton setTitle:BUTTON_TITLE_SEE_MORE forState:UIControlStateNormal];
        [_seeMoreButton addTarget:self action:@selector(clickedSeeMoreButton:) forControlEvents:UIControlEventTouchUpInside];
        [_seeMoreButton setTitleColor:[UIColor defaultABIBlueColor] forState:UIControlStateNormal];
        _seeMoreButton.titleLabel.font = USERNAME_FONT_SIZE;
        [_seeMoreButton setBackgroundColor:[UIColor clearColor]];
    }
    return _seeMoreButton;
}
#pragma mark - table view delegate methods
- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
    return self.chatterFeeds.count;
}
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    return 1;
}
- (CGFloat)tableView:(UITableView *)tableView heightForFooterInSection:(NSInteger)section {
    return section == self.chatterFeeds.count - 1 ? 0.001 : DEFAULT_CELL_PADDING;
}
- (UIView *)tableView:(UITableView *)tableView viewForFooterInSection:(NSInteger)section {
    return [UIView new];
}
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    NSString *cellIdentifier = @"ss"; //[NSString stringWithFormat:@"%ld-%ld", (long)indexPath.section, (long)indexPath.row];
    ABIChatterFeedListTableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:cellIdentifier]; //[self.dict objectForKey:cellIdentifier];
    if (cell == nil) {
        cell =
        [[ABIChatterFeedListTableViewCell alloc] initWithStyle:UITableViewCellStyleDefault
                                               reuseIdentifier:cellIdentifier
                                                      cellType:(self.chatterFeedType == ChatterGetMessages) ? CellStyleMessage : CellStyleFeedList];
            //  [self.dict removeObjectForKey:cellIdentifier];
            //  [self.dict setObject:cell forKey:cellIdentifier];
    }
    cell.indexPath = indexPath;
    cell.cellStyle = (self.chatterFeedType == ChatterGetMessages) ? CellStyleMessage : CellStyleFeedList;
    cell.cellBackgroundColor = [UIColor whiteColorABI];
    cell.cellBackgroundCornerRadius = 5.0f;
    cell.delegate = self;
    cell.detailsLabelNumberOfLines = 3;
    cell.dataModel = [NSArray objectFromArray:self.chatterFeeds atIndex:indexPath.section];
    cell.backgroundColor = [UIColor clearColor];
    cell.selectionStyle = UITableViewCellSelectionStyleNone;
    if (indexPath.section >= self.chatterFeeds.count) {
        if (self.chatterFeeds.count > self.indexPath.section) {
            [tableView scrollToRowAtIndexPath:self.indexPath atScrollPosition:UITableViewScrollPositionNone animated:NO];
        }
    }
    return cell;
}
- (void)needToUpdate:(NSIndexPath *)indexPath {

    if (indexPath) {

        NSArray *visibleSections = [self.postListTableView.indexPathsForVisibleRows valueForKey:@"section"];

        BOOL isVisibleCell = [visibleSections containsObject:@(indexPath.section)];
        if (isVisibleCell || indexPath.section == 0) {

            [self.postListTableView reloadSections:[NSIndexSet indexSetWithIndex:indexPath.section] withRowAnimation:UITableViewRowAnimationFade];

                //            if(visibleSections.count) {
                //                NSInteger lastSection = [[visibleSections lastObject] integerValue];
                //                NSIndexPath *lastIndex = [NSIndexPath indexPathForRow:0 inSection:lastSection];
                ////                if(lastIndex.section == indexPath.section) {
                ////                    [self.postListTableView scrollToRowAtIndexPath:indexPath
                ////                                                  atScrollPosition:UITableViewScrollPositionTop
                ////                                                          animated:NO];
                ////                }
                //            }
        }

        [AppDelegate appdelegateShareInstance].isNewPostDone = NO;
    }
}
- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
    self.isNeedRefreshUI = YES;
    self.selectedDataModel = [NSArray objectFromArray:self.chatterFeeds atIndex:indexPath.section];
    if (self.selectedDataModel) {
        [self performSegueWithIdentifier:SEGUE_ID_PushToABIChatterDetailsViewController sender:self];
    }
}
- (void)selectedCell:(ABIChatterFeedListTableViewCell *)cell {
    self.selectedCell = cell;
}
#pragma mark - Event
#pragma mark - IBAction
- (void)clickedFileContainLins:(ABISFChatterContentDataModel *)contentDataModel cell:(ABIChatterFeedListTableViewCell *)cell {

    if ([AppDelegate isOffline]) {
        [UIViewController alertInNoNetworkConnection:self clickedOkButton:NULL];
        [CustomLoaderManager hideLoader];
    } else {
        NSString *fileExtension = contentDataModel.fileExtension;
        fileExtension = [fileExtension lowercaseString];
        if (![NSString isNULLString:fileExtension] &&
            ([fileExtension containsString:m4v] || [fileExtension containsString:mp4] || [fileExtension containsString:mov] ||
             [fileExtension containsString:pdf] || [fileExtension containsString:docx] || [fileExtension containsString:txt] ||
             [fileExtension containsString:xlsx] || [fileExtension containsString:xls])) {
                ABIChatterFileViewerViewController *addController =
                (ABIChatterFileViewerViewController *)[UIViewController instantiateViewControllerWithIdentifier:kStoryBoardIDABIChatterFileViewerViewController];
                [addController setContentDataModel:contentDataModel];
                [self.navigationController pushViewController:addController animated:YES];
            } else {
                [self alertWithMessage:ALT_MSG_INCOMPATIBLE_FILE_TYPE];
            }
    }
}
- (void)clickedSeeMoreButton:(UIButton *)sender {
    switch (self.chatterFeedType) {
        case ChatterFeedTypeAll:
        case ChatterFeedTypeMe: [self invokeServiceAndRefreshUIWithFeedType:ChatterFeedTypeCustomPath completion:NULL]; break;
        case ChatterGetMessages: [self invokeServiceAndRefreshUIWithFeedType:ChatterFeedTypeMessageCustomPath completion:NULL]; break;
        default: break;
    }
}
- (void)clickedRecentCommentUserNamesButton:(UIButton *)sender cell:(ABIChatterFeedListTableViewCell *)cell {
    if (cell.feedElementDataModel.comment.isMoreAvailable && cell.uniqueCommentUsers.count) {
        ABIChatterFeedRecentCommentUserViewController *userListPopoverViewController = [[ABIChatterFeedRecentCommentUserViewController alloc] init];
        [userListPopoverViewController toggolVisibility];
        [userListPopoverViewController setAnnouncements:cell.uniqueCommentUsers];
    }
}
- (void)clickedPostComment:(UIButton *)sender cell:(ABIChatterFeedListTableViewCell *)cell {
    if ([NSString isNULLString:cell.commentText]) {
        [self alertWithMessage:ALT_MSG_NO_COMMENT_TEXT];
    } else if ([AppDelegate isOffline]) {
        [UIViewController alertInNoNetworkConnection:self clickedOkButton:NULL];
        [CustomLoaderManager hideLoader];
    } else {
        [AppDelegate appdelegateShareInstance].isNewPostDone = YES;
        self.indexPath = cell.indexPath;
        [CustomLoaderManager showLoader];
        /*!
         *  Post comment on a Feed
         */
        __weak typeof(self) weakSelf = self;
        [self.presenter postCommentOnAfeedWithFeedID:cell.feedElementDataModel.feedID
                                         commentText:cell.commentText
                                          completion:^(NSArray *result, NSError *error, SOQLStatus status) {
                                              [cell resetCommentTextField];
                                              if (!result.count) {
                                                  [CustomLoaderManager hideLoader];
                                                  [CustomLoaderManager showFlashWithMessage:ALT_MSG_FAILED_POST];
                                              } else {
                                                  [weakSelf
                                                   invokeServiceAndRefreshUIWithFeedType:weakSelf.chatterFeedType
                                                   completion:^{
                                                       [CustomLoaderManager hideLoader];
                                                       [CustomLoaderManager showFlashWithMessage:ALT_MSG_SUCESS_COMMENT_POST];
                                                   }];
                                              }
                                          }];
    }
}
@end
