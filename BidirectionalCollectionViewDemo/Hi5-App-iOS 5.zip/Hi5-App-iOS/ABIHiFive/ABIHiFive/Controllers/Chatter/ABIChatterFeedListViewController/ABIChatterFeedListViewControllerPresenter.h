    //
    //  ABIChatterFeedListViewControllerPresenter.h
    //  ABIHiFive
    //
    //  Created by Prsenjit Goswami on 24/07/16.
    //  Copyright © 2016 Cognizant. All rights reserved.
    //
#import "ABIChatterFeedListViewControllerProtocol.h"
#import <Foundation/Foundation.h>
@interface ABIChatterFeedListViewControllerPresenter : NSObject <ABIChatterFeedListViewControllerProtocol>
@end
