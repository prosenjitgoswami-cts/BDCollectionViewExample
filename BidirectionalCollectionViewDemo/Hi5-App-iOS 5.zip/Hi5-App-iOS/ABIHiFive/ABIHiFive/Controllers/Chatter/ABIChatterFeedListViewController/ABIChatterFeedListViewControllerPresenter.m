    //
    //  ABIChatterFeedListViewControllerPresenter.m
    //  ABIHiFive
    //
    //  Created by Prsenjit Goswami on 24/07/16.
    //  Copyright © 2016 Cognizant. All rights reserved.
    //
#import "ABIChatterFeedListViewControllerPresenter.h"
#import "ABISFChatterDataFetcherServices.h"
#import "Constants.h"
@implementation ABIChatterFeedListViewControllerPresenter
- (void)invokeUserFeedsAndRefreshUIWithFeedType:(ChatterFeedType)chatterFeedType
                                    nextPageURL:(NSString *)nextPageURL
                                       feedInfo:(void (^)(id feedInfoObject))feedInfo
                                     completion:(SOQLCompletion)completion {
    switch (chatterFeedType) {
        case ChatterFeedTypeAll:
            [ABISFChatterDataFetcherServices invokeChatterWithFeedType:ChatterFeedTypeAll
                                                     customRestAPIPath:nextPageURL
                                                              feedInfo:feedInfo
                                                            completion:completion];
            break;
        case ChatterFeedTypeMe:
            [ABISFChatterDataFetcherServices invokeChatterWithFeedType:ChatterFeedTypeMe
                                                     customRestAPIPath:nextPageURL
                                                              feedInfo:feedInfo
                                                            completion:completion];
            break;
        case ChatterFeedTypeCustomPath:
            [ABISFChatterDataFetcherServices invokeChatterWithFeedType:ChatterFeedTypeCustomPath
                                                     customRestAPIPath:nextPageURL
                                                              feedInfo:feedInfo
                                                            completion:completion];
            break;
        case ChatterGetMessages:
            [ABISFChatterDataFetcherServices invokeMessageWithType:ChatterGetMessages
                                                 customRestAPIPath:nextPageURL
                                                          feedInfo:feedInfo
                                                        completion:completion];
            break;
        case ChatterFeedTypeMessageCustomPath:
            [ABISFChatterDataFetcherServices invokeMessageWithType:ChatterFeedTypeMessageCustomPath
                                                 customRestAPIPath:nextPageURL
                                                          feedInfo:feedInfo
                                                        completion:completion];
            break;
        default: break;
    }
}
- (void)postCommentOnAfeedWithFeedID:(NSString *)feedID commentText:(NSString *)commentText completion:(SOQLCompletion)completionBlock {
    [ABISFChatterDataFetcherServices postCommentOnAfeed:feedID commentText:commentText completion:completionBlock];
}
@end
