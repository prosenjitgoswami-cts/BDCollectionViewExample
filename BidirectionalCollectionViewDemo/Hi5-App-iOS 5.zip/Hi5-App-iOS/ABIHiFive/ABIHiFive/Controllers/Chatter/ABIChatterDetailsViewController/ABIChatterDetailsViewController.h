    //
    //  ABIChatterDetailsViewController.h
    //  AnheuserBusch
    //
    //  Created by Amit Kumar on 7/21/16.
    //  Copyright © 2016 Cognizant. All rights reserved.
    //
#import "ABIReporteeListTableViewCell.h"
#import "ABISFChatterFeedElementDataModel.h"
#import "ABISFChatterPrivateMessageItemsDataModel.h"
#import "ABIBaseViewController.h"
#import <UIKit/UIKit.h>
@interface ABIChatterDetailsViewController : ABIBaseViewController <UITextFieldDelegate>
@property (nonatomic, strong, readonly) ABISFChatterFeedElementDataModel *feedElementDataModel;
@property (nonatomic, strong, readonly) ABISFChatterPrivateMessageItemsDataModel *messageItemsDataModel;
@property (nonatomic, strong) id dataModel;
    //- (void) scrollToCell:(NSIndexPath*) path;
@end
