    //
    //  ABIChatterDetailsViewController.m
    //  AnheuserBusch
    //
    //  Created by Amit Kumar on 7/21/16.
    //  Copyright © 2016 Cognizant. All rights reserved.
    //
#import "ABIChatterDetailsViewController.h"
#import "ABIChatterFeedDetailsCommentListTableViewCell.h"
#import "ABIChatterFeedListTableViewCell.h"
#import "ABISFChatterDataFetcherServices.h"
#import "ABIChatterFileViewerViewController.h"
#import "Constants.h"

@interface ABIChatterDetailsViewController () <ABIChatterFeedListTableViewCellDelegate>
@property (weak, nonatomic) IBOutlet UITableView *tableView;
@property (strong, nonatomic) UIView *tableFooter;
@property (strong, nonatomic) UIButton *seeMoreButton;
@property (strong, nonatomic) NSDictionary *views;
@property (strong, nonatomic) NSMutableDictionary *metrics;
@property (strong, nonatomic) NSMutableArray *commentItems;
@property (assign, nonatomic) CellStyle cellStyle;
@property (nonatomic, strong) ABISFChatterFeedElementDataModel *feedElementDataModel;
@property (nonatomic, strong) ABISFChatterPrivateMessageItemsDataModel *messageItemsDataModel;
@property (nonatomic, strong) NSString *nextPageUrl;
@property CGFloat initialHeight;
@property (nonatomic, weak) IBOutlet NSLayoutConstraint *tableViewBottomConstraint;
@end
@implementation ABIChatterDetailsViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    [self initialSetup];
}
- (void)viewWillAppear:(BOOL)animated {
    [super viewWillAppear:animated];
    [[self tableView] reloadData];
}

- (void)dealloc {
    [self removeKeyBoardNotification];
}

#pragma mark - Custom Accessors
- (NSDictionary *)views {
    if (!_views) {
        _views = @{ @"tableFooter" : self.tableFooter, @"seeMoreButton" : self.seeMoreButton };
    }
    return _views;
}
- (NSMutableDictionary *)metrics {
    if (!_metrics) {
        _metrics = [NSMutableDictionary dictionary];
        [self.metrics setObject:@(264.0) forKey:@"hPadding"];
    }
    return _metrics;
}
- (UIView *)tableFooter {
    if (!_tableFooter) {
        CGRect footerRect = CGRectMake(0, 0, 320, 40);
        _tableFooter = [[UIView alloc] initWithFrame:footerRect];
        _tableFooter.backgroundColor = [UIColor defaultPageBGColor];
        [_tableFooter addSubview:self.seeMoreButton];
    }
    return _tableFooter;
}
- (UIButton *)seeMoreButton {
    if (!_seeMoreButton) {
        _seeMoreButton = [[UIButton alloc] init];
        _seeMoreButton.translatesAutoresizingMaskIntoConstraints = NO;
        [_seeMoreButton setTitle:BUTTON_TITLE_SEE_MORE forState:UIControlStateNormal];
        [_seeMoreButton addTarget:self action:@selector(clickedSeeMoreButton:) forControlEvents:UIControlEventTouchUpInside];
        [_seeMoreButton setTitleColor:[UIColor defaultABIBlueColor] forState:UIControlStateNormal];
        _seeMoreButton.titleLabel.font = USERNAME_FONT_SIZE;
        [_seeMoreButton setBackgroundColor:[UIColor clearColor]];
    }
    return _seeMoreButton;
}

#pragma mark -  Public method
- (void)setDataModel:(id)dataModel {
    if ([dataModel isMemberOfClass:[ABISFChatterFeedElementDataModel class]]) {
        ABISFChatterFeedElementDataModel *feedElementDataModel = (ABISFChatterFeedElementDataModel *)dataModel;
        self.cellStyle = CellStyleFeedListDetails;
        self.feedElementDataModel = feedElementDataModel;
        [self refreshDataAndUpdateUI];
            //        NSString *text = [NSDate dispalyTimeAsLocalTZFormatWithUTCDate: feedElementDataModel.createdDate];
    } else if ([dataModel isMemberOfClass:[ABISFChatterPrivateMessageItemsDataModel class]]) {
        ABISFChatterPrivateMessageItemsDataModel *messageItemsDataModel = (ABISFChatterPrivateMessageItemsDataModel *)dataModel;
        self.cellStyle = CellStyleMessage;
        self.messageItemsDataModel = messageItemsDataModel;
        [self.tableView reloadData];
    }
}

#pragma mark -  Private Method

- (void)initialSetup {
    [self setNavigationPageTitle];
    [self configureUI];
    [self addKeyboardNotification];
}

- (void)setNavigationPageTitle {
    self.title = [NSString chatterPageTitle]; // PAGE_TITLE_CHATTER;
}

- (void)configureUI {
    self.view.backgroundColor = [UIColor defaultPageBGColor];
    [self setupChatterDetailsTableView];
    [self addConstraints];
}

- (void)setupChatterDetailsTableView {

    self.tableView.separatorColor = [UIColor clearColor];
    self.tableView.separatorStyle = UITableViewCellSeparatorStyleNone;
    self.tableView.estimatedRowHeight = 45.f;
    self.tableView.rowHeight = UITableViewAutomaticDimension;
}

- (void)addConstraints {
    [self.tableFooter
     addConstraints:[NSLayoutConstraint constraintsWithVisualFormat:@"V:|-5-[seeMoreButton]-5-|" options:0 metrics:nil views:self.views]];
    [self.tableFooter addConstraints:[NSLayoutConstraint constraintsWithVisualFormat:@"H:|[seeMoreButton(60)]" options:0 metrics:nil views:self.views]];
}

- (void)addKeyboardNotification {
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(keyboardShown:) name:UIKeyboardDidShowNotification object:nil];
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(keyboardHidden:) name:UIKeyboardDidHideNotification object:nil];
}

- (void)removeKeyBoardNotification {
    [[NSNotificationCenter defaultCenter] removeObserver:self name:UIKeyboardDidShowNotification object:nil];
    [[NSNotificationCenter defaultCenter] removeObserver:self name:UIKeyboardDidHideNotification object:nil];
}

- (BOOL)isSeeMoreButtonNeedToVisible {
    NSNumber *totalComment = self.feedElementDataModel.comment.totalInNumber;
    BOOL isSeeMoereVisible = NO;
    if ([NSString isNULLString:self.nextPageUrl]) {
        isSeeMoereVisible = NO;
    } else {
        isSeeMoereVisible = YES;
    }
    if (totalComment && totalComment.integerValue) {
        isSeeMoereVisible = isSeeMoereVisible && totalComment.integerValue > self.commentItems.count;
    }
    return isSeeMoereVisible;
}

- (void)keyboardShown:(NSNotification *)notification {
    _initialHeight = _tableView.frame.size.height;
    CGRect initialFrame = [[[notification userInfo] objectForKey:UIKeyboardFrameEndUserInfoKey] CGRectValue];
    CGRect convertedFrame = [self.view convertRect:initialFrame fromView:nil];
    self.tableViewBottomConstraint.constant = convertedFrame.size.height;
    [self.view layoutIfNeeded];
}

- (void)keyboardHidden:(NSNotification *)notification {
    self.tableViewBottomConstraint.constant = 0;
    [UIView beginAnimations:TableViewDownANIMATION context:NULL];
    [UIView setAnimationDuration:0.3f];
    [self.view layoutIfNeeded];
    [UIView commitAnimations];
}

- (void)refreshDataAndUpdateUI {
    if (_commentItems && _commentItems.count) {
        [_commentItems removeAllObjects];
        _commentItems = nil;
    }
    if ([self.feedElementDataModel respondsToSelector:@selector(comment)]) {
        if ([[self.feedElementDataModel comment] respondsToSelector:@selector(commentItems)]) {
            self.nextPageUrl = _feedElementDataModel.comment.nextPageUrlString;
            NSMutableArray *collectionOfComment = [NSMutableArray arrayWithArray:[self.feedElementDataModel comment].commentItems];
            if (collectionOfComment.count > 3) {
                self.commentItems = [[collectionOfComment subarrayWithRange:NSMakeRange(0, 3)] mutableCopy];
            } else {
                self.commentItems = collectionOfComment;
            }
        }
    }
    [self.tableView reloadData];
}

#pragma mark -  UITextField Delegate
- (BOOL)textFieldShouldReturn:(UITextField *)textField {
    [textField resignFirstResponder];
    return YES;
}

#pragma mark -  TableView Data Source
- (UIView *)tableView:(UITableView *)tableView viewForFooterInSection:(NSInteger)section {
    return (section == 1 && [self isSeeMoreButtonNeedToVisible]) ? self.tableFooter : nil;
}
- (CGFloat)tableView:(UITableView *)tableView heightForFooterInSection:(NSInteger)section {
    return (section == 1 && [self isSeeMoreButtonNeedToVisible]) ? 30.0f : 0.0f;
}
- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
    return 2;
}
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    NSInteger rowNumber = 1;
    switch (section) {
        case 1: rowNumber = [self.commentItems count]; break;
    }
    return rowNumber;
}
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    static NSString *chatterFeedListTableViewCell = @"ABIChatterFeedListTableViewCell";
    static NSString *multiUserCommentCell = @"ABIChatterFeedDetailsCommentListTableViewCell";
    switch (indexPath.section) {
        case 0: {
            ABIChatterFeedListTableViewCell *cell =
            (ABIChatterFeedListTableViewCell *)[tableView dequeueReusableCellWithIdentifier:chatterFeedListTableViewCell];
            if (cell == nil) {
                cell = [[ABIChatterFeedListTableViewCell alloc] initWithStyle:UITableViewCellStyleDefault
                                                              reuseIdentifier:chatterFeedListTableViewCell
                                                                     cellType:self.cellStyle];
                cell.cellBackgroundColor = [UIColor whiteColor];
            }
            cell.delegate = self;
            cell.dataModel = (self.cellStyle == CellStyleMessage) ? self.messageItemsDataModel : self.feedElementDataModel;
            cell.backgroundColor = [UIColor clearColor];
            cell.selectionStyle = UITableViewCellSelectionStyleNone;
            cell.detailsLabelNumberOfLines = 0;
            return cell;
            break;
        }
        case 1: {
            ABIChatterFeedDetailsCommentListTableViewCell *cell3 = [tableView dequeueReusableCellWithIdentifier:multiUserCommentCell];
            if (cell3 == nil) {
                cell3 =
                [[ABIChatterFeedDetailsCommentListTableViewCell alloc] initWithStyle:UITableViewCellStyleSubtitle reuseIdentifier:multiUserCommentCell];
            }
            if (self.commentItems.count) {
                id commentItem = [NSArray objectFromArray:self.commentItems atIndex:indexPath.row];
                cell3.commentItemModel = commentItem;
            } else {
                cell3.detailTextLabel.text = ALT_NO_COMMENT;
            }
            return cell3;
            break;
        }
        default: break;
    }
    return nil;
}
- (void)needToUpdate:(NSIndexPath *)indexPath {

    if (indexPath.section == 0) {

        [self.tableView reloadSections:[NSIndexSet indexSetWithIndex:indexPath.section] withRowAnimation:UITableViewRowAnimationFade];
    }
}
#pragma mark -  IBAction
- (void)clickedSeeMoreButton:(UIButton *)sender {
    if (![NSObject isNullObject:self.nextPageUrl]) {
        [self fetchCommentItemsWithNextURL:self.nextPageUrl];
        self.nextPageUrl = nil;
    }
}
- (void)fetchCommentItemsWithNextURL:(nullable NSString *)nextURLString {
    if ([AppDelegate isOffline]) {
        [UIViewController alertInNoNetworkConnection:self clickedOkButton:NULL];
        [CustomLoaderManager hideLoader];
    } else {
        __weak typeof(self) weakSelf = self;
        [CustomLoaderManager showLoader];
        [ABISFChatterDataFetcherServices invokeItemsOfCommentWithCustomRestAPIPath:nextURLString
                                                                      parentFeedID:self.feedElementDataModel.feedID
                                                                          feedInfo:^(id feedInfoObject) {
                                                                              self.nextPageUrl = feedInfoObject;
                                                                              [[weakSelf tableView] reloadData];
                                                                          }
                                                                        completion:^(id result, NSError *error, SOQLStatus status) {
                                                                            NSMutableArray *results = (NSMutableArray *)result;
                                                                            if (results && results.count) {
                                                                                for (id obj in results) {
                                                                                    if (![weakSelf.commentItems containsObject:obj]) {
                                                                                        [weakSelf.commentItems addObject:obj];
                                                                                    }
                                                                                }
                                                                                NSArray *sortedArray = [weakSelf.commentItems sortArrayForKey:kCreatedDate ascending:NO];
                                                                                weakSelf.commentItems = [sortedArray mutableCopy];
                                                                            }
                                                                            [[weakSelf tableView] reloadData];
                                                                            [CustomLoaderManager hideLoader];
                                                                        }];
    }
}
- (void)clickedPostComment:(UIButton *)sender cell:(ABIChatterFeedListTableViewCell *)cell {
    if ([NSString isNULLString:cell.commentText]) {
        [self alertWithMessage:ALT_MSG_NO_COMMENT_TEXT];
    } else {
        if ([AppDelegate isOffline]) {
            [UIViewController alertInNoNetworkConnection:self clickedOkButton:NULL];
            [CustomLoaderManager hideLoader];
        } else {
            [AppDelegate appdelegateShareInstance].isNewPostDone = YES;
            [CustomLoaderManager showLoader];
            /*!
             *  Post comment on a Feed
             */
            __weak typeof(self) weakSelf = self;
            [ABISFChatterDataFetcherServices postCommentOnAfeed:cell.feedElementDataModel.feedID
                                                    commentText:cell.commentText
                                                     completion:^(NSArray *result, NSError *error, SOQLStatus status) {
                                                         if (result && result.count) {
                                                             weakSelf.dataModel = nil;
                                                             weakSelf.dataModel = [result firstObject];
                                                         }
                                                         [CustomLoaderManager hideLoader];
                                                         [CustomLoaderManager showFlashWithMessage:ALT_MSG_SUCESS_COMMENT_POST];
                                                         [cell resetCommentTextField];
                                                     }];
        }
    }
}

#pragma mark -  ABIChatterFeedListTableViewCell
- (void)clickedFileContainLins:(ABISFChatterContentDataModel *)contentDataModel cell:(ABIChatterFeedListTableViewCell *)cell {
    if ([AppDelegate isOffline]) {
        [UIViewController alertInNoNetworkConnection:self clickedOkButton:NULL];
        [CustomLoaderManager hideLoader];
    } else {
        NSString *fileExtension = contentDataModel.fileExtension;
        fileExtension = [fileExtension lowercaseString];
        if (![NSString isNULLString:fileExtension] &&
            ([fileExtension containsString:m4v] || [fileExtension containsString:mp4] || [fileExtension containsString:mov] ||
             [fileExtension containsString:pdf] || [fileExtension containsString:docx] || [fileExtension containsString:txt] ||
             [fileExtension containsString:xlsx] || [fileExtension containsString:xls])) {
                ABIChatterFileViewerViewController *addController =
                (ABIChatterFileViewerViewController *)[UIViewController instantiateViewControllerWithIdentifier:kStoryBoardIDABIChatterFileViewerViewController];
                [addController setContentDataModel:contentDataModel];
                [self.navigationController pushViewController:addController animated:YES];
            } else {
                [self alertWithMessage:ALT_MSG_INCOMPATIBLE_FILE_TYPE];
            }
    }
}
@end
