    //
    //  ABIChatterRecentCommentUserListViewController.h
    //  AnheuserBusch
    //
    //  Created by IR Mac Mini on 25/07/16.
    //  Copyright © 2016 Cognizant. All rights reserved.
    //
#import <UIKit/UIKit.h>
@protocol ChatPopoverDelegate <NSObject>
- (void)didSelectedName:(NSString *)nameStr;
@end
@interface ABIChatterRecentCommentUserListViewController : UIViewController <UITableViewDataSource, UITableViewDelegate>
@property (nonatomic, strong) NSArray *chatPopoverNameArr;
@property (nonatomic, weak) IBOutlet UITableView *chatPopoverTableView;
@property (nonatomic, weak) id<ChatPopoverDelegate> delegate;
@end
