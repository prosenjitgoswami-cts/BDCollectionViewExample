    //
    //  ABIChatterRecentCommentUserListViewController.m
    //  AnheuserBusch
    //
    //  Created by IR Mac Mini on 25/07/16.
    //  Copyright © 2016 Cognizant. All rights reserved.
    //
#import "ABIChatterRecentCommentUserListViewController.h"
#import "ABIChatterRecentCommentUserListTableViewCell.h"
@interface ABIChatterRecentCommentUserListViewController ()
@end
@implementation ABIChatterRecentCommentUserListViewController {
    NSMutableArray *selectedIndexes;
}
@synthesize chatPopoverNameArr, delegate;
- (void)viewDidLoad {
    [super viewDidLoad];
    selectedIndexes = [NSMutableArray array];
        //[self.chatPopoverTableView registerClass:[ABIChatterRecentCommentUserListTableViewCell class]
        //forCellReuseIdentifier:@"ABIChatterRecentCommentUserListTableViewCell"];
}
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
        // Dispose of any resources that can be recreated.
}
- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
    return 1;
}
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    return [chatPopoverNameArr count];
}
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    static NSString *CellIdentifier = @"ABIChatterRecentCommentUserListTableViewCell";
    ABIChatterRecentCommentUserListTableViewCell *cell =
    (ABIChatterRecentCommentUserListTableViewCell *)[tableView dequeueReusableCellWithIdentifier:CellIdentifier];
    if (cell == nil) {
        cell = [[ABIChatterRecentCommentUserListTableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:CellIdentifier];
    }
    [cell populateCellData:[self.chatPopoverNameArr objectAtIndex:indexPath.row]];
    return cell;
}
- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath {
    return 44.0;
}
- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
    NSInteger indexValue = [selectedIndexes indexOfObject:[NSNumber numberWithInteger:indexPath.row]];
    if (indexValue > [selectedIndexes count]) {
        [selectedIndexes addObject:[NSNumber numberWithInteger:indexPath.row]];
    }
    if (delegate && [delegate respondsToSelector:@selector(didSelectedName:)]) {
        [delegate didSelectedName:[self.chatPopoverNameArr objectAtIndex:indexPath.row]];
    }
}
@end
