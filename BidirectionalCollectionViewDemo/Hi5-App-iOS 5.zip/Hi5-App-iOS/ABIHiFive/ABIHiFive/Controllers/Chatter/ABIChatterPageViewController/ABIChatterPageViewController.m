    //
    //  ABIChatterPageViewController.m
    //  AnheuserBusch
    //
    //  Created by Prsenjit Goswami on 21/07/16.
    //  Copyright © 2016 Cognizant. All rights reserved.
    //
#import "ABIChatterPageViewController.h"
#import "ABISFChatterDataFetcherServices.h"
#import "ABISFRosterDataModel.h"
#import "ABIChatterNewPostViewController.h"
#import "ABIChatterFeedListViewController.h"
#import "Constants.h"
#import "CustomTabPagerViewController.h"
@interface ABIChatterPageViewController () <CustomTabPagerDataSource, CustomTabPagerDelegate>
@property (strong, nonatomic) CustomTabPagerViewController *tabPageViewController;
@property (strong, nonatomic) UIButton *addNewPostButton;
@property (assign, nonatomic) NSInteger currentIndex;
@property (weak, nonatomic) ABIChatterFeedListViewController *vc;
@property (assign, nonatomic) BOOL once;
@end
@implementation ABIChatterPageViewController

#pragma mark -  View Controller Life Cycle
- (void)viewDidLoad {
    [super viewDidLoad];
    [self initialSetup];
}
- (void)viewWillAppear:(BOOL)animated {
    [super viewWillAppear:animated];

    if (!self.once && _tabPageViewController) {
        [_tabPageViewController repositionTab:self.currentIndex];
        self.once = YES;
    }
}
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
        // Dispose of any resources that can be recreated.
}
- (void)dealloc {
    _tabPageViewController.delegate = nil;
    _tabPageViewController.dataSource = nil;
    _tabPageViewController = nil;
    _vc = nil;
    _addNewPostButton = nil;
}

#pragma mark -  Private Method

- (void)initialSetup {
    self.currentIndex = 0;
    [self setNavigationPageTitle];
    [self configureUI];
}

- (void)setNavigationPageTitle {
    self.title = [NSString chatterPageTitle];
}
/*!
 *  Create UI with Component
 */
- (void)configureUI {
    [self addTabPageViewController];
    [self.view addSubview:self.addNewPostButton];
    [self.view bringSubviewToFront:self.addNewPostButton];
    [self addConstraints];
    [self.tabPageViewController reloadData];
}

    //
- (void)addTabPageViewController {
    [self addChildViewController:self.tabPageViewController];
    [self.view addSubview:self.tabPageViewController.view];
    [self didMoveToParentViewController:self.tabPageViewController];
}

/*!
 *  Add Component Constrains
 */
- (void)addConstraints {
    NSDictionary *views = @{ @"tabPageViewController" : self.tabPageViewController.view, @"addNewPostButton" : self.addNewPostButton };
    [self.view addConstraints:[NSLayoutConstraint constraintsWithVisualFormat:@"H:|[tabPageViewController]|" options:0 metrics:nil views:views]];
    [self.view addConstraints:[NSLayoutConstraint constraintsWithVisualFormat:@"V:|[tabPageViewController]|" options:0 metrics:nil views:views]];
    [self.view addConstraints:[NSLayoutConstraint constraintsWithVisualFormat:@"V:[addNewPostButton(50.0)]-50-|" options:0 metrics:nil views:views]];
    [self.view addConstraints:[NSLayoutConstraint constraintsWithVisualFormat:@"H:[addNewPostButton(50.0)]-25-|" options:0 metrics:nil views:views]];
}
- (ABIChatterFeedListViewController *)customViewConrollerAtIndex:(NSInteger)index {
    ABIChatterFeedListViewController *customViewConroller = [[UIStoryboard storyboardWithName:kStoryBoardIDMain bundle:nil]
                                                          instantiateViewControllerWithIdentifier:kStoryBoardIDABIChatterFeedListViewController];
    customViewConroller.chatterFeedType = index == 0 ? ChatterFeedTypeAll : ChatterGetMessages;
    if (index == 0) {
        _vc = customViewConroller;
    }
    return customViewConroller;
}

#pragma mark -  Accessors
- (CustomTabPagerViewController *)tabPageViewController {
    if (!_tabPageViewController) {
        _tabPageViewController = [CustomTabPagerViewController initialisedTabPageViewController:self];
    }
    return _tabPageViewController;
}
- (UIButton *)addNewPostButton {
    if (!_addNewPostButton) {
        _addNewPostButton = [UIButton customButtonWithImage:[UIImage imageNamed:newPostButton]
                                                        tag:1
                                                  addTarget:self
                                                     action:@selector(clickedAddNewPostButton:)
                                           forControlEvents:UIControlEventTouchUpInside];
        _addNewPostButton.layer.shadowRadius = 3.0f;
        _addNewPostButton.layer.shadowColor = [UIColor blackColor].CGColor;
        _addNewPostButton.layer.shadowOffset = CGSizeMake(0.0f, 5.0f);
        _addNewPostButton.layer.shadowOpacity = 0.5f;
        _addNewPostButton.layer.masksToBounds = NO;
    }
    return _addNewPostButton;
}
- (NSArray *)channelNames {
    return PAGER_TITLES_CHATTER_CHANNEL_NAMES;
}

#pragma mark -  Tab Pager Data Source
- (NSInteger)numberOfViewControllers {
    return [[self channelNames] count];
}
- (UIColor *)tabColor {
    return [UIColor cyanColorABI];
}
- (UIColor *)tabBackgroundColor {
    return [UIColor defaultABIBlueColor];
}
- (UIFont *)titleFont {
    return [UIFont fontHelvetica57Condensed:15.0f];
}
- (UIColor *)titleColor {
    return [UIColor whiteColor];
}
- (UIColor *)deselectedTitleColor {
    return [UIColor cyanColorABI];
}
- (UIViewController *)viewControllerForIndex:(NSInteger)index {
    return [self customViewConrollerAtIndex:index];
}
- (NSString *)titleForTabAtIndex:(NSInteger)index {
    return [self channelNames][index];
}

#pragma mark -  Tab Pager Delegate
- (void)tabPager:(CustomTabPagerViewController *)tabPager didTransitionToTabAtIndex:(NSInteger)index {
    if (index == self.currentIndex)
        return;
    _vc = [tabPager selectViewControllerIndex:index];
    if (_vc && [_vc respondsToSelector:@selector(setIsNeedRefreshUI:)]) {
        [_vc setIsNeedRefreshUI:NO];
        [_vc refreshOnTabChange];
    }
    self.currentIndex = index;
}

#pragma mark -  IBAction
- (void)clickedAddNewPostButton:(UIButton *)sender {
    if (_vc && [_vc respondsToSelector:@selector(setIsNeedRefreshUI:)]) {
        [_vc setIsNeedRefreshUI:YES];
    }
    [self performSegueWithIdentifier:SEGUE_ID_PushToPostPage sender:self];
}
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    if ([segue.identifier isEqualToString:SEGUE_ID_PushToPostPage]) {
        ABIChatterNewPostViewController *destination = [segue destinationViewController];
        destination.rosterDataModel = self.rosterDataModel;
    }
}
@end
