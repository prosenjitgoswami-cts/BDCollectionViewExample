    //
    //  ABIBusinessProtocol.h
    //  ABIHiFive
    //
    //  Created by Prsenjit Goswami on 15/06/16.
    //  Copyright © 2016 Cognizant. All rights reserved.
    //

#import <Foundation/Foundation.h>

@interface ABIBusinessProtocol : NSObject

+ (NSString *)getIncentiveColor:(NSNumber *)incentivePoint;
+ (NSString *)incentivePerformanceStatusStringWRTPoints:(NSNumber *)point;
+ (NSString *)nameAndSurnameOfRoster:(NSString *)rosterName;
+ (NSArray *)yearsForEarnedBadges;
+ (NSString *)dropDownDisplayKeyIncentive;
@end
