    //
    //  ABIBusinessProtocol.m
    //  ABIHiFive
    //
    //  Created by Prsenjit Goswami on 15/06/16.
    //  Copyright © 2016 Cognizant. All rights reserved.
    //

#import "ABIBusinessProtocol.h"
#import "ABIBusinessProtocol.h"
#import "Constants.h"
#import "NSMutableArray+HelperUtil.h"
#import "NSString+HelperUtil.h"

@implementation ABIBusinessProtocol

+ (NSString *)getIncentiveColor:(NSNumber *)incentivePoint {

    double overAllIncentiveProgressInDouble = (nil != incentivePoint) ? [incentivePoint doubleValue] : 0;
    NSString *progressStatusColor = [ABIBusinessProtocol colorNameForIncentiveInPercentage:(overAllIncentiveProgressInDouble / 100)];
    progressStatusColor = [progressStatusColor lowercaseString];

    return progressStatusColor;
}

    // BUSINESS LOGIC
+ (NSString *)nameAndSurnameOfRoster:(NSString *)rosterName {
    NSArray *arr = [rosterName componentsSeparatedByString:@","];
    if (arr.count > 1) {
        NSString *name = arr[1];
        NSString *surName = arr[0];
        return [NSString stringWithFormat:@"%@ %@", [NSString removeWhiteSpace:name], [NSString removeWhiteSpace:surName]];
    } else if (arr.count > 0) {
        NSString *name = arr[0];
        return [NSString stringWithFormat:@"%@", [NSString removeWhiteSpace:name]];
    }
    return [rosterName nullStringTextCorrection];
}
+ (NSString *)colorNameForIncentiveInPercentage:(CGFloat)multiplier {
    if (multiplier > kGREEN_COLOR_START_VALUE_IN_POINT) {
        return kGREEN;
    } else if (multiplier > kRED_COLOR_START_VALUE_IN_POINT) {
        return kYELLOW;
    } else {
        return kRED;
    }
    return nil;
}
+ (NSString *)incentivePerformanceStatusStringWRTPoints:(NSNumber *)point {
    CGFloat pointCount = point.floatValue;
    pointCount = pointCount / 100;
    if (pointCount > kGREEN_COLOR_START_VALUE_IN_POINT) {
        return EXCEEDED_PERFORMANCE_STATUS_TEXT;
    } else if (pointCount > kRED_COLOR_START_VALUE_IN_POINT) {
        return MEDIUM_PERFORMANCE_STATUS_TEXT;
    } else {
        return VERY_LOW_PERFORMANCE_STATUS_TEXT;
    }
}

#pragma mark - Badge

    // Badge

+ (NSArray *)yearsForEarnedBadges {

    return [NSMutableArray previousYearFromNow:PREVIOUS_YEAR_FROM_NOW];
}
+ (NSString *)dropDownDisplayKeyIncentive {

    return @"incentiveCustomDisplayText";
}
@end
