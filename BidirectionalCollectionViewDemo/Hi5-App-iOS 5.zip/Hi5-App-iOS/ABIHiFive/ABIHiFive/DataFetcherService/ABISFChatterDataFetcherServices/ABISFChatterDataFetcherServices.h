    //
    //  ABISFChatterDataFetcherServices.h
    //  ABIHiFive
    //
    //  Created by Prsenjit Goswami on 22/07/16.
    //  Copyright © 2016 Cognizant. All rights reserved.
    //
#import "ABISFChatterContentDataModel.h"
#import "Constants.h"
#import "SFRestRequest.h"
#import <Foundation/Foundation.h>
@class ABISFChatterParentDataModel;
@class ABISFChatterPhotosDataModel;
@class ABISFChatterFilesDataModel;
@class ABISFChatterCommentModel;
@class ABISFChatterFeedElementDataModel;
@interface ABISFChatterDataFetcherServices : NSObject
+ (void)invokeChatterUserDetailsWithFailedBlock:(nullable ABIFailedBlock)failedBlock successBlock:(nonnull ABIMutableArrayResponseBlock)successBlock;
#pragma mark - Invoke Message Details
+ (void)invokeMessageWithType:(ChatterFeedType)ChatterFeedType
            customRestAPIPath:(nonnull NSString *)customRestAPIPath
                     feedInfo:(void (^_Nonnull)(id _Nullable feedInfoObject))feedInfo
                   completion:(nonnull SOQLCompletion)completion;
#pragma mark Invoke Feed After Post
+ (void)invokeFeedAfterPostACommentWithFeedType:(ChatterFeedType)ChatterFeedType
                              customRestAPIPath:(nullable NSString *)customRestAPIPath
                                       feedInfo:(void (^_Nullable)(id _Nullable feedInfoObject))feedInfo
                                     completion:(nonnull SOQLCompletion)completion;
#pragma mark Invoke Feed Details
+ (void)invokeChatterWithFeedType:(ChatterFeedType)ChatterFeedType
                customRestAPIPath:(nonnull NSString *)customRestAPIPath
                         feedInfo:(void (^_Nullable)(id _Nullable feedInfoObject))feedInfo
                       completion:(nonnull SOQLCompletion)completion;
#pragma mark Invoke Items of Comment
+ (void)invokeItemsOfCommentWithCustomRestAPIPath:(nonnull NSString *)customRestAPIPath
                                     parentFeedID:(nonnull NSString *)parentFeedID
                                         feedInfo:(void (^_Nullable)(_Nullable id feedInfoObject))feedInfo
                                       completion:(nonnull SOQLCompletion)completion;
#pragma mark Invoke Mentions Search
+ (void)invokeMentionedListWithSearchWord:(NSString *_Nonnull)searchWord
                        mentionSearchType:(MentionSearchType)mentionSearchType
                               completion:(_Nonnull SOQLCompletion)completion;
#pragma mark -POST SEVICE
#pragma mark - Post Private Message
+ (void)postPrivateMessageWithQueryParams:(nonnull NSDictionary *)queryParams
                              failedBlock:(_Nullable ABIFailedBlock)failedBlock
                             successBlock:(nonnull ABIResponseBlock)successBlock;
#pragma mark Post a Comment on Feed
+ (void)postCommentOnAfeed:(nonnull NSString *)feedID commentText:(nonnull NSString *)commentText completion:(nonnull SOQLCompletion)completion;
#pragma mark Post a Feed with Attachment and Text
+ (void)postFeedSegmentAndAttachmentWithAttachmentId:(nullable NSString *)attachmentId
                                     messageSegments:(nullable NSArray *)messageSegments
                                          completion:(nonnull SOQLCompletion)completion;
#pragma mark Upload a File
+ (void)uploadFileWithMessageSegments:(nonnull NSArray *)messageSegments
                             fileData:(nonnull NSData *)fileData
                            imageName:(nonnull NSString *)fileName
                          description:(nonnull NSString *)description
                             mimeType:(nullable NSString *)mimeType
                           completion:(nonnull SOQLCompletion)completion;
#pragma mark Upload a File
+ (void)uploadFileWithFileData:(nonnull NSData *)fileData
                     imageName:(nonnull NSString *)fileName
                   description:(nonnull NSString *)description
                      mimeType:(nullable NSString *)mimeType
                    completion:(nonnull SOQLCompletion)completion;
@end
#pragma mark - Additions
@interface ABISFChatterDataFetcherServices (Additions)
+ (nullable id)commentsItemBodyText:(nonnull id)element;
+ (nullable id)objectFromCompatibilityDictionaryForKey:(nonnull NSString *)key elementDictionary:(nonnull id)element;
+ (nullable id)commentsItems:(nonnull id)element;
+ (nullable id)commentsItemsFormCommentPageDictionary:(nonnull id)commentPage;
+ (nullable id)commentsPagesDictionary:(nonnull id)element;
+ (nullable ABISFChatterCommentModel *)prepareABISFChatterCommentModelForAFeed:(nonnull id)element parentFeedID:(nonnull NSString *)parentFeedID;
+ (nullable NSString *)getTextKeyValueFromBodyDictionary:(nonnull NSDictionary *)bodyDict;
@end
