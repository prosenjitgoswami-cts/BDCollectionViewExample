    //
    //  ABISFChatterDataFetcherServices.m
    //  ABIHiFive
    //
    //  Created by Prsenjit Goswami on 22/07/16.
    //  Copyright © 2016 Cognizant. All rights reserved.
    //
#import "ABISFChatterDataFetcherServices.h"
#import "ABISFChatterCommentItemModel.h"
#import "ABISFChatterCommentModel.h"
#import "ABISFChatterContentDataModel.h"
#import "ABISFChatterDataModelBinder.h"
#import "ABISFChatterPathBuilder.h"
#import "ABISFRestJSONParamsBuilder.h"
#import "ABISFRestRequestManager.h"
#import "Constants.h"
#import "SFRestAPI.h"
@implementation ABISFChatterDataFetcherServices
static ABISFChatterDataFetcherServices *shareInstance = nil;
#pragma mark - GET SEVICE
#pragma mark - Fetch Chatter User Details
+ (void)invokeChatterUserDetailsWithFailedBlock:(nullable ABIFailedBlock)failedBlock successBlock:(nonnull ABIMutableArrayResponseBlock)successBlock {
    NSString *path = [ABISFChatterPathBuilder chatterRestAPIPath:ChatterRestAPIMe];
    [ABISFRestRequestManager requestWithMethod:SFRestMethodGET
                                          path:path
                                   queryParams:nil
                                   failedBlock:^(NSError *error, NSDictionary *extraInfo) {
                                       if (failedBlock)
                                           failedBlock(error, nil);
                                   }
                                  successBlock:^(id response, NSDictionary *extraInfo) {
                                      NSMutableArray *array = [ABISFChatterDataModelBinder bindResponseDataForChatterUser:response];
                                      if (successBlock)
                                          successBlock(array, nil);
                                  }];
}
#pragma mark - Invoke Message Details
+ (void)invokeMessageWithType:(ChatterFeedType)ChatterFeedType
            customRestAPIPath:(NSString *)customRestAPIPath
                     feedInfo:(void (^)(id feedInfoObject))feedInfo
                   completion:(SOQLCompletion)completion {
    NSString *path = nil;
    switch (ChatterFeedType) {
        case ChatterGetMessages: path = [ABISFChatterPathBuilder chatterRestAPIPath:ChatterRestAPISearchPathMessage]; break;
        case ChatterFeedTypeMessageCustomPath: path = customRestAPIPath; break;
        default: break;
    }
    [ABISFRestRequestManager requestWithMethod:SFRestMethodGET
                                          path:path
                                   queryParams:nil
                                   failedBlock:^(NSError *error, NSDictionary *extraInfo) {
                                       if (completion)
                                           completion(nil, error, 0);
                                   }
                                  successBlock:^(id response, NSDictionary *extraInfo) {
                                      [ABISFChatterDataModelBinder bindResponseDataForMessage:response
                                                                                     feedInfo:^(id feedInfoObject) {
                                                                                         dispatch_main_async_safeBlock(^{
                                                                                             if (feedInfo)
                                                                                                 feedInfo(feedInfoObject);
                                                                                         });
                                                                                     }
                                                                                   completion:^(id result, NSError *error, SOQLStatus status) {
                                                                                       dispatch_main_async_safeBlock(^{
                                                                                           if (completion)
                                                                                               completion(result, error, status);
                                                                                       });
                                                                                   }];
                                  }];
}
#pragma mark Invoke Feed After Post
+ (void)invokeFeedAfterPostACommentWithFeedType:(ChatterFeedType)ChatterFeedType
                              customRestAPIPath:(NSString *)customRestAPIPath
                                       feedInfo:(void (^)(id feedInfoObject))feedInfo
                                     completion:(SOQLCompletion)completion {
    NSString *restPath = nil;
    switch (ChatterFeedType) {
        case ChatterFeedTypeAll: restPath = [ABISFChatterPathBuilder chatterRestAPIPath:ChatterAllFeedElements]; break;
        case ChatterFeedTypeMe: restPath = [ABISFChatterPathBuilder chatterRestAPIPath:ChatterMeFeedElements]; break;
        case ChatterFeedTypeCustomPath: restPath = customRestAPIPath; break;
        default: break;
    }
    if ([NSString isNULLString:restPath]) {
        if (completion)
            completion(nil, nil, kSOQLStatusFailed);
        return;
    }
    [ABISFRestRequestManager requestWithMethod:SFRestMethodGET
                                          path:restPath
                                   queryParams:nil
                                   failedBlock:^(NSError *error, NSDictionary *extraInfo) {
                                       if (completion)
                                           completion(nil, error, 0);
                                   }
                                  successBlock:^(id response, NSDictionary *extraInfo) {
                                      dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0), ^{
                                          [ABISFChatterDataModelBinder bindResponseDataForFeedDetailsAfterPostAComment:response
                                                                                                              feedInfo:^(id feedInfoObject) {
                                                                                                                  dispatch_main_async_safeBlock(^{
                                                                                                                      if (feedInfo)
                                                                                                                          feedInfo(feedInfoObject);
                                                                                                                  });
                                                                                                              }
                                                                                                            completion:^(NSArray *results) {
                                                                                                                dispatch_main_async_safeBlock(^{
                                                                                                                    if (completion)
                                                                                                                        completion(results, nil, results ? kSOQLStatusSucccess : kSOQLStatusFailed);
                                                                                                                });
                                                                                                            }];
                                      });
                                  }];
}
#pragma mark Invoke Feed Details
+ (void)invokeChatterWithFeedType:(ChatterFeedType)ChatterFeedType
                customRestAPIPath:(NSString *)customRestAPIPath
                         feedInfo:(void (^)(id feedInfoObject))feedInfo
                       completion:(SOQLCompletion)completion {
    NSString *restPath = nil;
    switch (ChatterFeedType) {
        case ChatterFeedTypeAll: restPath = [ABISFChatterPathBuilder chatterRestAPIPath:ChatterAllFeedElements]; break;
        case ChatterFeedTypeMe: restPath = [ABISFChatterPathBuilder chatterRestAPIPath:ChatterMeFeedElements]; break;
        case ChatterFeedTypeCustomPath: restPath = customRestAPIPath; break;
        default: break;
    }
    if ([NSString isNULLString:restPath]) {
        if (completion)
            completion(nil, nil, kSOQLStatusFailed);
        return;
    }
    [ABISFRestRequestManager requestWithMethod:SFRestMethodGET
                                          path:restPath
                                   queryParams:nil
                                   failedBlock:^(NSError *error, NSDictionary *extraInfo) {
                                       if (completion)
                                           completion(nil, error, 0);
                                   }
                                  successBlock:^(id response, NSDictionary *extraInfo) {
                                      dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0), ^{
                                          [ABISFChatterDataModelBinder bindResponseDataForFeedDetails:response
                                                                                             feedInfo:^(id feedInfoObject) {
                                                                                                 dispatch_main_async_safeBlock(^{
                                                                                                     if (feedInfo)
                                                                                                         feedInfo(feedInfoObject);
                                                                                                 });
                                                                                             }
                                                                                           completion:^(NSArray *results) {
                                                                                               dispatch_main_async_safeBlock(^{
                                                                                                   if (completion)
                                                                                                       completion(results, nil, results ? kSOQLStatusSucccess : kSOQLStatusFailed);
                                                                                               });
                                                                                           }];
                                      });
                                  }];
}
#pragma mark Invoke Items of Comment
+ (void)invokeItemsOfCommentWithCustomRestAPIPath:(NSString *)customRestAPIPath
                                     parentFeedID:(NSString *)parentFeedID
                                         feedInfo:(void (^)(id feedInfoObject))feedInfo
                                       completion:(SOQLCompletion)completion {
    [ABISFRestRequestManager requestWithMethod:SFRestMethodGET
                                          path:customRestAPIPath
                                   queryParams:nil
                                   failedBlock:^(NSError *error, NSDictionary *extraInfo) {
                                       if (completion)
                                           completion(nil, error, 0);
                                   }
                                  successBlock:^(id response, NSDictionary *extraInfo) {
                                      NSString *nextPageUrlString = [NSDictionary objectForKeySafe:response key:kNextPageUrl];
                                      NSArray *nextUrlResults = [NSDictionary objectForKeySafe:response key:kItems];
                                      if (![NSArray isValidArray:nextUrlResults]) {
                                          if (completion)
                                              completion(nil, nil, 0);
                                          if (feedInfo)
                                              feedInfo(nil);
                                          return;
                                      }
                                      NSMutableArray *allcomments = [NSMutableArray new];
                                      for (id commentItem in nextUrlResults) {
                                          ABISFChatterCommentItemModel *commentItemModel =
                                          [[ABISFChatterCommentItemModel alloc] initWithParentFeedID:parentFeedID commentItem:commentItem];
                                          [allcomments addObject:commentItemModel];
                                      }
                                      if (feedInfo)
                                          feedInfo(nextPageUrlString);
                                      if (completion)
                                          completion(allcomments, nil, kSOQLStatusSucccess);
                                  }];
}
#pragma mark Invoke Mentions Search
+ (void)invokeMentionedListWithSearchWord:(NSString *)searchWord
                        mentionSearchType:(MentionSearchType)mentionSearchType
                               completion:(SOQLCompletion)completion {
    NSString *path = [ABISFChatterPathBuilder chatterRestAPIPathALLMentionWithSearchWord:searchWord mentionSearchType:mentionSearchType];
    [ABISFRestRequestManager requestWithMethod:SFRestMethodGET
                                          path:path
                                   queryParams:nil
                                   failedBlock:^(NSError *error, NSDictionary *extraInfo) {
                                       if (completion)
                                           completion(nil, nil, 0);
                                   }
                                  successBlock:^(id response, NSDictionary *extraInfo) {
                                      NSArray *searchResults = [NSDictionary objectForKeySafe:response key:kMentionCompletions];
                                      NSMutableArray *mentionCompletionss = [ABISFChatterDataModelBinder bindResponseDataForSearchMentions:searchResults];
                                      if (completion)
                                          completion(mentionCompletionss.count ? mentionCompletionss : nil, nil, (mentionCompletionss.count) ? 1 : 0);
                                  }];
}
#pragma mark - POST SEVICE
#pragma mark - Post Private Message
+ (void)postPrivateMessageWithQueryParams:(NSDictionary *)queryParams
                              failedBlock:(ABIFailedBlock)failedBlock
                             successBlock:(ABIResponseBlock)successBlock {
    NSString *path = [ABISFChatterPathBuilder chatterRestAPIPath:ChatterRestAPIPrivateMessage];
    [ABISFRestRequestManager requestWithMethod:SFRestMethodPOST path:path queryParams:queryParams failedBlock:failedBlock successBlock:successBlock];
}
#pragma mark Post a Comment on Feed

+ (NSString *)chatterRestAPIPathForComment:(NSString *)feedID {
    NSString *basePath = [ABISFChatterPathBuilder chatterRestAPIPath:ChatterRestAPIPathPostFeedElement];
    NSString *path = [NSString stringWithFormat:@"%@/%@/capabilities/comments/items", basePath, feedID];
    return path;
}

+ (void)postCommentOnAfeed:(NSString *)feedID commentText:(NSString *)commentText completion:(SOQLCompletion)completion {
    if ([NSString isNULLString:feedID] || [NSString isNULLString:commentText]) {
        if (completion)
            completion(nil, nil, kSOQLStatusFailed);
    } else {

        NSMutableDictionary *queryParams = [NSMutableDictionary dictionary];
        NSMutableDictionary *messageSegmentsDict = [NSMutableDictionary dictionary];
        NSMutableArray *messageSegments = [NSMutableArray array];
        if (![NSString isNULLString:commentText]) {
            NSMutableDictionary *messageSegment = [NSMutableDictionary dictionary];
            [messageSegment setObject:@"Text" forKey:@"type"];
            [messageSegment setObject:commentText forKey:@"text"];
            if (messageSegment.count) {
                [messageSegments addObject:messageSegment];
            }
        }
        if (messageSegments.count) {
            [messageSegmentsDict setObject:messageSegments forKey:@"messageSegments"];
        }
        if (messageSegmentsDict.count) {
            [queryParams setObject:messageSegmentsDict forKey:@"body"];
        }

        NSString *jsonString = [queryParams jsonStringWithPrettyPrint:YES];
        NSDictionary *jsonObj =
        [NSJSONSerialization JSONObjectWithData:[jsonString dataUsingEncoding:NSUTF8StringEncoding] options:NSJSONReadingMutableContainers error:nil];
        NSString *path = [ABISFChatterDataFetcherServices chatterRestAPIPathForComment:feedID];
            // NSString *path = [ABISFChatterPathBuilder chatterRestAPIPathForComment:feedID commentText:commentText];
        [ABISFRestRequestManager requestWithMethod:SFRestMethodPOST
                                              path:path
                                       queryParams:jsonObj
                                       failedBlock:^(NSError *error, NSDictionary *extraInfo) {
                                           if (completion)
                                               completion(nil, nil, kSOQLStatusFailed);
                                       }
                                      successBlock:^(id response, NSDictionary *extraInfo) {
                                          NSDictionary *resultDict = (NSDictionary *)response;
                                          NSDictionary *feedElement = [NSDictionary objectForKeySafe:resultDict key:kFeedElement];
                                          NSString *commentURLString = [NSDictionary objectForKeySafe:feedElement key:kUrl];
                                          if (![NSString isNULLString:commentURLString]) {
                                              [ABISFChatterDataFetcherServices invokeFeedAfterPostACommentWithFeedType:ChatterFeedTypeCustomPath
                                                                                                     customRestAPIPath:commentURLString
                                                                                                              feedInfo:NULL
                                                                                                            completion:completion];
                                          } else {
                                              if (completion)
                                                  completion(nil, nil, kSOQLStatusFailed);
                                          }
                                      }];
    }
}
#pragma mark Post a Feed with Attachment and Text
+ (void)postFeedSegmentAndAttachmentWithAttachmentId:(NSString *)attachmentId
                                     messageSegments:(NSArray *)messageSegments
                                          completion:(SOQLCompletion)completion {
    NSArray *attachments = nil;
    SOQLStatus status = kSOQLStatusFailed;
    if (![NSString isNULLString:attachmentId]) {
        attachments = @[ @{kid : attachmentId} ];
    }
    if (!messageSegments.count && !attachments.count) {
        status = kSOQLStatusFailed;
        if (completion)
            completion(nil, nil, status);
        return;
    }
    NSDictionary *jsonObj = [ABISFRestJSONParamsBuilder queryParamsForFeedWithMessageSegment:messageSegments attachments:attachments];
    NSString *path = [ABISFChatterPathBuilder chatterRestAPIPath:ChatterRestAPIPathPostFeedElement];
    [ABISFRestRequestManager requestWithMethod:SFRestMethodPOST
                                          path:path
                                   queryParams:jsonObj
                                   failedBlock:^(NSError *error, NSDictionary *extraInfo) {
                                       [NSObject performInMainThreadAfterDelay:3.0
                                                                    completion:^{
                                                                        if (completion)
                                                                            completion(nil, error, kSOQLStatusFailed);
                                                                    }];
                                   }
                                  successBlock:^(id response, NSDictionary *extraInfo) {
                                      [NSObject performInMainThreadAfterDelay:2.0
                                                                   completion:^{
                                                                       if ([NSObject isNullObject:response]) {
                                                                           if (completion)
                                                                               completion(nil, nil, kSOQLStatusFailed);
                                                                       } else {
                                                                           if (completion)
                                                                               completion(response, nil, kSOQLStatusSucccess);
                                                                       }
                                                                   }];
                                  }];
}
#pragma mark - Upload a File
+ (void)uploadFileWithMessageSegments:(NSArray *)messageSegments
                             fileData:(NSData *)fileData
                            imageName:(NSString *)fileName
                          description:(NSString *)description
                             mimeType:(NSString *)mimeType
                           completion:(SOQLCompletion)completion {
    /*!
     *  In version 36.0 and later, you can’t create a feed post and upload a binary file in the same request. Upload files to Salesforce first, and then
     use the file IDs to attach one or more files to a feed post.
     *

     */
    [ABISFChatterDataFetcherServices
     uploadFileWithFileData:fileData
     imageName:fileName
     description:description
     mimeType:mimeType
     completion:^(id result, NSError *error, SOQLStatus status) {
         ABISFChatterContentDataModel *contentDataModel = (ABISFChatterContentDataModel *)result;
         if (messageSegments && messageSegments.count && fileData && !contentDataModel && !contentDataModel.ID) {
             status = kSOQLStatusAttachmentUploadFailed;
             if (completion)
                 completion(nil, nil, status);
         }
         [ABISFChatterDataFetcherServices postFeedSegmentAndAttachmentWithAttachmentId:contentDataModel.ID
                                                                       messageSegments:messageSegments
                                                                            completion:completion];
     }];
}
#pragma mark Upload a File
+ (void)uploadFileWithFileData:(NSData *)fileData
                     imageName:(NSString *)fileName
                   description:(NSString *)description
                      mimeType:(NSString *)mimeType
                    completion:(SOQLCompletion)completion {
    if (!fileData || [NSString isNULLString:fileName] || [NSString isNULLString:fileName] || [NSString isNULLString:fileName]) {
        if (completion)
            completion(nil, nil, kSOQLStatusFailed);
        return;
    }
    SFRestRequest *restRequest = [[SFRestAPI sharedInstance] requestForUploadFile:fileData name:fileName description:description mimeType:mimeType];
    [ABISFRestRequestManager sendRequest:restRequest
                             failedBlock:^(NSError *error, NSDictionary *extraInfo) {
                                 if (completion)
                                     completion(nil, error, kSOQLStatusFailed);
                             }
                            successBlock:^(id response, NSDictionary *extraInfo) {
                                ABISFChatterContentDataModel *contentDataModel = [ABISFChatterDataModelBinder bindResponseDataForUploadFile:response];
                                if (completion)
                                    completion(contentDataModel, nil, kSOQLStatusSucccess);
                            }];
}
@end
#pragma mark - Additions
#pragma mark -
@implementation ABISFChatterDataFetcherServices (Additions)

+ (id)commentsItemBodyText:(id)element {
    NSString *commentsItemsBodyText = nil;
    NSDictionary *commentsItemsBody = [NSObject objectForKeySafe:element key:kBody];
    if (![NSObject isNullObject:commentsItemsBody]) {
        commentsItemsBodyText = [NSObject objectForKeySafe:commentsItemsBody key:kText];
    }
    return commentsItemsBodyText;
}
+ (id)commentsItems:(id)element {
    NSArray *items = nil;
    NSDictionary *capabilities = [NSObject objectForKeySafe:element key:kCapabilities];
    if (![NSObject isNullObject:capabilities]) {
        NSDictionary *comments = [NSObject objectForKeySafe:capabilities key:kComments];
        if (![NSObject isNullObject:comments]) {
            NSDictionary *pages = [NSObject objectForKeySafe:comments key:kPage];
            if (![NSObject isNullObject:pages]) {
                items = [NSObject objectForKeySafe:pages key:kItems];
            }
        }
    }
    return items;
}
+ (id)commentsItemsFormCommentPageDictionary:(id)commentPage {
    NSArray *items = nil;
    if (![NSObject isNullObject:commentPage]) {
        items = [NSObject objectForKeySafe:commentPage key:kItems];
    }
    return items;
}
+ (id)commentsPagesDictionary:(id)element {
    NSDictionary *page = nil;
    NSDictionary *capabilities = [NSObject objectForKeySafe:element key:kCapabilities];
    if (![NSObject isNullObject:capabilities]) {
        NSDictionary *comments = [NSObject objectForKeySafe:capabilities key:kComments];
        if (![NSObject isNullObject:comments]) {
            page = [NSObject objectForKeySafe:comments key:kPage];
        }
    }
    return page;
}
+ (id)objectFromCompatibilityDictionaryForKey:(NSString *)key elementDictionary:(id)element {
    NSDictionary *capabilities = [NSObject objectForKeySafe:element key:kCapabilities];
    NSDictionary *dict = nil;
    if (![NSObject isNullObject:capabilities]) {
        dict = [NSObject objectForKeySafe:capabilities key:key];
    }
    return dict;
}
+ (ABISFChatterCommentModel *)prepareABISFChatterCommentModelForAFeed:(id)element parentFeedID:(NSString *)parentFeedID {
    ABISFChatterCommentModel *comment = nil;
    NSDictionary *pages = [ABISFChatterDataFetcherServices commentsPagesDictionary:element];
    if (pages && pages.count) {
        comment = [[ABISFChatterCommentModel alloc] initWithCommentParentFeedID:parentFeedID commentPages:pages];
    }
    return comment;
}
+ (NSString *)getTextKeyValueFromBodyDictionary:(NSDictionary *)bodyDict {
    NSString *text = @"";
    if ([NSDictionary isValidDictionary:bodyDict]) {
        text = bodyDict[kText];
        text = [NSString isNULLString:text] ? @"" : text;
    }
    return text;
}
@end
/*
 Sales force - https://developer.salesforce.com/docs/atlas.en-us.chatterapi.meta/chatterapi/features_files.htm
 Quick Referance - https://developer.salesforce.com/docs/atlas.en-us.chatterapi.meta/chatterapi/quickreference.htm
 //Limitation Sales force
 //https://developer.salesforce.com/blogs/developer-relations/2014/03/building-a-native-ios-photo-sharing-app-on-salesforce1-mbaas.html


 //https://github.com/cseymourSF/Chatter-API-iOS-Sample/blob/master/Classes/UserPhotoPoster.m
 //https://www.cocoacontrols.com/controls/aktagsinputview


 */
