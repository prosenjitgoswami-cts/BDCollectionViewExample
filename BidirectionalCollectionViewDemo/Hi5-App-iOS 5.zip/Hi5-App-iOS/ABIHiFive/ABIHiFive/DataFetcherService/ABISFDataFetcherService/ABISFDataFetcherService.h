    //
    //  ABISFDataFetcherService.h
    //  ABIHiFive
    //
    //  Created by Prsenjit Goswami on 23/06/16.
    //  Copyright © 2016 Cognizant. All rights reserved.
    //
#import "Constants.h"
#import <Foundation/Foundation.h>
@class SFIdentityData, ABISFKPIsDetailsDataModel;
@interface ABISFDataFetcherService : NSObject
+ (nonnull ABISFDataFetcherService *)shareInstance;
@property (nonatomic, strong, nullable) NSArray *announcementsDrtails;
@property (nonatomic, strong, nullable) UIImage *notificationBellImage;
#pragma mark - Roster Details
+ (void)fetchAndProcessRosterDetailsWithRosterID:(nonnull NSString *)rosterID
                                 extraDependency:(nullable NSDictionary<NSString *, id> *)extraDependency
                                       ascending:(BOOL)ascending
                                      sortByKeys:(nullable NSArray<NSString *> *)sortByKeys
                                     failedBlock:(_Nonnull ABIFailedBlock)failedBlock
                                 completionBlock:(_Nonnull ABIMutableArrayResponseBlock)completionBlock;

#pragma mark - Badges Information in Badges Details Page
+ (void)fetchRosterBadgeDetailsWithRoster:(nonnull ABISFRosterDataModel *)roster
                                 forYears:(nullable NSArray<NSString *> *)years
                          extraDependency:(nullable NSDictionary<NSString *, id> *)extraDependency
                                ascending:(BOOL)ascending
                               sortByKeys:(nullable NSArray<NSString *> *)sortByKeys
                              failedBlock:(_Nonnull ABIFailedBlock)failedBlock
                          completionBlock:(_Nonnull ABIMutableArrayResponseBlock)completionBlock;
#pragma mark - Announcements Details
+ (void)fetchAndProcessAnnouncementsDetailsWithExtraDependency:(nullable NSDictionary<NSString *, id> *)extraDependency
                                                     ascending:(BOOL)ascending
                                                    sortByKeys:(nullable NSArray<NSString *> *)sortByKeys
                                                   failedBlock:(_Nonnull ABIFailedBlock)failedBlock
                                               completionBlock:(_Nonnull ABIMutableArrayResponseBlock)completionBlock;

#pragma mark - Incentive Details For Roster In Profile Page

+ (void)fetchAndProcessAllPeerDetailsWithRoster:(nonnull ABISFRosterDataModel *)roster
                                      incentive:(nonnull ABISFIncentiveDataModel *)incentive
                                    failedBlock:(_Nonnull ABIFailedBlock)failedBlock
                                completionBlock:(_Nonnull ABIMutableArrayResponseBlock)completionBlock;

+ (void)fetchAndProcessRosterIncentiveDetailsWithRoster:(nonnull ABISFRosterDataModel *)roster
                                        extraDependency:(nullable NSDictionary<NSString *, id> *)extraDependency
                                              ascending:(BOOL)ascending
                                             sortByKeys:(nullable NSArray<NSString *> *)sortByKeys
                                            failedBlock:(nonnull ABIFailedBlock)failedBlock
                                        completionBlock:(nonnull ABIMutableArrayResponseBlock)completionBlock;

#pragma mark - Reportee Details for Manager
+ (void)fetchAndProcessAllReporteeDetailsWithRoster:(nonnull ABISFRosterDataModel *)roster
                                       reporteeRole:(nullable NSString *)reporteeRole
                                    extraDependency:(nullable NSDictionary<NSString *, id> *)extraDependency
                                          ascending:(BOOL)ascending
                                         sortByKeys:(nullable NSArray<NSString *> *)sortByKeys
                                        failedBlock:(_Nonnull ABIFailedBlock)failedBlock
                                    completionBlock:(_Nonnull ABIMutableArrayResponseBlock)completionBlock;

#pragma mark - KIP DETAILS
+ (void)fetchAndProcessKIPsDetailsForAnIncentiveWithIncentive:(nonnull ABISFIncentiveDataModel *)incentive
                                                       roster:(nonnull ABISFRosterDataModel *)roster
                                              extraDependency:(nullable NSDictionary<NSString *, id> *)extraDependency
                                                    ascending:(BOOL)ascending
                                                   sortByKeys:(nullable NSArray<NSString *> *)sortByKeys
                                                  failedBlock:(_Nonnull ABIFailedBlock)failedBlock
                                              completionBlock:(nonnull void (^)(NSMutableArray<ABISFKPIsDetailsDataModel *> *_Nullable kpiDetails,
                                                                                NSDictionary *_Nullable extraInfo))completionBlock;
#pragma mark - Peer Ranking
+ (void)fetchAndProcessAllPeerDetailsWithRoster:(nonnull ABISFRosterDataModel *)roster
                                      incentive:(nonnull ABISFIncentiveDataModel *)incentive
                                extraDependency:(nullable NSDictionary<NSString *, id> *)extraDependency
                                      ascending:(BOOL)ascending
                                     sortByKeys:(nullable NSArray<NSString *> *)sortByKeys
                                    failedBlock:(_Nonnull ABIFailedBlock)failedBlock
                                completionBlock:(_Nonnull ABIMutableArrayResponseBlock)completionBlock;

#pragma mark - DMs Incentive Details For SD
+ (void)fetchAndProcessReporteesIncentiveDetailsWithManager:(nonnull ABISFRosterDataModel *)manager
                                               reporteeRole:(nullable NSString *)reporteeRole
                                            extraDependency:(nullable NSDictionary<NSString *, id> *)extraDependency
                                                  ascending:(BOOL)ascending
                                                 sortByKeys:(nullable NSArray<NSString *> *)sortByKeys
                                                failedBlock:(_Nonnull ABIFailedBlock)failedBlock
                                            completionBlock:(_Nonnull ABIMutableArrayResponseBlock)completionBlock;

#pragma mark -  My DMs Performance Of SD Manager
+ (void)
fetchAndProcessAllReporteeKPIsWiseIncentivePerformanceDetailsWithManager:(nonnull ABISFRosterDataModel *)manager
incentive:(nonnull ABISFIncentiveDataModel *)incentive
extraDependency:(nullable NSDictionary<NSString *, id> *)extraDependency
ascending:(BOOL)ascending
sortByKeys:(nullable NSArray<NSString *> *)sortByKeys
failedBlock:(_Nonnull ABIFailedBlock)failedBlock
completionBlock:
(nonnull void (^)(NSMutableArray<ABISFKPIsDetailsDataModel *> *_Nullable kpiDetails,
                  NSDictionary *_Nullable extraInfo))completionBlock;

#pragma mark - Additions

+ (void)fetchIncentiveDetailsAndPrecessKPIsDetailsWithRoster:(nonnull ABISFRosterDataModel *)roster
                                          reporteeIncentives:(nullable NSArray *)rosterIncentives
                                             extraDependency:(nullable NSDictionary *)extraDependency
                                                 failedBlock:(nonnull ABIFailedBlock)failedBlock
                                             completionBlock:(nonnull void (^)(NSMutableArray<ABISFIncentiveDataModel *> *_Nullable kpiDetails,
                                                                               NSDictionary *_Nullable extraInfo))completionBlock;

@end
