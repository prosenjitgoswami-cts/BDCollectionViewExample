    //
    //  ABISFDataFetcherService.m
    //  ABIHiFive
    //
    //  Created by Prsenjit Goswami on 23/06/16.
    //  Copyright © 2016 Cognizant. All rights reserved.
    //
#import "ABISFDataFetcherService.h"
#import "ABISFDataModelBinder.h"
#import "ABISFIncentiveDataModel.h"
#import "ABISFRestRequestManager.h"
#import "ABISOQLQueryBuilder.h"
#import "Constants.h"
#import "NSDictionary+ABIExtraDependency.h"
#import "SFRestAPI+Blocks.h"
#import "SFRestAPI.h"
#import "SFRestRequest.h"
#import <UIKit/UIKit.h>

@implementation ABISFDataFetcherService

static ABISFDataFetcherService *shareInstance = nil;
static NSInteger recurringIndex;

+ (ABISFDataFetcherService *)shareInstance {
    if (!shareInstance) {
        shareInstance = [[ABISFDataFetcherService alloc] init];
    }
    return shareInstance;
}

#pragma mark -  Profile Page

#pragma mark -   Roster Details

/**
 *  Roster Details, Precessing response record and Bind with
 * model(ABISFRosterDataModel)
 *
 *  @param rosterID        Roseter ID
 *  @param extraDependency Pass extra information as required
 *  @param ascending       Sort Order (if 'YES' ascending)
 *  @param sortByKeys      Results sort By key
 *  @param failedBlock     Failed Block
 *  @param completionBlock Collection of Roster DataModel
 */
+ (void)fetchAndProcessRosterDetailsWithRosterID:(nonnull NSString *)rosterID
                                 extraDependency:(nullable NSDictionary<NSString *, id> *)extraDependency
                                       ascending:(BOOL)ascending
                                      sortByKeys:(nullable NSArray<NSString *> *)sortByKeys
                                     failedBlock:(_Nonnull ABIFailedBlock)failedBlock
                                 completionBlock:(_Nonnull ABIMutableArrayResponseBlock)completionBlock {
    NSString *soqlQuery = [ABISOQLQueryBuilder soqlQueryForRosterProfileDetailsWithRosterID:rosterID
                                                                            extraDependency:extraDependency
                                                                                  ascending:(BOOL)ascending
                                                                                 sortByKeys:sortByKeys];
    [ABISFDataFetcherService requestForSOQLQueryAndBindModelUpdated:soqlQuery
                                                serviceOperationKey:ABIFetchOperationForRosterDetails
                                                    extraDependency:extraDependency
                                                          ascending:YES
                                                         sortByKeys:sortByKeys
                                                        failedBlock:failedBlock
                                                    completionBlock:completionBlock];
}

#pragma mark Roster Earned Badges Details
/**
 *  Fetch all Earned Badge information for Roster and for specific Year, then
 * precessing response record and Bind with Model
 *
 *  @param Roster         Roster
 *  @param years           Required Year
 *  @param extraDependency Pass extra information as required
 *  @param ascending       Sort Order (if 'YES' ascending)
 *  @param sortByKeys      Results sort By key
 *  @param failedBlock     Failed Block
 *  @param completionBlock Collection of Ea DataModel
 */
+ (void)fetchRosterBadgeDetailsWithRoster:(nonnull ABISFRosterDataModel *)roster
                                 forYears:(nullable NSArray<NSString *> *)years
                          extraDependency:(nullable NSDictionary<NSString *, id> *)extraDependency
                                ascending:(BOOL)ascending
                               sortByKeys:(nullable NSArray<NSString *> *)sortByKeys
                              failedBlock:(_Nonnull ABIFailedBlock)failedBlock
                          completionBlock:(_Nonnull ABIMutableArrayResponseBlock)completionBlock {
    NSString *soqlQuery = [ABISOQLQueryBuilder soqlQueryForRosterBadgeDetailsForRoster:roster
                                                                              forYears:years
                                                                       extraDependency:extraDependency
                                                                             ascending:ascending
                                                                            sortByKeys:sortByKeys];

    NSMutableDictionary *dict = [NSMutableDictionary dictionary];
    if (roster.idName)
        [dict setObject:roster.idName forKey:kRosterID];

    [ABISFDataFetcherService requestForSOQLQueryAndBindModelUpdated:soqlQuery
                                                serviceOperationKey:ABIFetchOperationForBadgeDetails
                                                    extraDependency:dict
                                                          ascending:ascending
                                                         sortByKeys:sortByKeys
                                                        failedBlock:failedBlock
                                                    completionBlock:completionBlock];
}

#pragma mark Roster Incentive Details
/**
 *  Fetch Incentive Details in Profile page, then precessing response record and
 Bind with Model
 *
 *  @param ID        ID can be Manager ID or Roster ID as Login and PageFlow
 *  @param role      Role can be Manager Role or Repotee role as Login and
 PageFlow
 *  @param extraDependency Pass extra information as required
 *  @param failedBlock     Failed Block
 @param ascending       Sort Order (if 'YES' ascending)
 *  @param sortByKeys      Results sort By key
 *  @param completionBlock Incentive Collection
 */
+ (void)fetchAndProcessRosterIncentiveDetailsWithRoster:(nonnull ABISFRosterDataModel *)roster
                                        extraDependency:(nullable NSDictionary<NSString *, id> *)extraDependency
                                              ascending:(BOOL)ascending
                                             sortByKeys:(nullable NSArray<NSString *> *)sortByKeys
                                            failedBlock:(nonnull ABIFailedBlock)failedBlock
                                        completionBlock:(nonnull ABIMutableArrayResponseBlock)completionBlock {

    NSString *role = roster.roleInString;

    void (^CommonServiceCall)(NSArray *reporteeIncentives) = ^(NSArray *reporteeIncentives) {

        [ABISFDataFetcherService fetchIncentiveDetailsAndPrecessKPIsDetailsWithRoster:roster
                                                                   reporteeIncentives:reporteeIncentives
                                                                      extraDependency:extraDependency
                                                                          failedBlock:failedBlock
                                                                      completionBlock:completionBlock];
    };

    if ([role isEqualToString:ABI_SF_USER_ROLE_SD]) {

        [ABISFDataFetcherService fetchAndProcessReporteesIncentiveDetailsWithManager:roster
                                                                        reporteeRole:role
                                                                     extraDependency:extraDependency
                                                                           ascending:ascending
                                                                          sortByKeys:sortByKeys
                                                                         failedBlock:^(NSError *error, NSDictionary *extraInfo) { CommonServiceCall(nil); }
                                                                     completionBlock:^(NSArray *results, NSDictionary *extraInfo) {

                                                                         CommonServiceCall(results);

                                                                     }];

    } else {
        CommonServiceCall(nil);
    }
}

/**
 *  Fetch All Incentive Details For Roster, then precessing response record and
 Bind with Model
 - First Fetch All incentive then
 - Fetch KPI details for each Incentive
 - Update the each Incentive data model
 *
 *  Perform in: viewDidLoad in Profile Page
 *  @param ID                 Roster ID
 *  @param role               Role of Roster (not in Use)
 *  @param reporteeIncentives Reportee Incentives (not in Use Who has no
 repotee)
 *  @param extraDependency    Pass extra information as required
 *  @param failedBlock        Failed Block
 *  @param completionBlock    Collection ABISFIncentiveDataModel
 */

+ (void)fetchIncentiveDetailsAndPrecessKPIsDetailsWithRoster:(ABISFRosterDataModel *)roster
                                          reporteeIncentives:(nullable NSArray *)reporteeIncentives
                                             extraDependency:(nullable NSDictionary *)extraDependency
                                                 failedBlock:(nonnull ABIFailedBlock)failedBlock
                                             completionBlock:(nonnull void (^)(NSMutableArray<ABISFIncentiveDataModel *> *_Nullable kpiDetails,
                                                                               NSDictionary *_Nullable extraInfo))completionBlock {

    recurringIndex = 0;

    if ([NSObject isNullObject:roster]) {
        if (failedBlock)
            failedBlock(nil, nil);
        return;
    }
    [ABISFDataFetcherService fetchAndProcessIncentiveDetailsWithRoster:roster
                                                       extraDependency:extraDependency
                                                             ascending:NO
                                                            sortByKeys:nil
                                                           failedBlock:^(NSError *error, NSDictionary *extraInfo) {
                                                                   // Return When Failed
                                                               if (failedBlock)
                                                                   failedBlock(error, nil);
                                                           }
                                                       completionBlock:^(NSMutableArray<ABISFIncentiveDataModel *> *results, NSDictionary *extraInfo) {
                                                               // Sort By Incentive Name
                                                           id obj = [results firstObject];
                                                           if ([NSArray isValidArray:results] && [obj isKindOfClass:[ABISFIncentiveDataModel class]]) {
                                                                   //                                                               [results sortFo rKey:@"incentiveDisplayName" ascending:YES];
                                                           }

                                                               // Error in response then return
                                                           if (![NSArray isValidArray:results]) {
                                                               if (failedBlock)
                                                                   failedBlock(nil, nil);
                                                               return;
                                                           }
                                                               // Fetch all KPI details for a incentive
                                                           [ABISFDataFetcherService updateKPIDetailsWithDatasForIncentives:results
                                                                                                        reporteeIncentives:reporteeIncentives
                                                                                                           extraDependency:extraDependency
                                                                                                                completion:^{
                                                                                                                    if (completionBlock)
                                                                                                                        completionBlock(results, nil);
                                                                                                                }];
                                                       }];
}

/**
 *  FetchAndProcess Roster incentive details, precessing response record and
 Bind with model(ABISFIncentiveDataModel)
 NOTE: Used in Profile Page

 *
 *  @param rosterID        Roster ID
 *  @param rosterRole      Roster Role (not in use now)
 *  @param extraDependency Pass extra information as required
 *  @param ascending       Sort Order (if 'YES' ascending)
 *  @param sortByKeys      Results sort By key
 *  @param failedBlock     Failed Block
 *  @param completionBlock Collection Incentive Datamodel
 */
+ (void)fetchAndProcessIncentiveDetailsWithRoster:(nonnull ABISFRosterDataModel *)roster
                                  extraDependency:(nullable NSDictionary<NSString *, id> *)extraDependency
                                        ascending:(BOOL)ascending
                                       sortByKeys:(nullable NSArray<NSString *> *)sortByKeys
                                      failedBlock:(_Nonnull ABIFailedBlock)failedBlock
                                  completionBlock:(_Nonnull ABIMutableArrayResponseBlock)completionBlock {
    NSString *soqlQuery = [ABISOQLQueryBuilder soqlQueryForRosterIncentiveDetailsWithRoster:roster
                                                                            extraDependency:extraDependency
                                                                                  ascending:ascending
                                                                                 sortByKeys:sortByKeys];
    [ABISFDataFetcherService requestForSOQLQueryAndBindModelUpdated:soqlQuery
                                                serviceOperationKey:ABIFetchOperationForIncentiveDetails
                                                    extraDependency:extraDependency
                                                          ascending:ascending
                                                         sortByKeys:sortByKeys
                                                        failedBlock:failedBlock
                                                    completionBlock:completionBlock];
}

#pragma mark -  Reportees Incentive Details
/**
 *   Fetch all Reportee incentive details for  'Manager'. The informaion which
 fetched by this SOQL is shwon in profile page "Least DM Score / Max DM
 Score in 'My Incentive' tab as Manager login" (e.g.DM(as Reportee) of SD(as
 Manager)).

 *   NOTE: ONLY MANAGER LOGIN THIS APPLICABLE
 *  fetchAndProcess Reportee incentive details, precessing response record and
 Bind with model(ABISFIncentiveDataModel)
 *
 *  @param managerID       Manager ID
 *  @param reporteeRole    Reportee Role
 *  @param extraDependency Pass extra information as required
 *  @param ascending       Sort Order (if 'YES' ascending)
 *  @param sortByKeys      Results sort By key
 *  @param failedBlock     Failed Block
 *  @param completionBlock Collection of ABISFIncentiveDataModel
 */
+ (void)fetchAndProcessReporteesIncentiveDetailsWithManager:(nonnull ABISFRosterDataModel *)manager
                                               reporteeRole:(nullable NSString *)reporteeRole
                                            extraDependency:(nullable NSDictionary<NSString *, id> *)extraDependency
                                                  ascending:(BOOL)ascending
                                                 sortByKeys:(nullable NSArray<NSString *> *)sortByKeys
                                                failedBlock:(_Nonnull ABIFailedBlock)failedBlock
                                            completionBlock:(_Nonnull ABIMutableArrayResponseBlock)completionBlock {
    NSString *soqlQuery = [ABISOQLQueryBuilder soqlQueryForReporteesIncentiveDetailsForManager:manager
                                                                                  reporteeRole:ABI_SF_USER_ROLE_DM // FIXME:Check
                           // Why Hard
                           // Code
                                                                               extraDependency:extraDependency
                                                                                     ascending:ascending
                                                                                    sortByKeys:sortByKeys];
    [ABISFDataFetcherService requestForSOQLQueryAndBindModelUpdated:soqlQuery
                                                serviceOperationKey:ABIFetchOperationForReporteesIncentiveDetails
                                                    extraDependency:@{
                                                                      ABI_SF_USER_ROLE_DM : kRosterRole
                                                                      }
                                                          ascending:ascending
                                                         sortByKeys:sortByKeys
                                                        failedBlock:failedBlock
                                                    completionBlock:completionBlock];
}

#pragma mark - All Reportee Details (For Manager Login)
/**
 *  Fetch All Reportee Details For A Manager
 *
 *  @param managerID       Manager ID
 *  @param reporteeRole    Reportee Role
 *  @param extraDependency Pass extra information as required
 *  @param ascending       Sort Order (if 'YES' ascending)
 *  @param sortByKeys      Results sort By key
 *  @param failedBlock     Failed Block
 *  @param completionBlock Collection Of RosterData Model
 */
+ (void)fetchAndProcessAllReporteeDetailsWithRoster:(nonnull ABISFRosterDataModel *)roster
                                       reporteeRole:(nullable NSString *)reporteeRole
                                    extraDependency:(nullable NSDictionary<NSString *, id> *)extraDependency
                                          ascending:(BOOL)ascending
                                         sortByKeys:(nullable NSArray<NSString *> *)sortByKeys
                                        failedBlock:(_Nonnull ABIFailedBlock)failedBlock
                                    completionBlock:(_Nonnull ABIMutableArrayResponseBlock)completionBlock {

    NSString *soqlQuery = [ABISOQLQueryBuilder soqlQueryForAllReporteeDetailsForManagerWithRoster:roster
                                                                                     reporteeRole:reporteeRole
                                                                                  extraDependency:extraDependency
                                                                                        ascending:ascending
                                                                                       sortByKeys:sortByKeys];

    [ABISFDataFetcherService requestForSOQLQueryAndBindModelUpdated:soqlQuery
                                                serviceOperationKey:ABIFetchOperationForAllReporteeDetails
                                                    extraDependency:extraDependency
                                                          ascending:ascending
                                                         sortByKeys:sortByKeys
                                                        failedBlock:failedBlock
                                                    completionBlock:completionBlock];
}

#pragma mark - KIPs Detsils Form Profile Page
#pragma mark -
#pragma mark KIPs Detsils For An Incentive
/**
 *  KIPs detsils for an incentive details, precessing response record and Bind
 * with Model (ABISFKPIsDetailsDataModel)
 *
 *  @param incentiveID     Incentive ID
 *  @param rosterID        Roster ID
 *  @param extraDependency Pass extra information as required
 *  @param ascending       Sort Order (if 'YES' ascending)
 *  @param sortByKeys      Results sort By key
 *  @param failedBlock     Failed Block
 *  @param completionBlock Collection of ABISFKPIsDetailsDataModel
 */
+ (void)fetchAndProcessKIPsDetailsForAnIncentiveWithIncentive:(nonnull ABISFIncentiveDataModel *)incentive
                                                       roster:(nonnull ABISFRosterDataModel *)roster
                                              extraDependency:(nullable NSDictionary<NSString *, id> *)extraDependency
                                                    ascending:(BOOL)ascending
                                                   sortByKeys:(nullable NSArray<NSString *> *)sortByKeys
                                                  failedBlock:(_Nonnull ABIFailedBlock)failedBlock
                                              completionBlock:(nonnull void (^)(NSMutableArray<ABISFKPIsDetailsDataModel *> *kpiDetails,
                                                                                NSDictionary *extraInfo))completionBlock {
    NSString *soqlQuery = [ABISOQLQueryBuilder soqlQueryForIncentiveKIPsDetailsForIncentive:incentive
                                                                                     roster:roster
                                                                            extraDependency:extraDependency
                                                                                  ascending:ascending
                                                                                 sortByKeys:sortByKeys];
    NSMutableDictionary *_extraDependency = [NSMutableDictionary dictionary];
    if (incentive.incentiveName)
        [_extraDependency setValue:incentive.incentiveName forKey:kIncentiveID];
    [ABISFDataFetcherService requestForSOQLQueryAndBindModelUpdated:soqlQuery
                                                serviceOperationKey:ABIFetchOperationForKPIDetailsForIncentive
                                                    extraDependency:_extraDependency
                                                          ascending:ascending
                                                         sortByKeys:sortByKeys
                                                        failedBlock:failedBlock
                                                    completionBlock:completionBlock];
}

#pragma mark All Reportee Performance Details (KPI Details DropDown)
/**
 *  Fetch All Reportee KPIs Details For  An Incentive of a Manager
 *
 *  @param managerID       Manager ID
 *  @param incentiveName   Incentive Name
 *  @param extraDependency Pass extra information as required
 *  @param ascending       Sort Order (if 'YES' ascending)
 *  @param sortByKeys      Results sort By key
 *  @param failedBlock     Failed Block
 *  @param completionBlock Collection of ABISFKPIsDetailsDataModel
 */
+ (void)fetchAndProcessAllReporteeKPIsWiseIncentivePerformanceDetailsWithManager:(nonnull ABISFRosterDataModel *)manager
                                                                       incentive:(nonnull ABISFIncentiveDataModel *)incentive
                                                                 extraDependency:(nullable NSDictionary<NSString *, id> *)extraDependency
                                                                       ascending:(BOOL)ascending
                                                                      sortByKeys:(nullable NSArray<NSString *> *)sortByKeys
                                                                     failedBlock:(_Nonnull ABIFailedBlock)failedBlock
                                                                 completionBlock:
(nonnull void (^)(NSMutableArray<ABISFKPIsDetailsDataModel *> *kpiDetails,
                  NSDictionary *extraInfo))completionBlock {

    NSString *soqlQuery = [ABISOQLQueryBuilder soqlQueryForAllReporteeKPIsWiseInccntivePerformanceDetailsForManager:manager
                                                                                                          incentive:incentive
                                                                                                    extraDependency:extraDependency
                                                                                                          ascending:ascending
                                                                                                         sortByKeys:sortByKeys];

    [ABISFDataFetcherService requestForSOQLQueryAndBindModelUpdated:soqlQuery
                                                serviceOperationKey:ABIFetchOperationForAllReporteeKPIsWiseIncentivePerformanceDetails
                                                    extraDependency:extraDependency
                                                          ascending:ascending
                                                         sortByKeys:sortByKeys
                                                        failedBlock:failedBlock
                                                    completionBlock:completionBlock];
}
#pragma mark - Peer Ranking Page
#pragma mark -  Fetch All Peer Details Details

+ (void)fetchAndProcessAllPeerDetailsWithRoster:(nonnull ABISFRosterDataModel *)roster
                                      incentive:(nonnull ABISFIncentiveDataModel *)incentive
                                    failedBlock:(_Nonnull ABIFailedBlock)failedBlock
                                completionBlock:(_Nonnull ABIMutableArrayResponseBlock)completionBlock {

    [ABISFDataFetcherService fetchAndProcessAllPeerDetailsWithRoster:roster
                                                           incentive:incentive
                                                     extraDependency:nil
                                                           ascending:NO
                                                          sortByKeys:nil
                                                         failedBlock:failedBlock
                                                     completionBlock:completionBlock];
}

/**
 *   Fetch AllPeer Ranking Incentive point wise Details of same Role selected
 * Roster
 *  FetProfile Page: Tap on Peer Ranking
 *  @param role            Role
 *  @param peerUserID      Peer UserID ID
 *  @param rosterDataModel ABISFRosterDataModel (not in use)
 *  @param incentiveName   IncentiveName
 *  @param extraDependency Pass extra information as required
 *  @param ascending       Sort Order (if 'YES' ascending)
 *  @param sortByKeys      Results sort By key
 *  @param failedBlock     Failed Block
 *  @param completionBlock Collection of ABISFPeerRankingDataModel
 */
+ (void)fetchAndProcessAllPeerDetailsWithRoster:(nonnull ABISFRosterDataModel *)roster
                                      incentive:(nonnull ABISFIncentiveDataModel *)incentive
                                extraDependency:(nullable NSDictionary<NSString *, id> *)extraDependency
                                      ascending:(BOOL)ascending
                                     sortByKeys:(nullable NSArray<NSString *> *)sortByKeys
                                    failedBlock:(_Nonnull ABIFailedBlock)failedBlock
                                completionBlock:(_Nonnull ABIMutableArrayResponseBlock)completionBlock {
    NSString *soqlQuery = [ABISOQLQueryBuilder soqlQueryForAllPeerDetailsForRoster:roster
                                                                         incentive:incentive
                                                                   extraDependency:extraDependency
                                                                         ascending:ascending
                                                                        sortByKeys:sortByKeys];
    NSMutableDictionary *_extraDependency = [NSMutableDictionary dictionary];
    if (extraDependency.count) {

        _extraDependency = [[NSMutableDictionary alloc] initWithDictionary:extraDependency];
    } else {

        _extraDependency = [NSMutableDictionary dictionary];
    }
    [_extraDependency setValue:roster forKey:kABISFRosterDataModel];

    [ABISFDataFetcherService requestForSOQLQueryAndBindModelUpdated:soqlQuery
                                                serviceOperationKey:ABIFetchOperationForPeerRankingIncentivePointWise
                                                    extraDependency:_extraDependency
                                                          ascending:NO
                                                         sortByKeys:nil
                                                        failedBlock:failedBlock
                                                    completionBlock:^(NSMutableArray *results, NSDictionary *extraInfo) {
                                                            // Sort By point
                                                            //                                                             [results sortFor
                                                            //                                                             Key:@"rosterNameText"
                                                            //                                                             ascending:YES];
                                                            //                                                              [results sortFor
                                                            //                                                              Key:incentivePointsInNumber1
                                                            //                                                              ascending:NO];

                                                        if (completionBlock)
                                                            completionBlock(results, extraInfo);

                                                    }];
}

#pragma mark -   Announcements Details
/**
 *  Fetch And Process Announcements detsils, precessing response record and Bind
 * with Model
 *
 *  @param extraDependency Pass extra information as required
 *  @param ascending       Sort Order (if 'YES' ascending)
 *  @param sortByKeys      Results sort By key
 *  @param failedBlock     Failed Block
 *  @param completionBlock Collection ABISFAnnouncementDataModel
 */
+ (void)fetchAndProcessAnnouncementsDetailsWithExtraDependency:(nullable NSDictionary<NSString *, id> *)extraDependency
                                                     ascending:(BOOL)ascending
                                                    sortByKeys:(nullable NSArray<NSString *> *)sortByKeys
                                                   failedBlock:(_Nonnull ABIFailedBlock)failedBlock
                                               completionBlock:(_Nonnull ABIMutableArrayResponseBlock)completionBlock {
    NSString *soqlQuery =
    [ABISOQLQueryBuilder soqlQueryForAnnouncementsDetailsWithExtraDependency:extraDependency ascending:ascending sortByKeys:sortByKeys];
    [ABISFDataFetcherService requestForSOQLQueryAndBindModelUpdated:soqlQuery
                                                serviceOperationKey:ABIFetchOperationForAnnouncementDetails
                                                    extraDependency:extraDependency
                                                          ascending:ascending
                                                         sortByKeys:sortByKeys
                                                        failedBlock:failedBlock
                                                    completionBlock:completionBlock];
}

#pragma mark -  Request Methods
+ (void)requestForSOQLQueryAndBindModelUpdated:(nonnull NSString *)soqlQuery
                           serviceOperationKey:(ABIFetchOperationKey)serviceOperationKey
                               extraDependency:(nullable NSDictionary<NSString *, id> *)extraDependency
                                     ascending:(BOOL)ascending
                                    sortByKeys:(nullable NSArray *)sortByKeys
                                   failedBlock:(_Nonnull ABIFailedBlock)failedBlock
                               completionBlock:(_Nonnull ABIMutableArrayResponseBlock)completionBlock {
    /*!
     *  Request With SOQL Query
     *
     *  @param result    Response Result
     *  @param extraDependency Pass extra information (if needed)
     *
     */
    if ([AppDelegate isOffline]) {
        if (failedBlock)
            failedBlock([NSError errorNoNetworkConnection], nil);
    } else if ([NSString isNULLString:soqlQuery]) {
        if (failedBlock)
            failedBlock(nil, nil);
    } else {

        [ABISFRestRequestManager requestForSOQLQueryUpdated:soqlQuery
                                            extraDependency:extraDependency
                                                failedBlock:failedBlock
                                            completionBlock:^(id result, NSDictionary *extraInfo) {

                                                /**
                                                 *  Response data handed over to the binder, that bind
                                                 * Response in model
                                                 */
                                                [ABISFDataModelBinder bindResponse:result
                                                               serviceOperationKey:serviceOperationKey
                                                                   extraDependency:extraDependency
                                                                         ascending:ascending
                                                                        sortByKeys:sortByKeys
                                                                       failedBlock:failedBlock
                                                                   completionBlock:completionBlock];
                                            }];
    }
}

#pragma mark - Private Method

+ (void)updateKPIDetailsWithDatasForIncentives:(nonnull NSArray<ABISFIncentiveDataModel *> *)incentives
                            reporteeIncentives:(nonnull NSArray<ABISFIncentiveDataModel *> *)reporteeIncentives
                               extraDependency:(nonnull NSDictionary *)extraDependency
                                    completion:(void (^)(void))completion {

    if (extraDependency.count) {

        BOOL skipFetchingKPIDetails = [extraDependency extraDependencySkipFetchingKPIDetails];
        if (skipFetchingKPIDetails && completion) {
            completion();
            return;
        }
    }

        // When iteration is completed
    if (incentives && recurringIndex >= incentives.count) {
        if (completion)
            completion();
        return;
    }

        // Take ABISFIncentiveDataModel model from Array
    __block ABISFIncentiveDataModel *incentive = [NSArray objectFromArray:incentives atIndex:recurringIndex];
    if (!incentive) {
            // Fetch KPIs Details For Next Incentive
        recurringIndex += 1;
        [self updateKPIDetailsWithDatasForIncentives:incentives
                                  reporteeIncentives:reporteeIncentives
                                     extraDependency:extraDependency
                                          completion:completion];
    } else {
        /*!
         *  Fetch KPI Details
         */
        __weak typeof(self) weakSelf = self;
            // Update Number of DMs Coiunt WRT Incentive Name and Incentive Week
        [incentive calculateNumberOfReportee:reporteeIncentives];
        [ABISFDataFetcherService fetchAndProcessKIPsDetailsForAnIncentiveWithIncentive:incentive
                                                                                roster:incentive.rosterDataModel
                                                                       extraDependency:extraDependency
                                                                             ascending:YES
                                                                            sortByKeys:nil
                                                                           failedBlock:^(NSError *error, NSDictionary *extraInfo) {
                                                                               if (completion)
                                                                                   completion();
                                                                           }
                                                                       completionBlock:^(NSMutableArray<NSDictionary *> *resultKPIDetails, NSDictionary *extraInfo) {

                                                                               // Update KPIs Results
                                                                           incentive.kpisDetails = resultKPIDetails;
                                                                           NSMutableArray *incentiveKPIDetails = incentive.channelWiseKPIsCollection;
                                                                           NSString *progressStatusColor = incentive.progressStatusColorName;

                                                                           NSInteger totalKpis = 0;
                                                                           NSInteger countOfProgressColor = 0;

                                                                           if ([incentiveKPIDetails count]) {

                                                                               for (id channelKPIs in incentiveKPIDetails) {
                                                                                   if (channelKPIs && [NSArray isValidArray:channelKPIs]) {
                                                                                       NSArray *kpisDetsil = (NSArray *)channelKPIs;
                                                                                       NSPredicate *predicate =
                                                                                       [NSPredicate predicateWithFormat:@"self.progressStatusColor =  %@ || "
                                                                                        @"self.progressStatusColor =  %@",
                                                                                        [progressStatusColor uppercaseString], [progressStatusColor lowercaseString]];
                                                                                       NSArray *statusColorDetails = [kpisDetsil filteredArrayUsingPredicate:predicate];
                                                                                       countOfProgressColor += statusColorDetails.count ? statusColorDetails.count : 0;
                                                                                       totalKpis += kpisDetsil.count;
                                                                                   }
                                                                               }
                                                                           }
                                                                               // Update Progress totalKPIsNumber
                                                                           incentive.totalKPIsNumber = @(totalKpis);
                                                                               // Update Progress countOfProgressColor
                                                                           incentive.countOfProgressColor = @(countOfProgressColor);
                                                                               // Update Progress attributedString
                                                                           incentive.attributedString = [NSString descriptionTextName:progressStatusColor totalKPIs:totalKpis subKpis:countOfProgressColor];

                                                                               // Fetch KPIs Details For Next Incentive
                                                                           recurringIndex += 1;
                                                                           [weakSelf updateKPIDetailsWithDatasForIncentives:incentives
                                                                                                         reporteeIncentives:reporteeIncentives
                                                                                                            extraDependency:extraDependency
                                                                                                                 completion:completion];
                                                                       }];
    }
}
+ (NSString *)dictToJson:(NSDictionary *)dict {
    NSData *jsonData = [NSJSONSerialization dataWithJSONObject:dict options:NSJSONWritingPrettyPrinted error:nil];
    return [[NSString alloc] initWithBytes:[jsonData bytes] length:[jsonData length] encoding:NSUTF8StringEncoding];
}

@end
